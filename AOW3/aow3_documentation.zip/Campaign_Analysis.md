# Campaign Analysis - Art of War 3: RTS Strategy Game

## Overview

Art of War 3 features a campaign system driven by the GAI (Game AI) scripting engine, which provides a powerful command-based scenario definition language. The campaign is organized into chapters with individual missions, each defined as a sequence of GAI commands that control enemy behavior, tutorial prompts, camera movement, and victory conditions. The GAI system also powers the tutorial, skirmish modes, and bot AI behaviors. With 753 GAI command identifiers (144 unique command types plus their component, serializer, and deserializer variants), the scripting engine is the most complex subsystem in the game.

## Campaign Structure

### Chapter and Mission Organization

Campaign data is organized by chapter and mission numbers, as evidenced by the map naming convention:

**Campaign Maps**:
- Chapter 1: Maps 1_2, 1_3, 1_4, 1_5, 1_6 (5 missions)
- Chapter 3: Map 3_2 (at least 2 missions)
- Chapter 4: Map 4_1 (at least 1 mission)

**PvP Maps**:
- pvp_11 (dedicated PvP battlefield)

**Campaign Metadata**:
- `CAMPAIGN` - Campaign identifier constant
- `CAMPAIGN_ID_KEY` - Campaign ID storage key
- `CAMPAIGN_NAME_KEY` - Campaign name storage key
- `CAMPAIGN_TILE_VISIBILITY_OFFSET` - Campaign tile visibility setting
- `CampaignModel` - Campaign data model
- `CampaignInfo` - Campaign information
- `CampaignInstaller` - Campaign Zenject installer
- `CampaignMissionsForPvP` - PvP-eligible campaign missions
- `CampaignTilePresenter` - Campaign map tile UI

### Mission Types

The game supports multiple mission types identified through the battle system:

- **Campaign Missions**: Story-driven missions with GAI scripts
- **Skirmish Missions**: Custom battles defined through `com.geargames.aow.entities.skirmish`
- **PvE Missions**: Player vs Environment with `AICommWinPVE` victory condition
- **PvP Missions**: Player vs Player with `AICommWinPVP` / `AICommWinPVPSingleSide` victory conditions
- **Tutorial Missions**: Guided tutorials with extensive GAI scripting
- **Tournament Missions**: Competitive format missions

## GAI Scripting System

### Command Architecture

The GAI system uses a three-tier architecture for each command:

1. **GAICommand** - The command definition class
2. **GAICommand*Component** - The runtime component that executes the command
3. **GAICommand*STSerializer/STDeserializer** - Network serialization for multiplayer sync

Many commands also have:
4. **GAICommand*DependencyCollector** - Prerequisite condition tracking

### Core GAI Commands (144 Types)

#### Flow Control Commands
These commands control the execution flow of GAI scripts:

| Command | Constant | Description |
|---------|----------|-------------|
| `GAICommandChanceJump` | `GAI_COMMAND_CHANCE_JUMP` | Probabilistic branch to another node |
| `GAICommandCounterJump` | `GAI_COMMAND_COUNTER_JUMP` | Jump based on counter value |
| `GAICommandFlagJump` | `GAI_COMMAND_FLAG_JUMP` | Jump when flag is set |
| `GAICommandFlagJumpCancel` | `GAI_COMMAND_FLAG_JUMP_CANCEL` | Jump when flag is cleared |
| `GAICommandSequentJump` | `GAI_COMMAND_SEQUENT_JUMP` | Sequential execution jump |
| `GAICommandTriggerJump` | `GAI_COMMAND_TRIGGER_JUMP` | Conditional trigger jump |
| `GAICommandRandomJump` | `GAI_COMMAND_RANDOM_JUMP` | Random branch selection |
| `GAICommandLoopStart` | `GAI_COMMAND_LOOP_START` | Begin loop block |
| `GAICommandLoopEnd` | `GAI_COMMAND_LOOP_END` | End loop block |

#### Counter and Flag Commands
| Command | Constant | Description |
|---------|----------|-------------|
| `GAICommandCounter` | `GAI_COMMAND_COUNTER` | Define/reset counter |
| `GAICommandCounterInc` | `GAI_COMMAND_COUNTER_INC` | Increment counter |
| `GAICommandCounterCompare` | `GAI_COMMAND_COUNTER_COMPARE` | Compare counter values |
| `GAICommandFlag` | `GAI_COMMAND_FLAG` | Set a named flag |
| `GAICommandFlagRemove` | `GAI_COMMAND_FLAG_REMOVE` | Remove a flag |
| `GAICommandParamToCounter` | `GAI_COMMAND_PARAM_TO_COUNTER` | Convert parameter to counter |
| `GAICommandPickAmountToCounter` | `GAI_COMMAND_PICK_AMOUNT_TO_COUNTER` | Set counter from pickup amount |

#### Building Commands
| Command | Constant | Description |
|---------|----------|-------------|
| `GAICommandBuilding` | `GAI_COMMAND_BUILDING` | Create/reference building |
| `GAICommandBuildingSetPlace` | `GAI_COMMAND_BUILDING_SET_PLACE` | Place building at position |
| `GAICommandBuildingSetRestrict` | `GAI_COMMAND_BUILDING_SET_RESTRICT` | Restrict building placement |
| `GAICommandBuildingHideFromList` | `GAI_COMMAND_BUILDING_HIDE_FROM_LIST` | Hide building from UI list |
| `GAICommandBuildingNeutral` | `GAI_COMMAND_BUILDING_NEUTRAL` | Create neutral building |
| `GAICommandUnbuildZone` | `GAI_COMMAND_UNBUILD_ZONE` | Define no-build zone |
| `GAICommandUnbuildZoneRemove` | `GAI_COMMAND_UNBUILD_ZONE_REMOVE` | Remove no-build zone |
| `GAICommandConstruction` | `GAI_COMMAND_CONSTRUCTION` | Start building construction |
| `GAICommandConstructionAssistant` | `GAI_COMMAND_CONSTRUCTION_ASSISTANT` | Construction help/assist |
| `GAICommandConstructionSchedule` | `GAI_COMMAND_CONSTRUCTION_SCHEDULE` | Schedule future construction |

#### Unit and Army Commands
| Command | Constant | Description |
|---------|----------|-------------|
| `GAICommandArmySet` | `GAI_COMMAND_ARMY_SET` | Define army composition |
| `GAICommandArmyConditional` | `GAI_COMMAND_ARMY_CONDITIONAL` | Conditional army definition |
| `GAICommandAttackSet` | `GAI_COMMAND_ATTACK_SET` | Define attack formation |
| `GAICommandMatrixArmySet` | `GAI_COMMAND_MATRIX_ARMY_SET` | Set army matrix |
| `GAICommandTroopMove` | `GAI_COMMAND_TROOP_MOVE` | Move troop group |
| `GAICommandTroopCute` | `GAI_COMMAND_TROOP_CUTE` | Remove/cull troops |
| `GAICommandTroopDrop` | `GAI_COMMAND_TROOP_DROP` | Drop/deploy troops |
| `GAICommandTroopEvacuate` | `GAI_COMMAND_TROOP_EVACUATE` | Evacuate/withdraw troops |
| `GAICommandMatrixTroopCute` | `GAI_COMMAND_MATRIX_TROOP_CUTE` | Matrix-based troop removal |
| `GAICommandMatrixTroopDrop` | `GAI_COMMAND_MATRIX_TROOP_DROP` | Matrix-based troop deployment |
| `GAICommandSquadZone` | `GAI_COMMAND_SQUAD_ZONE` | Define squad zone |
| `GAICommandPassUnits` | `GAI_COMMAND_PASS_UNITS` | Pass unit references |
| `GAICommandPassBuildings` | `GAI_COMMAND_PASS_BUILDINGS` | Pass building references |
| `GAICommandPassCoord` | `GAI_COMMAND_PASS_COORD` | Pass coordinate data |
| `GAICommandPickUnits` | `GAI_COMMAND_PICK_UNITS` | Pick/select units |
| `GAICommandPickBuildings` | `GAI_COMMAND_PICK_BUILDINGS` | Pick/select buildings |
| `GAICommandPickLoad` | `GAI_COMMAND_PICK_LOAD` | Pick/load data |

#### Camera Commands
| Command | Constant | Description |
|---------|----------|-------------|
| `GAICommandCameraSet` | `GAI_COMMAND_CAMERA_SET` | Set camera position/target |
| `GAICommandCameraSave` | `GAI_COMMAND_CAMERA_SAVE` | Save current camera state |
| `GAICommandCameraRestore` | `GAI_COMMAND_CAMERA_RESTORE` | Restore saved camera state |
| `GAICommandCameraMask` | `GAI_COMMAND_CAMERA_MASK` | Apply camera mask/limits |
| `GAICommandCameraTranslateDisable` | `GAI_COMMAND_CAMERA_TRANSLATE_DISABLE` | Disable camera movement |

#### Combat and Damage Commands
| Command | Constant | Description |
|---------|----------|-------------|
| `GAICommandDamageBonus` | `GAI_COMMAND_DAMAGE_BONUS` | Apply damage bonus |
| `GAICommandDamageReduce` | `GAI_COMMAND_DAMAGE_REDUCE` | Apply damage reduction |
| `GAICommandExplosion` | `GAI_COMMAND_EXPLOSION` | Create explosion effect |
| `GAICommandMineField` | `GAI_COMMAND_MINE_FIELD` | Create mine field |
| `GAICommandNuclearStrike` | `GAI_COMMAND_NUCLEAR_STRIKE` | Nuclear strike event |

#### Resource Commands
| Command | Constant | Description |
|---------|----------|-------------|
| `GAICommandGold` | `GAI_COMMAND_GOLD` | Grant/remove gold |
| `GAICommandHealth` | `GAI_COMMAND_HEALTH` | Set/modify health |
| `GAICommandEventCurrency` | `GAI_COMMAND_EVENT_CURRENCY` | Event-specific currency |
| `GAICommandBoostAdd` | `GAI_COMMAND_BOOST_ADD` | Add boost effect |

#### UI and Visual Commands
| Command | Constant | Description |
|---------|----------|-------------|
| `GAICommandDialog` | `GAI_COMMAND_DIALOG` | Show dialog/cutscene |
| `GAICommandDarkenBuUn` | `GAI_COMMAND_DARKEN_BU_UN` | Darken buildings/units |
| `GAICommandDarkenMapArea` | `GAI_COMMAND_DARKEN_MAP_AREA` | Darken map area |
| `GAICommandDarkenWidget` | `GAI_COMMAND_DARKEN_WIDGET` | Darken UI widget |
| `GAICommandMarkBuUn` | `GAI_COMMAND_MARK_BU_UN` | Mark/highlight buildings/units |
| `GAICommandMarkBuUnRemove` | `GAI_COMMAND_MARK_BU_UN_REMOVE` | Remove building/unit mark |
| `GAICommandMarkGround` | `GAI_COMMAND_MARK_GROUND` | Mark ground area |
| `GAICommandMarkGroundRemove` | `GAI_COMMAND_MARK_GROUND_REMOVE` | Remove ground mark |
| `GAICommandMarkWidget` | `GAI_COMMAND_MARK_WIDGET` | Mark UI widget |
| `GAICommandChangeAppearance` | `GAI_COMMAND_CHANGE_APPEARANCE` | Change visual appearance |
| `GAICommandUILayoutReset` | `GAI_COMMAND_GUI_LAYOUT_RESET` | Reset UI layout |
| `GAICommandUISwitcher` | `GAI_COMMAND_UI_SWITCHER` | Switch UI state |
| `GAICommandDeployMode` | `GAI_COMMAND_DEPLOY_MODE` | Enter deployment mode |
| `GAICommandSpecMode` | `GAI_COMMAND_SPEC_MODE` | Enter spectator mode |
| `GAICommandSelectionClear` | `GAI_COMMAND_SELECTION_CLEAR` | Clear unit selection |

#### Objective and Progress Commands
| Command | Constant | Description |
|---------|----------|-------------|
| `GAICommandObjectiveAdd` | `GAI_COMMAND_OBJECTIVE_ADD` | Add mission objective |
| `GAICommandObjectiveChange` | `GAI_COMMAND_OBJECTIVE_CHANGE` | Modify objective state |
| `GAICommandProgressBar` | `GAI_COMMAND_PROGRESS_BAR` | Show progress bar |
| `GAICommandProgressBarFlags` | `GAI_COMMAND_PROGRESS_BAR_FLAGS` | Progress bar with flags |
| `GAICommandScoreBoard` | `GAI_COMMAND_SCORE_BOARD` | Show scoreboard |
| `GAICommandTourTable` | `GAI_COMMAND_TOUR_TABLE` | Tournament bracket |
| `GAICommandDomination` | `GAI_COMMAND_DOMINATION` | Domination mode |
| `GAICommandWinOnly` | `GAI_COMMAND_WIN_ONLY` | Win-only condition |
| `GAICommandAliveAllianceWin` | `GAI_COMMAND_ALIVE_ALLIANCE_WIN` | Last alliance standing |

#### Utility Commands
| Command | Constant | Description |
|---------|----------|-------------|
| `GAICommandCheckPoint` | `GAI_COMMAND_CHECK_POINT` | Create checkpoint/save |
| `GAICommandTimer` | `GAI_COMMAND_TIMER` | Set countdown timer |
| `GAICommandTimerCountdown` | `GAI_COMMAND_TIMER_COUNTDOWN` | Countdown display |
| `GAICommandRoute` | `GAI_COMMAND_ROUTE` | Define patrol route |
| `GAICommandRound` | `GAI_COMMAND_ROUND` | Round-based logic |
| `GAICommandGatherArea` | `GAI_COMMAND_GATHER_AREA` | Define gather area |
| `GAICommandGatherPoint` | `GAI_COMMAND_GATHER_POINT` | Define gather point |
| `GAICommandSettings` | `GAI_COMMAND_SETTINGS` | Modify battle settings |
| `GAICommandSurrender` | `GAI_COMMAND_SURRENDER` | Force surrender |
| `GAICommandWall` | `GAI_COMMAND_WALL` | Create wall structure |
| `GAICommandFogOpener` | `GAI_COMMAND_FOG_OPENER` | Open fog of war |
| `GAICommandFogOpenerRemove` | `GAI_COMMAND_FOG_OPENER_REMOVE` | Close fog of war |
| `GAICommandLongTapEnable` | `GAI_COMMAND_LONG_TAP_ENABLE` | Enable long tap input |
| `GAICommandUnitForcedMoveDisable` | `GAI_COMMAND_UNIT_FORCED_MOVE_DISABLE` | Disable forced move |
| `GAICommandTrainAcceleration` | `GAI_COMMAND_TRAIN_ACCELERATION` | Accelerate training |
| `GAICommandBonusChest` | `GAI_COMMAND_BONUS_CHEST` | Place bonus chest |
| `GAICommandLost` | `GAI_COMMAND_LOST` | Defeat condition |
| `GAICommandAddTestString` | `GAI_COMMAND_ADD_TEST_STRING` | Debug test string |
| `GAICommandSendAnalyticStep` | `GAI_COMMAND_SEND_ANALYTIC_STEP` | Analytics event |
| `GAICommandGroupSetBegin` | `GAI_COMMAND_GROUP_SET_BEGIN` | Begin group definition |
| `GAICommandGroupSetEnd` | `GAI_COMMAND_GROUP_SET_END` | End group definition |
| `GAICommandFinishBattleByTourTable` | `GAI_COMMAND_FINISH_BATTLE_BY_TOUR_TABLE` | End battle by tournament |
| `GAICommandMapConstructScenario` | `GAI_COMMAND_MAP_CONSTRUCT_SCENARIO` | Map construction scenario |
| `GAICommandMapMarkerObject` | `GAI_COMMAND_MAP_MARKER_OBJECT` | Object map marker |
| `GAICommandMapMarkerPoint` | `GAI_COMMAND_MAP_MARKER_POINT` | Point map marker |

## Tutorial System

The tutorial system is implemented through dedicated GAI commands with extensive finish condition tracking:

### Tutorial Commands

| Command | Description |
|---------|-------------|
| `GAICommandTutorialBegin` | Start tutorial sequence |
| `GAICommandTutorialEnd` | End tutorial sequence |
| `GAICommandTutorialHint` | Show tutorial hint |
| `GAICommandTutorialItem` | Give tutorial item |
| `GAICommandTutorialWindow` | Show tutorial window |
| `GAICommTutorialFinished` | Network signal for tutorial completion |

### Tutorial Finish Conditions

The tutorial system tracks 25+ finish conditions that must be met before the tutorial advances:

| Condition | Description |
|-----------|-------------|
| `GAICommandTutorialFinishConditionTrue` | Always completes (auto-advance) |
| `GAICommandTutorialFinishConditionForced` | Forced completion |
| `GAICommandTutorialFinishConditionBuildingBuild` | Player builds a building |
| `GAICommandTutorialFinishConditionBuildingLevel` | Building reaches level |
| `GAICommandTutorialFinishConditionBuildingHealth` | Building health threshold |
| `GAICommandTutorialFinishConditionBuildingRepair` | Player repairs building |
| `GAICommandTutorialFinishConditionBuyUnitCount` | Player buys N units |
| `GAICommandTutorialFinishConditionUnitOrdered` | Unit ordered from building |
| `GAICommandTutorialFinishConditionUnitsMoved` | Units moved to location |
| `GAICommandTutorialFinishConditionUnitsSelected` | Units selected |
| `GAICommandTutorialFinishConditionUnitGroupSet` | Unit group created |
| `GAICommandTutorialFinishConditionUnitBombersTargeting` | Bombers targeted |
| `GAICommandTutorialFinishConditionActiveAbilityUsed` | Hero ability activated |
| `GAICommandTutorialFinishConditionBoostApply` | Boost applied |
| `GAICommandTutorialFinishConditionClickIndicator` | UI indicator clicked |
| `GAICommandTutorialFinishConditionMining` | Resource mined |
| `GAICommandTutorialFinishConditionDemining` | Mines cleared |
| `GAICommandTutorialFinishConditionUraniumRefill` | Uranium refilled |
| `GAICommandTutorialFinishConditionUraniumSpend` | Uranium spent |
| `GAICommandTutorialFinishConditionSuperWeaponUnavailable` | Super weapon disabled |
| `GAICommandTutorialFinishConditionSendAIComm` | AI command sent |
| `GAICommandTutorialFinishConditionObjectivesWindow` | Objectives window viewed |

### Tutorial Check Commands

| Command | Description |
|-----------|-------------|
| `GAICommandTutorialCheckBuildingSelection` | Verify building selected |
| `GAICommandTutorialCheckBuildingSetToPosition` | Verify building placed at position |
| `GAICommandTutorialCheckCameraOutsideRect` | Verify camera within bounds |
| `GAICommandTutorialCheckMinedArea` | Verify area mined |
| `GAICommandTutorialCheckObjectivesWindow` | Verify objectives viewed |
| `GAICommandTutorialCheckSelectedMine` | Verify mine selected |
| `GAICommandTutorialCheckUnitsSelection` | Verify units selected |

### Tutorial Dependency Collectors

Tutorial commands use dependency collectors to ensure prerequisites are met:
- `GAICommandTutorialBeginDependencyCollector` - Tutorial begin prerequisites
- `GAICommandBonusChestDependencyCollector` - Bonus chest prerequisites
- `GAICommandCheckPointDependencyCollector` - Checkpoint prerequisites
- `GAICommandCounterIncDependencyCollector` - Counter increment prerequisites
- `GAICommandCounterJumpDependencyCollector` - Counter jump prerequisites
- `GAICommandFlagJumpDependencyCollector` - Flag jump prerequisites
- `GAICommandPickAmountToCounterDependencyCollector` - Pick amount prerequisites
- `GAICommandQuestDependencyCollector` - Quest prerequisites
- `GAICommandRandomJumpDependencyCollector` - Random jump prerequisites
- `GAICommandTriggerJumpDependencyCollector` - Trigger jump prerequisites
- `GAICommandFogOpenerRemoveDependencyCollector` - Fog opener remove prerequisites
- `GAICommandMarkGroundRemoveDependencyCollector` - Ground mark remove prerequisites
- `GAICommandQuestCancelDependencyCollector` - Quest cancel prerequisites
