# AI System - Art of War 3: RTS Strategy Game

## Overview

Art of War 3 implements a three-layer AI architecture designed to serve different gameplay needs: the GAI (Game AI) scripting system for narrative and tutorial control, the Bot AI for automated opponent behavior, and the AIComm battle command system for network-synchronized gameplay commands. Together, these three layers provide comprehensive AI coverage from high-level mission scripting down to individual unit actions in multiplayer battles. The system processes 144 GAI command types, bot behavior trees, and 48+ AIComm battle command types.

## Layer 1: GAI Scripting System

### Architecture Overview

The GAI scripting system is a node-based command execution engine that drives campaign missions, tutorials, and scripted scenarios. It operates at the highest level of abstraction, controlling not just unit behavior but the entire game experience including camera, UI, objectives, and narrative flow.

**Core Architecture**:
- `GAICommand` - Base command class with `GAICommandAttribute` for registration
- `GAICommandsNode` - Node in the execution graph
- `GAICommandAbstractComponent` - Runtime component for command execution
- `GAICommandAbstractModelComponent` - Model-level component
- `GAICommandAbstractActionButton` - UI action button integration
- `GAICommandAbstractDependencyCollector<T>` - Generic prerequisite tracking
- `GAICommandDependencyCollectorFactory` - Factory for dependency collectors
- `GAICommandReferenceCollector` - Reference management
- `GAICommandReferences` - Reference data
- `GAICommandInvalidDependency` - Invalid dependency sentinel

### Command Execution Model

GAI commands execute in a node-based graph where:
1. Commands are organized in `GAICommandsNode` structures
2. Each node can have dependency collectors that gate execution
3. Flow control commands (Jump, Loop) redirect execution to other nodes
4. Conditions (Flags, Counters, Triggers) evaluate at runtime
5. The `GAISideConfigCommand` configures per-side AI behavior

### Command Categories

#### Flow Control (9 Commands)
The flow control system provides branching, looping, and conditional execution:

| Command | Purpose |
|---------|---------|
| `GAICommandChanceJump` | Probabilistic branching (random % chance to jump to another node) |
| `GAICommandCounterJump` | Jump based on counter comparison |
| `GAICommandFlagJump` | Jump when a named flag is set |
| `GAICommandFlagJumpCancel` | Jump when a flag is NOT set |
| `GAICommandSequentJump` | Sequential execution flow |
| `GAICommandTriggerJump` | Jump when a trigger condition is met |
| `GAICommandRandomJump` | Random node selection |
| `GAICommandLoopStart/End` | Loop block definition |

**Jump Dependency Collectors**: `GAICommandChanceJumpDependencyCollector`, `GAICommandCounterJumpDependencyCollector`, `GAICommandFlagJumpDependencyCollector`, `GAICommandRandomJumpDependencyCollector`, `GAICommandTriggerJumpDependencyCollector`

#### Counter and Flag System (7 Commands)
State tracking for flow control decisions:

| Command | Purpose |
|---------|---------|
| `GAICommandCounter` | Define or reset a named counter |
| `GAICommandCounterInc` | Increment counter value |
| `GAICommandCounterCompare` | Compare counter against threshold |
| `GAICommandFlag` | Set a named boolean flag |
| `GAICommandFlagRemove` | Remove/clear a flag |
| `GAICommandParamToCounter` | Convert parameter value to counter |
| `GAICommandPickAmountToCounter` | Set counter from pickup quantity |

**Counter Dependency**: `GAICommandCounterIncDependencyCollector`, `GAICommandPickAmountToCounterDependencyCollector`

#### Building Commands (6 Commands)
Control building creation, placement, and restrictions:

| Command | Purpose |
|---------|---------|
| `GAICommandBuilding` | Define/reference a building entity |
| `GAICommandBuildingSetPlace` | Place building at specific coordinates |
| `GAICommandBuildingSetRestrict` | Restrict where buildings can be placed |
| `GAICommandBuildingHideFromList` | Hide building from the build menu |
| `GAICommandBuildingNeutral` | Create a neutral (non-player) building |
| `GAICommandConstruction` | Begin building construction |
| `GAICommandConstructionAssistant` | Assist with construction |
| `GAICommandConstructionSchedule` | Schedule construction for later |

#### Army and Troop Commands (8 Commands)
Control unit groups and army composition:

| Command | Purpose |
|---------|---------|
| `GAICommandArmySet` | Define army composition |
| `GAICommandArmyConditional` | Conditional army definition |
| `GAICommandAttackSet` | Define attack formation |
| `GAICommandMatrixArmySet` | Set army via matrix definition |
| `GAICommandTroopMove` | Move troop group to location |
| `GAICommandTroopCute` | Remove/cull troops from game |
| `GAICommandTroopDrop` | Deploy troops at location |
| `GAICommandTroopEvacuate` | Withdraw/evacuate troops |
| `GAICommandMatrixTroopCute` | Matrix-based troop removal |
| `GAICommandMatrixTroopDrop` | Matrix-based troop deployment |

#### Camera Commands (5 Commands)
Control camera positioning and restrictions:

| Command | Purpose |
|---------|---------|
| `GAICommandCameraSet` | Move camera to position |
| `GAICommandCameraSave` | Save current camera state |
| `GAICommandCameraRestore` | Restore saved camera state |
| `GAICommandCameraMask` | Restrict camera movement area |
| `GAICommandCameraTranslateDisable` | Disable camera translation |

#### Combat Commands (6 Commands)
Control damage, explosions, and combat events:

| Command | Purpose |
|---------|---------|
| `GAICommandDamageBonus` | Apply damage multiplier |
| `GAICommandDamageReduce` | Apply damage reduction |
| `GAICommandExplosion` | Create explosion at location |
| `GAICommandMineField` | Create mine field |
| `GAICommandNuclearStrike` | Nuclear strike event |
| `GAICommandImplosion` (AIComm) | Implosion weapon |

#### Resource Commands (4 Commands)
Control resource allocation:

| Command | Purpose |
|---------|---------|
| `GAICommandGold` | Grant or remove gold |
| `GAICommandHealth` | Set/modify entity health |
| `GAICommandEventCurrency` | Event-specific currency |
| `GAICommandBoostAdd` | Add boost effect |

#### Visual/UI Commands (12 Commands)
Control visual presentation and UI state:

| Command | Purpose |
|---------|---------|
| `GAICommandDialog` | Show dialog/cutscene |
| `GAICommandDarkenBuUn` | Darken buildings/units (spotlight effect) |
| `GAICommandDarkenMapArea` | Darken map area |
| `GAICommandDarkenWidget` | Darken UI widget |
| `GAICommandMarkBuUn` | Highlight buildings/units |
| `GAICommandMarkBuUnRemove` | Remove building/unit highlight |
| `GAICommandMarkGround` | Highlight ground area |
| `GAICommandMarkGroundRemove` | Remove ground highlight |
| `GAICommandMarkWidget` | Highlight UI widget |
| `GAICommandChangeAppearance` | Change visual appearance |
| `GAICommandUILayoutReset` | Reset UI layout |
| `GAICommandUISwitcher` | Switch UI state |

#### Objective Commands (5 Commands)
Manage mission objectives and progress display:

| Command | Purpose |
|---------|---------|
| `GAICommandObjectiveAdd` | Add mission objective |
| `GAICommandObjectiveChange` | Modify objective state |
| `GAICommandProgressBar` | Display progress bar |
| `GAICommandProgressBarFlags` | Progress bar with flag markers |
| `GAICommandScoreBoard` | Display scoreboard |

#### Utility Commands (15 Commands)
Various utility functions:

| Command | Purpose |
|---------|---------|
| `GAICommandCheckPoint` | Create save checkpoint |
| `GAICommandTimer` | Set countdown timer |
| `GAICommandTimerCountdown` | Display countdown |
| `GAICommandRoute` | Define patrol route |
| `GAICommandRound` | Round-based logic |
| `GAICommandGatherArea` | Define gather area |
| `GAICommandGatherPoint` | Define gather point |
| `GAICommandSettings` | Modify battle settings |
| `GAICommandSurrender` | Force surrender |
| `GAICommandWall` | Create wall structure |
| `GAICommandFogOpener/Remove` | Control fog of war |
| `GAICommandLongTapEnable` | Enable long press input |
| `GAICommandUnitForcedMoveDisable` | Disable forced movement |
| `GAICommandTrainAcceleration` | Speed up training |
| `GAICommandBonusChest` | Place bonus chest |
| `GAICommandWinOnly` | Win-only condition |
| `GAICommandAliveAllianceWin` | Last alliance standing |
| `GAICommandDomination` | Domination mode |
| `GAICommandLost` | Defeat condition |

#### Map Commands (3 Commands)
| Command | Purpose |
|---------|---------|
| `GAICommandMapConstructScenario` | Define map construction scenario |
| `GAICommandMapMarkerObject` | Place object marker on map |
| `GAICommandMapMarkerPoint` | Place point marker on map |

#### Mode Commands (3 Commands)
| Command | Purpose |
|---------|---------|
| `GAICommandDeployMode` | Enter deployment mode |
| `GAICommandSpecMode` | Enter spectator mode |
| `GAICommandSelectionClear` | Clear unit selection |

#### Tutorial Commands (29+ Types)
Dedicated tutorial system with 25+ finish conditions (detailed in Campaign_Analysis.md)

#### Group Commands (2 Commands)
| Command | Purpose |
|---------|---------|
| `GAICommandGroupSetBegin` | Begin group definition |
| `GAICommandGroupSetEnd` | End group definition |

#### Special Commands (3 Commands)
| Command | Purpose |
|---------|---------|
| `GAICommandAddTestString` | Debug: add test string |
| `GAICommandSendAnalyticStep` | Fire analytics event |
| `GAICommandFinishBattleByTourTable` | End battle by tournament result |
| `GAICommandTourTable` | Tournament bracket display |

#### Squad and Pickup Commands (4 Commands)
| Command | Purpose |
|---------|---------|
| `GAICommandSquadZone` | Define squad zone |
| `GAICommandPassUnits` | Pass unit references |
| `GAICommandPassBuildings` | Pass building references |
| `GAICommandPassCoord` | Pass coordinate data |
| `GAICommandPickUnits` | Pick/select units |
| `GAICommandPickBuildings` | Pick/select buildings |
| `GAICommandPickLoad` | Pick/load data |

## Layer 2: Bot AI

### Architecture

The Bot AI system in `com.geargames.aow.entities.battle.bot` provides automated opponent behavior for PvE scenarios and potentially PvP practice matches. While less detail is available from the binary analysis (fewer string identifiers than GAI), the bot AI operates at a strategic level above the AIComm command layer.

**Bot Behavior Model**:
- Bots likely use the GAI system as their behavioral backbone
- The `bot` namespace suggests additional behavior tree logic
- Bot actions are expressed as AIComm commands for network synchronization
- Bots must obey the same deterministic lockstep rules as human players

**Bot AI Communication**: Bots use AIComm commands to interact with the battle simulation, ensuring their actions are properly synchronized with the game state. This means bot actions go through the same validation and CRC checking as human player actions.

## Layer 3: AIComm Battle Command System

### Architecture

The AIComm system handles real-time battle commands that are exchanged between clients and the server during active gameplay. Every player action in battle is expressed as an AIComm command, serialized, and transmitted for lockstep synchronization.

**Command Flow**:
1. Player performs action (click, tap, key press)
2. Game creates AIComm command object
3. STSerializer converts to binary
4. Command encrypted and sent to server
5. Server validates and broadcasts to all clients
6. All clients deserialize via STDeserializer
7. Command executed deterministically on same tick
8. `AICommandsAtTickSTSerializer/STDeserializer` batches commands per tick

### Command Categories (48+ Commands)

#### Movement Commands (7 Commands)
| Command | Description |
|---------|-------------|
| `AICommUnitsMove` | Move units to position |
| `AICommUnitsStop` | Stop units |
| `AICommUnitsHoldPosition` | Hold position |
| `AICommUnitsBombard` | Bombard area |
| `AICommUnitsPatrolTargeting` | Patrol route |
| `AICommUnitsSpec` | Special ability |
| `AICommUnitsPsionic` | Psionic attack |

#### Building Commands (7 Commands)
| Command | Description |
|---------|-------------|
| `AICommBuSet` | Place building |
| `AICommBuildingUpgrade` | Upgrade building |
| `AICommBuildingRemove` | Remove building |
| `AICommBuildingRepair` | Repair building |
| `AICommBuildingRallyPoint` | Set rally point |
| `AICommBuyUnit` | Purchase unit |
| `AICommCancelBuyUnit` | Cancel unit purchase |

#### Hero Commands (5 Commands)
| Command | Description |
|---------|-------------|
| `AICommHeroActivate` | Activate hero |
| `AICommHeroActivateAndBuy` | Buy and activate hero |
| `AICommHeroAbilityActive` | Use hero ability |
| `AICommHeroBatteryBuy` | Buy hero energy |
| `AICommHeroEnergyRefill` | Refill hero energy |

#### Super Weapon Commands (4 Commands)
| Command | Description |
|---------|-------------|
| `AICommNuclearLaunch` | Launch nuclear weapon |
| `AICommImplosion` | Implosion weapon |
| `AICommMineLay` | Lay mines |
| `AICommMineSweep` | Clear mines |

#### Transport Commands (2 Commands)
| Command | Description |
|---------|-------------|
| `AICommUnitsLoadTransport` | Load into transport |
| `AICommUnitsUnloadTransport` | Unload from transport |

#### Air Commands (2 Commands)
| Command | Description |
|---------|-------------|
| `AICommAircraftRebase` | Rebase aircraft |
| `AICommUnitBombersTargeting` | Bomber targeting |
| `AICommFightersGuard` | Fighter escort |

#### Battle Control Commands (7 Commands)
| Command | Description |
|---------|-------------|
| `AICommSurrender` | Surrender |
| `AICommSurrenderSpectator` | Spectator surrender |
| `AICommBattleResume` | Resume battle |
| `AICommChatMessageSend` | Battle chat |
| `AICommBoostBuyAndApply` | Buy and apply boost |
| `AICommBoost` | Apply boost |
| `AICommBonusChest` | Collect bonus chest |
| `AICommDeployExtend` | Extend deployment zone |

#### Synchronization Commands (5 Commands)
| Command | Description |
|---------|-------------|
| `AICommCRCRequest` | CRC check request |
| `AICommCRCAnswer` | CRC check response |
| `AICommVerify` | Battle verification |
| `AICommSyncTest` | Sync test |
| `AICommExecutionLags` | Report execution lag |

#### Win Condition Commands (4 Commands)
| Command | Description |
|---------|-------------|
| `AICommWinPVE` | PvE victory |
| `AICommWinPVP` | PvP victory |
| `AICommWinPVPSingleSide` | Single-side PvP win |
| `AICommTutorialFinished` | Tutorial complete |

#### Settings Commands (2 Commands)
| Command | Description |
|---------|-------------|
| `AICommSettings` | Battle settings |
| `AICommSquad` | Squad formation |

### AIComm Command Constants

All AIComm commands have integer constants following the `BATTLE_AI_COMMAND_*` naming pattern:
- `BATTLE_AI_COMMAND_TYPE_MIN` - Minimum command ID
- `BATTLE_AI_COMMAND_TYPE_MAX` - Maximum command ID
- `BATTLE_AI_COMMAND_NOT_VALID` - Invalid command sentinel
- Individual constants for each command type (listed in Network_Messages.md)

## AI System Interaction

The three AI layers interact as follows:

```
[GAI Scripting Layer] (High-level narrative/tutorial control)
        |
        | Issues commands via GAICommand* types
        v
[Bot AI Layer] (Strategic decision-making)
        |
        | Generates AIComm commands
        v
[AIComm Layer] (Network-synchronized execution)
        |
        | Serialized and transmitted
        v
[Battle Logic] (Deterministic simulation)
```

The GAI layer controls what happens (narrative, tutorials, objectives). The Bot AI layer decides what to do (strategic decisions, resource allocation, attack timing). The AIComm layer executes how it happens (unit movements, building placement, ability activation). All three layers ultimately produce AIComm commands that are processed by the deterministic battle simulation.

## AI Command Batching

Commands are batched per tick using `AICommandsAtTickSTSerializer/STDeserializer`:
- All commands for a given tick are collected
- Commands are serialized into a single batch message
- Batch is transmitted to all clients
- All clients execute the batch deterministically on the same tick
- This ensures lockstep synchronization across all participants
