# Combat System - Art of War 3: RTS Strategy Game

## Overview

The combat system in Art of War 3 is a real-time deterministic simulation that handles damage calculation, armor resolution, projectile trajectories, weapon systems, and area-of-effect mechanics. The system supports three armor types (light, medium, heavy), multiple weapon categories (rifle, tank, rocket, torpedo, laser, psionic), and hero-specific combat mechanics with unique ability weapons. Combat occurs across three domains (ground, water, air) with domain-specific damage modifiers and projectile behaviors.

## Damage Pipeline

### Damage Calculation Flow

The damage pipeline processes attacks through multiple stages:

1. **Weapon Selection**: The attacking unit selects its weapon based on target type and range
2. **Attack Calculation**: `CalculateForWeapon` computes base damage using weapon stats
3. **Armor Resolution**: `CalculateWeaponArmorDamage` applies armor reduction
4. **Modifier Application**: Attack/defense bonuses and reductions are applied
5. **Damage Application**: `SafeSetDamageStat` applies final damage to target health
6. **Visual Feedback**: Weapon fire, bullet, impact, and explosion VFX play

### Attack Stats

**Base Attack Properties**:
- `ACT_ATTACK` - Base attack stat
- `ACT_ATTACK_BU` - Attack stat for buildings
- `Attack` - Attack value reference
- `AttackBonus` / `AttackBonusDisabled` - Bonus attack modifier
- `AttackDecr` - Attack decrement modifier
- `AttackSpeedReduction` - Speed penalty while attacking
- `ATTACK_BASE_ID` - Base attack identifier

**Attack Interval System**:
- `ATTACK_INTERVAL_LAND` - Land unit attack speed
- `ATTACK_INTERVAL_WATER` - Water unit attack speed
- `ATTACK_INTERVAL_FIGHTER` - Fighter aircraft attack speed
- `ATTACK_INTERVAL_BOMBER` - Bomber aircraft attack speed
- `ATTACK_INTERVAL_NUCLEAR` - Nuclear weapon attack interval
- `ATTACK_INTERVAL_COUNT` - Number of interval categories

**Attack Coefficient Calculation**:
- `AttackCoeffCalculating` - Attack coefficient computation
- `ARMOR_COEFF` - Armor coefficient for damage reduction
- `AttackCpLimitPercent` - CP limit percentage for attacks
- `AttackCpPercMin` / `AttackCpPercMax` - CP percentage range

## Armor System

### Armor Types

The game implements three armor types with different damage reduction characteristics:

| Armor Type | Constant | Description |
|------------|----------|-------------|
| Light | `ARMOR_LIGHT` / `ARMOR_TYPE_LIGHT` | Low protection, fast units |
| Medium | `ARMOR_MEDIUM` / `ARMOR_TYPE_MEDIUM` | Balanced protection and speed |
| Heavy | `ARMOR_HEAVY` / `ARMOR_TYPE_HEAVY` | High protection, slow units |
| Building | `ACT_ARMOR` / `ACT_ARMOR_BU` | Building-specific armor |

`ARMOR_TYPE_COUNT` indicates there are exactly 3 armor types in the game.

### Armor Calculation

The `ArmorStatHelper` class provides armor damage reduction calculations:

```
DamageAfterArmor = BaseDamage * ArmorCoeff(ArmorType, WeaponType)
```

**Armor Constants**:
- `ARMOR` / `ARMOR1` - Armor stat identifiers
- `ARMOR_COEFF` - Armor coefficient multiplier
- `ArmorBonus` - Additional armor bonus
- `BuildingLevelArmor` - Building armor per level
- `BUILDING_LEVEL_ARMOR` - Building armor stat name

**Hero-Specific Armor**:
- `COIL_TANK_FRONTAL_ARMOR` - CoilTank enhanced frontal armor
- `ATLANT_ANGLE_FRONTAL_DEFENSE` - Atlas frontal defense angle
- `ATLANT_ABSOLUTE_DAMAGE_REDUCTION` - Atlas flat damage reduction
- `ATLANT_DAMAGE_THRESHOLD` - Atlas damage threshold

### Armor Class Abilities

Some heroes have armor-related ability parameters:
- `ArmorAbilityParamDescription` - Generic armor ability description
- `AtlantAbsoluteDamageReductionAbilityParamDescription` - Atlas flat damage reduction
- `AtlantAngleFrontalDefenseAbilityParamDescription` - Atlas directional defense
- `AtlantDamageThresholdAbilityParamDescription` - Atlas damage threshold

## Weapon System

### Weapon Architecture

The weapon system uses a component-based architecture:

```
AbstractClientWeapon (base)
  +-- AbstractClientEnginedWeapon (engine-driven weapons)
  +-- AtlantMainClientWeapon (Atlas primary weapon)
  +-- AtlantActiveClientWeapon (Atlas active ability weapon)
```

**Weapon Engine**: `AbstractWeaponEngine` provides the calculation engine for weapon behavior including:
- Damage computation
- Range checking
- Target selection
- Firing interval management

**Weapon Settings**:
- `AdditionalWeaponSettings` - Secondary weapon configuration
- `BurstWeaponSettings` - Burst fire parameters
- `AbilityWeaponId` / `ActiveAbilityWeaponId` - Ability weapon identifiers
- `AbilityWeaponStateOwnership` - Weapon state ownership

### Weapon Categories

Based on VFX assets and constants, the weapon categories include:

#### Rifle Weapons
- Standard infantry rifle: `fire_rifle1_s1/s2/s3/s4`, `bul_rifle1_s1/s2/s3`
- Advanced rifle: `fire_rifle2_s1/s2/s3/s4`, `bul_rifle2_s1/s2/s3/s4/s5`
- Rifle variant: `fire_rifle3_s1/s2/s3`
- Fighter rifle: `fire_rifle2_s4_fighter`
- Impact effects: `boom_rifle1_s1/s2/s3/s4_ground/inf/veh/water`

#### Tank Weapons
- Tank shells: `fire_tank0/1/2/3/4/5`, `bul_tank1_s1/s2/s3`, `bul_tank2_s2/s3`, `bul_tank3_s3`, `bul_tank4_s3`

#### Rocket Weapons
- Standard rockets: `bul_rocket1_s1/s2/s3`, `bul_rocket2_s1/s2/s3`
- Advanced rockets: `bul_rocket3_s2/s3`, `bul_rocket4_s1/s2/s3`
- Nuclear rocket: `bul_rocket3_s5_nuke`
- Small hero rockets: `bul_rocket_small_salamander`, `bul_rocket_leviaphan`

#### Torpedo Weapons
- Standard torpedoes: `bul_torpedo1`, `bul_torpedo2`, `bul_torpedo3`, `bul_torpedo4`
- Hidden torpedo: `bul_torpedo2_hidden`

#### Special Weapons
- UFO Laser: `bul_ufo_lazergun`, `ufo_fire`, `impact_ufo_lazer_ground/inf/veh/water`
- Bombs: `bul_bomb1`, `bul_bomb2`
- Grenades: `bul_grenade1`, `bul_grenade2`
- Flamethrower: `flamethrower1_2/3/4/5cells`

### Weapon Take Object Rules

Weapons have configurable target selection rules:
- `COMMON_WEAPON_TAKE_OBJ_ALWAYS` - Always acquire target
- `COMMON_WEAPON_TAKE_OBJ_NEVER` - Never auto-acquire
- `COMMON_WEAPON_TAKE_OBJ_NON_DEFINED` - Default behavior
- `COMMON_WEAPON_TAKE_OBJ_NON_EMPTY_TARGET` - Only when target exists

## Projectile System

### Bullet Types

The `BulletSTSerializer/STDeserializer` handles projectile data serialization. Projectiles have the following properties:

- `BULLET_ACTION_DAMAGE` - Damage action type
- Trajectory type (ballistic, direct, homing)
- Speed and acceleration
- Impact effect category (ground, water, vehicle, infantry, air)

### Trajectory System

The `com.geargames.aow.entities.battle.flight` namespace handles projectile trajectories:

**Trajectory Types** (inferred from VFX and code):
- **Direct**: Instant-hit for laser weapons (Beholder, Seraphim)
- **Ballistic**: Arc trajectory for rockets and artillery
- **Homing**: Guided projectiles for certain rockets
- **Arc**: Parabolic for grenades and bombs
- **Chain**: Lightning chain for CoilTank and Solaris

**Surface Categories**: Each impact effect is categorized by surface:
- `ground` - Standard land impact
- `water` - Water splash
- `veh` - Vehicle/armor impact
- `inf` - Infantry impact
- `air` - Air unit impact

## Super Weapon System

### Nuclear Strike
The nuclear weapon is the most powerful super weapon:

**Nuclear Launch Flow**:
1. Player clicks `AttackSuperWeaponNuclearTap`
2. `AICommNuclearLaunch` sent to server
3. Nuclear silo building plays launch animation (`eff_rocket_nuke_launch`)
4. Nuclear rocket projectile (`bul_rocket3_s5_nuke`) travels to target
5. Massive explosion VFX plays (`boom_expl5_s5_nuke/nuke_rocket/nuke_water`)
6. Area damage applied to all units and buildings in radius

**Nuclear Explosion VFX**:
- `boom_expl5_s5_nuke` - Ground nuclear explosion
- `boom_expl5_s5_nuke_rocket` - Nuclear rocket explosion
- `boom_expl5_s5_nuke_water` - Water nuclear explosion

### Space Strike
The orbital super weapon strikes from above:

**Space Strike Flow**:
1. Player clicks `AttackSuperWeaponSpaceTap`
2. Space strike animation plays (`eff_space_super_launch`)
3. Ray from sky impacts target (`boom_expl5_s5_space_ray`)
4. Area damage applied

**Space Strike VFX**:
- `boom_expl5_s5_space` - Ground space strike
- `boom_expl5_s5_space_ray` - Strike ray
- `boom_expl5_s5_space_water` - Water space strike
- `eff_space_1/super_launch/super_launch_wait/super_wait/super_work`

### Implosion Weapon
The `AICommImplosion` command triggers an implosion weapon that draws units inward:
- Likely used by a specific hero or super weapon
- Reverse of explosion mechanics

## Hero Combat Mechanics

### Hero Active Abilities

Each hero has a unique active ability triggered via `AICommHeroAbilityActive`:

| Hero | Active Ability | Weapon Index |
|------|---------------|--------------|
| Wasp | Acid spray / Rocket barrage | `ACTIVE_ABILITY_WEAPON_INDEX` |
| Beholder | Scanner / Laser | Custom targeting |
| Salamander | Turbo / Submerge | Movement + attack |
| Atlas | Immortality shield | `AtlantActiveClientWeapon` |
| CoilTank | Lightning ball / Nova | Energy discharge |
| CryoTank | Frost bomb / Nova | Freeze AoE |
| Gatling | Explosive rounds / Smoke | Sustained fire |
| Railgun | March / Quake / Siege | Mode switching |
| Leviaphan | Nuclear launch | Multi-turret |
| Seraphim | Laser / Kara | VTOL + attack |
| Solaris | Impulse / Lightning | Chain damage |
| Cerber | Jump jet / Grenade | Mobility + AoE |
| Codomash | Turret deployment | Structure creation |

### Hero Ability Effects

When a hero ability is interrupted:
- `AbilityStoppedHeroStunned` - Hero becomes stunned if ability is cancelled
- `IsAttackBonusEnabled` / `IsAttackBonusDisabled` - Attack bonus toggle
- `AlliedBaseIsUnderAttack` / `AlliedUnitIsUnderAttack` - Alert triggers
- `AllySideAttackGlobalBuff` - Allied attack buff

### Hero Weapon Parameters

**Atlas-Specific**:
- `ATLANT_ABSOLUTE_DAMAGE_REDUCTION` - Flat damage reduction
- `ATLANT_ANGLE_FRONTAL_DEFENSE` - Directional defense angle
- `ATLANT_DAMAGE_THRESHOLD` - Minimum damage to trigger effects
- `AtlantMainClientWeapon` / `AtlantActiveClientWeapon` - Weapon instances

**CoilTank-Specific**:
- `COILTANK_BALL_LIGHTNING_DAMAGE` - Ball lightning damage value
- `COILTANK_ENERGY_BURNING` - Energy drain rate
- `COIL_TANK_ENERGY_ABILITY_ID` - Energy ability identifier
- `COIL_TANK_FRONTAL_ARMOR` - Enhanced frontal armor
- `COIL_TANK_WEAPON` - Weapon identifier

## Battle Statistics

The combat system tracks extensive statistics:

**Building Statistics**:
- `BatBuildingsConstructed` - Buildings built
- `BatBuildingsErased` - Buildings destroyed

**Unit Statistics**:
- `BatUnitsKilled` - Units killed
- `BatUnitsTrained` - Units trained
- `BatUnitsValueKilled` - Resource value of units killed

**Hero Statistics**:
- `BatHeroActiveKill` - Heroes killed by active ability
- `BatHeroKillSingleLife` - Heroes killed in single life
- `BatHeroesKill` - Heroes killed by player
- `BatHeroesKilled` - Player's heroes killed
- `BatTyphoonKillHero` - Typhoon kills hero

**Combat Statistics**:
- `BatMinesDamaged` - Mines damaged
- `BatShieldFogUsed` - Shield fog uses
- `BattleActivityTime` - Total battle time

## Visual Effects in Combat

### Attack Sequence VFX
Each attack follows a standard VFX sequence:
1. **Fire**: Muzzle flash (`fire_[weapon]_s[size]`)
2. **Bullet**: Projectile travel (`bul_[weapon]_s[size]`)
3. **Impact**: Hit effect (`hero_impact_[hero]_[weapon]_[surface]`)
4. **Explosion**: Area effect (`boom_expl[size]_s[severity]_[surface]`)

### Damage Visualization
- `eff_bld_additive/diffuse/fire/fresnel/glow/lightning/smoke` - Building damage effects
- `eff_stat_buff_armor/health` - Stat buff indicators
- `eff_stat_explosion_ground/water` - Explosion indicators
- `BuildingStunEffect` - Building stun visualization
- `global_buff_healing` - Healing buff effect

### Combat Audio
- `AudioBattleSoundsHandler` - Combat sound management
- `AudioBattleVoiceWeightSettings` - Voice priority settings
- `AudioBattleVoicesPlayer` - Voice line playback
- `TryPlay[Action]VoiceToSelectedUnits` - 10+ voice trigger methods
- `BattleVoicesConf` / `BattleVoicesResist` - Voice configuration
- `Battle_IsVoiceQueueEnabled` - Voice queue feature toggle
