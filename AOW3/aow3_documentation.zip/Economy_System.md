# Economy System - Art of War 3: RTS Strategy Game

## Overview

The economy system in Art of War 3 manages all in-game resources, currencies, production pipelines, and monetization mechanisms. The economy is built around several resource types (energy, gold, uranium, blueprints, batteries, event currencies), each serving distinct gameplay functions. The system integrates with the building infrastructure for production, the billing system for monetization, the ads system for alternative acquisition, and the boost system for temporary enhancements. The energy grid is particularly critical as it powers all building operations.

## Resource Types

### Energy
Energy is the primary operational resource that powers buildings. Without sufficient energy, buildings become stunned and non-functional.

**Energy Properties**:
- `Energy` - Current energy amount
- `EnergyMax` - Maximum energy capacity
- `EnergyRegenValue` - Energy regeneration rate
- `EnergyForAds` - Energy obtainable from ads
- `ACT_ENERGY_GEN` - Energy generation stat
- `ACT_ENERGY_REGEN` - Energy regeneration stat
- `BuildingEnergyNeedStat` - Per-building energy consumption
- `BuildingEnergyProductionStat` - Per-building energy generation
- `BUILDING_LEVEL_ENERGY` - Energy per building level

**Energy Buildings**:
- `BuildingListPowerStation` - Generates energy
- Power stations can be upgraded for increased output
- Energy grid connects all buildings to the power network
- Deficit causes `BuildingStunOn` on non-essential buildings

**Energy Acceleration**:
- `AccelerateEnergy` - Speed up energy generation
- `AdsAccelerateUpgradeRequest/Answer` - Ad-based energy boost

### Gold
Gold is the primary soft currency used for building construction, unit production, and upgrades.

**Gold Properties**:
- `GAICommandGold` - Scripted gold grants
- `MINI_PROMO_CATEGORY_GOLD` - Gold promotion category
- `BatUnitsValueKilled` - Gold value of killed units
- `CareerStone` - Career milestone rewards (likely gold)

**Gold Sources**:
- Battle rewards (`BattleReward`, `BattleRewardSTSerializer`)
- Career progression (`CareerRewardItem`)
- Daily login rewards (`DailyEntrance`)
- Event rewards (`ActionEventRewardNotification`)
- Battle pass rewards (`BattlePassReward`)
- Bonus chests (`BonusChest`, `GAICommandBonusChest`)
- Crate openings (`CRATE_REQUEST`, `CRATE_WINS_ANSWER`)

### Uranium
Uranium is the premium currency used for super weapons, hero abilities, and premium upgrades.

**Uranium Properties**:
- `UranumBattleModel` - Uranium state during battle
- `com.geargames.aow.entities.uw` - Uranium weapon entities
- `com.geargames.aow.messages.uw` - Uranium weapon messages
- `com.geargames.aow.scenes.main.gui.upgrades.uranum` - Uranium upgrade UI
- `com.geargames.aow.ugui.uranium` - Uranium UI components

**Uranium Usage**:
- Super weapon activation (`AttackSuperWeaponNuclearTap`, `AttackSuperWeaponSpaceTap`)
- Hero energy refill (`AICommHeroEnergyRefill`)
- Upgrade acceleration (`AccelerateUpgradeRequest`)
- Episode unlocking (`BuyEpisodeUnlockRequest/Answer`)

**Uranium Tutorials**:
- `GAICommandTutorialFinishConditionUraniumRefill` - Uranium refill tutorial
- `GAICommandTutorialFinishConditionUraniumSpend` - Uranium spend tutorial

### Blueprints
Blueprints are collectible items used for unit upgrades and modifications.

**Blueprint Properties**:
- `IBlueprintsResourceService.Collection` - Blueprint collection
- `IBlueprintsResourceService.GetValue` - Blueprint value query
- `IBlueprintsResourceService.get_Collection` - Collection accessor

### Batteries
Batteries are a resource type used for hero energy and special abilities.

**Battery Properties**:
- `IBatteriesResourceService.Collection` - Battery collection
- `IBatteriesResourceService.GetValue` - Battery value query
- `BatterySTSerializer/STDeserializer` - Battery serialization
- `AICommHeroBatteryBuy` - Purchase hero battery
- `AICommHeroEnergyRefill` - Refill hero energy

### Event Currency
Time-limited event-specific currencies:

- `GAICommandEventCurrency` - Event currency in GAI scripts
- `GAICommandEventCurrencyComponent` - Runtime component
- Action events: `ActionEventInfo`, `ActionEventProfile`, `ActionEventEndNotification`, `ActionEventRewardNotification`

## Production System

### Building Production Pipeline

The production system transforms resources into units and upgrades:

1. **Resource Check**: `CheckResources` validates sufficient resources
2. **Order Placement**: `AICommBuyUnit` / building upgrade initiated
3. **Resource Deduction**: Costs deducted from player inventory
4. **Production Queue**: Building processes order over time
5. **Completion**: Unit spawns or upgrade applies
6. **Rally Point**: Produced units move to rally point

**Production Validation**:
- `CanBuildingProduceUnit` - Unit production capability check
- `CanOrderInBuilding` - Order placement validation
- `CheckResources` - Resource sufficiency check
- `CanBuildingUpgrade` - Upgrade availability check

**Production Acceleration**:
- `AccelerateUpgradeRequest/Answer` - Premium acceleration
- `AdsAccelerateUpgradeRequest/Answer` - Ad-based acceleration
- `CompleteActiveUpgradeRequest/Answer` - Instant completion
- `GAICommandTrainAcceleration` - Scripted acceleration
- `CONFIRM_ACCELERATE_UPGRADE_REQUEST` - Acceleration confirmation

### Upgrade System

**Active Upgrades**:
- `ActiveUpgradeLevelSTSerializer/STDeserializer` - Active upgrade data
- `ActiveUpgradeNotificationSTSerializer/STDeserializer` - Upgrade completion notification
- `AccelerateUpgradeAnswer/Request` - Speed up upgrade
- `CancelUpgradeRequest/Answer` - Cancel in-progress upgrade
- `CompleteActiveUpgradeRequest/Answer` - Instant completion

**Upgrade Costs**:
- `BuildingPriceStat` - Building price calculation
- `BUILDING_LEVEL_PRICE` - Price per level
- `BattleCost` / `BattlePrice` - Battle entry costs
- `BattleEntranceCostBase` / `BattleEntranceCostInc` - Cost progression

## Monetization System

### In-App Purchases (Billing)

**Billing Infrastructure**:
- `BillingConfigurationSTSerializer/STDeserializer` - Billing config
- `BillingButtonInfoSTSerializer/STDeserializer` - Purchase button info
- `BillingNotificationSTSerializer/STDeserializer` - Purchase notification
- `BillingResponseTimeout` - Billing response timeout
- `BUY_GOODS_REQUEST/ANSWER` - Purchase goods
- `CONSUME_PURCHASE_REQUEST/ANSWER` - Consume purchase
- `BuyViaProviderBillingRequest` - Provider-specific billing
- `BuyViaProviderBillingRequestHelper` - Billing helper

**Billing Response Codes**:
- `BILLING_RESPONSE_RESULT_OK` - Success
- `BILLING_RESPONSE_RESULT_USER_CANCELED` - User cancelled
- `BILLING_RESPONSE_RESULT_BILLING_UNAVAILABLE` - Billing unavailable
- `BILLING_RESPONSE_RESULT_SERVICE_UNAVAILABLE` - Service unavailable
- `BILLING_RESPONSE_RESULT_ITEM_UNAVAILABLE` - Item unavailable
- `BILLING_RESPONSE_RESULT_DEVELOPER_ERROR` - Developer error
- `BILLING_RESPONSE_RESULT_ERROR` - Generic error
- `BILLING_RESPONSE_RESULT_ITEM_ALREADY_OWNED` - Already owned
- `BILLING_RESPONSE_RESULT_ITEM_NOT_OWNED` - Not owned

**Google Play Billing**:
- Version: 8.0.0
- `com.android.vending.BILLING` permission
- `BuyViaProviderBillingRequest` for provider-specific purchases

### Advertising System

**Ad Types**:
- Rewarded Video: `ADS_REWARD_REQUEST/ANSWER`
- Interstitial: `IronSourceService.Interstitial`
- Banner: Implied by `AdsTypeInfo`
- App Open: Bytedance Pangle app open ads

**Ad Infrastructure**:
- `AdsInfoSTSerializer/STDeserializer` - Ad information
- `AdsParamsSTSerializer/STDeserializer` - Ad parameters
- `AdsIsReadySTSerializer/STDeserializer` - Ad readiness check
- `AdsSwitcherSTSerializer/STDeserializer` - Ad network switching
- `AdsToPrepareSTSerializer/STDeserializer` - Ad preparation
- `AdsAvailabilityUpdateSTSerializer/STDeserializer` - Availability updates
- `AdsTypeInfoSTSerializer/STDeserializer` - Ad type information

**Ad Mediation**:
- `ApplovinMaxService` - AppLovin MAX mediation
- `GGMediation` - Custom Gear Games mediation
- `IronSourceService` - IronSource mediation
- `UseMultiAdUnitsEnabled` / `IsMultiAdUnitsAbTestEnabled` - A/B testing

**Ad Rewards**:
- `ADS_REWARD_REQUEST/ANSWER` - Claim ad reward
- `ADS_ACCELERATE_UPGRADE_REQUEST/ANSWER` - Ad-based upgrade speed
- `ADS_REWIND_REQUEST` - Rewind ad timer
- `EnergyForAds` - Energy from ads

### Black Market

The Black Market is a rotating shop offering special items:
- `BlackMarketConfigurationSTSerializer/STDeserializer` - Market config
- `BlackMarketGoodsSTSerializer/STDeserializer` - Market items
- `BlackMarketConfigurationUpdateRequest/Answer` - Market refresh
- `AddedGoodsSTSerializer/STDeserializer` - Goods added notification

### Battle Pass

**Battle Pass System**:
- `BattlePassInfo` - Season information
- `BattlePassProfileInfo` - Player progress
- `BattlePassPremium` - Premium track status
- `BattlePassPoints` - Point accumulation
- `BattlePassReward` - Reward items
- `BattlePassScale` - Reward scaling
- `BattlePassRewardRequest/Answer` - Claim reward

**Battle Pass UI**:
- `com.geargames.aow.ugui.battlepass` - Battle pass UI components
- `ButtonDebugBattlePassOpen` - Debug open
- `ButtonDebugBattlePassPoints` - Debug points

### Crate System

**Crate Mechanics**:
- `CRATE_REQUEST` - Open a crate
- `CRATE_WINS_REQUEST/ANSWER` - Crate win history
- `CRATE_DATE_REWIND_REQUEST/ANSWER` - Rewind crate timer
- `BoxItem` - Individual crate item
- `BoxRewardMessage` - Reward notification

**Crate VFX**:
- `eff_collect_box/container/pumpkin/tree/gear/cake` - Collection effects
- `eff_cryptodata/cryptodata_box` - Crypto data crate
- `eff_joker_box` - Joker crate
- `eff_pot_of_gold_box` - Pot of gold crate

## Boost System

### Boost Types
- `BoostActive` - Active boost instance
- `BoostBonusInfo` - Boost bonus details
- `BoostBlinkInfo` - Boost visual indicator
- `BoostType` - Boost type definitions

### Boost Management
- `AICommBoostBuyAndApply` - Buy and apply in battle
- `AICommBoost` - Apply boost effect
- `BOOST_APPLY_IN_BATTLE_KEY_ADD` - In-battle boost application
- `BoostConvertRequest/Answer` - Convert boost type
- `BoostsPreferredAddRequest/Answer` - Add preferred boost
- `BoostsPreferredResetRequest/Answer` - Reset preferred boost
- `BattleBoostCategories` - Boost categorization
- `BoostsResourceService` - Boost resource service

## Career and Progression

### Career System
- `CareerUp` - Career level advancement
- `CareerStone` - Career milestone
- `CareerRewardItem` - Career reward

### Level System
- `com.geargames.aow.messages.levels` - Level messages
- `BuildingLevelForOpen` - Level requirement for buildings
- `RankForHero` / `RankForOpenHero` - Hero unlock requirements

### Episode System
- `BuyEpisodeUnlockRequest/Answer` - Episode purchase
- Campaign chapters unlock progressively

## Economy Constants

**Battle Pricing**:
- `BattleCost` - Base battle cost
- `BattlePrice` - Battle entry price
- `BattleEntranceCostBase` - Base entrance cost
- `BattleEntranceCostInc` - Incremental cost increase
- `BattleEntranceCostExhibition` - Exhibition cost
- `BattlePvPPrices` - PvP pricing structure

**Resource Limits**:
- `EnergyMax` - Maximum energy
- `BuildingsAmount` - Building count
- `CalcBuildingCountLimit` - Maximum buildings
- `BuildingLimitations*` - Per-type limits

**Reward Scaling**:
- `BattlePrizeMult` - Prize multiplier
- `BattlePassScale` - Battle pass reward scaling
- `BattleLengthIntervalMultiplier` - Length-based reward modifier
