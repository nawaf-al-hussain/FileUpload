# Web Research - Art of War 3: RTS Strategy Game

## Overview

This document provides a structured framework for gathering community-sourced information about Art of War 3 that cannot be obtained through reverse engineering alone. While binary analysis reveals code structure, network protocols, and data models, community sources provide gameplay context, balance values, historical changes, and player-facing documentation that fills gaps in the technical analysis.

## Official Sources

### Gear Games Official Channels
- **Website**: The developer's official website for game information, patch notes, and announcements
- **Google Play Store**: com.geargames.aow - Version history, update notes, user reviews
- **App Store**: iOS version listing for cross-platform comparison
- **Social Media**: Official accounts for event announcements and community engagement

### In-Game Resources
- **Tutorial System**: The GAI-driven tutorial system (GAICommandTutorialBegin through GAICommandTutorialEnd) provides guided gameplay introduction
- **Help/FAQ**: In-game help system potentially accessible through the UI
- **Patch Notes**: Version 6.5.22 (versionCode 38820) represents hundreds of updates

## Community Sources

### Wiki and Database Sites
- **Fandom Wiki**: Community-maintained wiki with unit stats, building costs, and strategy guides
- **Reddit**: r/ArtofWar3 community for discussions, strategies, and patch analysis
- **Discord**: Official and community Discord servers for real-time discussions

### YouTube and Streaming
- **Gameplay Videos**: Visual confirmation of unit behaviors, building interactions, and combat mechanics
- **Strategy Guides**: Player-created content explaining optimal build orders and tactics
- **Update Reviews**: Content creators analyzing patch changes

### Modding Community
- **APK Analysis**: Other reverse engineering efforts may provide complementary insights
- **Custom Maps**: Map editor usage through `BattleMapEditorUtils` and `com.geargames.aow.tools.battleMapEditor`

## Data Points Requiring Community Verification

### Exact Stat Values
The binary analysis reveals stat categories and systems but not the specific numeric values. Community sources should verify:

1. **Unit Stats**: Health, damage, speed, range, armor values for each unit at each level
2. **Building Stats**: Construction cost, time, health, armor per level for each building
3. **Hero Stats**: Ability damage, cooldown, duration, energy costs for each hero ability
4. **Resource Generation**: Energy production rates, resource income values, generation multipliers
5. **Battle Template Parameters**: Army size limits, cost calculations, format restrictions

### Gameplay Mechanics
1. **Faction Differences**: Whether factions (s1, s2, s3) are cosmetically different only or have stat variations
2. **Armor Calculation**: How ARMOR_COEFF and armor types (light/medium/heavy) interact with damage
3. **Super Weapon Mechanics**: Nuclear launch timing, charge requirements, and damage values
4. **Hero Ability Interactions**: How hero abilities stack, counter, and interact with each other
5. **Fog of War Rules**: Exact vision ranges, detection mechanics, and stealth interaction

### Meta-Game Information
1. **Rating System**: How ELO/MMR ratings are calculated and matchmaking parameters
2. **Battle Pass Structure**: Season duration, reward tiers, and premium benefits
3. **Clan System Details**: Clan size limits, role permissions, supply mechanics
4. **Event Types**: Time-limited event formats and reward structures
5. **Economy Balance**: Gold generation rates, uranium costs, premium currency values

### Historical Data
1. **Version History**: Changes between major versions affecting gameplay
2. **Hero Release Timeline**: When each hero was added (some marked as unreleased/secret)
3. **Map Additions**: When each map was introduced
4. **Balance Changes**: Unit and building stat modifications over time
5. **Feature Timeline**: When features like modifications, clan wars, and battle pass were added

## Research Methodology

### Primary Research
1. **APK Diff Analysis**: Compare different version APKs to identify stat changes
2. **Network Traffic Capture**: Analyze actual message payloads during gameplay
3. **Memory Analysis**: Extract runtime stat values from active game process
4. **Asset Inspection**: Parse Unity asset bundles for configuration ScriptableObjects

### Secondary Research
1. **Community Database Scraping**: Extract structured data from wiki sites
2. **Video Frame Analysis**: Capture UI values from gameplay recordings
3. **Community Survey**: Crowd-source stat verification from active players
4. **Developer Communication**: Track official announcements for confirmed mechanics

## Version-Specific Notes

### Version 6.5.22 (versionCode 38820)
- Current version as of analysis
- Contains 8 DEX files indicating significant code volume
- IL2CPP metadata version 31
- Split APK with required base__abi split
- Target SDK 35 (Android 15), Min SDK 23 (Android 6.0)

### Feature Toggles
The binary contains numerous feature toggles following `Battle_Is[Feature]Enabled` pattern. Community verification is needed to determine which features are currently active in production:
- `Battle_IsLiquidFogEnabled`
- `Battle_IsGAICutsceneFeatureEnabled`
- `Battle_IsNewShieldIndicatorLogicEnabled`
- `Battle_IsVoiceQueueEnabled`
- `Battle_IsVisualStateServiceEnabled`
- And 15+ additional toggles

### Unreleased Content
Several hero identifiers suggest unreleased or secret content:
- Heroes with `IsHeroSecret` flag
- `IsHeroRestoreAvailable` suggesting hero recovery mechanics
- Heroes with full VFX sets but potentially not yet available in game
