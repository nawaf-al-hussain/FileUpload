# Network Messages - Art of War 3: RTS Strategy Game

## Overview

Art of War 3 implements a comprehensive network messaging system with over 710 distinct message types. The system follows a strict Request/Answer pattern for client-server communication, with each message type having paired `STSerializer` and `STDeserializer` implementations for binary serialization over TCP. The total count of 2,598 serializer/deserializer pairs covers every data structure that crosses the network boundary. Messages are categorized into several distinct groups: AIComm battle commands, lobby/matchmaking messages, clan messages, chat messages, billing messages, configuration messages, and profile messages.

## Message Architecture

### Serialization Pattern

Every network message follows the STSerializer/STDeserializer pattern. The "ST" prefix likely stands for "Stream Type" or "Serialized Type", and the pattern ensures bidirectional serialization consistency. For example, the `AccelerateUpgradeRequest` message has:
- `AccelerateUpgradeRequestSTSerializer` - Client-side serialization for sending
- `AccelerateUpgradeRequestSTDeserializer` - Server-side deserialization for receiving
- `AccelerateUpgradeAnswerSTSerializer` - Server-side serialization for responding
- `AccelerateUpgradeAnswerSTDeserializer` - Client-side deserialization for processing

### Message Flow Pattern

Messages follow a consistent flow:
1. Client creates a Request message object
2. STSerializer converts the request to binary via `GearGamesByteBuffer`
3. Binary data is encrypted via RSA/DES crypto provider
4. Encrypted data is sent over TCP connection
5. Server decrypts, deserializes via STDeserializer
6. Server processes and creates an Answer message
7. Answer is serialized, encrypted, and sent back
8. Client decrypts, deserializes, and processes the answer

### Message Infrastructure

The message infrastructure includes these foundational types:
- `CSMessage` - Base message type for client-server communication
- `GearGamesByteBuffer` - Binary buffer for serialization (get, put, flip, mark, reset, duplicate)
- `AbstractNetworkCryptoProvider` - Encryption abstraction (RSA/DES)
- `ActiveNetworkConnector` - Active network connection manager
- `CSAbstractMessageWaiter<T>` - Generic message waiting pattern
- `CSAbstractReliableMessageWaiter<T>` - Reliable message waiting with retry
- `CSHttpSendRequestAndReceiveResponse` - HTTP-based message transport
- `CSPushLaunchMessageSender` - Push notification message sender

## AIComm Battle Commands (48+ Commands)

AIComm messages are the real-time battle commands exchanged during active gameplay. They represent every action a player can take during a battle and are synchronized across all clients via the server.

### Unit Movement Commands
| Command | Description |
|---------|-------------|
| `AICommUnitsMove` | Move units to target position |
| `AICommUnitsStop` | Stop all selected units |
| `AICommUnitsHoldPosition` | Hold position command |
| `AICommUnitsBombard` | Bombard area command |
| `AICommUnitsPatrolTargeting` | Patrol path targeting |
| `AICommUnitsSpec` | Special ability activation |
| `AICommUnitsPsionic` | Psionic attack command |
| `AICommUnitsLoadTransport` | Load units into transport |
| `AICommUnitsUnloadTransport` | Unload units from transport |
| `AICommUnitBombersTargeting` | Bomber targeting command |
| `AICommFightersGuard` | Fighter guard/escort command |
| `AICommAircraftRebase` | Aircraft rebase to new airfield |

### Building Commands
| Command | Description |
|---------|-------------|
| `AICommBuSet` | Place building at position |
| `AICommBuildingUpgrade` | Upgrade building level |
| `AICommBuildingRemove` | Remove/demolish building |
| `AICommBuildingRepair` | Repair damaged building |
| `AICommBuildingRallyPoint` | Set building rally point |
| `AICommBuyUnit` | Purchase unit from building |
| `AICommCancelBuyUnit` | Cancel unit purchase |

### Hero Commands
| Command | Description |
|---------|-------------|
| `AICommHeroActivate` | Activate hero unit |
| `AICommHeroActivateAndBuy` | Activate and purchase hero |
| `AICommHeroAbilityActive` | Trigger hero active ability |
| `AICommHeroBatteryBuy` | Purchase hero battery/energy |
| `AICommHeroEnergyRefill` | Refill hero energy |

### Super Weapon Commands
| Command | Description |
|---------|-------------|
| `AICommNuclearLaunch` | Launch nuclear strike |
| `AICommImplosion` | Implosion weapon activation |
| `AICommMineLay` | Lay mine at position |
| `AICommMineSweep` | Sweep/clear mines |

### Battle Control Commands
| Command | Description |
|---------|-------------|
| `AICommSurrender` | Player surrenders |
| `AICommSurrenderSpectator` | Spectator surrender |
| `AICommBattleResume` | Resume paused battle |
| `AICommChatMessageSend` | Send in-battle chat message |
| `AICommBoostBuyAndApply` | Buy and apply boost |
| `AICommBoost` | Apply boost effect |
| `AICommBonusChest` | Collect bonus chest |
| `AICommDeployExtend` | Extend deployment zone |
| `AICommSettings` | Change battle settings |
| `AICommSquad` | Squad formation command |

### Synchronization Commands
| Command | Description |
|---------|-------------|
| `AICommCRCRequest` | Request CRC check from opponent |
| `AICommCRCAnswer` | Respond with CRC data |
| `AICommVerify` | Battle state verification |
| `AICommSyncTest` | Synchronization test |
| `AICommExecutionLags` | Report execution lag |
| `AICommTutorialFinished` | Tutorial completion signal |

### Win Condition Commands
| Command | Description |
|---------|-------------|
| `AICommWinPVE` | PvE victory declaration |
| `AICommWinPVP` | PvP victory declaration |
| `AICommWinPVPSingleSide` | Single-side PvP win |

### AIComm BATTLE_AI_COMMAND Constants
The game defines integer constants for each AIComm type:
- `BATTLE_AI_COMMAND_TYPE_MIN` to `BATTLE_AI_COMMAND_TYPE_MAX`
- `BATTLE_AI_COMMAND_NOT_VALID` - Invalid command sentinel
- `BATTLE_AI_COMMAND_AIRCRAFT_REBASE` through `BATTLE_AI_COMMAND_WIN_PVP_SINGLE_SIDE`

## Request/Answer Message Pairs

### Authentication and Session Messages
| Request | Answer | Description |
|---------|--------|-------------|
| `CHAT_LOGIN_REQUEST` | `CHAT_LOGIN_ANSWER` | Chat authentication |
| `CHOOSE_PROFILE_REQUEST` | `CHOOSE_PROFILE_ANSWER` | Profile selection |
| `ACTIVATE_PIN_REQUEST` | `ACTIVATE_PIN_ANSWER` | PIN activation |
| `CHECK_PROFILE_STATE_REQUEST` | - | Profile state check |
| `CONNECTION_CHECK_REQUEST` | `CONNECTION_CHECK_ANSWER` | Connection verification |
| `BIND_SOCIAL_PROFILE_REQUEST` | `BIND_SOCIAL_PROFILE_ANSWER` | Social profile binding |

### Battle Matchmaking Messages
| Request | Answer | Description |
|---------|--------|-------------|
| `BATTLE_LIST_REQUEST` | `BATTLE_LIST_ANSWER` | Available battle list |
| `BATTLE_3X3_RANDOM_REQUEST` | `BATTLE_3X3_RANDOM_ANSWER` | 3v3 random matchmaking |
| `BATTLE_3X3_RANDOM_CANCEL_REQUEST` | `BATTLE_3X3_RANDOM_CANCEL_ANSWER` | Cancel 3v3 matchmaking |
| `BATTLE_LOAD_PROGRESS_REQUEST` | `BATTLE_LOAD_PROGRESS_ANSWER` | Loading progress sync |
| `BATTLE_RESULT_REQUEST` | `BATTLE_RESULT_ANSWER` | Battle result query |
| `BATTLE_SESSION_RESTORE_REQUEST` | `BATTLE_SESSION_RESTORE_ANSWER` | Session restoration |
| `BATTLE_REPLAY_REQUEST` | `BATTLE_REPLAY_ANSWER` | Battle replay request |
| `BATTLE_LOGOUT_REQUEST` | - | Battle logout |
| `BATTLE_PASS_REWARD_REQUEST` | `BATTLE_PASS_REWARD_ANSWER` | Battle pass reward claim |

### Building and Upgrade Messages
| Request | Answer | Description |
|---------|--------|-------------|
| `ACCELERATE_UPGRADE_REQUEST` | `ACCELERATE_UPGRADE_ANSWER` | Speed up upgrade |
| `ADS_ACCELERATE_UPGRADE_REQUEST` | `ADS_ACCELERATE_UPGRADE_ANSWER` | Ad-based speed up |
| `CANCEL_UPGRADE_REQUEST` | `CANCEL_UPGRADE_ANSWER` | Cancel upgrade |
| `COMPLETE_ACTIVE_UPGRADE_REQUEST` | `COMPLETE_ACTIVE_UPGRADE_ANSWER` | Complete upgrade instantly |
| `BUY_EPISODE_UNLOCK_REQUEST` | `BUY_EPISODE_UNLOCK_ANSWER` | Purchase episode unlock |

### Clan Messages (40+ Messages)
| Request | Answer | Description |
|---------|--------|-------------|
| `CLAN_CREATE_REQUEST` | `CLAN_CREATE_ANSWER` | Create clan |
| `CLAN_GET_REQUEST` | `CLAN_GET_ANSWER` | Get clan info |
| `CLAN_LIST_REQUEST` | `CLAN_LIST_ANSWER` | List clans |
| `CLAN_INFO_REQUEST` | `CLAN_INFO_ANSWER` | Clan details |
| `CLAN_LEAVE_REQUEST` | `CLAN_LEAVE_ANSWER` | Leave clan |
| `CLAN_DISMISS_REQUEST` | `CLAN_DISMISS_ANSWER` | Dismiss clan |
| `CLAN_EXCLUDE_REQUEST` | `CLAN_EXCLUDE_ANSWER` | Exclude member |
| `CLAN_CHANGE_NAME_REQUEST` | `CLAN_CHANGE_NAME_ANSWER` | Change clan name |
| `CLAN_CHANGE_EMBLEM_REQUEST` | `CLAN_CHANGE_EMBLEM_ANSWER` | Change clan emblem |
| `CLAN_CHANGE_LEADER_REQUEST` | `CLAN_CHANGE_LEADER_ANSWER` | Transfer leadership |
| `CLAN_ADD_DEPUTY_REQUEST` | `CLAN_ADD_DEPUTY_ANSWER` | Add deputy |
| `CLAN_REMOVE_DEPUTY_REQUEST` | `CLAN_REMOVE_DEPUTY_ANSWER` | Remove deputy |
| `CLAN_RIGHTS_UPDATE_REQUEST` | `CLAN_RIGHTS_UPDATE_ANSWER` | Update member rights |
| `CLAN_SETTINGS_REQUEST` | `CLAN_SETTINGS_ANSWER` | Clan settings |
| `CLAN_ANNOUNCEMENT_REQUEST` | `CLAN_ANNOUNCEMENT_ANSWER` | Announcement |
| `CLAN_APPROVE_NAME_REQUEST` | `CLAN_APPROVE_NAME_ANSWER` | Approve name |
| `CLAN_APPROVE_DESCRIPTION_REQUEST` | `CLAN_APPROVE_DESCRIPTION_ANSWER` | Approve description |
| `CLAN_APPROVE_ANNOUNCEMENT_REQUEST` | `CLAN_APPROVE_ANNOUNCEMENT_ANSWER` | Approve announcement |
| `CLAN_DESCRIPTION_REQUEST` | `CLAN_DESCRIPTION_ANSWER` | Get description |
| `CLAN_HISTORY_REQUEST` | `CLAN_HISTORY_ANSWER` | Clan history |
| `CLAN_PARTICIPANTS_REQUEST` | `CLAN_PARTICIPANTS_ANSWER` | Member list |
| `CLAN_PARTICIPANT_STATE_LIST_REQUEST` | `CLAN_PARTICIPANT_STATE_LIST_ANSWER` | Member states |
| `CLAN_CALL_REQUEST` | `CLAN_CALL_ANSWER` | Clan call |
| `CLAN_CALL_AVAILABILITY_REQUEST` | `CLAN_CALL_AVAILABILITY_ANSWER` | Call availability |
| `CLAN_CALL_CONFIRMATION_REQUEST` | `CLAN_CALL_CONFIRMATION_ANSWER` | Confirm call |
| `CLAN_CALL_LIST_REQUEST` | `CLAN_CALL_LIST_ANSWER` | Call list |
| `CLAN_CALL_REMOVE_REQUEST` | `CLAN_CALL_REMOVE_ANSWER` | Remove call |
| `CLAN_REJECT_ALL_CALLS_REQUEST` | `CLAN_REJECT_ALL_CALLS_ANSWER` | Reject all calls |
| `CLAN_BATTLE_LIST_REQUEST` | `CLAN_BATTLE_LIST_ANSWER` | Clan battle list |
| `CLAN_CALLER_LEVEL_REQUEST` | `CLAN_CALLER_LEVEL_ANSWER` | Caller level |
| `CLAN_CALLER_RANK_REQUEST` | `CLAN_CALLER_RANK_ANSWER` | Caller rank |
| `CLAN_CHAT_JOIN_REQUEST` | `CLAN_CHAT_JOIN_ANSWER` | Join clan chat |
| `CLAN_CHAT_LEAVE_REQUEST` | `CLAN_CHAT_LEAVE_ANSWER` | Leave clan chat |
| `CLAN_CHAT_POST_REQUEST` | `CLAN_CHAT_POST_ANSWER` | Post to clan chat |
| `CLAN_CHAT_HISTORY_REQUEST` | `CLAN_CHAT_HISTORY_ANSWER` | Chat history |
| `CLAN_CHAT_UNREAD_POSTS_AMOUNT_REQUEST` | `CLAN_CHAT_UNREAD_POSTS_AMOUNT_ANSWER` | Unread count |
| `CLAN_DONATE_SETTINGS_REQUEST` | - | Donate settings |
| `CLAN_TAKE_BONUS_REQUEST` | - | Take clan bonus |
| `CLAN_SUPPLY_CONFIGURATION_REQUEST` | - | Supply configuration |
| `CLAN_SUPPLY_DEBUG_REQUEST` | `CLAN_SUPPLY_DEBUG_ANSWER` | Debug supply |

### Chat Messages
| Request | Answer | Description |
|---------|--------|-------------|
| `COMMON_CHAT_JOIN_REQUEST` | `COMMON_CHAT_JOIN_ANSWER` | Join global chat |
| `COMMON_CHAT_LEAVE_REQUEST` | `COMMON_CHAT_LEAVE_ANSWER` | Leave global chat |
| `COMMON_CHAT_POST_REQUEST` | `COMMON_CHAT_POST_ANSWER` | Post message |
| `COMMON_CHAT_HISTORY_REQUEST` | `COMMON_CHAT_HISTORY_ANSWER` | Chat history |
| `COMMON_CHAT_COMPLAINT_REQUEST` | `COMMON_CHAT_COMPLAINT_ANSWER` | Report user |
| `COMMON_CHAT_IGNORE_REQUEST` | `COMMON_CHAT_IGNORE_ANSWER` | Ignore user |
| `COUNTRY_CHAT_JOIN_REQUEST` | `COUNTRY_CHAT_JOIN_ANSWER` | Join country chat |
| `COUNTRY_CHAT_POST_REQUEST` | `COUNTRY_CHAT_POST_ANSWER` | Post country message |
| `COUNTRY_CHAT_COMPLAINT_REQUEST` | `COUNTRY_CHAT_COMPLAINT_ANSWER` | Report in country |
| `COUNTRY_CHAT_IGNORE_REQUEST` | `COUNTRY_CHAT_IGNORE_ANSWER` | Ignore in country |

### Competition Messages
| Request | Answer | Description |
|---------|--------|-------------|
| `CANCEL_JOIN_COMPETITIONS_REQUEST` | `CANCEL_JOIN_COMPETITIONS_ANSWER` | Cancel competition join |
| `CANCEL_JOIN_TOURNAMENT_REQUEST` | `CANCEL_JOIN_TOURNAMENT_ANSWER` | Cancel tournament join |
| `CANCEL_JOIN_MISSION_REQUEST` | `CANCEL_JOIN_MISSION_ANSWER` | Cancel mission join |
| `COMPETITION_COOP_BATTLE_INVITE_REQUEST` | `COMPETITION_COOP_BATTLE_INVITE_ANSWER` | Coop battle invite |
| `COMPETITION_COOP_BATTLE_INVITE_INFO_REQUEST` | `COMPETITION_COOP_BATTLE_INVITE_INFO_ANSWER` | Invite info |
| `COMPETITION_COOP_BATTLE_CANCEL_REQUEST` | `COMPETITION_COOP_BATTLE_CANCEL_ANSWER` | Cancel coop battle |
| `COMPETITION_COOP_MATCHING_ADD_REQUEST` | `COMPETITION_COOP_MATCHING_ADD_ANSWER` | Add to matching |
| `COMPETITION_COOP_MATCHING_REMOVE_REQUEST` | `COMPETITION_COOP_MATCHING_REMOVE_ANSWER` | Remove from matching |
| `COMPETITION_COOP_MATCHING_LIST_REQUEST` | `COMPETITION_COOP_MATCHING_LIST_ANSWER` | List matching |
| `COMPETITION_COOP_CANCEL_MATCHING_REQUEST` | `COMPETITION_COOP_CANCEL_MATCHING_ANSWER` | Cancel matching |
| `COMPETITION_COOP_BAN_REQUEST` | `COMPETITION_COOP_BAN_ANSWER` | Ban from coop |
| `COMPETITION_DEBUG_REQUEST` | `COMPETITION_DEBUG_ANSWER` | Debug competition |
| `COMPETITION_HALL_OF_FAME_REQUEST` | `COMPETITION_HALL_OF_FAME_ANSWER` | Hall of fame |
| `COMPETITION_RATING_PROFILE_REQUEST` | `COMPETITION_RATING_PROFILE_ANSWER` | Profile rating |
| `COMPETITION_RATING_CLAN_REQUEST` | `COMPETITION_RATING_CLAN_ANSWER` | Clan rating |
| `COMPETITION_UPDATE_REQUEST` | - | Update competition |

### Billing Messages
| Request | Answer | Description |
|---------|--------|-------------|
| `BUY_GOODS_REQUEST` | `BUY_GOODS_ANSWER` | Purchase goods |
| `CONSUME_PURCHASE_REQUEST` | `CONSUME_PURCHASE_ANSWER` | Consume purchase |
| `BILLING_NOTIFICATION` | - | Billing event notification |

### Profile Messages
| Request | Answer | Description |
|---------|--------|-------------|
| `ADD_FRIEND_REQUEST` | `ADD_FRIEND_ANSWER` | Add friend |
| `CHANGE_NAME_REQUEST` | `CHANGE_NAME_ANSWER` | Change display name |
| `APPROVE_NAME_REQUEST` | `APPROVE_NAME_ANSWER` | Approve name |
| `CHANGE_LOCALE_REQUEST` | `CHANGE_LOCALE_ANSWER` | Change language |
| `CHANGE_COUNTRY_REQUEST` | `CHANGE_COUNTRY_ANSWER` | Change country |
| `CHANGE_LANGUAGE_CHAT_REQUEST` | `CHANGE_LANGUAGE_CHAT_ANSWER` | Change chat language |
| `ACHIEVEMENT_READ_REQUEST` | `ACHIEVEMENT_READ_ANSWER` | Read achievement |
| `ACHIEVEMENT_STATISTICS_REQUEST` | `ACHIEVEMENT_STATISTICS_ANSWER` | Achievement stats |
| `BOOST_CONVERT_REQUEST` | `BOOST_CONVERT_ANSWER` | Convert boost |
| `BOOSTS_PREFERRED_ADD_REQUEST` | `BOOSTS_PREFERRED_ADD_ANSWER` | Add preferred boost |
| `BOOSTS_PREFERRED_RESET_REQUEST` | `BOOSTS_PREFERRED_RESET_ANSWER` | Reset preferred boost |
| `BLACK_MARKET_CONFIGURATION_UPDATE_REQUEST` | `BLACK_MARKET_CONFIGURATION_UPDATE_ANSWER` | Update black market |
| `CRATE_REQUEST` | `CRATE_WINS_ANSWER` | Open crate / crate wins |
| `CRATE_DATE_REWIND_REQUEST` | `CRATE_DATE_REWIND_ANSWER` | Rewind crate date |

### Ads Messages
| Request | Answer | Description |
|---------|--------|-------------|
| `ADS_REQUEST` | `ADS_ANSWER` | Request ad |
| `ADS_REWARD_REQUEST` | `ADS_REWARD_ANSWER` | Claim ad reward |
| `ADS_REWIND_REQUEST` | - | Rewind ad |
| `ADS_HIGH_REQUEST_TIMEOUT` | - | Ad timeout config |

### Push/Notification Messages
| Message | Direction | Description |
|---------|-----------|-------------|
| `BattleFinishNotification` | Server->Client | Battle finished |
| `BattleButtonStateNotification` | Server->Client | Battle button state change |
| `BattleLoadProgressNotification` | Server->Client | Load progress broadcast |
| `BattleLogicDesyncNotification` | Server->Client | Desync detected |
| `ActiveUpgradeNotification` | Server->Client | Upgrade completed |
| `AchievementReachedNotification` | Server->Client | Achievement unlocked |
| `AvailableQuestNotification` | Server->Client | Quest available |
| `BillingNotification` | Server->Client | Purchase event |
| `ActionEventEndNotification` | Server->Client | Event ended |
| `ActionEventRewardNotification` | Server->Client | Event reward |
| `AppointStartMessage` | Server->Client | Battle start appointment |
| `BoxRewardMessage` | Server->Client | Box/reward notification |
| `CLAN_SUPPLY_RESTART_MESSAGE` | Server->Client | Supply restart |
| `CLIENT_GO_TO_BATTLE_NOTIFICATION` | Server->Client | Go to battle push |
| `ACCOUNT_REGISTRATION_DATE_CHANGE_PUSH_MESSAGE` | Server->Client | Registration date change |
| `AppMetricaDuidReceivedMessage` | Internal | Metrica device ID |

## Special Message Types

### Batch Messages
- `BATCH_MESSAGE_TYPE` - Multiple messages packed into single transmission
- `COMPLEX_MESSAGE` - Multi-part message
- `COMPLEX_BATTLE_MESSAGE` - Multi-part battle message

### Timeout Constants
- `BattleReceiveMessageTimeoutDefault` - Default message receive timeout
- `BattleSendMessageTimeout` - Message send timeout
- `BattleSessionRestoreResponseTimeout` - Session restore timeout
- `BillingResponseTimeout` - Billing response timeout
- `AnswerReceiveTimeout` - Generic answer timeout
- `CatalogRequestsTimeout` - Catalog request timeout
- `AdsHighRequestTimeout` - High-priority ad timeout
- `AdvertisingInfoRequestDuration` - Ad info request duration

### Connection Check
- `CHECK_CONNECTION_MESSAGE_BYTE_SIZE_DEFAULT` - Connection check message size
- `BattlePvPSocketHeartbeatTimeout` - PvP heartbeat timeout
- `BattlePvESocketHeartbeatTimeout` - PvE heartbeat timeout

## Client-Server Flow (CS) Classes

The CS namespace contains the orchestration layer for network operations:

| Class | Purpose |
|-------|---------|
| `CSMainSendRequestAndWaitReadyToActAnswer` | Send request and wait for ready-to-act answer |
| `CSMainWaitReadyToActAnswer` | Wait for ready-to-act signal |
| `CSMainPinRequestWaiter` | Wait for PIN request completion |
| `CSMainGoToBattle` | Transition to battle from main menu |
| `CSMainReadyToBattleWaiter` | Wait until ready for battle |
| `CSMainReturnFromBattle` | Return from battle to main menu |
| `CSMainReturnFromBattleReplay` | Return from battle replay |
| `CSMainReturnFromBattleWaiter` | Wait for return from battle |
| `CSMainBattleBaseDictionaryReceiver` | Receive battle base dictionary |
| `CSMainSessionRestoreAnswerReceiver` | Receive session restore answer |
| `CSBattleLoginToBattle` | Login to battle server |
| `CSBattleLogon` | Battle authentication |
| `CSBattleRun` | Run battle |
| `CSBattleRunDeactivate` | Deactivate battle run |
| `CSBattleRunWithoutServer` | Run offline battle |
| `CSBattleSessionRestore` | Restore battle session |
| `CSBattleSessionRestoreAnswerReceiver` | Session restore receiver |
| `CSBattleStartingFailed` | Handle battle start failure |
| `CSBattleInitializeWaiter` | Wait for battle initialization |
| `CSBattleEndingWaiter` | Wait for battle ending |
| `CSBattleFinish` | Process battle finish |
| `CSLoadMapResources` | Load map resources |
| `CSLoginToBattle` | Login to battle |
| `CSPingBattleHosts` | Ping battle hosts |
| `CSPingBattleHostsOnMain` | Ping hosts from main menu |
| `CSAppointStartBattleReceiver` | Receive battle start appointment |
| `CSStartBattleNotificationReceiver` | Receive start battle notification |
| `CSStartBattleCancellationNotificationWaiter` | Wait for cancellation |
| `CSHttpSendRequestAndReceiveResponse` | HTTP message transport |
| `CSPushLaunchMessageSender` | Push notification sender |
| `CSRequestPostNotificationsPermissionWindow` | Permission request window |
