# Art of War 3 - Recreation-Oriented Mapping

## Overview

This document provides per-system recreation guides with pseudocode and modern implementation recommendations. Each system is documented with: (1) what was discovered through reverse engineering, (2) the logical architecture that must be recreated, (3) pseudocode for key algorithms, and (4) modern technology recommendations for a recreation project.

## System 1: Combat Engine

### Discovery Summary

The combat system processes damage through a multi-stage pipeline: weapon firing generates projectiles with specific trajectory types, projectiles impact targets, damage is calculated against armor values with type-specific modifiers, and health is updated. The system supports damage bonuses (GAI_COMMAND_DAMAGE_BONUS) and damage reduction (GAI_COMMAND_DAMAGE_REDUCE) modifiers from the AI scripting layer. Three armor types exist with different resistance profiles against the six-plus weapon categories.

### Architecture for Recreation

```
CombatEngine
  +-- WeaponManager
  |     +-- WeaponComponent (per unit)
  |           +-- DamageBase: float
  |           +-- Range: float
  |           +-- TrajectoryType: enum
  |           +-- AttackSpeed: float
  +-- DamageCalculator
  |     +-- ArmorResolver
  |     |     +-- LightArmor (infantry)
  |     |     +-- MediumArmor (vehicles)
  |     |     +-- HeavyArmor (buildings)
  |     +-- ModifierStack
  |           +-- DamageBonus modifiers
  |           +-- DamageReduce modifiers
  +-- HealthManager
        +-- Per-entity health tracking
        +-- Death events
        +-- Destruction callbacks
```

### Pseudocode

```python
class CombatEngine:
    def process_tick(self, dt: float):
        for unit in self.active_units:
            if unit.weapon.is_ready():
                target = unit.find_target_in_range()
                if target:
                    projectile = unit.weapon.fire(target)
                    self.projectile_manager.add(projectile)
        
        for projectile in self.projectile_manager.update(dt):
            if projectile.reached_target():
                damage = self.calculate_damage(
                    projectile.damage,
                    projectile.weapon_type,
                    target.armor_type,
                    target.armor_value
                )
                damage *= sum(unit.damage_bonus_modifiers)
                damage *= (1.0 - sum(unit.damage_reduce_modifiers))
                target.health -= damage
                if target.health <= 0:
                    self.on_unit_destroyed(target)
    
    def calculate_damage(self, base_damage, weapon_type, armor_type, armor_value):
        type_multiplier = ARMOR_TABLE[weapon_type][armor_type]
        reduction = armor_value / (armor_value + DAMAGE_CONSTANT)
        return base_damage * type_multiplier * (1.0 - reduction)
```

### Modern Implementation Recommendations

- **Language**: C# with .NET 8 or Rust for performance-critical combat calculations
- **ECS Pattern**: Use Entity Component System (Arch, Unity DOTS, or Flecs) for efficient unit iteration
- **Determinism**: Use fixed-point arithmetic (Fix64) for deterministic simulation across platforms
- **Networking**: Integrate combat ticks with lockstep protocol, hash combat state each tick

## System 2: AI Command System (AIComm)

### Discovery Summary

The AIComm layer transmits battle commands between clients and server using a paired serializer/deserializer (STSerializer/STDeserializer) pattern. Commands include: BuyUnit, CancelBuyUnit, BuildingUpgrade, BuildingRepair, BuildingRemove, BuildingRallyPoint, AttackSet, Boost, CRC verification, AircraftRebase, BattleResume, BonusChest, and more. Each command has both a serializer and deserializer implementation using the GearGamesByteBuffer format.

### Pseudocode

```python
class AICommSystem:
    def queue_command(self, command: AICommCommand):
        self.command_queue.append((self.current_tick, command))
    
    def flush_commands(self) -> bytes:
        buffer = ByteBuffer()
        buffer.write_int32(len(self.command_queue))
        for tick, cmd in self.command_queue:
            buffer.write_int32(tick)
            buffer.write_int32(cmd.type_id)
            self.serializer.serialize(cmd, buffer)
        self.command_queue.clear()
        return encrypt(buffer.to_bytes())
```

### Modern Implementation Recommendations

- **Protocol**: Use Protocol Buffers or FlatBuffers for efficient cross-platform serialization
- **Networking**: Netcode for GameObjects (Unity) or Nakama server for authoritative multiplayer
- **Command Pattern**: Implement as an event-sourced system with replay capability
- **CRC/Hashing**: Use xxHash for fast CRC computation on game state

## System 3: GAI Scripting Engine

### Discovery Summary

The GAI scripting engine drives campaign missions and tutorials. It uses XML-based script files parsed by GAIXmlFileHelper. The engine supports 144+ command types including flow control (loops, jumps, flags, counters), tutorial management, camera control, building/army management, and objective tracking. The system includes dependency collectors that track when commands can be garbage collected.

### Pseudocode

```python
class GAIEngine:
    def __init__(self):
        self.flags = {}
        self.counters = {}
        self.checkpoints = {}
    
    def update(self, dt: float):
        while self.current_node:
            command = self.current_node.command
            if command.type == "FLAG":
                self.flags[command.name] = command.value
                self.advance()
            elif command.type == "FLAG_JUMP":
                if self.flags.get(command.condition_flag) == command.expected_value:
                    self.current_node = self.find_node(command.target_label)
                else:
                    self.advance()
            elif command.type == "TUTORIAL_FINISH_CONDITION_UNITS_SELECTED":
                if self.game_state.are_units_selected(command.unit_type, command.count):
                    self.advance()
                else:
                    break
            else:
                self.execute_immediate(command)
                self.advance()
```

### Modern Implementation Recommendations

- **Scripting Language**: Use Lua or a custom DSL with YAML/JSON definition files
- **Visual Editor**: Build a node-based visual editor like Unity Timeline
- **Hot Reload**: Support hot-reloading of scripts for rapid iteration
- **State Serialization**: Make GAI state serializable for save/load and replay

## System 4: Network Protocol

### Discovery Summary

The network stack uses custom TCP transport with RSA/DES encryption. The GearGamesByteBuffer provides read/write operations for the binary protocol. The crypto layer includes RSA for key exchange and DES for symmetric data encryption. A VPN detection system (CheckNeedVpn) adapts to restricted network environments.

### Pseudocode

```python
class NetworkClient:
    def perform_handshake(self):
        server_pubkey = self.socket.receive()
        self.session_key = DES.generate_key()
        encrypted_key = RSA.encrypt(self.session_key, server_pubkey)
        self.socket.send(encrypted_key)
    
    def send_message(self, message):
        buffer = GearGamesByteBuffer()
        buffer.write_int32(message.type_id)
        message.serializer.serialize(buffer)
        encrypted = DES.encrypt(buffer.to_bytes(), self.session_key)
        frame = struct.pack('>I', len(encrypted)) + encrypted
        self.socket.send(frame)
```

### Modern Implementation Recommendations

- **Transport**: Use WebSocket or QUIC for modern transport with NAT traversal
- **Encryption**: Replace RSA/DES with TLS 1.3 or Noise Protocol Framework
- **Serialization**: Use FlatBuffers for zero-copy deserialization
- **Server**: Implement with Go, Rust, or C# for high-concurrency TCP handling

## System 5: Economy and Resource Management

### Discovery Summary

Six resource types drive the economy: Gold (primary), Uranium (secondary), Blueprints (hero upgrades), Energy (building grid), Skill Points (hero abilities), and Credits (premium). The energy grid system limits building count through power generation/consumption balance. Buildings produce resources on timers, and the production system uses queuing with acceleration options.

### Pseudocode

```python
class EconomySystem:
    def update(self, dt: float):
        for building in self.active_buildings:
            if building.is_producing and building.has_energy:
                building.production_progress += dt * building.production_speed
                if building.production_progress >= building.production_time:
                    self.complete_production(building)
        
        total_production = sum(b.energy_output for b in self.energy_producers)
        total_consumption = sum(b.energy_input for b in self.energy_consumers)
        self.energy_balance = total_production - total_consumption
```

### Modern Implementation Recommendations

- **Server Authority**: All resource calculations must be server-side to prevent cheating
- **Event-Driven**: Use event sourcing for resource changes with audit trail and replay
- **Caching**: Cache frequently accessed resource values with invalidation on change
- **Anti-Cheat**: Validate all client resource requests server-side

## System 6: Unit Component Architecture

### Discovery Summary

Units use a component-based architecture where behavior is composed from multiple components. At least 57 component types were identified with 25+ interface contracts. Components include weapon systems, movement, health, armor, AI behavior, hero abilities, and fog of war interaction.

### Modern Implementation Recommendations

- **ECS Framework**: Use Arch (C#), Flecs (C), or Legion (Rust) for high-performance ECS
- **Prototype Pattern**: Define units as data (JSON/ScriptableObject) rather than code
- **Interface Contracts**: Use Rust traits or C# interfaces for component behavior contracts
- **Hot-Reload**: Support runtime component modification for debugging and modding

## Cross-System Integration Notes

### Deterministic Simulation

All gameplay systems must produce identical results on all clients given the same inputs. This requires:
1. Fixed-point arithmetic (no floating-point variance)
2. Deterministic random number generation (shared seed)
3. Identical update order (sorted entity lists)
4. CRC verification each tick

### Network Integration

The AIComm command system is the bridge between gameplay and networking:
1. All player actions generate AIComm commands
2. Commands are batched per tick and serialized
3. Both clients send command sets to server
4. Server validates, combines, and broadcasts
5. Clients execute both command sets in identical order
6. CRC hashes verify state consistency

### Save/Load Integration

Game state serialization must capture all unit positions, health, and component states, all building states and production queues, resource balances and energy grid state, GAI script execution state (flags, counters, checkpoints), AIComm command queue state, and fog of war visibility state per player.
