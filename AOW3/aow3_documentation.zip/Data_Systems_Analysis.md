# Data Systems Analysis - Art of War 3: RTS Strategy Game

## Overview

Art of War 3 implements a sophisticated data management architecture spanning serialization, save systems, player profiles, configuration dictionaries, and resource management. The game uses a custom binary serialization framework (STSerializer/STDeserializer) for all network and persistence operations, Unity Addressables for asset management, and a dictionary-based configuration system for game balance data. This document analyzes each data subsystem, its storage format, and how data flows through the application.

## Serialization Framework

### STSerializer/STDeserializer Pattern

The game implements a custom binary serialization framework with 2,598 paired serializer/deserializer classes. Every data structure that crosses the network boundary or requires persistence has dedicated serializer implementations, avoiding reflection-based serialization for performance.

**Pattern Structure**:
```
[TypeName]STSerializer   - Serializes the type to binary
[TypeName]STDeserializer - Deserializes binary to the type
```

**Base Classes**:
- `AbstractErrorSerializer` - Base error serializer
- `AnySerializer` - Generic/fallback serializer
- `BooleanSerializer` / `ByteSerializer` / `BuiltinTypesSerializer` - Primitive serializers
- `AlphaKeysSerializer` - Unity-specific type serialization
- `AOWErrorSerializerV1` / `AOWErrorSerializerForSenderV1` - Versioned error serialization

**Serialization Infrastructure**:
- `ApplySerializerSettings` - Configures serializer behavior
- `SerializerTypeName` / `SerializerBaseTypeName` - Type identification
- `DeserializeRootElementName` - XML/JSON root element naming

### GearGamesByteBuffer

The `GearGamesByteBuffer` class in `com.geargames` provides the low-level binary buffer for all serialization operations. It follows the Java NIO ByteBuffer pattern:

**API Methods**:
- `get()` / `put()` - Primitive read/write
- `flip()` - Switch from write to read mode
- `mark()` / `reset()` - Position bookmarking
- `duplicate()` - Create buffer copy
- `size()` - Get buffer size
- `Limit` (get/set) - Buffer limit access

**Usage Pattern**:
1. Create buffer with estimated size
2. Write fields using `put()` methods
3. `flip()` to prepare for reading
4. Transmit or store buffer
5. On receiving end, read fields using `get()` methods

### Version Handling

Serialization includes version awareness through:
- `AOWErrorSerializerV1` - Versioned error format
- `BattleLogicVersion_290` - Battle logic version identifier
- `BattleContextVersion` - Battle context versioning

## Save System

### Profile Data

Player profiles are managed through the profile message system:

**Profile Messages**:
- `CHOOSE_PROFILE_REQUEST/ANSWER` - Profile selection
- `AccountSTSerializer/STDeserializer` - Account data serialization
- `AvatarSTSerializer/STDeserializer` / `AvatarElementSTSerializer/STDeserializer` - Avatar customization
- `AowLocaleSTSerializer/STDeserializer` - Locale preference
- `ProfileSTSerializer/STDeserializer` (implied by message types)

**Profile Data Includes**:
- Player name and avatar
- Locale/country preferences
- Career progress (`CareerStone`, `CareerUp`, `CareerRewardItem`)
- Achievement progress (`AchievementConfiguration`, `AchievementLevel`)
- Battle statistics (`BattlesPlayed`, `BattlesTotal`)
- Hero collection (`HeroCards`, `HeroInfo`, `HeroSlotModels`)
- Boost inventory (`BoostActive`, `BoostBonusInfo`)
- Battle pass progress (`BattlePassInfo`, `BattlePassProfileInfo`)

### Battle State Persistence

Battle state can be persisted and restored:

**Session Restore**:
- `BattleSessionRestoreRequest/Answer` - Restore after disconnect
- `BattleInitializeSnapshot` - Snapshot-based initialization
- `BattleSessionRestoreAttemptCount` - Retry limit
- `BattleSessionRestoreResponseTimeout` - Timeout
- `BattleResumptionDynamic` / `BattleResumptionInfo` - Resumption configuration

**Replay System**:
- `BattleReplayRequest/Answer` - Replay request
- `BattleReplaySTSerializer/STDeserializer` - Replay data serialization
- `BattleReplayType` - Replay format
- `IBattleReplayRestartable.OnGameObjectsActivated/OnSceneReset` - Replay restart interface

## Configuration System

### Battle Base Dictionary

The `BattleBaseDictionary` is the central configuration data store for battle-related game balance:

**Related Types**:
- `BattleBaseDictionaryDataSource` - Data source for dictionary
- `BattleBaseDictionaryInfo` - Dictionary metadata
- `BattleBaseDictionarySTSerializer/STDeserializer` - Dictionary serialization
- `BaseDictionarySTSerializer/STDeserializer` - Base dictionary type
- `CSMainBattleBaseDictionaryReceiver` - Network receiver
- `LoadBattleBaseDictionary` - Dictionary loading

**Dictionary Contents** (inferred from serializer pairs):
- `AbilityTypeSTSerializer` - Ability type definitions
- `AuraTypeSTSerializer` - Aura type definitions
- `BatterySTSerializer` - Battery/energy definitions
- `BoostTypeSTSerializer` - Boost type definitions
- `BuffTypeSTSerializer` - Buff type definitions
- `BuildingTypeSTSerializer` - Building type definitions
- `BuildingLevelTypeSTSerializer` - Building level definitions
- `BulletSTSerializer` - Bullet/projectile definitions
- `WeaponType` enumerations
- `ArmorType` definitions

### Configuration Messages

Configuration updates are delivered via network messages:

- `BaseConfigurationSTSerializer/STDeserializer` - Base configuration
- `AchievementConfigurationSTSerializer/STDeserializer` - Achievement config
- `AchievementConfigurationUpdateSTSerializer/STDeserializer` - Achievement updates
- `BillingConfigurationSTSerializer/STDeserializer` - Billing/pricing config
- `BlackMarketConfigurationSTSerializer/STDeserializer` - Black market config
- `BlackMarketConfigurationUpdateRequest/Answer` - Black market updates
- `BattleNetworkConfigurationSTSerializer/STDeserializer` - Network config
- `AdsParamsSTSerializer/STDeserializer` - Ad parameters
- `AdsSwitcherSTSerializer/STDeserializer` - Ad switching logic

### Client Remote Parameters

`ClientRemoteParams` in `com.geargames.aow.config` provides server-controlled configuration:
- `BattleGraphicsPreset` - Graphics quality
- `BattleGraphicsLevel` - Graphics level
- `BattleQualityLevel` - Quality settings
- Various feature toggles

## Resource Management System

### Addressable Resource System

The game uses Unity's Addressable Asset System with custom resource management:

**Resource Service Interfaces**:
- `IBatteriesResourceService` - Battery resource queries with `Collection` and `GetValue` properties
- `IBlueprintsResourceService` - Blueprint resource queries with `Collection` and `GetValue` properties

**Resource Loading Pipeline**:
- `BattleResourcesLoader` - Main resource loader
- `BattleResourcesLoaderFromAssetBundle` - Asset bundle source
- `BattleMapsResourceLoader` - Map-specific loader
- `AbstractResourceLoader` / `AbstractResourceLoaderAsync` - Base loaders
- `ByteResourceLoaderAsync` - Byte-level resource loading
- `CSAbstractResourceLoader` / `CSAbstractByteResourceLoader` / `CSAbstractSerializableResourceLoader<T>`

**Resource Dispatcher**:
- `DispatcherResources` namespace with sub-components:
  - `ClientResourceAdapters` - Platform-specific adapters
  - `DownloadConditions` - Conditional download logic
  - `ResourceAvailableCheckers` - Availability verification
  - `ResourceLoadingProgresses` - Progress tracking
  - `ResourceSettings` - Configuration

**Resource Categories**:
- `ConfigResourceCategories` - Configuration resource groups
- `DictionariesResourceInfos` - Dictionary resource information
- `BASE_RESOURCE_CATEGORY_SETTINGS` - Default category settings
- `ResourceType` enumeration

### Resource Caching

- `CacheResource` / `CacheResourceNotFound` / `CacheResourceSaveDiskFull` / `CacheResourceSerializationError`
- `CacheResourcesFound` / `CachedResources` / `CachedResourcesPath` / `CachedResourceInfo`
- `ResourcesCache` in `com.geargames.common.resources`
- `HasResourcesOnLocalStorage` - Local storage check

### Resource Warming

Resource pre-warming improves load times:
- `WarmResources` / `WarmResourcesAsync` / `WarmResourceOperationAsync`
- `WaitResourceWarmTask`
- `BattleGameObjectPoolsWarmed`
- `InitializeBattlePoolsOptimized`
- `BattleUnitModificationResourceWarmer`
- `RetryResourceLoadingCount` - Retry configuration

## Data Flow Architecture

### Initialization Flow

1. App launches with `MultiDexApplication` (Android)
2. Firebase auto-init disabled (`firebase_messaging_auto_init_enabled: false`, `firebase_analytics_collection_enabled: false`, `firebase_crashlytics_collection_enabled: false`)
3. Logon scene loads, connects to login server
4. `AddressFinder` resolves server endpoints
5. Authentication completes, profile data loaded
6. `BaseConfiguration` and dictionaries downloaded
7. Main menu scene loads with player data
8. Resources pre-warmed in background

### Battle Data Flow

1. Player selects battle template
2. Matchmaking creates battle session
3. Client connects to battle server
4. `BattleBaseDictionary` loaded/verified
5. Map resources loaded via `BattleMapsResourceLoader`
6. `BattleInitialize` receives initial game state
7. `BattleCurrentTickProvider` starts tick simulation
8. `AICommandsAtTick` exchanged each tick
9. `CRCInfo` verified periodically
10. `BattleFinish` signals end
11. `BattleResultRequest/Answer` delivers results
12. Resources unloaded, return to main menu

### Configuration Update Flow

1. Server sends configuration update notification
2. Client receives via appropriate message handler
3. `STDeserializer` parses update data
4. Configuration applied to game systems
5. Feature toggles evaluated
6. UI updated to reflect changes

## Data Model Patterns

### Entity Serialization

Every major entity type follows a consistent serialization pattern:

**Account Data**:
- `AccountSTSerializer/STDeserializer`
- `AowLocaleSTSerializer/STDeserializer`
- `AvatarSTSerializer/STDeserializer` / `AvatarElementSTSerializer/STDeserializer`

**Battle Data**:
- `BattleSTSerializer/STDeserializer`
- `BattleMapSTSerializer/STDeserializer`
- `BattleCellSTSerializer/STDeserializer` / `BattleCellBasicSTSerializer/STDeserializer`
- `BattleSideSTSerializer/STDeserializer`
- `BattleAllianceSTSerializer/STDeserializer`
- `BattleTemplateSTSerializer/STDeserializer`

**Entity Data**:
- `BuildingSTSerializer/STDeserializer` / `BuildingTypeSTSerializer/STDeserializer` / `BuildingLevelTypeSTSerializer/STDeserializer`
- `AbilitySTSerializer/STDeserializer` / `AbilityTypeSTSerializer/STDeserializer`
- `AuraSTSerializer/STDeserializer` / `AuraTypeSTSerializer/STDeserializer`
- `BoostSTSerializer/STDeserializer` / `BoostTypeSTSerializer/STDeserializer`

**Message Data**:
- All Request/Answer pairs have matching serializer pairs
- Notifications have single serializer pairs (server-to-client only)
- Batch messages contain arrays of serialized messages

### Nested Data Structures

Complex data types use nested serialization:
- `CRCInfoSide` contains `CRCInfoBuilding[]` and `CRCInfoUnit[]`
- `BattleAllianceDescription` contains `BattleSide[]`
- `BattleMissionDescription` contains `BattleObjective[]`
- `BattlePassInfo` contains `BattlePassReward[]` and `BattlePassScale[]`
- `BlackMarketConfiguration` contains `BlackMarketGoods[]`
