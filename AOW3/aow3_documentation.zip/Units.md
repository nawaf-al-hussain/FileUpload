# Units - Art of War 3: RTS Strategy Game

## Overview

Art of War 3 features a comprehensive unit system with distinct unit types organized across two factions (sides), each with unique hero units, infantry, vehicles, aircraft, and naval units. The unit system uses a prototype-based architecture where `UnitPrototype` and `UnitType` define the base configuration for each unit, with runtime instances (`ClientUnit`) inheriting properties and allowing modifications. Units are produced from specific building types, can be upgraded through a modification system, and interact with the battlefield through a component-based architecture.

## Hero Units

Heroes are the most powerful units in the game, featuring unique active and passive abilities, special weapons, and enhanced stats. Based on the VFX asset catalog and code identifiers, the following heroes are identified:

### Wasp
A hovercraft-type hero with acid and rocket weapons. The Wasp specializes in area denial through acid pools and long-range rocket attacks.

**Identifiers from code**:
- `hero_fire_wasp_acid`, `hero_fire_wasp_rocket` - Attack types
- `hero_bul_wasp_acid`, `hero_bul_wasp_rocket` - Projectile types
- `hero_impact_wasp_acid`, `hero_impact_wasp_rocket_ground/veh/water` - Impact effects
- `hero_wasp_collecting_ground/water` - Resource collection
- `hero_wasp_death` - Death animation
- `wasp_acid`, `wasp_aura`, `wasp_passive` - Aura/passive effects
- `bul_wasp_s1` - Basic projectile
- `fx_wasp_spot` - Spot/targeting indicator

**Weapons**: Acid spray (area denial), Rocket launcher (ranged attack)
**Ability Type**: Area-denial with acid pools, rocket barrage active ability
**Movement**: Hover (traverses both ground and water)

### Beholder
A flying surveillance/combat hero with laser weapons and a scanner ability. The Beholder provides intelligence and precision strike capability.

**Identifiers from code**:
- `hero_fire_beholder_scanner`, `hero_fire_beholder_lazer` - Attack types
- `hero_bul_beholder_lazergun` - Laser projectile
- `hero_impact_beholder_lazer_ground/inf/veh/water` - Laser impact effects
- `hero_impact_beholder_scanner` - Scanner effect
- `hero_beholder_death` - Death animation
- `hero_beholder_fire` - Fire effect
- `hero_beholder_turbine_idle/move` - Turbine effects
- `anim_hero_impact_beholder_scanner` - Scanner animation
- `material_beholder_scanner` - Scanner material
- `sprite_beholder_scanner_alpha` - Scanner sprite

**Weapons**: Laser gun (precision attack), Scanner (reconnaissance ability)
**Ability Type**: Scanner reveals fog of war or enemy positions; laser provides precision damage
**Movement**: Air (helicopter with turbine VFX)

### Salamander
An amphibious hero with rocket weapons and submerge capability. The Salamander excels in naval and coastal combat.

**Identifiers from code**:
- `hero_fire_salamander_rocket` - Attack type
- `hero_bul_salamander_rocket` / `bul_rocket_small_salamander` - Projectile
- `hero_impact_salamander_rocket_air/ground/water` - Impact effects
- `hero_salamander_death`, `hero_salamander_death_water` - Death effects
- `hero_salamander_emersion` - Submerge/emerge effect
- `hero_salamander_turbo` - Turbo/boost effect
- `waves_sides_salamander` - Water wave effect

**Weapons**: Small rockets (ranged attack)
**Ability Type**: Submerge/emerge for stealth; turbo speed boost
**Movement**: Amphibious (ground and water with emersion effects)

### Atlas/Atlant
A heavy tank hero with gun and barrage weapons plus a shield/immortality ability. The Atlas is the tankiest hero with defensive capabilities.

**Identifiers from code**:
- `hero_fire_atlant_gun`, `hero_fire_atlant_barrage` - Attack types
- `hero_bul_atlant_gun`, `hero_bul_atlant_barrage` - Projectile types
- `hero_impact_atlant_gun_air/ground/veh/water` - Gun impact
- `hero_impact_atlant_barrage_ground/veh/water` - Barrage impact
- `hero_death_atlant_first`, `hero_death_atlant_second` - Two-phase death
- `eff_atlant_immortality` - Immortality/shield effect
- `hero_atlant_barrage_deactivate` - Barrage deactivation
- `ATLANT_ABSOLUTE_DAMAGE_REDUCTION` - Damage reduction constant
- `ATLANT_ANGLE_FRONTAL_DEFENSE` - Frontal defense angle
- `ATLANT_DAMAGE_THRESHOLD` - Damage threshold for ability
- `AtlantAbsoluteDamageReductionAbilityParamDescription`
- `AtlantAngleFrontalDefenseAbilityParamDescription`
- `AtlantDamageThresholdAbilityParamDescription`
- `AtlantMainClientWeapon`, `AtlantActiveClientWeapon`
- `fx_atlant_shield` - Shield visual

**Weapons**: Main gun (direct fire), Barrage (area bombardment)
**Ability Type**: Immortality shield (temporary invulnerability), Frontal defense angle, Absolute damage reduction, Damage threshold
**Movement**: Ground (heavy tank)

**Key Constants**:
- `ATLANT_ABSOLUTE_DAMAGE_REDUCTION` - Flat damage reduction value
- `ATLANT_ANGLE_FRONTAL_DEFENSE` - Angle within which frontal defense applies
- `ATLANT_DAMAGE_THRESHOLD` - Minimum damage to trigger ability

### CoilTank
An electric tank hero with ball lightning, electrode, and nova weapons. The CoilTank specializes in area-of-effect electrical damage.

**Identifiers from code**:
- `hero_fire_coiltank_ball`, `hero_fire_coiltank_electrodes`, `hero_fire_coiltank_lightning`, `hero_fire_coiltank_nova` - Attack types
- `hero_bul_coiltank_ball`, `hero_bul_coiltank_lightning` - Projectile types
- `hero_impact_coiltank_ball_air/damage/ground/inf/veh/water` - Ball impact
- `hero_impact_coiltank_lightning_air/ground/inf/veh/water` - Lightning impact
- `hero_impact_coiltank_nova_air/ground/inf/veh` - Nova impact
- `hero_impact_coiltank_electrodes`, `hero_impact_coiltank_stun` - Electrode/stun effects
- `hero_charge_coiltank_ball`, `hero_charge_coiltank_nova` - Charge effects
- `hero_idle_coiltank_coil`, `hero_idle_coiltank_electrodes` - Idle effects
- `COILTANK_BALL_LIGHTNING_DAMAGE` - Ball lightning damage constant
- `COILTANK_ENERGY_BURNING` - Energy burning constant
- `COIL_TANK_ENERGY_ABILITY_ID` - Energy ability identifier
- `COIL_TANK_FRONTAL_ARMOR` - Frontal armor value
- `COIL_TANK_WEAPON` - Weapon identifier

**Weapons**: Ball lightning (AoE), Lightning bolt (chain), Electrodes (persistent field), Nova (burst)
**Ability Type**: Electrical AoE damage, stun effect, energy burning
**Movement**: Ground (tank with coil animation)

**Key Constants**:
- `COILTANK_BALL_LIGHTNING_DAMAGE` - Ball lightning damage value
- `COILTANK_ENERGY_BURNING` - Energy drain rate
- `COIL_TANK_FRONTAL_ARMOR` - Enhanced frontal armor
- `COIL_TANK_WEAPON` - Primary weapon ID

### CryoTank
A frozen weapons hero with gun, frost bomb, and nova attacks. The CryoTank applies cold effects that slow and freeze enemies.

**Identifiers from code**:
- `hero_fire_cryotank_gun`, `hero_fire_cryotank_frostbomb`, `hero_fire_cryotank_nova` - Attack types
- `hero_bul_cryotank_gun`, `hero_bul_cryotank_frostbomb` - Projectile types
- `hero_impact_cryotank_gun_ground/veh/water` - Gun impact
- `hero_impact_cryotank_frostbomb` - Frostbomb impact
- `hero_impact_cryotank_boom_ground/water` - Boom impact
- `hero_impact_cryotank_nova_air/ground/inf/veh` - Nova impact
- `hero_funnel_cryotank_boom`, `hero_funnel_cryotank_gun` - Funnel effects
- `eff_cryo_capsule_collect`, `eff_cryo_capsule_spawn`, `eff_cryo_smoke` - Capsule effects
- `bul_psitank_active_additive`, `bul_psitank_wave_dark`, `bul_psitank_wave_light`, `bul_psitank_wave_passive_light` - Shared psi materials

**Weapons**: Frost gun (ranged slow), Frost bomb (AoE freeze), Nova (burst freeze)
**Ability Type**: Freeze/slow effects, area denial with ice
**Movement**: Ground (tank with cold smoke)

### Gatling
A rapid-fire hero with machine gun and explosive attacks. The Gatling specializes in sustained damage output.

**Identifiers from code**:
- `hero_fire_gatling_gun`, `hero_fire_gatling_explosive` - Attack types
- `hero_bul_gatling_gun`, `hero_bul_gatling_explosive`, `hero_bul_gatling_smoke` - Projectile types
- `hero_impact_gatling_explosive` - Explosive impact
- `hero_boom_gatling_explosive_ground/veh/water` - Explosion effects
- `hero_boom_gatling_smoke`, `hero_boom_gatling_smoke_water` - Smoke effects
- `hero_gatling_boom_death`, `hero_gatling_smoke_aura` - Death/aura effects
- `fx_hero_gatling_gun_heat` - Gun heat material

**Weapons**: Gatling gun (rapid fire), Explosive rounds (AoE)
**Ability Type**: Smoke screen (concealment), heat management
**Movement**: Ground (tracked vehicle with smoke)

### Railgun
A long-range artillery hero with march, quake, and siege firing modes. The Railgun provides devastating ranged firepower.

**Identifiers from code**:
- `hero_fire_railgun_march`, `hero_fire_railgun_quake`, `hero_fire_railgun_siege` - Attack modes
- `hero_bul_railgun_march`, `hero_bul_railgun_quake`, `hero_bul_railgun_siege` - Projectile types
- `hero_impact_railgun_march_ground/veh/water` - March impact
- `hero_impact_railgun_quake_ground/veh/water` - Quake impact
- `hero_impact_railgun_siege_ground/veh/water` - Siege impact
- `hero_funnel_railgun_quake` - Funnel effect

**Weapons**: Railgun with three modes - March (mobile), Quake (area), Siege (structure damage)
**Ability Type**: Mode switching between movement-friendly, area damage, and anti-structure
**Movement**: Ground (artillery with deployment modes)

### Leviaphan
A massive naval/aerial hero with gun and nuclear weapons. The Leviaphan is the game's super-unit with nuclear capability.

**Identifiers from code**:
- `hero_fire_leviaphan_gun`, `hero_fire_leviaphan_nuclear` - Attack types
- `hero_bul_leviaphan_gun_air/front/side` - Directional projectiles
- `hero_impact_leviaphan_gun_air/ground/veh/water` - Gun impact
- `hero_impact_leviaphan_nuclear`, `hero_impact_leviaphan_nuclear_water` - Nuclear impact
- `hero_leviaphan_death` - Death effect
- `hero_leviaphan_nuke_prepare`, `hero_leviaphan_nuke_start` - Nuclear launch sequence
- `hero_leviaphan_passive` - Passive effect
- `hero_leviaphan_turbine_main_idle/move`, `hero_leviaphan_turbine_side_idle/move` - Turbine effects

**Weapons**: Multi-directional guns (air/front/side), Nuclear missile
**Ability Type**: Nuclear launch (super weapon), multi-turret targeting
**Movement**: Air/naval (massive unit with dual turbines)

### Seraphim
An air superiority hero with laser and kara weapons plus vertical takeoff/landing capability.

**Identifiers from code**:
- `hero_fire_seraphim_lazer`, `hero_fire_seraphim_kara` - Attack types
- `hero_bul_seraphim_lazergun`, `hero_bul_seraphim_kara` - Projectile types
- `hero_impact_seraphim_lazer_ground/veh/water` - Laser impact
- `hero_impact_seraphim_kara_ground/veh/water` - Kara impact
- `hero_seraphim_boom_death`, `hero_seraphim_boom_pre_death` - Death effects
- `hero_seraphim_boom_air_death`, `hero_seraphim_boom_air_pre_death` - Air death
- `hero_seraphim_turbine_down/idle/move/up/turbo` - Turbine effects
- `hero_seraphim_waves_ground` - Ground wave
- Button references: `ButtonUnitSpecSeraphimDepart`, `ButtonUnitSpecSeraphimLand`

**Weapons**: Laser gun (precision), Kara (area weapon)
**Ability Type**: VTOL (depart/land), turbo speed boost
**Movement**: Air (VTOL with turbine effects)

### Solaris
An energy-based hero with gun, impulse, and lightning weapons. The Solaris uses chain lightning and electromagnetic attacks.

**Identifiers from code**:
- `hero_fire_solaris_gun`, `hero_fire_solaris_impulse`, `hero_fire_solaris_impulse_2`, `hero_fire_solaris_lightning` - Attack types
- `hero_bul_solaris_gun`, `hero_bul_solaris_impulse`, `hero_bul_solaris_lightning` - Projectile types
- `hero_impact_solaris_gun_ground/tech/water` - Gun impact
- `hero_impact_solaris_impulse_ground/veh` - Impulse impact
- `hero_impact_solaris_lightning` - Lightning impact
- `hero_solaris_death_ground/water`, `hero_solaris_idle_water`, `hero_solaris_move/move_water` - Movement/death
- `hero_solaris_charge` - Charge effect
- `hero_solaris_waves_ground` - Ground wave
- `hero_smoke_solaris` - Smoke effect
- `SolarisChainMaterial`, `SolarisChainLine` - Chain lightning materials

**Weapons**: Solar gun (direct), Impulse (AoE burst), Lightning (chain)
**Ability Type**: Chain lightning, charge-up attacks
**Movement**: Amphibious (ground and water with distinct animations)

### Cerber
A jump jet infantry hero with machine gun, grenade, and knife weapons. The Cerber is a fast, agile combat unit.

**Identifiers from code**:
- `hero_fire_cerber_machinegun`, `hero_fire_cerber_grenade`, `hero_fire_cerber_knife` - Attack types
- `hero_bul_cerber_machinegun`, `hero_bul_cerber_grenade` - Projectile types
- `hero_impact_cerber_machinegun_ground/inf/veh/water` - MG impact
- `hero_impact_cerber_grenade_ground/tech/water` - Grenade impact
- `hero_impact_cerber_blade_inf/veh` - Blade impact
- `hero_impact_cerber_flydeath` - Fly death impact
- `hero_cerber_jump_jet_1/ground` - Jump jet effects
- `hero_cerber_jump_trail`, `hero_cerber_knife_trail`, `hero_cerber_trail` - Trail effects
- `cerber_aura`, `funnel1_cerber` - Aura/funnel effects

**Weapons**: Machine gun (rapid fire), Grenade (AoE), Knife (melee)
**Ability Type**: Jump jet (vertical mobility), close combat
**Movement**: Infantry with jump jets

### Codomash
A deployable turret hero that can transform between mobile and stationary modes. The Codomash creates turrets and has passive/spec mode transitions.

**Identifiers from code**:
- `hero_fire_codomash_turret` - Turret fire
- `hero_bul_codomash_turret` - Turret projectile
- `hero_impact_codomash_bur_inf/veh/ground/veh/water` - Impact effects
- `hero_codomash_active_ability` - Active ability
- `hero_codomash_death` - Death
- `hero_codomash_move` - Movement
- `hero_codomash_passive_from/to` - Passive mode transition
- `hero_codomash_spec_from/to` - Spec mode transition
- `hero_codomash_turret_birth/death` - Turret lifecycle
- `fx_codomash_ground` - Ground effect

**Weapons**: Turret (deployed), mobile weapons
**Ability Type**: Turret deployment, mode switching (passive/spec)
**Movement**: Ground (with deploy mechanic)

## Unit Type Categories

### Infantry Units
Based on building lists and button references:
- Rifle infantry (produced from Barracks)
- Special infantry (psi units, demo units)

### Vehicle Units
Based on VFX and building lists:
- Tanks (light, medium, heavy)
- Artillery
- Transport vehicles

### Aircraft Units
Based on VFX and AIComm commands:
- Fighters (`jet_fighter1`, `jet_smoke_fighter1/fighter2`)
- Bombers (`AICommUnitBombersTargeting`, `AICommAircraftRebase`)
- Helicopters (Beholder, Seraphim)

### Naval Units
Based on VFX and assets:
- Ships (`ship_waves_back`, naval weapons)
- Submarines (Salamander submerge/emerge)
- Torpedoes (`bul_torpedo1` through `bul_torpedo4`)

### Special Units
- Psionic units (`AICommUnitsPsionic`, `bul_psitank_*` materials)
- Transport units (`AICommUnitsLoadTransport/UnloadTransport`)
- Mine layers/sweepers (`AICommMineLay/MineSweep`)

## Unit Production System

Units are produced from specific building types, as indicated by the building list constants:

| Building Type | Produces |
|---------------|----------|
| `BuildingListBarracks` | Infantry units |
| `BuildingListAirFactory` | Aircraft |
| `BuildingListAdvancedFactory` | Advanced vehicles |
| `BuildingListAssaultFactory` | Assault vehicles |
| `BuildingListShipyard` | Naval units |
| `BuildingListHero` | Hero units |
| `BuildingListAirport` | Aircraft (rebase capable) |

The production flow is:
1. Player selects building
2. Player clicks `ButtonBuildingOrderUnit1/2/3` to order a unit
3. `AICommBuyUnit` is sent to server
4. Building produces unit over time
5. Unit spawns at rally point
6. `AICommCancelBuyUnit` can cancel production

## Unit Stats and Configuration

Key stat references from game strings:

- `ACT_ATTACK`, `ACT_ATTACK_BU` - Attack stats
- `ACT_ARMOR`, `ACT_ARMOR_BU` - Armor stats
- `ACT_ENERGY_GEN`, `ACT_ENERGY_REGEN` - Energy stats
- `ARMOR_TYPE_LIGHT/MEDIUM/HEAVY` - Armor classification
- `ATTACK_INTERVAL_LAND/WATER/AIR/BOMBER/FIGHTER/NUCLEAR` - Attack speed by category
- `ATTACK_SPEED_REDUCTION` - Speed penalty while attacking
- `ACTIVE_ABILITY_WEAPON_INDEX` - Index for active ability weapon
- `IsUnitStrafable` - Whether unit can strafe
- `IsUnitPrototypeOpened` - Whether unit type is unlocked
- `AvailableUnitPrototypes` - Collection of unlocked types
- `IsUnitModificationsFeatureActive` - Whether modifications are enabled

## Unit Modification System

Units can be modified through the `modification` system:
- `ApplyUnitTypeModification` - Apply a single modification
- `ApplyUnitTypeModifications` - Apply multiple modifications
- `UnitModificationsConfigurationDataSource` - Modification configuration source
- `BattleUnitModificationResourceWarmer` - Pre-warm modification resources
- `BattleRewardModification` - Battle reward modification type
- `IsUnitModificationsFeatureActive` - Feature toggle for modifications
