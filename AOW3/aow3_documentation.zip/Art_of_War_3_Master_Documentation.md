# Art of War 3 Master Documentation

## Overview

This master document ties together all 17 specialized documentation files for the reverse engineering analysis of Art of War 3: RTS Strategy Game (com.geargames.aow), version 6.5.22. It provides a navigational guide, cross-references between documents, and a summary of key findings across all analysis domains.

## Document Index

| # | Document | Focus | Key Findings |
|---|----------|-------|--------------|
| 1 | IL2CPP_Type_Analysis.md | Type system, namespaces, hierarchies | 29,334 types, 334 com.geargames.* identifiers, MVP architecture, feature toggle system |
| 2 | Game_Systems_Map.md | System categories and dependencies | 130+ system categories, interaction map, feature toggle catalog |
| 3 | Network_Messages.md | All network message types | 710+ message types, 2,598 serializer pairs, 48+ AIComm commands, 40+ clan messages |
| 4 | Multiplayer_Architecture.md | Network stack, sync, crypto | Deterministic lockstep, RSA/DES crypto, CRC verification, desync detection |
| 5 | Asset_Catalog.md | 773 addressable assets | 23 bundles, 8 maps, 523 prefabs, 13 hero VFX sets, 3 biomes |
| 6 | Units.md | Unit encyclopedia | 13 heroes identified, hero abilities, production system, modification system |
| 7 | Buildings.md | Building encyclopedia | 17 building types, stat system, level progression, energy grid |
| 8 | Web_Research.md | Community data framework | Placeholder for stat values, balance data, historical changes |
| 9 | Data_Systems_Analysis.md | Serialization, save, config | STSerializer/STDeserializer pattern, BattleBaseDictionary, resource warming |
| 10 | Campaign_Analysis.md | GAI scripting, missions, tutorial | 144 GAI command types, 25+ tutorial finish conditions, flow control system |
| 11 | Gameplay_Analysis.md | Comprehensive gameplay overview | Game modes, core mechanics, hero system, super weapons, meta-game |
| 12 | Android_Layer_Analysis.md | Java layer, SDKs, platform | 8 DEX files, 10+ ad SDKs, Firebase integration, 35,274 Java classes |
| 13 | AI_System.md | 3-layer AI architecture | GAI scripting, Bot AI, AIComm commands, command batching |
| 14 | Combat_System.md | Damage pipeline, armor, weapons | 3 armor types, 6+ weapon categories, super weapons, hero combat |
| 15 | Economy_System.md | Resources, production, monetization | Energy grid, gold/uranium/blueprints, billing, ads, battle pass |
| 16 | Unit_Component_System.md | Component architecture | Prototype system, component base classes, interface contracts |
| 17 | ArtOfWar3_Recreation_Blueprint.md | Recreation spec and data models | Complete data models, network protocol spec, implementation recommendations |

## Cross-Document Relationships

### Network and AI Systems
The network message system (Document 3) is deeply connected to the AI command system (Document 13). Every player action in battle is expressed as an AIComm command, which is then serialized and transmitted through the network layer (Document 4). The GAI scripting system (Document 10) produces AIComm commands for automated gameplay, and the Bot AI also generates AIComm commands for its decisions.

**Key Cross-References**:
- Network_Messages.md Section "AIComm Battle Commands" <-> AI_System.md Section "Layer 3: AIComm"
- Multiplayer_Architecture.md Section "Battle Synchronization" <-> AI_System.md Section "AI Command Batching"
- Campaign_Analysis.md Section "GAI Scripting System" <-> AI_System.md Section "Layer 1: GAI Scripting"

### Units and Combat
The unit encyclopedia (Document 6) defines what units exist and their general properties, while the combat system (Document 14) defines how those units fight. The unit component system (Document 16) defines how combat components are attached to unit entities.

**Key Cross-References**:
- Units.md Section "Hero Units" <-> Combat_System.md Section "Hero Combat Mechanics"
- Units.md Section "Unit Stats" <-> Combat_System.md Section "Damage Pipeline"
- Unit_Component_System.md Section "Weapon Components" <-> Combat_System.md Section "Weapon System"

### Buildings and Economy
The building encyclopedia (Document 7) defines what buildings exist and their properties, while the economy system (Document 15) defines how buildings produce resources and consume energy.

**Key Cross-References**:
- Buildings.md Section "Resource Buildings" <-> Economy_System.md Section "Energy"
- Buildings.md Section "Building Level System" <-> Economy_System.md Section "Upgrade System"
- Buildings.md Section "Building Production" <-> Economy_System.md Section "Production System"

### Assets and Units/Buildings
The asset catalog (Document 5) maps visual assets to game entities defined in the unit (Document 6) and building (Document 7) documents.

**Key Cross-References**:
- Asset_Catalog.md Section "Hero VFX Prefabs" <-> Units.md Section "Hero Units"
- Asset_Catalog.md Section "Building Prefabs" <-> Buildings.md Section "Building Types"
- Asset_Catalog.md Section "Map Bundles" <-> Campaign_Analysis.md Section "Campaign Structure"

### Data Systems and All Documents
The data systems analysis (Document 9) underpins all other documents as it defines how data is serialized, stored, and transmitted.

**Key Cross-References**:
- Data_Systems_Analysis.md Section "STSerializer/STDeserializer" <-> Network_Messages.md (all serializer pairs)
- Data_Systems_Analysis.md Section "Battle Base Dictionary" <-> Buildings.md Section "Building Stats"
- Data_Systems_Analysis.md Section "Configuration System" <-> Game_Systems_Map.md Section "Feature Toggle System"

## Key Technical Findings Summary

### Architecture
- Unity IL2CPP v31 game with 29,334 types and 170,264 strings
- Component-based entity architecture with prototype system
- MVP (Model-View-Presenter) pattern for UI
- Zenject/Extenject dependency injection
- Deterministic lockstep multiplayer with CRC verification

### Network
- Custom TCP protocol with RSA/DES hybrid encryption
- 710+ message types with 2,598 serializer/deserializer pairs
- 48+ AIComm battle command types
- GearGamesByteBuffer for binary serialization
- Comprehensive desync detection and correction

### AI
- Three-layer AI: GAI Scripting (144 commands), Bot AI, AIComm (48 commands)
- Tutorial system with 25+ finish conditions
- Flow control: jumps, loops, counters, flags, triggers
- Command batching per tick for lockstep sync

### Content
- 13 hero types with unique abilities and VFX
- 17 building types across production, defense, and resource categories
- 8 campaign maps plus PvP maps
- 773 addressable assets across 23 bundles
- 3 biome themes: Common/War, Desert, Jungle

### Platform
- 8 DEX files with 35,274 Java classes
- 10+ advertising SDKs (AppLovin, IronSource, Pangle, Vungle, Yandex, AdMob)
- Firebase integration (Messaging, Crashlytics, Analytics)
- Google Play Billing v8.0.0
- Google Play Games integration
- Yandex AppMetrica analytics
- AltUnity testing framework in production build

### Monetization
- In-app purchases (Google Play Billing)
- Rewarded video ads (multiple networks)
- Interstitial ads
- Battle pass (premium and free tracks)
- Black market rotating shop
- Crate/loot box system
- Acceleration purchases

## Reverse Engineering Methodology

### Tools Used
- APK extraction and decompilation
- IL2CPP metadata analysis (metadata version 31)
- JADX decompilation of Java layer (8 DEX files)
- String table analysis (170,264 entries)
- Asset catalog parsing (773 addressable assets)
- Identifier pattern analysis (GAI commands, network messages)

### Confidence Levels
- **High Confidence**: Network message types, GAI commands, building/unit categories, SDK integrations (directly observable in code/strings)
- **Medium Confidence**: Hero ability mechanics, damage pipeline details, stat calculation formulas (inferred from code structure and VFX names)
- **Low Confidence**: Exact stat values, balance numbers, matchmaking algorithm details (require runtime analysis or community data)

### Limitations
- IL2CPP compilation prevents direct C# source recovery
- Exact numeric values for stats, costs, and timing not extractable from binary
- Server-side logic cannot be analyzed from client binary
- Some features may be disabled/unused (feature toggles)
- Unreleased/secret hero content may not be accessible in-game

## Recommended Next Steps

1. **Runtime Analysis**: Use Frida or similar to extract stat values during gameplay
2. **Network Capture**: Capture and analyze actual network traffic for protocol details
3. **Memory Analysis**: Extract runtime data structures from active game process
4. **Asset Bundle Parsing**: Parse Unity asset bundles for ScriptableObject configuration
5. **Community Verification**: Cross-reference findings with wiki and community data
6. **Version Diffing**: Compare different APK versions for balance changes
