# Buildings - Art of War 3: RTS Strategy Game

## Overview

The building system in Art of War 3 is a core gameplay mechanic that provides unit production, resource generation, defensive capabilities, and technology progression. Buildings are constructed from a Construction Yard, require energy to operate, and can be upgraded through multiple levels. The system supports two factions with visually distinct but functionally equivalent building sets (s1, s2, s3 sides). Buildings interact with the energy grid, fog of war, and unit production pipelines in an interconnected web of dependencies.

## Building Types

Based on the `BuildingList*` constants and `BuildingType` identifiers, the following building categories are identified:

### Core Buildings

#### Headquarters (HQ)
`BuildingListHQ` - The central building of each player's base. The HQ is the most critical structure; losing it typically results in defeat.

**Properties**:
- `BuildingLevelForOpen` - Level required to unlock
- `BuildingTypeHero` - Has hero training capability
- Main tower weapon (`MainTowerWeapon`) - Defensive weapon

#### Construction Yard
`BuildingListConstrYard` - The primary building construction facility. All structures are built from the Construction Yard.

**Related Classes**:
- `BuildingConstr` - Construction data
- `BuildingConstructionStyle` - Visual construction animation
- `BuildingConstructionTimeStat` - Build time per level
- `BuildingsConstrComponent` - Construction component
- `BuildingsBaseComponent` - Base building component

### Production Buildings

#### Barracks
`BuildingListBarracks` - Produces infantry units.

**Production Interface**:
- `ButtonBuildingOrderUnit1` - Order first unit type
- `ButtonBuildingOrderUnit2` - Order second unit type
- `ButtonBuildingOrderUnit3` - Order third unit type
- `BuildingLimitationsBarracks` - Barracks build limits

**Related Classes**:
- `BarrackBuildings` - Barracks building collection
- `CanBuildingProduceUnit` - Production capability check
- `CanOrderInBuilding` - Order placement validation

#### Factory (Standard)
`BuildingListFactory` references via `BuildingListAdvancedFactory` and `BuildingListAssaultFactory` - Produces vehicle units of different tiers.

**Sub-types**:
- `BuildingListAdvancedFactory` - Advanced vehicle production
- `BuildingListAssaultFactory` - Assault vehicle production

**Related Classes**:
- `BuildingListFilter` - Filters available buildings
- `BuildingSlotPresenter1/2/3` - Production slot presenters
- `ActivatedBuildingSlotStrategy` - Active slot behavior
- `BuildingSlotNotAvailableState` - Locked slot state

#### Air Factory
`BuildingListAirFactory` - Produces aircraft units.

**Related Systems**:
- `BuildingListAirport` - Airport for aircraft rebase
- `AICommAircraftRebase` - Aircraft rebase command
- `AirportSlotSTSerializer/STDeserializer` - Airport slot data

#### Shipyard
`BuildingListShipyard` - Produces naval units.

### Defense Buildings

#### Tower
`BuildingListTower` - Defensive turret that automatically attacks enemies.

**Properties**:
- `UnitStrafeTower` - Tower strafing behavior
- Tower weapon system

#### Bunker
`BuildingListBunker` - Defensive structure providing cover for units.

#### Air Defense
`BuildingListAirDefence` - Anti-air turret targeting aircraft.

**Related Class**: `AirDefense` - Air defense logic

#### Naval Turret
`BuildingListNavalTurret` - Water-based defensive turret.

#### Wall
`BuildingListWall` - Defensive wall structure.

**Related Classes**:
- `GAICommandWall` - GAI wall command
- `BuildingBarrierMask` - Wall barrier collision

#### Nuclear Silo
`BuildingListNuclearSilo` - Launches nuclear super weapon.

**Related Systems**:
- `AICommNuclearLaunch` - Nuclear launch command
- `AttackSuperWeaponNuclearTap` - Nuclear attack input
- `eff_rocket_nuke_launch` - Nuclear launch VFX
- `boom_expl5_s5_nuke*` - Nuclear explosion VFX

### Resource Buildings

#### Power Station
`BuildingListPowerStation` - Generates energy for the base.

**Related Properties**:
- `BuildingEnergyNeedStat` - Energy consumption
- `BuildingEnergyProductionStat` - Energy generation
- `ACT_ENERGY_GEN`, `ACT_ENERGY_REGEN` - Energy generation stats
- `BUILDING_LEVEL_ENERGY` - Energy per level

#### Supply Depot
`BuildingListSupplyDepot` - Provides supply/resource storage.

**Related Classes**:
- `eff_supply` - Supply VFX
- `CLAN_SUPPLY_*` messages - Clan supply system

### Hero Building
`BuildingTypeHero` / `BuildingListHero` - Special building for training and activating hero units.

**Related Classes**:
- `HeroBuildingNameId` - Hero building identifier
- `MaxHeroBuildingLevel` - Maximum hero building level
- `HasHeroBuildingWithRequiredLevel` - Level check
- `AllOwnActiveHeroBuildings` - Active hero buildings
- `IsHeroInTrainingQueue` - Training state
- `BuildingWhereHeroInTrainingQueue` - Training building
- `AddHeroBuilding` - Construction method

## Building Stats System

Buildings have a comprehensive stat system defined through specialized stat factories:

### BuildingBaseStatsFactory
Creates the base stats for all buildings including:
- `BuildingHealthStat` - HP/health points
- `BuildingArmorStat` - Damage reduction
- `BuildingHpRegenStat` - Health regeneration rate
- `BuildingViewStat` - Sight/vision range

### BuildingCostStatsFactory
Manages construction costs:
- `BuildingPriceStat` - Resource cost to build
- `BuildingConstructionTimeStat` - Time to construct
- `BUILDING_LEVEL_PRICE` - Price per level
- `BUILDING_LEVEL_TIME_CONSTR` - Construction time per level
- `BUILDING_LEVEL_TIME_CONSTR_INIT` - Initial construction time

### BuildingProduceStatsFactory
Manages production capabilities:
- Production queue capacity
- Production speed modifiers
- Unit types available for production

### BuildingSpecialStatsFactory
Manages special abilities:
- Weapon systems for towers
- Super weapon charge rates
- Special ability parameters

## Building Level System

Buildings progress through multiple levels with stats defined per level:

**Level Properties**:
- `BUILDING_LEVEL_ARMOR` - Armor per level
- `BUILDING_LEVEL_ENERGY` - Energy production per level
- `BUILDING_LEVEL_LIFE` - Health per level
- `BUILDING_LEVEL_OPEN_WATER` - Water traversal per level
- `BUILDING_LEVEL_PRICE` - Upgrade price per level
- `BUILDING_LEVEL_REGEN` - Regeneration per level
- `BUILDING_LEVEL_SIGHT` - Vision range per level
- `BUILDING_LEVEL_TIME_CONSTR` - Construction time per level
- `BUILDING_LEVEL_TYPE` - Type change per level
- `BUILDING_LEVEL_UPGRADE_SLOT_ID` - Upgrade slot per level

**Level Management**:
- `BuildingLevel` - Current level
- `BuildingLevelPrototypeId` - Prototype per level
- `BuildingLevelForOpen` - Level required to unlock
- `BuildingsByLevel` - Buildings organized by level
- `CalcBuildingsByLevel` / `CalcBuildingsByLevelIncludeProcessed` - Level calculation
- `BuildingUpgradeLevelTransformerDefault` - Default level upgrade handler

## Building Construction System

### Construction Flow
1. Player selects building from `BuildingsConstrComponent`
2. `BuildingCanNotBeBuiltHere` / `BuildingIsOutOfConstructionArea` validates placement
3. `BuildingPlacement` determines valid positions
4. `BuildingsAutoPlacement` assists with positioning
5. `CalculateBuildingPosition` computes final coordinates
6. `AddBuildingCoroutine` executes construction over time
7. `BuildingConstr` tracks construction progress
8. `BuildingComplete` signals completion

### Construction Properties
- `BUILDING_OFFSET` - Building offset from grid
- `BUILDING_WIDTH` / `BUILDING_HEIGHT` - Building dimensions
- `BUILDING_BAND` - Building band/zoning
- `BUILDING_STUN` - Stun state during construction
- `CONFEDERATION_MAX_BUILDING_SIZE` - Maximum building size limit
- `CONSTR_ARMOR_DIVIDER` - Construction armor divisor (reduced armor while building)

## Building Upgrade System

### Upgrade Flow
1. Player clicks `ButtonBuildingUpgrade` or `ButtonFastBuildingUpgrades`
2. `BuildingUpgradeComponents` handles upgrade logic
3. `CanBuildingUpgrade` validates upgrade possibility
4. `AccelerateUpgradeRequest` / `AdsAccelerateUpgradeRequest` can speed up
5. `CancelUpgradeRequest` can cancel in-progress upgrade
6. `CompleteActiveUpgradeRequest` instantly completes (premium)
7. `BuildingUpgradeComplete` signals completion
8. `ActiveUpgradeNotification` notifies of completion
9. `ActiveUpgradeLevelSTSerializer/STDeserializer` tracks active upgrades

### Upgrade Acceleration
- `AccelerateUpgradeRequest/Answer` - Standard acceleration (premium currency)
- `AdsAccelerateUpgradeRequest/Answer` - Ad-based acceleration
- `CONFIRM_ACCELERATE_UPGRADE_REQUEST` - Confirmation for acceleration

## Building Destruction System

### Destruction Flow
1. Building health reaches zero
2. `BuildingDestroyed` event fires
3. `BuildingDestroyedSTSerializer/STDeserializer` serializes destruction
4. `BoomBuilding` creates explosion VFX
5. `BuildingDestroyFlashEffector` creates flash effect
6. `debris_bld_s1/s2/s3` creates debris particles
7. `bld_destroy1_s1/s2/s3` shows destroyed model

### Destruction VFX
- `boom_bld_expl1_s1/s2/s3` - Building explosion sizes
- `boom_bld_expl2_s2_w/s3_w` - Water building explosions
- `bld_destroy1_s1/s2/s3` - Destroyed building models
- `debris_bld_s1/s2/s3` - Building debris
- `debris_tail_big/small` - Debris trails
- `smoke_fire_1` - Post-destruction smoke

## Building Repair System

- `BuildingRepair` / `AICommBuildingRepair` - Repair command
- `BuildingRepairSTSerializer/STDeserializer` - Repair data
- `BuildingStunOn/Off` - Stun state during repair
- `BuildingStunEffect` - Visual stun indicator

## Building Rally Point System

- `BuildingRallyPointSet` - Set rally point
- `BuildingRallyPointsShower` - Display rally points
- `AICommBuildingRallyPoint` - Network rally point command
- `RallyPointTapCoroutine` - Rally point tap interaction
- `ButtonBuildingRallypoint` - Rally point button

## Building Context Menu System

- `BuildingContextMenuUpdate` - Menu update coroutine
- `AbstractGUIBattleBuildingContextMenuUpdater` - Menu updater base
- `BuildingContextMenuUpdaterPrefab` - Menu prefab
- `BuildingContextMenuUpdatersParent` - Menu parent container
- `BuildingPanelMenuUpdater` - Panel menu updater
- `BuildingPanelUpgradeButton` - Upgrade button

## Building Visual System

### Building Ground System
- `BuildingGround` - Ground plane component
- `BuildingGroundAnimation` - Ground animation
- `BuildingGroundFader` - Ground fade effect
- `BuildingGroundPrefabSettings` - Ground prefab configuration
- `BuildingGroundPrefabsF1/F2` - Faction-specific grounds
- `BuildingGroundSoundEffector` - Ground sound effects
- `BuildingGroundState` - Ground visual state
- `BuildingGroundsByBuilding` - Ground per building type

### Building Visual Effects
- `BuildingHue` - Color tinting
- `BuildingFadeTime` - Fade animation duration
- `BuildingBandMask` - Band/zoning overlay
- `BuildingBarrierMask` - Barrier collision mask
- `BuildingMarkArrow` - Arrow indicator
- `BuildingMarkAttackBillboard` - Attack indicator
- `BuildingMarkProtect` - Protection indicator
- `BuildingMarkPlacement` - Placement preview
- `BuildingMarkCreator` - Mark factory
- `BuildingMinimapColor` - Minimap representation

### Building Super Weapon Effects
- `BuildingSuperWeaponAnimationController` - Super weapon animations
- `BuildingSuperWeaponFlashEffector` - Flash effects
- `BuildingSpaceStrikeFlashEffector` - Space strike flash
- `BuildingSpaceStrikeSoundEffector` - Space strike sound
- `eff_smoke_launcher_super_launch` - Launcher launch VFX
- `eff_smoke_launcher_super_wait` - Launcher wait VFX
- `eff_smoke_launcher_work` - Launcher work VFX
- `eff_space_super_launch/wait/work` - Space weapon VFX

## Building Hotkeys
- `BuildingHotkeys` - Keyboard shortcuts for building selection
- `UIStandartUpgradeBuilding` - Standard upgrade hotkey
- `UIUpgradeBuildingFastButton` - Fast upgrade hotkey
- `UITapBuildToUnlockUnit` - Build to unlock unit hotkey
- `UITapUnlockUnit` - Unlock unit hotkey

## Building Statistics

Battle statistics track building-related metrics:
- `BatBuildingsConstructed` - Buildings built during battle
- `BatBuildingsErased` - Buildings destroyed during battle
- `BuildingsAmount` - Current building count
- `EnemyBuildingsAmount` - Enemy building count
- `CalcBuildingCountLimit` - Maximum building count
- `CalcBuildingsConstructed` - Construction calculation
- `CalcNotApprovedBuildings` - Unapproved building count
- `CalculateActiveBuildings` - Active building count
