# Game Systems Map - Art of War 3: RTS Strategy Game

## Overview

Art of War 3 implements a complex, interconnected game architecture with over 130 distinct system categories. The game follows a service-oriented architecture with dependency injection (Zenject/Extenject pattern based on the `MonoInstaller` and `PrefabResourceInstaller` naming conventions), where each major feature is encapsulated as a system with clearly defined interfaces. Systems communicate through message passing, event buses, and direct service references. This document maps out all identified systems and their interdependencies.

## System Categories and Dependencies

### 1. Core Game Systems

#### 1.1 Battle System
The battle system is the central gameplay loop, encompassing all real-time strategy interactions. It depends on virtually every other system in the game.

**Key Classes**: `Battle`, `BattleAct`, `BattleRun`, `BattleFinish`, `BattleStart`, `BattleInitialize`, `BattleSession`, `BattleEnd`, `BattleEnding`, `BattleState`

**Dependencies**: Unit System, Building System, Combat System, AI System, Network System, Resource System, Map System, UI System, Sound System, Replay System

**Sub-systems**:
- `BattleInitialize` - Battle setup and configuration loading via `BattleInitializeSnapshot`
- `BattleRun` - Active battle simulation execution
- `BattleFinish` - Battle conclusion with `BattleFinishCondition`, `BattleFinishReason`, `BattleFinishResult`, `BattleFinishTick`
- `BattleSession` - Session tracking with `BattleSessionId`, `BattleSessionRestore`
- `BattleEnding` - End-game state machine
- `BattleState` - State management for battle phases

#### 1.2 Unit System
Manages all unit entities on the battlefield including creation, destruction, movement, and state management.

**Key Classes**: `AllUnits`, `BattleUnits`, `AddUnit`, `UnitEventRouter`, `ClientUnit`, `UnitPrototype`, `UnitType`, `WeaponType`

**Dependencies**: Combat System, Resource System, Building System, AI System, Animation System, Sound System

**Sub-systems**:
- Unit Selection: `AddSelectUnitsByPolygon`, `AddSelectUnitsByRectangle`, `SelectUnitsByPolygon`, `SelectUnitsByRectangle`, `AddUnitToSelection`, `AddUnitsToSelection`, `InternalSetUnitSelection`
- Unit Production: `AddUnitNode`, `AddUnitNotone`, `AddUnitOne`, `AddUnitSet`, `CanOrderInBuilding`, `CanBuildingProduceUnit`
- Unit State: `AbstractUnitVisualState`, `IsUnitStrafable`, `IsUnitPrototypeOpened`, `ApplyUnitStateConfigs`, `ApplyUnitAbilityConfigs`, `OverrideUnitState`
- Unit Modification: `ApplyUnitTypeModification`, `ApplyUnitTypeModifications`, `IsUnitModificationsFeatureActive`

#### 1.3 Building System
Manages construction, upgrades, and production for all structures on the battlefield.

**Key Classes**: `Building`, `Buildings`, `BuildingDispatcher`, `BuildingComponents`, `BuildingPrototypes`, `BuildingType`

**Dependencies**: Resource System, Energy Grid, Unit System, Map System, UI System

**Sub-systems**:
- Construction: `AddBuilding`, `AddBuildingCoroutine`, `BuildingConstr`, `BuildingConstructionStyle`, `BuildingConstructionTimeStat`
- Upgrade: `BuildingUpgrade`, `BuildingUpgradeComplete`, `BuildingUpgradeComponents`, `BuildingUpgradeLevelTransformerDefault`, `CanBuildingUpgrade`
- Placement: `BuildingPlacement`, `BuildingSetLocation`, `BuildingCanNotBeBuiltHere`, `BuildingIsOutOfConstructionArea`, `BuildingsAutoPlacement`
- Destruction: `BuildingDestroyed`, `BoomBuilding`, `BuildingDestroyFlashEffector`
- Repair: `BuildingRepair`, `BuildingStunOn`, `BuildingStunOff`, `BuildingStunEffect`
- Rally Points: `BuildingRallyPointSet`, `BuildingRallyPointsShower`, `AICommBuildingRallyPoint`

#### 1.4 Combat System
Handles damage calculation, weapon firing, armor resolution, and all offensive/defensive interactions.

**Key Classes**: `COMBAT`, `Attack`, `Armor`, `AttackCoeffCalculating`, `CalculateWeaponArmorDamage`, `AbstractClientWeapon`, `AbstractWeaponEngine`

**Dependencies**: Unit System, Building System, Bullet System, Animation System, Sound System

**Sub-systems**:
- Damage Pipeline: `CalculateForWeapon`, `CalculateWeaponArmorDamage`, `AttackCoeffCalculating`, `SafeSetDamageStat`
- Armor: `ARMOR`, `ARMOR_HEAVY`, `ARMOR_LIGHT`, `ARMOR_MEDIUM`, `ArmorStatHelper`, `ArmorType`, `ArmorBonus`
- Attack Modifiers: `AttackBonus`, `AttackBonusDisabled`, `AttackDecr`, `AttackSpeedReduction`
- Weapons: `AbstractClientWeapon`, `AbstractClientEnginedWeapon`, `AdditionalWeaponSettings`, `BurstWeaponSettings`

#### 1.5 Resource System
Manages in-game resources including energy, gold, uranium, and other currencies.

**Key Classes**: `AddResource`, `BindCostResources`, `BindCostResourceServices`, `BindPlayerResources`, `BoostsResourceService`, `CheckResources`

**Dependencies**: Building System, Unit System, Economy System, Network System

**Sub-systems**:
- Resource Services: `IBatteriesResourceService`, `IBlueprintsResourceService`
- Resource Loading: `BattleResourcesLoader`, `BattleResourcesLoaderFromAssetBundle`, `CacheResource`
- Resource Checking: `CheckResources`, `HasResourcesOnLocalStorage`
- Resource Binding: `BindCostResources`, `BindCostResourceServices`, `BindPlayerResources`, `BindResourceSystem`

### 2. AI Systems

#### 2.1 GAI Scripting System
The Game AI (GAI) system provides a scripted command sequence engine for tutorials, campaign missions, and bot behaviors. It operates at the highest level of AI abstraction, controlling the narrative and tutorial flow through a sequence of commands with dependency tracking.

**Key Classes**: `GAICommand`, `GAICommandsNode`, `GAICommandAttribute`, `GAISideConfigCommand`

**Dependencies**: Unit System, Building System, Camera System, Tutorial System, UI System

**Command Categories**:
- Tutorial Commands: 30+ `GAICommandTutorial*` variants for guided gameplay
- Building Commands: `GAICommandBuilding`, `GAICommandBuildingSetPlace`, `GAICommandBuildingSetRestrict`
- Troop Commands: `GAICommandTroopMove`, `GAICommandTroopCute`, `GAICommandTroopDrop`, `GAICommandTroopEvacuate`
- Camera Commands: `GAICommandCameraSet`, `GAICommandCameraSave`, `GAICommandCameraRestore`, `GAICommandCameraMask`
- Flow Control: `GAICommandChanceJump`, `GAICommandCounterJump`, `GAICommandFlagJump`, `GAICommandLoopStart/End`, `GAICommandSequentJump`, `GAICommandTriggerJump`

#### 2.2 Bot AI System
Controls automated player opponents in PvE and PvP scenarios.

**Key Namespace**: `com.geargames.aow.entities.battle.bot`

**Dependencies**: GAI System, Unit System, Building System, Map System, Resource System

#### 2.3 AIComm Battle Command System
The AIComm system handles real-time battle commands exchanged between client and server during multiplayer matches. This is the network-synchronized command layer.

**Key Classes**: 48+ AIComm types covering all battle actions

**Dependencies**: Network System, Battle System, Unit System, Building System

### 3. Network Systems

#### 3.1 Client-Server Communication
**Key Classes**: `AbstractClientNetworkConnector`, `ActiveNetworkConnector`, `CSMessage`, `GearGamesByteBuffer`

**Dependencies**: Serialization System, Cryptography System, Auth System

#### 3.2 Message System
**Key Classes**: `CSMainSendRequestAndWaitReadyToActAnswer`, `CSMainWaitReadyToActAnswer`, `CSHttpSendRequestAndReceiveResponse`

**Dependencies**: Serialization System, Network System

#### 3.3 Battle Network
**Key Classes**: `CSBattleLoginToBattle`, `CSBattleLogon`, `CSBattleRun`, `CSBattleInitializeWaiter`

**Dependencies**: Battle System, Network System, Auth System

### 4. UI Systems

#### 4.1 Battle UI
**Key Classes**: `BattleGUI`, `BattleButtonPresenter`, `BattleButtonState`, `BattleIndicators`

**Sub-systems**:
- Unit Selection UI: `unitselection` namespace with `IClickableAction.OnClick` interface
- Building Context Menu: `buildings` namespace with `AbstractGUIBattleBuildingContextMenuUpdater`
- Minimap: `minimap` namespace
- Boosts Panel: `boosts` namespace
- Unit Spec Abilities: `unitspec` namespace with `AbstractGUIBattleActionUnitSpecTargeting`

#### 4.2 Main Menu UI
**Key Classes**: Main menu GUI in `com.geargames.aow.scenes.main.gui`

**Sub-systems**:
- Clan UI: `clan` namespace
- Profile UI: `profile` namespace with `DailyEntrance`
- Rating UI: `rating` namespace
- Quest UI: `quests` namespace
- Store UI: `upgrades.uranum` namespace

### 5. Meta-Game Systems

#### 5.1 Clan System
**Key Messages**: 40+ CLAN_* message types covering creation, management, chat, calls, supply, rights, and battles

**Dependencies**: Chat System, Network System, Social System

#### 5.2 Competition/Tournament System
**Key Messages**: COMPETITION_* messages for matching, coop battles, ratings, hall of fame

**Dependencies**: Battle System, Network System, Rating System

#### 5.3 Chat System
**Key Messages**: CHAT_LOGIN, COMMON_CHAT_*, COUNTRY_CHAT_*, CLAN_CHAT_*, FRIEND_CHAT_*, SUPPORT_CHAT_*

**Dependencies**: Network System, Social System, Clan System

#### 5.4 Achievement System
**Key Classes**: `AchievementConfiguration`, `AchievementLevel`, `AchievementReached`, `AchievementStatistics`

**Dependencies**: Profile System, Network System

#### 5.5 Battle Pass System
**Key Classes**: `BattlePass`, `BattlePassInfo`, `BattlePassPremium`, `BattlePassProfileInfo`, `BattlePassReward`, `BattlePassScale`, `BattlePassPoints`

**Dependencies**: Profile System, Network System, Billing System

#### 5.6 Career System
**Key Classes**: `CareerRewardItem`, `CareerStone`, `CareerUp`

**Dependencies**: Profile System, Battle System

#### 5.7 Hero System
**Key Classes**: `Hero`, `HeroBehaviour`, `HeroBuyChecker`, `HeroCards`, `HeroConfigurationDataSource`, `HeroIcon`, `HeroInfo`, `HeroSlotModels`, `HeroesExist`

**Dependencies**: Unit System, Building System, Resource System, Combat System

#### 5.8 Black Market System
**Key Classes**: `BlackMarketConfiguration`, `BlackMarketGoods`

**Dependencies**: Economy System, Network System, Billing System

#### 5.9 Ads System
**Key Classes**: `AdsInfo`, `AdsParams`, `AdsSwitcher`, `AdsToPrepare`, `AdsTypeInfo`, `AdsAvailabilityUpdate`

**Dependencies**: Billing System, Network System, Platform Services

### 6. Infrastructure Systems

#### 6.1 Serialization System
**Key Pattern**: STSerializer/STDeserializer pairs (2,598 pairs total)

**Dependencies**: None (foundational)

#### 6.2 Cryptography System
**Key Namespace**: `com.geargames.common.network.cryptography`

**Dependencies**: Network System

#### 6.3 Object Pool System
**Key Namespaces**: `com.geargames.common.objectpool`, `com.geargames.common.pool`, `com.geargames.aow.ugui.pool`

**Dependencies**: None (foundational)

#### 6.4 Analytics System
**Key Namespaces**: `com.geargames.common.analytics`, `com.geargames.aow.services.appmetrica`

**Dependencies**: Network System, Event System

#### 6.5 Logging System
**Key Namespaces**: `com.geargames.aow.logging`, `com.geargames.common.logging`, `com.geargames.unity.logging`

**Sub-systems**:
- `AOWErrorSender`, `AOWErrorStorerToFile`, `AOWErrorFactory`, `AOWErrorData`
- Battle-specific: `BattleLogicInfoLogCollector`, `BattleLoadingInfoLogCollector`, `BattleLogoutInfoLogCollector`
- Main-specific: `scenes.main.logging`
- Logon-specific: `scenes.logon.logging`

### 7. Platform Integration Systems

#### 7.1 Billing System
**Key Classes**: `BillingConfiguration`, `BillingButtonInfo`, `BuyGoodsRequest/Answer`, `ConsumePurchaseRequest/Answer`, `BuyViaProviderBillingRequest`

**Dependencies**: Platform SDK, Network System

#### 7.2 Social System
**Key Namespace**: `com.geargames.aow.social`

**Dependencies**: Platform SDK, Network System

#### 7.3 Notification System
**Key Namespace**: `com.geargames.aow.localNotifications`

**Dependencies**: Platform SDK, Firebase Cloud Messaging

#### 7.4 Sound System
**Key Namespace**: `com.geargames.aow.sounds`

**Sub-systems**:
- `AudioBattleSoundsHandler`
- `AudioBattleVoiceWeightSettings`
- `AudioBattleVoicesPlayer`
- `AbstractBattleSoundEffectManager`
- `BattleHelicopterSoundEffectManager`

## System Interaction Map

```
[Battle System] <---> [Unit System] <---> [Combat System]
      |                     |                    |
      v                     v                    v
[Building System] <---> [Resource System]  [Bullet System]
      |                     |                    
      v                     v                    
[Energy Grid] <---> [Economy System] <---> [Billing System]
      |                                           |
      v                                           v
[AI System (GAI/Bot/AIComm)]              [Ads System]
      |
      v
[Network System] <---> [Serialization] <---> [Cryptography]
      |
      v
[Clan System]   [Chat System]   [Competition System]
      |               |                  |
      v               v                  v
[Social System]  [Profile System]  [Rating System]
                          |
                          v
                   [Hero System]   [Career System]   [Battle Pass]
```

## Feature Toggle System

The game implements a comprehensive feature toggle system that controls runtime behavior without requiring app updates. Battle feature toggles follow the naming convention `Battle_Is[FeatureName]Enabled` and are managed by `BattleFeatureToggleService` with `BattleFeatureToggles` and `BattleFeatures` classes.

Identified feature toggles include:
- `Battle_IsLiquidFogEnabled` - Liquid fog rendering
- `Battle_IsNewBallisticEngineSkipPositionEnabled` - Ballistic engine optimization
- `Battle_IsGAICutsceneFeatureEnabled` - GAI cutscene system
- `Battle_IsNewShieldIndicatorLogicEnabled` - Shield indicator update
- `Battle_IsVoiceQueueEnabled` - Voice queue system
- `Battle_IsVisualStateServiceEnabled` - Visual state service
- `Battle_IsTerrainNormalMapEnabled` - Terrain normal mapping
- `Battle_IsNewAuraHideActionDestroyEnabled` - Aura hide optimization
- `Battle_IsNewBulletSelfDirectedStartEnabled` - Bullet self-direction
- `Battle_IsNewFogVisibleStateLogicEnabled` - Fog visibility update
- `Battle_IsNewMinimapMarksEnabled` - Minimap marks update
- `Battle_IsNewNormalizedHealthLogicEnabled` - Health normalization
- `Battle_IsModificationAnimationEnabled` - Modification animations
- `Battle_IsMoveStepSoundFadeEnabled` - Movement sound fade
- `Battle_IsRefactorSetVisibleEnabled` - Visibility refactor
- `Battle_IsCoiltankIdleSoundEnabled` - Coiltank idle sound
- `Battle_IsSolarisAnimationSettingsOverrideEnabled` - Solaris animation override
- `Battle_IsTabletCameraDistanceLogicEnabled` - Tablet camera distance
- `Battle_IsUGUIScoreBoardEnabled` - UGUI scoreboard
- `Battle_IsDisableTopColliderInPvPEnabled` - PvP top collider disable
