# Android Layer Analysis - Art of War 3: RTS Strategy Game

## Overview

The Android layer of Art of War 3 (com.geargames.aow) version 6.5.22 consists of 8 DEX files containing 35,274 decompiled Java classes. The application uses MultiDex (androidx.multidex.MultiDexApplication) to exceed the standard 65K method limit. The manifest reveals extensive integration with advertising SDKs, analytics platforms, billing systems, and social services. The game targets Android 15 (SDK 35) with a minimum of Android 6.0 (SDK 23).

## Application Configuration

### Manifest Details
- **Package**: com.geargames.aow
- **Version**: 6.5.22 (versionCode 38820)
- **Install Location**: preferExternal
- **Compile SDK**: 35 (Android 15)
- **Min SDK**: 23 (Android 6.0 Marshmallow)
- **Target SDK**: 35 (Android 15)
- **Required Split**: base__abi (architecture-specific native library split)
- **Theme**: NoTitleBar.Fullscreen
- **Hardware Accelerated**: true (application-level), false (main activity)
- **Extract Native Libs**: true
- **Cleartext Traffic**: allowed (usesCleartextTraffic=true)
- **App Category**: game
- **GWP-ASan**: always enabled (memory sanitizer for security)
- **Orientation**: userLandscape (forced landscape)
- **Launch Mode**: singleTask

### Main Activity
- **Class**: com.trophit.MyUnityPlayerActivity
- **Custom Scheme**: aow:// (deep link support)
- **Config Changes**: Handles all configuration changes without restart
- **Max Aspect Ratio**: 2.3
- **Min Aspect Ratio**: 1.0
- **Notch Support**: enabled

## Permissions

### Network Permissions
- `android.permission.INTERNET` - Network access
- `android.permission.ACCESS_NETWORK_STATE` - Network status
- `android.permission.ACCESS_WIFI_STATE` - WiFi status

### Billing Permissions
- `com.android.vending.BILLING` - In-app purchases
- `com.android.vending.CHECK_LICENSE` - License verification
- `com.google.android.finsky.permission.BIND_GET_INSTALL_REFERRER_SERVICE` - Install referrer

### Advertising Permissions
- `com.google.android.gms.permission.AD_ID` - Advertising ID
- `android.permission.ACCESS_ADSERVICES_ATTRIBUTION` - Ads attribution
- `android.permission.ACCESS_ADSERVICES_AD_ID` - Ads services ID
- `android.permission.ACCESS_ADSERVICES_TOPICS` - Ads topics

### Notification Permissions
- `android.permission.POST_NOTIFICATIONS` - Push notifications
- `android.permission.SCHEDULE_EXACT_ALARM` - Exact alarm scheduling

### Other Permissions
- `android.permission.VIBRATE` - Haptic feedback
- `android.permission.REORDER_TASKS` - Task reordering
- `com.amazon.privacypass.ATTEST` - Amazon Privacy Pass

### Custom Permissions
- `com.geargames.aow.DYNAMIC_RECEIVER_NOT_EXPORTED_PERMISSION` - Signature-level broadcast
- `com.geargames.aow.permission.C2D_MESSAGE` - Cloud messaging

## Integrated SDKs

### Firebase Suite
The game integrates multiple Firebase services with auto-initialization disabled:

**Firebase Cloud Messaging (FCM)**:
- `firebase_messaging_auto_init_enabled: false` - Manual initialization
- `com.google.firebase.messaging.FirebaseMessagingService`
- `com.google.firebase.iid.FirebaseInstanceIdReceiver`
- Custom notification handling via `gg_notifications_use_custom: true`
- `gg_notifications_disable_custom_on_android_12: true`
- Custom notification icon: `notification_icon`
- Custom notification background: `notification_background`

**Firebase Crashlytics**:
- `firebase_crashlytics_collection_enabled: false` - Manual initialization
- NDK crash reporting: `com.google.firebase.crashlytics.ndk.CrashlyticsNdkRegistrar`
- Session tracking: `com.google.firebase.sessions.SessionLifecycleService`

**Firebase Analytics**:
- `firebase_analytics_collection_enabled: false` - Manual initialization
- `com.google.firebase.analytics.connector.internal.AnalyticsConnectorRegistrar`

**Firebase Installations**:
- `com.google.firebase.installations.FirebaseInstallationsRegistrar`

**Firebase Provider**:
- Authority: `com.geargames.aow.firebaseinitprovider`
- Init order: 100
- Direct boot aware

### Advertising SDKs

**Google Ads (AdMob)**:
- Application ID: `ca-app-pub-5737320574620202~1904033054`
- Optimized initialization: `OPTIMIZE_INITIALIZATION: true`
- Optimized ad loading: `OPTIMIZE_AD_LOADING: true`
- Delayed measurement: `DELAY_APP_MEASUREMENT_INIT: true`

**AppLovin MAX**:
- `com.applovin.adview.AppLovinFullscreenActivity`
- `com.applovin.mediation.MaxDebuggerActivity` (and 15+ related activities)
- `com.applovin.sdk.AppLovinWebViewActivity`
- `com.applovin.impl.adview.activity.FullscreenAdService`
- Service: `com.geargames.aow.services.ads.ApplovinMaxService`

**IronSource**:
- `com.unity3d.services.ads.adunit.AdUnitActivity` (and 3 variants)
- `com.unity3d.ads.adplayer.FullScreenWebViewDisplay`
- Service: `com.geargames.aow.services.ads.IronSourceService`
  - Sub-services: `Interstitial`, `RewardedVideo`

**Pangle/Bytedance**:
- Version: 8.0.0.4
- 15+ activity types including reward video, full screen, app open ads
- `com.bytedance.sdk.openadsdk.activity.*` activities

**Vungle**:
- `com.vungle.ads.internal.ui.VungleActivity`

**Yandex Mobile Ads**:
- `com.yandex.mobile.ads.common.AdActivity`
- Debug panel with file provider

**Custom Mediation**:
- `com.geargames.aow.services.ads.GGMediation` - Gear Games ad mediation layer

**Facebook SDK**:
- `com.facebook.sdk.AutoInitEnabled: false` - Manual initialization

**MyTarget**:
- `com.my.target.autoInitMode: 0` - Disabled auto-init

### Analytics SDKs

**Yandex AppMetrica**:
- Runs in separate process `:Metrica`
- Service: `com.yandex.metrica.MetricaService`
- Provider: `com.yandex.metrica.PreloadInfoContentProvider`
- Internal service: `io.appmetrica.analytics.internal.AppMetricaService`
- Caffeine cache integration for analytics data
- Service: `com.geargames.aow.services.appmetrica`

**Unity Analytics**:
- `InitUnityAnalytics` method in C# layer
- `IsUnityBuiltinEvent` flag for event classification

### Billing SDKs

**Google Play Billing**:
- Version: 8.0.0
- `com.android.billingclient.api.ProxyBillingActivity`
- `com.android.billingclient.api.ProxyBillingActivityV2`
- `BuyViaProviderBillingRequest` in C# layer
- Service: `com.geargames.aow.services.billing`

### Social/Platform SDKs

**Google Play Games**:
- `com.google.android.gms.games.provider.PlayGamesInitProvider`
- `com.google.android.gms.games.internal.v2.resolution.GamesResolutionActivity`
- `com.google.games.bridge.GenericResolutionActivity`

**Digital Turbine Ignite**:
- `com.digitalturbine.ignite.cl.IgniteRemoteService`

**Amazon Privacy Pass**:
- `com.amazon.privacypass` library (optional)

### Testing Frameworks

**AltUnity Tester**:
- `AltUnityRunner`, `AltUnityDriverAssembly`, `AltUnityGGImprovementsAssembly`
- `AltUnityServerAssembly` - Server-side test component
- `AowAltUnityGGImprovementsAssembly` - Game-specific test improvements
- `AltUnityInputsVisualiser`, `AltUnityPopUp`, `AltUnityIcon` - Test UI elements
- This is a UI testing framework for automated testing

**AndroidX Test**:
- `androidx.test.core.app.InstrumentationActivityInvoker` activities
- Profile installer: `androidx.profileinstaller.ProfileInstallerInitializer`

## Unity Integration

### Unity Player Configuration
- `unityplayer.SkipPermissionsDialog: true` - Skip runtime permissions
- `unity.splash-mode: 2` - Splash screen mode
- `unity.splash-enable: true` - Splash enabled
- `unity.launch-fullscreen: true` - Fullscreen launch
- `unity.render-outside-safearea: true` - Render beyond safe area
- `unity.strip-engine-code: true` - Engine code stripping
- `unity.auto-report-fully-drawn: true` - Auto report startup
- `unity.auto-set-game-state: true` - Auto game state

### Native Library
- `android.app.lib_name: unity` - Unity native library
- Split APK: `base__abi` split required (no libil2cpp.so in base)
- `extractNativeLibs: true` - Extract native libraries

## Service Architecture

### Custom Services (C# Layer)
The game implements services through dependency injection:

| Service | Namespace | Purpose |
|---------|-----------|---------|
| `ApplovinMaxService` | `services.ads` | AppLovin ad mediation |
| `GGMediation` | `services.ads` | Custom ad mediation |
| `IronSourceService` | `services.ads` | IronSource ads |
| `AppMetrica` | `services.appmetrica` | Yandex analytics |
| `Billing` | `services.billing` | In-app purchases |
| `FeatureToggle` | `services.featuretoggle` | Feature flags |
| `BatteriesResourceService` | `services.resources` | Battery resource queries |
| `BlueprintsResourceService` | `services.resources` | Blueprint resource queries |
| `RevU` | `services.revu` | Review prompts |
| `Vibro` | `services.vibro` | Haptic feedback |

### Vibro System
- `AowVibro` / `AowVibroAndroid` / `AowVibroEmpty` - Platform-specific haptics
- `AowVibroManager` - Vibration management
- `AowVibroEventType` - Vibration event types
- `AowPlayVibro` - Vibration playback
- `VIBRO_TYPE_NONE` - No vibration type

## Notification System

### Custom Notifications
The game implements a custom notification system overriding Firebase defaults:
- `gg_notifications_use_custom: true`
- `gg_notifications_disable_custom_on_android_12: true`
- Custom icon: `notification_icon` (drawable resource)
- Custom background: `notification_background` (drawable resource)
- Small icon: `notify_icon_small` (drawable resource)

### Permission Handling
The game implements a sophisticated permission request system:
- `CRP_GO_TO_SETTINGS_IF_STANDARD_REQUEST_DENIED_BY_THE_SYSTEM` - Settings redirect
- `CRP_IGNORE_POST_NOTIFICATIONS_PERMISSION_REQUEST` - Ignore notification permission
- `CRP_REQUEST_PUSH_TOKEN_MANUALLY` - Manual push token request
- `CRP_REQUEST_SCHEDULE_EXACT_ALARM_AFTER_POST_NOTIFICATION` - Alarm after notification
- `CRP_USE_OUR_STORE_REVIEW_REQUEST_METHOD` - Custom review method
- `CSRequestPostNotificationsPermissionWindow` - Permission request window
- `IsAllowRequestNotificationsPermission` - Permission state check

## Security Considerations

### Network Security
- `usesCleartextTraffic: true` - Allows HTTP traffic (potential security risk)
- Custom RSA/DES encryption for game protocol
- `CheckNeedVpn` - VPN detection
- `AddressFinder` - Dynamic server resolution

### Memory Security
- `gwpAsanMode: always` - Google's heap buffer overflow detection
- `enableOnBackInvokedCallback: true` - Predictive back gesture support

### Anti-Tampering
- Split APK with `base__abi` required split
- IL2CPP compilation (C# to native code)
- 8 DEX files making static analysis harder
- AltUnity testing framework presence in production build
