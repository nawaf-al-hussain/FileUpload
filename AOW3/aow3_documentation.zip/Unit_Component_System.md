# Unit Component System - Art of War 3: RTS Strategy Game

## Overview

Art of War 3 uses a component-based entity architecture for units and buildings, following a pattern common in Unity games but with custom abstractions that provide type safety and controlled lifecycle management. The system separates entity definitions (prototypes) from runtime instances, uses component composition over inheritance, and provides interface contracts for cross-component communication. This document details the component architecture, interface contracts, and how components interact to form complex unit behaviors.

## Core Architecture

### Entity Prototype System

Units and buildings are defined through a prototype system that separates configuration from runtime state:

**Prototype Interfaces**:
- `IEntityInfo.Prototype` - Entity info prototype accessor
- `IEntityPrototypical.Prototype` - Prototypical interface
- `get_Prototype` methods on both interfaces

**Prototype Classes**:
- `UnitPrototype` - Base unit definition with stats, weapons, and behaviors
- `BuildingPrototypes` - Building definition collection
- `BuildingPrototypesMap` - Name-to-prototype mapping
- `BuildingLevelPrototypeId` - Per-level prototype reference
- `AvailableUnitPrototypes` - Unlocked unit prototypes

**Prototype Flow**:
1. Game loads prototype definitions from `BattleBaseDictionary`
2. Prototypes are stored in `BuildingPrototypesMap` / `UnitPrototype` collections
3. Runtime instances reference their prototype for base stats
4. Modifications overlay on top of prototype values
5. `IsUnitPrototypeOpened` checks if prototype is available to player

### Entity Instance System

Runtime entities are created from prototypes:

**Unit Instance**: `ClientUnit` - Runtime unit with:
- Reference to `UnitPrototype` for base stats
- Active component collection
- Runtime state (position, health, selected, etc.)
- Weapon instances
- Modification overrides

**Building Instance**: `ClientBuilding` - Runtime building with:
- Reference to building prototype
- Active component collection
- Construction/upgrade state
- Production queue
- Energy connection state

## Component Base Classes

### AbstractUnitComponent
The base class for all unit components:

```
AbstractUnitComponent
  +-- (various specific components)
```

Each unit component:
- Has a defined lifecycle (initialize, update, destroy)
- Can query other components on the same entity
- Receives events from the entity's event router
- Has controlled enable/disable state

**Component Lifecycle**:
1. Entity created from prototype
2. Components instantiated based on prototype definition
3. Components initialized with prototype data
4. Components registered with entity's component system
5. Components updated each tick during battle
6. Components destroyed when entity is removed

### AbstractBuildingComponent
The base class for all building components:

```
AbstractBuildingComponent
  +-- AbstractBuildingGroundComponent
```

Building components handle:
- Construction state
- Production queue management
- Upgrade processing
- Energy consumption
- Weapon system (for towers)

### Component Collection

`BuildingComponents` manages the collection of components on a building entity. Each component type has a specific role:

- Construction component: Manages build progress
- Production component: Manages unit production queue
- Upgrade component: Manages level progression
- Energy component: Manages power connection
- Weapon component: Manages defensive weapons (towers)
- Rally point component: Manages unit spawn destination

## Interface Contracts

### IEntityInfo Interface
Provides entity information access:
- `Prototype` property - Get the entity's prototype definition
- `get_Prototype` method - Accessor for prototype

### IEntityPrototypical Interface
Marks entities that follow the prototype pattern:
- `Prototype` property - Get/set prototype reference
- `get_Prototype` method - Accessor

### IComponentCleanable Interface
In `com.geargames.aow.client.gui.managedwindow`:
- `Clean` method - Reset component state for reuse

### IAsyncExecutable Interface
In `com.geargames.aow.ui.dispatchers`:
- `ExecuteAsync` method - Asynchronous execution

### IOptimizable Interface
In `com.geargames.aow.ui.dispatchers`:
- `Optimize` method - Performance optimization pass

### IReadOnlyListPresenter Interface
In `com.geargames.aow.ui`:
- `UpdateList<TModel>` method - Update displayed list

### IWindowFactory Interface
In `com.geargames.aow.scenes.main`:
- `Create` method - Create window instance

### IBattleReplayRestartable Interface
In `com.geargames.aow.scenes.battle.unity`:
- `OnGameObjectsActivated` method - Handle replay restart
- `OnSceneReset` method - Handle scene reset for replay

## Unit-Specific Components

### Movement Components

**Ground Movement**: Standard land unit pathfinding and movement
**Air Movement**: `AirUnitMoveEngine` - Air unit movement with:
- `AirUnitLiftDirection` - Takeoff direction
- `AirUnitSpecFromModeEngine` - Special mode transition (to air)
- `AirUnitSpecToModeEngine` - Special mode transition (from air)
- `AbstractAirUnitSpecTransferModeEngine` - Base mode transfer

**Water Movement**: Naval unit movement with water-specific physics
**Amphibious Movement**: Combined ground/water (Salamander, Solaris)

### Weapon Components

**Weapon Hierarchy**:
```
AbstractClientWeapon (base)
  +-- AbstractClientEnginedWeapon (engine-driven)
  +-- AtlantMainClientWeapon (Atlas main gun)
  +-- AtlantActiveClientWeapon (Atlas active ability)
```

**Weapon Component Features**:
- `MainTowerWeapon` - HQ defensive weapon
- `UnitStrafeTower` - Tower strafing behavior
- `AbilityWeaponId` / `ActiveAbilityWeaponId` - Ability weapon slots
- `AbilityWeaponStateOwnership` - Weapon state control
- `CheckWeaponForAbilities` - Weapon-ability compatibility check
- `GetAdditionalWeapons` - Secondary weapon enumeration
- `CalculateForWeapon` - Damage calculation per weapon

**Weapon State Machine**:
- Idle: Weapon ready, no target
- Aiming: Rotating toward target
- Firing: Active attack cycle
- Cooldown: Post-fire delay
- Disabled: Weapon inactive (stun, no energy)

### Selection Components

**Selection System**:
- `AddUnitToSelection` / `AddUnitsToSelection` - Additive selection
- `AddSelectUnitsByPolygon` / `AddSelectUnitsByRectangle` - Area selection
- `SelectCentralUnit` - Center unit in selection
- `SelectAllUnitsOnMapWithSettings` - Select all units
- `InternalSetUnitSelection` - Internal selection setter
- `GAICommandSelectionClear` - Clear selection (GAI)

**Selection State**:
- Selected: Unit has visual highlight
- Hover: Mouse/touch over unit
- Grouped: Part of a control group

### Visual State Components

**Visual State System**:
- `AbstractUnitVisualState` - Base visual state
- `Battle_IsVisualStateServiceEnabled` - Visual state toggle
- `ApplyUnitStateConfigs` - Apply state visual configuration
- `ApplyUnitAbilityConfigs` - Apply ability visual configuration
- `OverrideUnitState` - Force visual state override

**Visual State Types**:
- Idle: Default animation loop
- Moving: Walk/drive/fly animation
- Attacking: Weapon fire animation
- Dying: Death animation
- Stunned: Stun indicator
- Boosted: Boost visual effect
- Cloaked: Fog/shield visual

### Ability Components

**Hero Ability System**:
- `BaseUnitAbilityDescription` - Ability description base
- `BaseHeroAbilityModelDecorator` - Hero ability model
- `AbstractHeroAbilityEffectsPlayer` - Ability VFX playback
- `ACTIVE_ABILITY_WEAPON_INDEX` - Active ability weapon slot
- `AbilityStoppedHeroStunned` - Stun on ability interrupt

**Ability Types**:
- Active abilities: Player-triggered via `AICommHeroAbilityActive`
- Passive abilities: Auto-triggered based on conditions
- Aura abilities: Persistent area effects

### Transport Components

**Transport System**:
- `AICommUnitsLoadTransport` - Load units into transport
- `AICommUnitsUnloadTransport` - Unload from transport
- Transport capacity tracking
- Transport movement with loaded units
- Unload zone targeting

### Mining Components

**Mining System** (`com.geargames.aow.scenes.battle.entities.components.mine`):
- Mine laying: `AICommMineLay`
- Mine sweeping: `AICommMineSweep`
- `GAICommandMineField` - Scripted mine field
- Mine detection and disarm mechanics
- `GAICommandTutorialFinishConditionMining/Demining` - Mining tutorials
- `GAICommandTutorialCheckSelectedMine` / `GAICommandTutorialCheckMinedArea` - Mine tutorials

### Recoloring Components

**Dynamic Color System** (`com.geargames.aow.scenes.battle.entities.recolorerRenderers`):
- Faction color application
- Health-based color tinting
- Selection highlight colors
- `RecoloringRenderersFoggyDetected` - Fog-affected recoloring

### Event System Components

**Event Routing** (`com.geargames.aow.scenes.battle.entities.eventSystems`):
- `UnitEventRouter` - Route events to appropriate components
- Damage events
- Selection events
- Movement events
- Ability events

## Component Communication

### Event-Driven Communication

Components communicate through the entity's event system:
1. Component A triggers an event (e.g., "weapon fired")
2. `UnitEventRouter` dispatches event to interested components
3. Component B receives event and reacts (e.g., play animation)
4. State changes propagate through the component graph

### Direct Component Access

Components can directly access sibling components:
- Weapon component queries movement component for facing
- Selection component queries weapon component for range display
- Ability component queries weapon component for cooldown
- Visual state component queries all components for state

### Data Flow

```
[Prototype Definition]
        |
        v
[Entity Creation] --> [Component Instantiation]
        |                      |
        v                      v
[Component Initialization] <--+
        |
        v
[Component Update Loop]
   |         |         |
   v         v         v
[Weapon]  [Movement] [Visual]
   |         |         |
   +---------+---------+
        |
        v
[Event Router] --> [Network Serialization]
```

## Component Serialization

Each component's state must be serializable for:
- Network synchronization (AIComm messages)
- Battle replay recording
- Session restore after disconnect
- CRC verification

Component state is serialized through:
- `AICommandsAtTickSTSerializer/STDeserializer` - Batch command serialization
- Individual AIComm serializer/deserializer pairs
- `CRCInfoUnit` - Unit state hash for verification
- `CRCInfoBuilding` - Building state hash for verification

## Building Component System

### Building Ground Component
`AbstractBuildingGroundComponent` manages the visual ground plane for buildings:
- `BuildingGround` - Ground plane renderer
- `BuildingGroundAnimation` - Ground animation state
- `BuildingGroundFader` - Fade in/out
- `BuildingGroundPrefabSettings` - Visual configuration
- `BuildingGroundPrefabsF1/F2` - Faction-specific prefabs
- `BuildingGroundSoundEffector` - Ground sound effects

### Building Slot Components
Building production slots follow a state machine:
- `BaseBuildingSlotState` - Base state
- `ActivatedBuildingSlotStrategy` - Active slot
- `BuildingSlotNotAvailableState` - Locked slot
- `BuildingSlotPresenter1/2/3` - Slot UI presenters

### Building Upgrade Components
- `BuildingUpgradeComponents` - Upgrade logic
- `BuildingUpgradeLevelTransformerDefault` - Level change handler
- `UpgradeBuildings` - Building upgrade collection
- `UpgradeUnits` - Unit upgrade collection
