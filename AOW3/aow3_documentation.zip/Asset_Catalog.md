# Asset Catalog - Art of War 3: RTS Strategy Game

## Overview

Art of War 3 uses Unity's Addressable Asset System to manage 773 assets distributed across 23 asset bundles. The asset system is designed for on-demand loading with separate bundles for maps, VFX, decorations, and UI elements. The split APK architecture (with required `base__abi` split) means the base APK does not contain `libil2cpp.so`, which is delivered through the ABI-specific split. This document provides a comprehensive catalog of all addressable assets and their organization.

## Asset Distribution Summary

| Category | Count | Description |
|----------|-------|-------------|
| Prefabs | 523 | Game object templates (VFX, UI, heroes, buildings) |
| Other | 169 | Materials, models, shaders, animations |
| Images | 58 | Textures, minimaps, sprite sheets |
| Bundles | 23 | Addressable asset bundles |

## Asset Bundles

### Map Bundles (8 maps)
Map bundles contain the terrain, navigation data, and environmental configuration for each battlefield:

| Bundle ID | Path | Description |
|-----------|------|-------------|
| `maps_1_2` | `built-inmaps_assets_1_2/map.prefab.bundle` | Campaign map 1-2 |
| `maps_1_3` | `built-inmaps_assets_1_3/map.prefab.bundle` | Campaign map 1-3 |
| `maps_1_4` | `built-inmaps_assets_1_4/map.prefab.bundle` | Campaign map 1-4 |
| `maps_1_5` | `built-inmaps_assets_1_5/map.prefab.bundle` | Campaign map 1-5 |
| `maps_1_6` | `built-inmaps_assets_1_6/map.prefab.bundle` | Campaign map 1-6 |
| `maps_3_2` | `built-inmaps_assets_3_2/map.prefab.bundle` | Campaign map 3-2 |
| `maps_4_1` | `built-inmaps_assets_4_1/map.prefab.bundle` | Campaign map 4-1 |
| `pvp_11` | `built-inmaps_assets_pvp_11/map.prefab.bundle` | PvP map 11 |

Map naming convention: The first number appears to be the campaign chapter, the second is the mission within that chapter. The `pvp_11` map is a dedicated PvP battlefield.

### Minimap Bundles (9 minimaps)
Each map bundle has a corresponding minimap image bundle:

| Bundle ID | Path | Description |
|-----------|------|-------------|
| minimap_1_2 | `built-inminimaps_assets_1_2/minimap.png.bundle` | Minimap for map 1-2 |
| minimap_1_3 | `built-inminimaps_assets_1_3/minimap.png.bundle` | Minimap for map 1-3 |
| minimap_1_4 | `built-inminimaps_assets_1_4/minimap.png.bundle` | Minimap for map 1-4 |
| minimap_1_5 | `built-inminimaps_assets_1_5/minimap.png.bundle` | Minimap for map 1-5 |
| minimap_1_6 | `built-inminimaps_assets_1_6/minimap.png.bundle` | Minimap for map 1-6 |
| minimap_3_2 | `built-inminimaps_assets_3_2/minimap.png.bundle` | Minimap for map 3-2 |
| minimap_4_1 | `built-inminimaps_assets_4_1/minimap.png.bundle` | Minimap for map 4-1 |
| minimap_empty | `built-inminimaps_assets_minimap_empty.png.bundle` | Empty/default minimap |
| minimap_pvp_11 | `built-inminimaps_assets_pvp_11/minimap.png.bundle` | Minimap for PvP 11 |

### VFX Bundle (1 bundle)
| Bundle ID | Path | Description |
|-----------|------|-------------|
| vfx | `built-invfx_assets_all.bundle` | All visual effects assets |

The VFX bundle is a monolithic bundle containing all particle effects, projectile visuals, explosion effects, and hero ability effects. This design choice means all VFX must be downloaded before any battle can start, but avoids per-effect loading during gameplay.

### Decoration Bundles (3 bundles)
| Bundle ID | Path | Description |
|-----------|------|-------------|
| decorations-common | `decorations-common_assets_all.bundle` | Common/war theme decorations |
| decorations-desert | `decorations-desert_assets_all.bundle` | Desert biome decorations |
| decorations-jungle | `decorations-jungle_assets_all.bundle` | Jungle biome decorations |

Maps are themed with specific decoration sets. The "common" set likely applies to the war/standard theme, while desert and jungle provide biome-specific environmental objects.

### System Bundles (2 bundles)
| Bundle ID | Path | Description |
|-----------|------|-------------|
| unitybuiltinshaders | `6fa4f6a0b6639b945af95f3940a532e6_unitybuiltinshaders.bundle` | Unity built-in shaders |
| defaultlocalgroup | `defaultlocalgroup_assets_all.bundle` | Default local group assets |

## Hero VFX Prefabs

The game features extensive hero-specific visual effects, each hero having fire, bullet, impact, and death prefabs:

### Wasp (Hero)
- `hero_fire_wasp_acid`, `hero_fire_wasp_rocket` - Attack effects
- `hero_bul_wasp_acid`, `hero_bul_wasp_rocket` - Projectile effects
- `hero_impact_wasp_acid`, `hero_impact_wasp_rocket_*` - Impact effects (ground/veh/water)
- `hero_impact_wasp_smoke` - Smoke effect
- `hero_wasp_collecting_ground`, `hero_wasp_collecting_water` - Resource collection
- `hero_wasp_death` - Death effect
- `wasp_acid`, `wasp_aura`, `wasp_passive` - Aura/passive effects
- `bul_wasp_s1` - Basic projectile

### Beholder (Hero)
- `hero_fire_beholder_scanner`, `hero_fire_beholder_lazer` - Attack effects
- `hero_bul_beholder_lazergun` - Laser projectile
- `hero_impact_beholder_lazer_*` - Laser impact (ground/inf/veh/water)
- `hero_impact_beholder_scanner` - Scanner impact
- `hero_beholder_death` - Death effect
- `hero_beholder_fire` - Fire effect
- `hero_beholder_turbine_idle`, `hero_beholder_turbine_move` - Movement effects
- `anim_hero_impact_beholder_scanner` - Scanner animation
- `material_beholder_scanner` - Scanner material

### Salamander (Hero)
- `hero_fire_salamander_rocket` - Rocket attack
- `hero_bul_salamander_rocket` - Rocket projectile (`bul_rocket_small_salamander`)
- `hero_impact_salamander_rocket_*` - Impact effects (air/ground/water)
- `hero_salamander_death`, `hero_salamander_death_water` - Death effects
- `hero_salamander_emersion` - Submerge/emerge effect
- `hero_salamander_turbo` - Turbo/boost effect
- `waves_sides_salamander` - Water wave effect

### Atlas/Atlant (Hero)
- `hero_fire_atlant_gun`, `hero_fire_atlant_barrage` - Attack effects
- `hero_bul_atlant_gun`, `hero_bul_atlant_barrage` - Projectile effects
- `hero_impact_atlant_gun_*` - Gun impact (air/ground/veh/water)
- `hero_impact_atlant_barrage_*` - Barrage impact (ground/veh/water)
- `hero_death_atlant_first`, `hero_death_atlant_second` - Death phases
- `eff_atlant_immortality` - Immortality/shield effect
- `hero_atlant_barrage_deactivate` - Barrage deactivation

### CoilTank (Hero)
- `hero_fire_coiltank_ball`, `hero_fire_coiltank_electrodes`, `hero_fire_coiltank_lightning`, `hero_fire_coiltank_nova` - Attack effects
- `hero_bul_coiltank_ball`, `hero_bul_coiltank_lightning` - Projectile effects
- `hero_impact_coiltank_ball_*` - Ball impact (air/damage/ground/inf/veh/water)
- `hero_impact_coiltank_lightning_*` - Lightning impact (air/ground/inf/veh/water)
- `hero_impact_coiltank_nova_*` - Nova impact (air/ground/inf/veh)
- `hero_impact_coiltank_electrodes`, `hero_impact_coiltank_stun` - Electrode/stun effects
- `hero_charge_coiltank_ball`, `hero_charge_coiltank_nova` - Charge effects
- `hero_idle_coiltank_coil`, `hero_idle_coiltank_electrodes` - Idle effects
- Custom materials: `coiltank_ball_bul_additive`, `coiltank_ball_bul_offset`, `coiltank_lightning_1` through `coiltank_ligtning_5`, `coiltank_ring_add`

### CryoTank (Hero)
- `hero_fire_cryotank_gun`, `hero_fire_cryotank_frostbomb`, `hero_fire_cryotank_nova` - Attack effects
- `hero_bul_cryotank_gun`, `hero_bul_cryotank_frostbomb` - Projectile effects
- `hero_impact_cryotank_gun_*` - Gun impact (ground/veh/water)
- `hero_impact_cryotank_frostbomb` - Frostbomb impact
- `hero_impact_cryotank_boom_*` - Boom impact (ground/water)
- `hero_impact_cryotank_nova_*` - Nova impact (air/ground/inf/veh)
- `hero_funnel_cryotank_boom`, `hero_funnel_cryotank_gun` - Funnel effects
- `eff_cryo_capsule_collect`, `eff_cryo_capsule_spawn`, `eff_cryo_smoke` - Capsule effects

### Gatling (Hero)
- `hero_fire_gatling_gun`, `hero_fire_gatling_explosive` - Attack effects
- `hero_bul_gatling_gun`, `hero_bul_gatling_explosive`, `hero_bul_gatling_smoke` - Projectile effects
- `hero_impact_gatling_explosive` - Explosive impact
- `hero_boom_gatling_explosive_*` - Explosion effects (ground/veh/water)
- `hero_boom_gatling_smoke`, `hero_boom_gatling_smoke_water` - Smoke effects
- `hero_gatling_boom_death`, `hero_gatling_smoke_aura` - Death/aura effects
- `fx_hero_gatling_gun_heat` - Gun heat material

### Railgun (Hero)
- `hero_fire_railgun_march`, `hero_fire_railgun_quake`, `hero_fire_railgun_siege` - Attack modes
- `hero_bul_railgun_march`, `hero_bul_railgun_quake`, `hero_bul_railgun_siege` - Projectile effects
- `hero_impact_railgun_march_*` - March impact (ground/veh/water)
- `hero_impact_railgun_quake_*` - Quake impact (ground/veh/water)
- `hero_impact_railgun_siege_*` - Siege impact (ground/veh/water)
- `hero_funnel_railgun_quake` - Funnel effect

### Leviaphan (Hero)
- `hero_fire_leviaphan_gun`, `hero_fire_leviaphan_nuclear` - Attack effects
- `hero_bul_leviaphan_gun_air`, `hero_bul_leviaphan_gun_front`, `hero_bul_leviaphan_gun_side` - Directional projectiles
- `hero_impact_leviaphan_gun_*` - Gun impact (air/ground/veh/water)
- `hero_impact_leviaphan_nuclear`, `hero_impact_leviaphan_nuclear_water` - Nuclear impact
- `hero_leviaphan_death` - Death effect
- `hero_leviaphan_nuke_prepare`, `hero_leviaphan_nuke_start` - Nuclear launch sequence
- `hero_leviaphan_passive` - Passive effect
- `hero_leviaphan_turbine_*` - Turbine effects (main/side idle/move)

### Seraphim (Hero)
- `hero_fire_seraphim_lazer`, `hero_fire_seraphim_kara` - Attack effects
- `hero_bul_seraphim_lazergun`, `hero_bul_seraphim_kara` - Projectile effects
- `hero_impact_seraphim_lazer_*` - Laser impact (ground/veh/water)
- `hero_impact_seraphim_kara_*` - Kara impact (ground/veh/water)
- `hero_seraphim_boom_death`, `hero_seraphim_boom_pre_death` - Death effects
- `hero_seraphim_boom_air_death`, `hero_seraphim_boom_air_pre_death` - Air death
- `hero_seraphim_turbine_*` - Turbine effects (down/idle/move/up/turbo)
- `hero_seraphim_waves_ground` - Ground wave effect

### Solaris (Hero)
- `hero_fire_solaris_gun`, `hero_fire_solaris_impulse`, `hero_fire_solaris_impulse_2`, `hero_fire_solaris_lightning` - Attack effects
- `hero_bul_solaris_gun`, `hero_bul_solaris_impulse`, `hero_bul_solaris_lightning` - Projectile effects
- `hero_impact_solaris_gun_*` - Gun impact (ground/tech/water)
- `hero_impact_solaris_impulse_*` - Impulse impact (ground/veh)
- `hero_impact_solaris_lightning` - Lightning impact
- `hero_solaris_death_ground`, `hero_solaris_death_water` - Death effects
- `hero_solaris_idle_water`, `hero_solaris_move`, `hero_solaris_move_water` - Movement
- `hero_solaris_charge` - Charge effect
- `hero_solaris_waves_ground` - Ground wave
- `hero_smoke_solaris` - Smoke effect
- `SolarisChainMaterial`, `SolarisChainLine` - Chain/lightning materials

### Cerber (Hero)
- `hero_fire_cerber_machinegun`, `hero_fire_cerber_grenade`, `hero_fire_cerber_knife` - Attack effects
- `hero_bul_cerber_machinegun`, `hero_bul_cerber_grenade` - Projectile effects
- `hero_impact_cerber_machinegun_*` - MG impact (ground/inf/veh/water)
- `hero_impact_cerber_grenade_*` - Grenade impact (ground/tech/water)
- `hero_impact_cerber_blade_*` - Blade impact (inf/veh)
- `hero_impact_cerber_flydeath` - Fly death impact
- `hero_cerber_jump_jet_1`, `hero_cerber_jump_jet_ground` - Jump jet effects
- `hero_cerber_jump_trail`, `hero_cerber_knife_trail`, `hero_cerber_trail` - Trail effects
- `cerber_aura`, `funnel1_cerber` - Aura/funnel effects

### Codomash (Hero)
- `hero_fire_codomash_turret` - Turret fire
- `hero_bul_codomash_turret` - Turret projectile
- `hero_impact_codomash_*` - Impact effects (bur_inf/bur_veh/ground/veh/water)
- `hero_codomash_active_ability`, `hero_codomash_death`, `hero_codomash_move` - Ability/death/move
- `hero_codomash_passive_from`, `hero_codomash_passive_to` - Passive mode transition
- `hero_codomash_spec_from`, `hero_codomash_spec_to` - Spec mode transition
- `hero_codomash_turret_birth`, `hero_codomash_turret_death` - Turret lifecycle
- `fx_codomash_ground` - Ground effect material

## Building Prefabs

Building prefabs follow the naming pattern `bld_[type]_[faction]` where faction numbers correspond to player sides:

| Prefab | Description |
|--------|-------------|
| `bld_building1_s1` | Building type 1, side 1 |
| `bld_building1_s2` | Building type 1, side 2 |
| `bld_building1_s3` | Building type 1, side 3 |
| `bld_destroy1_s1` | Destroyed building, side 1 |
| `bld_destroy1_s2` | Destroyed building, side 2 |
| `bld_destroy1_s3` | Destroyed building, side 3 |
| `bld_destroy2_s2_w` | Destroyed building 2, side 2, water |
| `bld_destroy2_s3_w` | Destroyed building 2, side 3, water |

## Explosion VFX Prefabs

Explosions are categorized by size (s0-s6), surface type (ground/water/veh/inf/air), and source:

| Pattern | Examples |
|---------|---------|
| `boom_expl1_s[0-6]_[surface]` | Standard explosions, sizes 0-6 |
| `boom_expl2_s[1-3]_[surface]` | Secondary explosions |
| `boom_expl3_s[1-4]_[surface]` | Tertiary explosions |
| `boom_expl4_s1_ground` | Small infantry explosion |
| `boom_expl5_s5_nuke*` | Nuclear explosion (ground/rocket/water) |
| `boom_expl5_s5_space*` | Space weapon (default/ray/water) |
| `boom_bld_expl[1-2]*` | Building explosions |
| `boom_unit_expl[1-4]*` | Unit explosions |
| `boom_rifle1_s[1-4]_[surface]` | Rifle impact effects |

## Projectile VFX Prefabs

Projectiles follow the naming pattern `bul_[type]_[size/faction]`:

| Pattern | Examples |
|---------|---------|
| `bul_rifle[1-2]_s[1-5]` | Rifle projectiles |
| `bul_tank[1-4]_s[1-3]` | Tank shells |
| `bul_rocket[1-4]_s[1-5]` | Rockets |
| `bul_rocket3_s5_nuke` | Nuclear rocket |
| `bul_bomb[1-2]` | Bombs |
| `bul_grenade[1-2]` | Grenades |
| `bul_torpedo[1-4]` | Torpedoes |
| `bul_ufo_lazergun` | UFO laser |

## UI Prefabs

| Prefab | Description |
|--------|-------------|
| `animation_battle_defeat` | Battle defeat animation |
| `animation_battle_defeat_without_end` | Defeat without end screen |
| `animation_battle_roundswitch` | Round switch animation |
| `animation_battle_win` | Victory animation |
| `animation_battle_win_without_end` | Victory without end screen |
| `window_magic` | Magical window (login) |
| `panel_entrance_14_day` | 14-day login reward |
| `panel_entrance_30_day_premium` | 30-day premium |
| `panel_entrance_30_day_premium_with_banner` | Premium with banner |
| `panel_select_faction` | Faction selection |
| `effect_progressbar` | Progress bar VFX |
| `cloud` | Cloud environment object |

## Terrain and Decoration Assets

### Shader Assets
| Asset | Description |
|-------|-------------|
| `Landscape.shader` | Main terrain shader |
| `OpaqueFloraMask.shader` | Opaque vegetation mask |
| `TransparentFloraMask.shader` | Transparent vegetation mask |
| `AOW Water.shader` | Water shader (unused) |
| `Water Waves.shader` | Water wave shader |

### Desert Theme Materials
- `desert_mat_decoration_bridges`, `desert_mat_decoration_cutout`, `desert_mat_decoration_diffuse`, `desert_mat_decoration_diffuse2`
- `desert_mat_decoration_anim_cutout` (animated trees)
- `mat_terrain_desert` - Desert terrain material

### Jungle Theme Materials
- `jungle_mat_decoration_bridges`, `jungle_mat_decoration_diffuse2`, `jungle_mat_decorations_cutout`, `jungle_mat_decorations_diffuse`
- `jungle_mat_decorations_anim_cutout`, `jungle_mat_decorations_anim_cutout_2` (animated trees)
- `mat_terrain_jungle` - Jungle terrain material

### Desert Models
- `desert_bridge`, `desert_dry_grass_2`, `desert_dry_trees_2`, `desert_ground_grass`, `desert_ground_grass2`
- `desert_houses`, `desert_objects_1`, `desert_objects_2`
- `desert_road_angle_asphalt`, `desert_road_mirror`, `desert_road_up`
- `desert_stones_2`, `desert_thorn`

### Jungle Models
- `jungle_3dgras`, `jungle_bent_trees`, `jungle_border_bushes`, `jungle_bridge_wide`, `jungle_bridges`
- `jungle_bush`, `jungle_bush_and_stones1`, `jungle_goingup_planes`, `jungle_ground_atlas_2`
- `jungle_ground_grass2`, `jungle_ground_grasses3`, `jungle_grounds_grass`
- `jungle_houses`, `jungle_middlepath_stones`, `jungle_objekts_atlas_2`
- `jungle_palm_hight`, `jungle_palm_low`, `jungle_road_angle_asphalt`, `jungle_road_mirror`, `jungle_road_up`
- `jungle_roads`, `jungle_rock_tree`, `jungle_stone`
- `Jungle_Tree_LOW`, `jungle_tree_ultralow`, `jungle_tree_underbrush_new`
- `jungle_trees_hight`, `jungle_under_brushes`, `jungle_waterlily`

### War/Common Models
- `quest_dock`, `quest_objects`, `war_objects`

### Textures
- Desert: `tex_terrain_desert.jpg`, `tex_ground_desert.png`, `tex_ground_desert_alpha.png`, `tex_objects_desert.png`, `tex_objects_desert_alpha.png`
- Jungle: `tex_terrain_jungle.jpg`, `tex_ground_jungle.png`, `tex_ground_jungle_02.png`, `tex_objects_jungle.png`, `tex_objects_jungle_2.png`, `tex_objects_jungle_alpha.png`, `tex_objects_jungle_2_alpha.png`
- Common: `tex_cloud.png`, `tex_war_objects.png`, `tex_war_objects_alpha.png`
- Water: `water_color_11.png`, `water_color_12.png`, `noise.jpg`
