# Art of War 3 Recreation Blueprint - Architecture Spec and Data Models

## Overview

This document provides a comprehensive blueprint for recreating the Art of War 3 game based on reverse engineering findings. It covers the overall architecture, data models, network protocol, and system designs needed to build a functionally equivalent game. The blueprint is informed by the actual class names, message types, and system interactions discovered in the binary analysis of version 6.5.22.

## Target Architecture

### High-Level Architecture

```
[Client Application]
   |
   +-- [Presentation Layer] (Unity/Custom Engine)
   |     +-- Scene Management (Battle, Main Menu, Login, Loading)
   |     +-- UI System (MVP Pattern)
   |     +-- VFX System (Particle Effects, Projectiles)
   |     +-- Audio System (Sounds, Voice, Music)
   |     +-- Input System (Touch, Gesture, Keyboard)
   |
   +-- [Game Logic Layer]
   |     +-- Battle Simulation (Deterministic Lockstep)
   |     +-- Unit System (Component-Based)
   |     +-- Building System (Production, Energy Grid)
   |     +-- Combat System (Damage Pipeline, Armor)
   |     +-- AI System (GAI Scripting, Bot AI)
   |     +-- Economy System (Resources, Boosts, Billing)
   |     +-- Meta-Game (Campaign, Clan, Tournament, Chat)
   |
   +-- [Network Layer]
   |     +-- TCP Transport (Custom Protocol)
   |     +-- Encryption (RSA/DES Hybrid)
   |     +-- Serialization (STSerializer/STDeserializer)
   |     +-- Message System (Request/Answer Pattern)
   |     +-- Session Management (Auth, Reconnect)
   |
   +-- [Data Layer]
         +-- Configuration (Battle Base Dictionary)
         +-- Asset Management (Addressable Assets)
         +-- Profile Storage (Player Progress)
         +-- Caching (Resource Cache)
```

### Server Architecture (Inferred)

```
[Game Server]
   |
   +-- [Login Server]
   |     +-- Authentication
   |     +-- Profile Management
   |     +-- Address Resolution
   |
   +-- [Battle Server]
   |     +-- Matchmaker
   |     +-- Battle Session Management
   |     +-- Command Validation
   |     +-- CRC Verification
   |     +-- Desync Detection
   |
   +-- [Meta Server]
   |     +-- Clan Management
   |     +-- Chat Relay
   |     +-- Tournament Management
   |     +-- Billing Processing
   |     +-- Configuration Distribution
   |
   +-- [Database]
         +-- Player Profiles
         +-- Clan Data
         +-- Rankings/Ratings
         +-- Billing Records
         +-- Configuration
```

## Core Data Models

### Unit Model

```typescript
interface UnitPrototype {
  id: string;
  name: string;
  faction: number; // s1, s2, s3
  category: UnitCategory; // Infantry, Vehicle, Aircraft, Naval, Hero
  armorType: ArmorType; // Light, Medium, Heavy
  baseStats: UnitStats;
  weapons: WeaponDefinition[];
  abilities: AbilityDefinition[];
  productionBuilding: string; // Building type that produces this unit
  productionCost: ResourceCost;
  productionTime: number; // seconds
  modifications: ModificationDefinition[];
  isHero: boolean;
  heroData?: HeroData;
}

enum UnitCategory {
  Infantry = "infantry",
  Vehicle = "vehicle",
  Aircraft = "aircraft",
  Naval = "naval",
  Hero = "hero"
}

enum ArmorType {
  Light = "light",
  Medium = "medium",
  Heavy = "heavy"
}

interface UnitStats {
  health: number;
  armor: number;
  speed: number;
  sight: number;
  energy: number;
  attackInterval: number;
  attackBonus: number;
}

interface WeaponDefinition {
  id: string;
  name: string;
  damage: number;
  range: number;
  attackInterval: number;
  projectileType: ProjectileType;
  targetCategories: UnitCategory[];
  surfaceType: SurfaceType; // ground, water, air
  isAbilityWeapon: boolean;
}

enum ProjectileType {
  Bullet = "bullet",
  Rocket = "rocket",
  Laser = "laser",
  Torpedo = "torpedo",
  Bomb = "bomb",
  Grenade = "grenade",
  Lightning = "lightning",
  Acid = "acid",
  Psionic = "psionic"
}

enum SurfaceType {
  Ground = "ground",
  Water = "water",
  Air = "air"
}

interface AbilityDefinition {
  id: string;
  name: string;
  type: "active" | "passive" | "aura";
  energyCost: number;
  cooldown: number;
  duration: number;
  weaponIndex: number; // ACTIVE_ABILITY_WEAPON_INDEX
  effects: AbilityEffect[];
}

interface HeroData {
  heroType: HeroType;
  maxUpgradeCount: number;
  cardsRequired: number[];
  slotIndex: number; // 0, 1, or 2
  abilityDescriptions: HeroAbilityDescription[];
}

enum HeroType {
  Wasp = "wasp",
  Beholder = "beholder",
  Salamander = "salamander",
  Atlas = "atlas",
  CoilTank = "coiltank",
  CryoTank = "cryotank",
  Gatling = "gatling",
  Railgun = "railgun",
  Leviaphan = "leviaphan",
  Seraphim = "seraphim",
  Solaris = "solaris",
  Cerber = "cerber",
  Codomash = "codomash"
}

interface ResourceCost {
  gold: number;
  energy: number;
  uranium: number;
  batteries: number;
  blueprints: number;
}
```

### Building Model

```typescript
interface BuildingPrototype {
  id: string;
  name: string;
  type: BuildingType;
  faction: number;
  size: { width: number; height: number };
  levels: BuildingLevel[];
  limitations: BuildingLimitations;
  energyProduction: number;
  energyConsumption: number;
  producesUnits: string[]; // Unit prototype IDs
  weapons: WeaponDefinition[]; // For towers
}

enum BuildingType {
  HQ = "hq",
  ConstructionYard = "constr_yard",
  Barracks = "barracks",
  AdvancedFactory = "advanced_factory",
  AssaultFactory = "assault_factory",
  AirFactory = "air_factory",
  Airport = "airport",
  Shipyard = "shipyard",
  PowerStation = "power_station",
  SupplyDepot = "supply_depot",
  Tower = "tower",
  Bunker = "bunker",
  AirDefense = "air_defense",
  NavalTurret = "naval_turret",
  Wall = "wall",
  NuclearSilo = "nuclear_silo",
  Hero = "hero_building"
}

interface BuildingLevel {
  level: number;
  health: number;
  armor: number;
  regen: number;
  sight: number;
  price: ResourceCost;
  constructionTime: number;
  energyProduction: number;
  energyConsumption: number;
  upgradeSlotId: string;
}

interface BuildingLimitations {
  maxCount: number;
  requiresBuilding: string | null;
  requiresLevel: number;
  restrictedArea: boolean;
}
```

### Battle Model

```typescript
interface BattleConfiguration {
  battleId: string;
  templateId: string;
  mapId: string;
  format: BattleFormat;
  type: BattleType;
  sides: BattleSide[];
  alliances: BattleAlliance[];
  conditions: BattleCondition[];
  objectives: BattleObjective[];
  networkConfig: BattleNetworkConfiguration;
}

enum BattleFormat {
  PvP1v1 = "1v1",
  PvP3v3 = "3v3",
  PvE = "pve",
  Coop = "coop",
  Tournament = "tournament"
}

enum BattleType {
  Skirmish = "skirmish",
  Campaign = "campaign",
  Ranked = "ranked",
  Custom = "custom"
}

interface BattleSide {
  sideNumber: number;
  allianceNumber: number;
  player: PlayerInfo;
  startingResources: ResourceCost;
  buff: BattleSideBuff | null;
}

interface BattleAlliance {
  number: number;
  sides: number[];
  description: BattleAllianceDescription;
}

interface CRCInfo {
  tick: number;
  sides: CRCInfoSide[];
}

interface CRCInfoSide {
  sideNumber: number;
  buildings: CRCInfoBuilding[];
  units: CRCInfoUnit[];
}

interface CRCInfoBuilding {
  id: string;
  position: { x: number; y: number };
  health: number;
  level: number;
  type: string;
}

interface CRCInfoUnit {
  id: string;
  position: { x: number; y: number };
  health: number;
  state: string;
  type: string;
}
```

### Network Message Model

```typescript
interface NetworkMessage {
  type: MessageType;
  messageId: number;
  senderId: number;
  timestamp: number;
  payload: Uint8Array; // Serialized via GearGamesByteBuffer
}

enum MessageType {
  Request = "request",
  Answer = "answer",
  Notification = "notification",
  AIComm = "aicomm",
  Batch = "batch",
  Complex = "complex"
}

interface AICommCommand {
  commandType: AICommType;
  tick: number;
  sideNumber: number;
  data: Uint8Array; // Command-specific serialized data
}

enum AICommType {
  UnitsMove = 0,
  UnitsStop = 1,
  UnitsHoldPosition = 2,
  UnitsBombard = 3,
  UnitsPatrolTargeting = 4,
  UnitsSpec = 5,
  UnitsPsionic = 6,
  UnitsLoadTransport = 7,
  UnitsUnloadTransport = 8,
  BuSet = 9,
  BuildingUpgrade = 10,
  BuildingRemove = 11,
  BuildingRepair = 12,
  BuildingRallyPoint = 13,
  BuyUnit = 14,
  CancelBuyUnit = 15,
  HeroActivate = 16,
  HeroActivateAndBuy = 17,
  HeroAbilityActive = 18,
  HeroBatteryBuy = 19,
  HeroEnergyRefill = 20,
  NuclearLaunch = 21,
  Implosion = 22,
  MineLay = 23,
  MineSweep = 24,
  AircraftRebase = 25,
  UnitBombersTargeting = 26,
  FightersGuard = 27,
  Surrender = 28,
  SurrenderSpectator = 29,
  BattleResume = 30,
  ChatMessageSend = 31,
  BoostBuyAndApply = 32,
  Boost = 33,
  BonusChest = 34,
  DeployExtend = 35,
  Settings = 36,
  Squad = 37,
  CRCRequest = 38,
  CRCAnswer = 39,
  Verify = 40,
  SyncTest = 41,
  ExecutionLags = 42,
  TutorialFinished = 43,
  WinPVE = 44,
  WinPVP = 45,
  WinPVPSingleSide = 46,
  NotValid = -1
}
```

### GAI Script Model

```typescript
interface GAIScript {
  nodes: GAINode[];
  variables: { counters: Map<string, number>; flags: Set<string> };
  sideConfig: GAISideConfig[];
}

interface GAINode {
  id: string;
  command: GAICommandType;
  parameters: Record<string, any>;
  dependencies: GAIDependency[];
  nextNode: string | null;
  jumpTargets: Map<string, string>; // condition -> node id
}

enum GAICommandType {
  // Flow Control
  ChanceJump = "chance_jump",
  CounterJump = "counter_jump",
  FlagJump = "flag_jump",
  FlagJumpCancel = "flag_jump_cancel",
  SequentJump = "sequent_jump",
  TriggerJump = "trigger_jump",
  RandomJump = "random_jump",
  LoopStart = "loop_start",
  LoopEnd = "loop_end",
  // Counter/Flag
  Counter = "counter",
  CounterInc = "counter_inc",
  CounterCompare = "counter_compare",
  Flag = "flag",
  FlagRemove = "flag_remove",
  // Building
  Building = "building",
  BuildingSetPlace = "building_set_place",
  BuildingSetRestrict = "building_set_restrict",
  BuildingHideFromList = "building_hide_from_list",
  BuildingNeutral = "building_neutral",
  Construction = "construction",
  // Army
  ArmySet = "army_set",
  ArmyConditional = "army_conditional",
  AttackSet = "attack_set",
  TroopMove = "troop_move",
  TroopCute = "troop_cute",
  TroopDrop = "troop_drop",
  TroopEvacuate = "troop_evacuate",
  // Camera
  CameraSet = "camera_set",
  CameraSave = "camera_save",
  CameraRestore = "camera_restore",
  CameraMask = "camera_mask",
  CameraTranslateDisable = "camera_translate_disable",
  // Combat
  DamageBonus = "damage_bonus",
  DamageReduce = "damage_reduce",
  Explosion = "explosion",
  MineField = "mine_field",
  NuclearStrike = "nuclear_strike",
  // Resource
  Gold = "gold",
  Health = "health",
  EventCurrency = "event_currency",
  BoostAdd = "boost_add",
  // UI
  Dialog = "dialog",
  DarkenBuUn = "darken_bu_un",
  DarkenMapArea = "darken_map_area",
  DarkenWidget = "darken_widget",
  MarkBuUn = "mark_bu_un",
  MarkBuUnRemove = "mark_bu_un_remove",
  MarkGround = "mark_ground",
  MarkGroundRemove = "mark_ground_remove",
  MarkWidget = "mark_widget",
  ChangeAppearance = "change_appearance",
  GUILayoutReset = "gui_layout_reset",
  UISwitcher = "ui_switcher",
  // Objective
  ObjectiveAdd = "objective_add",
  ObjectiveChange = "objective_change",
  ProgressBar = "progress_bar",
  ScoreBoard = "score_board",
  // Tutorial (29+ types)
  TutorialBegin = "tutorial_begin",
  TutorialEnd = "tutorial_end",
  TutorialHint = "tutorial_hint",
  TutorialWindow = "tutorial_window",
  // Utility
  CheckPoint = "check_point",
  Timer = "timer",
  TimerCountdown = "timer_countdown",
  Surrender = "surrender",
  Wall = "wall",
  FogOpener = "fog_opener",
  FogOpenerRemove = "fog_opener_remove",
  // ... and more
}

interface GAIDependency {
  type: string;
  parameters: Record<string, any>;
  isSatisfied: () => boolean;
}
```

## Network Protocol Specification

### Transport Protocol
- **Transport**: TCP (persistent connections)
- **Encryption**: RSA/DES hybrid
- **Serialization**: Custom binary (GearGamesByteBuffer)
- **Message Framing**: Length-prefixed messages

### Connection Flow

```
Client                              Server
  |                                    |
  |---- TCP Connect ------------------>|
  |                                    |
  |<--- RSA Public Key ----------------|
  |                                    |
  |---- DES Key (RSA encrypted) ------>|
  |                                    |
  |<--- Auth Challenge ----------------|
  |                                    |
  |---- Auth Response ---------------->|
  |                                    |
  |<--- Configuration Data ------------|
  |                                    |
  |---- Ready to Act ----------------->|
  |                                    |
  |<--- Ready to Act Answer ---------->|
  |                                    |
  | [Battle commands exchange]         |
  |                                    |
  |---- AIComm Commands (per tick) --->|
  |<--- AIComm Commands (per tick) ----|
  |                                    |
  |---- CRC Request ------------------>|
  |<--- CRC Answer --------------------|
  |                                    |
  |---- Battle Finish ---------------->|
  |<--- Battle Finish Notification ----|
```

### Message Format

```
[4 bytes: message length]
[2 bytes: message type]
[4 bytes: message ID]
[4 bytes: sender ID]
[8 bytes: timestamp]
[N bytes: serialized payload]
```

## Implementation Recommendations

### Deterministic Simulation
1. Use fixed-point arithmetic (no floating point)
2. Lockstep tick rate of ~10-20 ticks per second
3. All random numbers from seeded PRNG
4. CRC checks every N ticks
5. Command batching per tick

### Serialization System
1. Implement custom binary serializer per type (avoid reflection)
2. Version all serializable types
3. Support forward/backward compatibility
4. Test with fuzzing for desync prevention

### AI System
1. Implement GAI as a data-driven scripting engine
2. Support hot-reload of GAI scripts for testing
3. Visual editor for GAI node graphs
4. Bot AI as behavior trees consuming GAI commands
5. All AI output expressed as AIComm commands

### Resource Management
1. Use Unity Addressables or equivalent
2. Bundle assets by map and biome
3. Implement resource warming for battle start
4. Cache resources locally with version checking

### Testing Strategy
1. Unit tests for damage pipeline
2. Integration tests for network serialization
3. Fuzz testing for desync detection
4. Replay-based regression testing
5. Automated CRC comparison tests
