# Multiplayer Architecture - Art of War 3: RTS Strategy Game

## Overview

Art of War 3 implements a deterministic lockstep multiplayer architecture with server-authoritative validation. The system is designed for real-time strategy gameplay where precise synchronization between clients is critical. The architecture supports 1v1 PvP, 3v3 PvP, cooperative modes, and tournament formats. The network stack uses a custom TCP protocol with RSA/DES hybrid encryption, custom binary serialization via `GearGamesByteBuffer`, and includes comprehensive desync detection and correction mechanisms.

## Network Stack Architecture

### Layer 1: Transport Layer

The transport layer uses TCP connections with the following infrastructure:

**Address Discovery**: The `AddressFinder` class in `com.geargames.common.network` resolves server addresses dynamically. The `CheckNeedVpn` class determines whether a VPN route is needed to reach game servers, suggesting the game operates servers in regions that may require VPN access from certain locations. The `BattleHosts` class maintains a list of available battle server endpoints.

**Connection Management**: `AbstractClientNetworkConnector` provides the base for all network connections with two concrete implementations:
- `AbstractClientMainNetworkConnector` - Handles lobby/meta-game server connection
- `AbstractClientBattleNetworkConnector` - Handles battle server connection

`ActiveNetworkConnector` manages the currently active connection, handling connection state transitions via `AbstractNetworkConnectorState`.

**Heartbeat System**: Connection health is maintained through heartbeat messages with configurable timeouts:
- `BattlePvPSocketHeartbeatTimeout` - PvP heartbeat interval
- `BattlePvESocketHeartbeatTimeout` - PvE heartbeat interval
- `BattleReceiveMessageTimeoutDefault` - Default receive timeout
- `BattleSendMessageTimeout` - Send timeout
- `CHECK_CONNECTION_MESSAGE_BYTE_SIZE_DEFAULT` - Connection check message size

### Layer 2: Serialization Layer

The serialization layer uses a custom binary format implemented through `GearGamesByteBuffer`:

**GearGamesByteBuffer API**:
- `get()` / `put()` - Read/write primitive values
- `flip()` - Prepare buffer for reading after writing
- `mark()` / `reset()` - Position bookmarking
- `duplicate()` - Create buffer copy
- `size()` - Get buffer size
- `Limit` property - Get/set buffer limit

**Serializer Pattern**: Every network message type has paired `STSerializer` and `STDeserializer` classes (2,598 pairs total). This pattern provides:
- Type-safe serialization with compile-time verification
- Version-safe deserialization with field-level compatibility
- Consistent binary layout across all message types
- No reflection overhead - all serialization code is hand-crafted

**Batch Serialization**: `BATCH_MESSAGE_TYPE`, `COMPLEX_MESSAGE`, and `COMPLEX_BATTLE_MESSAGE` support packing multiple messages into a single network packet for efficiency.

### Layer 3: Encryption Layer

The encryption layer uses hybrid RSA/DES encryption:

**Provider**: `AbstractNetworkCryptoProvider` in `com.geargames.common.network.cryptography` provides the encryption abstraction.

**Protocol**:
1. Client connects and receives server's RSA public key
2. Client generates a random DES session key
3. Client encrypts DES key with server's RSA public key and sends it
4. Both sides use DES symmetric encryption for all subsequent communication
5. This hybrid approach provides RSA-level key exchange security with DES-level performance for bulk data

**Async Handshake**: `AsyncHandshakeRequest` handles the asynchronous key exchange process during connection establishment.

### Layer 4: Message Layer

The message layer implements a reliable request-answer pattern:

**Message Waiter System**: `CSAbstractMessageWaiter<T>` provides typed message waiting with:
- `CSAbstractReliableMessageWaiter<T>` - Reliable delivery with retry
- `CSExpectedServerMessageWasNotReceived` - Timeout exception type
- `AlreadyWaitingForMandatoryMessage` - Duplicate wait prevention
- `AbstractCheckerWaitMessage` - Conditional message checking

**HTTP Fallback**: `CSHttpSendRequestAndReceiveResponse` provides an HTTP-based fallback for messages that cannot use the TCP connection, particularly useful for:
- Initial server discovery
- Reconnection attempts
- Operations when battle server is unreachable

**Push Messages**: `CSPushLaunchMessageSender` handles push notification delivery for out-of-game events like clan calls and battle invitations.

## Authentication Flow

### 1. Login/Logon Phase

The authentication process uses the `com.geargames.aow.scenes.logon` scene:

1. **Address Resolution**: `AddressFinder` locates the appropriate login server
2. **VPN Check**: `CheckNeedVpn` determines if alternate routing is needed
3. **Connection**: `AbstractClientMainNetworkConnector` establishes TCP connection
4. **Encryption Setup**: RSA/DES handshake via `AsyncHandshakeRequest`
5. **Authentication**: `CHAT_LOGIN_REQUEST/ANSWER` authenticates the user
6. **Profile Selection**: `CHOOSE_PROFILE_REQUEST/ANSWER` selects active profile
7. **Configuration Load**: Various configuration messages load game state

**Reconnection**: The `com.geargames.aow.scenes.relogon` scene handles reconnection with:
- `CSMainSessionRestoreAnswerReceiver` for session restoration
- `BattleSessionRestoreResponseTimeout` for timing restoration attempts
- `BattleSessionRestoreAttemptCount` tracking restoration retries

### 2. Battle Connection Phase

Once a battle is matched, the client transitions to the battle server:

1. **Battle Login**: `CSBattleLoginToBattle` authenticates with battle server
2. **Map Resources**: `CSLoadMapResources` downloads map data
3. **Initialization**: `CSBattleInitializeWaiter` waits for full initialization
4. **Load Progress**: `BattleLoadProgressRequest/Answer/Notification` synchronizes loading between players
5. **Battle Start**: `CSBattleRun` signals the battle to begin

## Matchmaking System

### PvP Matchmaking

The matchmaking system uses the lobby infrastructure in `com.geargames.aow.entities.lobby`:

**1v1 Matchmaking**:
- Player selects battle template via `BattleTemplateId`
- `BattleStartRequest` initiates matchmaking
- Server finds opponent based on rating/army composition
- `AppointStartMessage` notifies both players when match is found
- `AppointStartBattlePvPTimeout` and `AppointStartBattlePvETimeout` control appointment timeouts

**3v3 Matchmaking**:
- `BATTLE_3X3_RANDOM_REQUEST/ANSWER` initiates 3v3 search
- `BATTLE_3X3_RANDOM_CANCEL_REQUEST/ANSWER` cancels search
- Teams are formed by the server from individual players

**Coop Matchmaking**:
- `COMPETITION_COOP_MATCHING_ADD_REQUEST/ANSWER` adds player to coop pool
- `COMPETITION_COOP_MATCHING_LIST_REQUEST/ANSWER` shows available matches
- `COMPETITION_COOP_MATCHING_REMOVE_REQUEST/ANSWER` removes from pool
- `COMPETITION_COOP_BATTLE_INVITE_REQUEST/ANSWER` sends coop invite
- `COMPETITION_COOP_BATTLE_CANCEL_REQUEST/ANSWER` cancels coop battle

### Battle Templates

The `BattleTemplate` system defines battle configurations:
- `BattleTemplateId` - Unique template identifier
- `BattleTemplateModel` / `BattleTemplateModelFactory` - Template data models
- `BattleTemplates` - Collection of available templates
- `AvailableBattleTemplates` - Player-accessible templates
- `BattleFormat` / `BattleFormats` / `BattleFormatExtension` - Format definitions
- `BattleCost` / `BattlePrice` / `BattleEntranceCostBase` / `BattleEntranceCostInc` - Pricing

## Battle Synchronization

### Deterministic Lockstep Model

The battle uses a deterministic lockstep model where all clients simulate the same game state from the same initial conditions:

1. **Tick System**: `BattleCurrentTickProvider` provides the current simulation tick. `BattleTicksInterval` defines the tick rate.
2. **Command Batching**: `AICommandsAtTickSTSerializer/STDeserializer` batches all commands for a given tick into a single message.
3. **Command Execution**: All clients execute the same commands in the same order on the same tick.
4. **State Verification**: Periodic CRC checks verify synchronization.

### CRC Synchronization Check

The CRC system detects desynchronization between clients:

**CRC Request Flow**:
1. Client sends `AICommCRCRequest` with its current game state hash
2. Server forwards CRC request to opponent
3. Opponent responds with `AICommCRCAnswer` containing its hash
4. If hashes match, game continues normally
5. If hashes differ, `BattleLogicDesyncNotification` is generated

**CRC Data Structure**: `CRCInfo` contains:
- `CRCInfoSide` - Per-side game state hash
- `CRCInfoBuilding` - Building state hash (position, health, level, etc.)
- `CRCInfoUnit` - Unit state hash (position, health, state, etc.)

**Desync Handling**:
- `BattleLogicDesync` / `BattleLogicDesyncInfoMessage` - Desync data
- `BattleLogicDesyncDebugRequest` - Debug request for desync investigation
- `BattleLogicDesyncNotification` - Server notification of desync
- `BATTLE_LOGIC_DESYNC_INFO` / `BATTLE_LOGIC_DESYNC_NOTIFICATION` - Message types
- `BATTLE_LOGIC_DESYNC_DEBUG_REQUEST` - Debug request type

### Battle Finish Synchronization

When a battle ends, the finish must be synchronized:
- `BattleFinishNotification` - Server notifies all clients of battle end
- `BattleFinishNotificationNotReceived` - Error when notification not received
- `BattleFinishCondition` / `BattleFinishReason` / `BattleFinishResult` - Finish details
- `BattleFinishTick` / `BattleSideFinishTick` / `ActualBattleFinishTick` / `BattleExitTick` - Timing
- `CSBattleEndingWaiter` - Waits for all clients to acknowledge ending

## Session Management

### Battle Session

`BattleSession` tracks the active battle with:
- `BattleSessionId` - Unique session identifier
- `BattleSessionRestoreRequest/Answer` - Session restoration after disconnect
- `BattleSessionRestoreAttemptCount` - Maximum restore attempts
- `BattleSessionRestoreResponseTimeout` - Restoration timeout

### Battle Lifecycle

The full battle lifecycle follows this sequence:
1. `AppointStartBattle` - Battle appointment created
2. `CSBattleLogon` - Authenticate with battle server
3. `CSLoadMapResources` - Download map and assets
4. `BattleInitialize` / `BattleInitializeSnapshot` - Initialize game state
5. `BattleLoadProgressRequest/Answer` - Synchronize loading
6. `CSBattleRun` - Begin simulation
7. `AICommandsAtTick` - Exchange commands each tick
8. `AICommCRCRequest/Answer` - Periodic sync checks
9. `BattleFinish` / `BattleFinishNotification` - Game ends
10. `CSMainReturnFromBattle` - Return to main menu
11. `BattleResultRequest/Answer` - Get final results
12. `BattleReplayRequest/Answer` - Optionally view replay

### Battle Reconnection

If a client disconnects during battle:
1. `BattleConnectionStateErrorLast` tracks the last connection error
2. Client attempts `BattleSessionRestoreRequest`
3. Server responds with `BattleSessionRestoreAnswer` containing current game state
4. Client re-simulates from snapshot to current tick
5. `BattleResumptionDynamic` and `BattleResumptionInfo` control resumption behavior
6. `UpdateResumptionBattleActivityCoroutine` handles the resumption UI

## Network Configuration

**Battle Network Configuration**: `BattleNetworkConfiguration` (with STSerializer/STDeserializer) contains:
- Server addresses and ports
- Heartbeat intervals
- Timeout values
- Encryption parameters
- Bandwidth limits

**Timeout Constants**:
- `AppointStartBattlePvPTimeout` - PvP match start timeout
- `AppointStartBattlePvETimeout` - PvE match start timeout
- `BattleReceiveMessageTimeoutDefault` - Default receive timeout
- `BattleSendMessageTimeout` - Send timeout
- `BattleSessionRestoreResponseTimeout` - Session restore timeout
- `BillingResponseTimeout` - Billing response timeout
- `AnswerReceiveTimeout` - Generic answer timeout

## Matchmaker Implementation

The matchmaker is implemented in `com.geargames.aow.client.main.matching`:

**CallSite Operations**: `CallSiteOps_CreateMatchmaker` creates the matchmaker instance.

**Matching Flow**:
1. Player selects battle parameters (template, format)
2. Matchmaker evaluates eligible opponents based on:
   - Rating/rank proximity
   - Army composition similarity
   - Connection quality (ping)
   - Wait time (gradually expands search)
3. Match found -> `AppointStartMessage` sent to both players
4. Players confirm readiness
5. Battle server connection established
6. Battle begins

**Cancellation**: Players can cancel matchmaking via:
- `BATTLE_3X3_RANDOM_CANCEL_REQUEST`
- `CANCEL_JOIN_COMPETITIONS_REQUEST`
- `CANCEL_JOIN_TOURNAMENT_REQUEST`
- `CANCEL_JOIN_MISSION_REQUEST`

## Error Handling

The network layer includes comprehensive error handling:

**Error Types**:
- `AOWErrorSerializerV1` / `AOWErrorSerializerForSenderV1` - Error serialization
- `AOWErrorData` / `AOWErrorFactory` / `AOWErrorSender` / `AOWErrorStorerToFile`
- `BadServerAnswer` / `BadServerResourceAnswer` - Invalid server response
- `CSExpectedServerMessageWasNotReceived` - Expected message not received
- `AlreadyWaitingForMandatoryMessage` - Duplicate wait
- `BattleCouldNotBeStarted` - Battle start failure
- `BattleHung` - Battle appears frozen
- `BattleTooLong` - Battle exceeds maximum duration
- `BattleLimitReached` - Player has too many active battles
- `BattleSizeException` - Battle size validation error
- `BattleStarterException` - Battle starter error
- `BattleException` - Generic battle error

**Connection Error Recovery**:
- `AllRequestsLoginServerFailed` - All login server attempts failed
- `BattleConnectionStateErrorLast` - Last connection error tracking
- `CSBattleStartingFailed` - Battle start failure handler
