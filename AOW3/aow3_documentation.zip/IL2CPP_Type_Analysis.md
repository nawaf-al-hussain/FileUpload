# IL2CPP Type Analysis - Art of War 3: RTS Strategy Game

## Overview

Art of War 3 (com.geargames.aow) version 6.5.22 is built on Unity IL2CPP with metadata version 31. The binary contains 29,334 types and 170,264 strings distributed across 8 DEX files (classes.dex through classes8.dex). The game uses IL2CPP compilation which converts C# to C++, making reverse engineering significantly more complex than standard Mono-based Unity games. The metadata version 31 corresponds to Unity 2021.x or 2022.x era IL2CPP builds.

The type system is deeply hierarchical with extensive use of generics, interfaces, and component-based architecture typical of Unity games enhanced with custom ECS-like patterns. The com.geargames.* namespace alone contains 334 identifiers spanning serialization, networking, cryptography, analytics, resource management, and gameplay systems.

## Namespace Organization

### com.geargames (Root Namespace)

The root namespace contains the foundational `GearGamesByteBuffer` class which is central to the entire network communication system. This class provides low-level byte manipulation methods including `get`, `put`, `flip`, `mark`, `reset`, `duplicate`, `size`, and `Limit` accessors. The ByteBuffer pattern follows Java NIO conventions, suggesting the server-side architecture may be Java-based.

### com.geargames.aow (Game Namespace)

The primary game namespace is organized into the following sub-namespaces:

#### com.geargames.aow.entities
Core game entity definitions including:
- `ads` - Advertisement entity models
- `armymatrix` - Army composition and matrix data
- `battle` - Battle system entities
  - `aicomm` - AI communication commands
  - `bot` - Bot AI behavior definitions
  - `conditions` - Battle condition entities
  - `descriptions` - Battle description data
  - `flight` - Flight/air unit path data
- `career` - Career/progression entities
- `chat` - Chat system entities
- `clan` - Clan system entities
- `competitions` - Competition/tournament entities
- `events` - Time-limited event entities
- `featureToggle` - Feature flag entities
- `gai` - GAI (Game AI) scripting entities
  - `gaicomm` - GAI communication layer
- `lobby` - Lobby/matchmaking entities
  - `enums` - Lobby enumeration types
- `mainmenu` - Main menu entity models
- `modification` - Unit/building modification entities
- `ow` - Open World entities
- `plates` - UI plate/panel entities
- `skirmish` - Skirmish mode entities
- `tms` - TMS (Tournament Management System) entities
- `tournament` / `tournamentNew` - Tournament system entities
- `upgrade` - Upgrade system entities
- `uw` - Uranium weapon system entities

#### com.geargames.aow.scenes
Scene management and presentation layer:

- `battle` - Battle scene (largest subsystem)
  - `entities` - Battle-scene entity implementations
    - `components` - Unity component adapters
    - `mine` - Mine/mining components
    - `eventSystems` - Custom event systems
    - `recolorerRenderers` - Dynamic color rendering
  - `gui` - Battle UI system
    - `actioneffects` - Action visual feedback
    - `actions` - Player action handlers
    - `boosts` - Boost UI elements
    - `buildings` - Building UI in battle
    - `buildingset` - Building placement UI
    - `cards` - Card-based UI
    - `chat` - In-battle chat
    - `globalDialogWindow` - Modal dialogs
    - `minimap` - Minimap rendering
    - `mining` - Resource mining UI
    - `progressBar` - Progress indicators
    - `replay` - Battle replay UI
    - `tutorial` - Tutorial overlay
    - `unitselection` - Unit selection mechanics
    - `unitspec` - Unit special ability UI
  - `logging` - Battle-specific logging
  - `logicservice` - Core battle logic
    - `commands` - Battle command system
    - `debug` - Debug commands
  - `map` - Map rendering and management
    - `ai` - Map AI navigation
    - `gai` - GAI map scripting
      - `commands.unity` - Unity-specific GAI commands
      - `unity.editor` - Editor GAI tools
      - `unity.input` - Input-driven GAI
    - `input` - Map input handling
    - `input.gesturehandlers` - Touch gesture processing
    - `unity` - Unity map integration
  - `network` - Battle network layer
  - `unity` - Unity scene integration
  - `utils` - Battle utility functions
- `battleloading` - Battle loading scene
  - `gui` - Loading screen UI
  - `logging` - Loading diagnostics
  - `network` - Pre-battle network setup
- `battlelogout` - Post-battle logout scene
- `gui` - Shared GUI components
- `logon` - Login/authentication scene
  - `gui` - Login UI
  - `gui.magicalwindow` - Special login window
  - `logging` - Auth logging
  - `network` - Auth network layer
  - `network.Settings` - Connection settings
- `main` - Main menu scene (second largest subsystem)
  - `assets` - Asset management
    - `DispatcherResources` - Resource dispatch with sub-adapters
      - `ClientResourceAdapters` - Platform adapters
      - `DownloadConditions` - Conditional download logic
      - `ResourceAvailableCheckers` - Availability verification
      - `ResourceLoadingProgresses` - Progress tracking
      - `ResourceSettings` - Configuration
  - `chat` - Main menu chat integration
  - `gui` - Main menu UI
    - `actions` - Menu action handlers
    - `analitycs` - UI analytics
    - `battle` - Battle entry UI
    - `chat` - Chat panels
    - `clan` - Clan management UI
    - `leagueup` - League promotion UI
    - `levelup` - Level-up celebrations
    - `modifications` - Modification screens
    - `profile` - Player profile UI
    - `quests` - Quest tracking UI
    - `rating` - Rating/ranking displays
    - `reusable` - Shared UI components
    - `setting` / `settings` - Settings panels
    - `skills` - Skill tree UI
    - `social` - Social features UI
    - `supply` - Supply drop UI
    - `testmissions` - Debug mission launcher
    - `tms` - TMS UI
    - `upgrades` - Upgrade screens
    - `upgrades.uranum` - Uranium upgrade screens
  - `logging` - Main menu diagnostics
  - `network` - Main menu network
- `relogon` - Reconnection scene
- `scripts.assetLoader` - Asset loading scripts

#### com.geargames.aow.services
Service layer following dependency injection patterns:

- `ads` - Advertisement services
  - `ApplovinMaxService` - AppLovin MAX mediation
  - `GGMediation` - Custom ad mediation
  - `IronSourceService` - IronSource integration
    - `Interstitial` - Interstitial ad handling
    - `RewardedVideo` - Rewarded video handling
- `appmetrica` - Yandex AppMetrica analytics
- `billing` - In-app purchase service
- `featuretoggle` - Feature flag service
- `resources` - Resource management services
  - `IBatteriesResourceService` - Battery resource queries
  - `IBlueprintsResourceService` - Blueprint resource queries
- `revu` - Review/prompt service
- `vibro` - Haptic feedback service

#### com.geargames.aow.messages
Network message definitions organized by domain:

- `achievements` - Achievement messages
- `ads` - Advertisement messages
- `authorization` - Auth messages
- `billing` - Purchase messages
- `career` - Career progression messages
- `chat` - Chat messages
  - `clan` - Clan chat
  - `commonchat` - Global chat
  - `country` - Country chat
  - `fraction` - Faction chat
  - `friends` - Friend chat
  - `language` - Language chat
  - `news` - News feed
  - `privatechat` - Direct messages
  - `support` - Support chat
- `ci` - CI/debug messages
- `clan` - Clan management messages
- `competition` - Competition messages
  - `debug` - Debug competition messages
- `configuration` - Config messages
- `daily` - Daily reward messages
- `entrance` - Login entrance messages
- `events` - Event messages
- `hero` - Hero system messages
- `levels` - Level messages
- `lobby` - Lobby messages
- `mainmenu` - Main menu messages
- `missions` - Mission messages
- `modification` - Modification messages
- `ow` - Open world messages
- `profile` - Profile messages
- `quests` - Quest messages
- `ratings` - Rating messages
- `recruiting` - Recruiting messages
- `session` - Session messages
- `special` - Special event messages
- `tournament` - Tournament messages
- `upgrade` - Upgrade messages
- `uw` - Uranium weapon messages
- `warehouse` - Warehouse/inventory messages

#### com.geargames.aow.ugui
Unity GUI framework extension layer:

- `HallOfFame` - Hall of fame display
- `army` - Army management UI
  - `debug` - Debug army tools
  - `models` - Army data models
    - `info` - Info models
    - `Stats` - Statistics models
  - `modifications` - Army modification UI
  - `presenters` - MVP presenters
    - `info` - Info presenters
  - `upgrades` - Army upgrade UI
- `battlepass` - Battle pass UI
- `bookmark` - Navigation bookmarks
- `chat` - Chat UI components
- `clan` - Clan UI
  - `card` - Clan card components
- `competition` - Competition UI
- `extension` - UI extensions
- `ggmediation` - Ad mediation UI
- `lobby` - Lobby UI
- `notification` - Notification UI
- `osa` - Optimized scroll adapter
  - `utils` - OSA utilities
- `pattern` - UI design patterns
- `pool` - Object pool UI
- `recycling` - UI recycling system
- `resources` - UI resource displays
- `scaling` - UI scaling system
- `scoreboard` - Scoreboard UI
- `scroll` - Scroll view system
  - `recycling` - Scroll recycling
- `scroller` - Scroller components
- `sounds` - UI sound system
- `startup` - Startup UI
- `store` - Store/shop UI
- `supply` - Supply UI
- `uranium` - Uranium UI

### com.geargames.common (Shared Library)

Cross-cutting concerns shared across GearGames products:

- `analytics` - Analytics framework
  - `HttpEventSender` - HTTP-based event reporting
  - `HttpMessageSender` - HTTP message transport
  - `cache` - Analytics event caching
- `input` - Input abstraction
- `logging` - Logging framework
  - `LogsSerialization` - Log serialization
- `network` - Network framework
  - `AddressFinder` - Server address discovery
  - `CheckNeedVpn` - VPN detection
  - `HttpMessageSender` - HTTP transport
  - `cryptography` - Crypto providers (RSA/DES)
- `objectpool` - Object pooling
- `plugins` - Plugin system
- `pool` - Pool management
- `resources` - Resource management
  - `ResourcesCache` - Resource caching
- `serialization` - Serialization framework
- `utils` - Utility classes
  - `zlinq` - Custom LINQ implementation

### com.geargames.serialization (Serialization Framework)

- `serializers` - Custom serializer implementations

### com.geargames.unity (Unity Extensions)

- `logging` - Unity logging adapter
- `network` - Unity network adapter
- `utils` - Unity utilities

## Key Type Hierarchies

### Network Connector Hierarchy

The network layer follows a clean abstract hierarchy:

```
AbstractClientNetworkConnector
  +-- AbstractClientMainNetworkConnector
  +-- AbstractClientBattleNetworkConnector
ActiveNetworkConnector (concrete implementation)
```

`AbstractNetworkConnectorState` manages connection state transitions. `AbstractNetworkCryptoProvider` provides the encryption layer with RSA/DES implementation. The `CSMessage` base type handles all client-server message framing.

### Unit Component Hierarchy

Units use a component-based architecture:

```
AbstractUnitComponent
  +-- AbstractBuildingComponent
  |     +-- AbstractBuildingGroundComponent
  +-- AbstractClientUnitHeroBehaviour
  +-- (various specific components)
```

Key interfaces include:
- `IEntityInfo` with `Prototype` property and `IEntityPrototypical` pattern
- `IEntityPrototypical` providing prototype-based entity configuration

### Weapon System Hierarchy

```
AbstractClientWeapon
  +-- AbstractClientEnginedWeapon
  +-- AtlantMainClientWeapon
  +-- AtlantActiveClientWeapon
  +-- (hero-specific weapons)
```

`AbstractWeaponEngine` provides the base for weapon calculation engines. The `BurstWeaponSettings` and `AdditionalWeaponSettings` classes configure weapon behavior parameters.

### Battle Logic Hierarchy

```
BattleAct (base battle action)
BattleStart -> BattleRun -> BattleFinish
BattleInitialize -> BattleInitializeSnapshot
BattleSession -> BattleSessionRestore
BattleLoading -> BattleLoadingScreen
```

The `BattleLogicService` namespace contains the `commands` sub-namespace with battle command processing, and `debug` for debug commands.

### Serializer Pattern (STSerializer/STDeserializer)

The game uses a dual serializer pattern for network messages with 2,598 serializer/deserializer pairs. Each serializable type has matching `STSerializer` and `STDeserializer` classes. This pattern is consistent across all network messages, game entities, and configuration objects. The sheer volume (2,598 pairs) indicates comprehensive network serialization coverage for every data structure that crosses the client-server boundary.

### GAI Command Hierarchy

The GAI (Game AI) scripting system uses a three-tier command pattern:

```
GAICommand (base)
  +-- GAICommandAbstractComponent
  |     +-- GAICommandAbstractModelComponent
  +-- GAICommandAbstractActionButton
  +-- GAICommandAbstractDependencyCollector`1
```

Each command has a matching `Component` implementation, and many have `DependencyCollector` variants for tracking prerequisite conditions. The `GAICommandAttribute` marks commands for automatic registration.

## Type Count Distribution

| Namespace | Estimated Type Count | Category |
|-----------|---------------------|----------|
| com.geargames.aow.scenes.battle | ~800+ | Battle Scene |
| com.geargames.aow.scenes.main | ~400+ | Main Menu Scene |
| com.geargames.aow.messages.* | ~700+ | Network Messages |
| com.geargames.aow.entities.* | ~300+ | Game Entities |
| com.geargames.aow.ugui.* | ~200+ | UI Framework |
| com.geargames.aow.scenes.battle.map.gai | ~150+ | GAI Scripting |
| com.geargames.aow.services.* | ~100+ | Service Layer |
| com.geargames.common.* | ~80+ | Shared Library |
| STSerializer/STDeserializer pairs | ~2598 | Serialization |
| Unity/System types | ~24000+ | Framework |

## Notable Type Patterns

### Generic Repository Pattern
The codebase makes heavy use of generic types for data access:
- `BattleAssetEntry<T>` and `BattleAssetLoader<T>` for typed asset loading
- `AbstractClientRequest<T>` and `AbstractJsonClientRequest<T>` for typed network requests
- `CSAbstractMessageWaiter<T>` for typed message waiting
- `GAICommandAbstractDependencyCollector<T>` for generic dependency collection

### Async/Await Pattern
The game extensively uses Unity's coroutine system alongside UniTask:
- `AsyncUniTaskMethodBuilder` and `AsyncUniTaskVoidMethodBuilder` for custom async support
- `AutoResetUniTaskCompletionSource<T>` for async coordination
- Coroutine state machines (`<MethodName>d__N` pattern) for iterator methods

### MVP Architecture
The UI follows Model-View-Presenter pattern:
- `ArmyHeroClassPriceButtonPresenter`, `ArmyHeroClassPriceCostPresenter`, `ArmyHeroClassWindowPresenter`
- `ArmyProductionInfoPresenter`, `ArmyProductionInfoListItemPresenter`
- `BattleButtonPresenter`, `BattleTemplateModelFactory`
- `CampaignTilePresenter`, `BattleAbstractTilePresenter`

### Feature Toggle System
Battle features are controlled by boolean flags following the pattern `Battle_Is[FeatureName]Enabled`:
- `Battle_IsLiquidFogEnabled`
- `Battle_IsNewBallisticEngineSkipPositionEnabled`
- `Battle_IsGAICutsceneFeatureEnabled`
- `Battle_IsNewShieldIndicatorLogicEnabled`
- `Battle_IsVoiceQueueEnabled`
- `Battle_IsVisualStateServiceEnabled`
- `Battle_IsTerrainNormalMapEnabled`
