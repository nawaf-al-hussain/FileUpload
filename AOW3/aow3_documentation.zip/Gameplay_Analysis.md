# Gameplay Analysis - Art of War 3: RTS Strategy Game

## Overview

Art of War 3 is a real-time strategy game featuring two distinct factions battling across land, sea, and air. The gameplay revolves around base construction, resource management, unit production, and tactical combat. The game supports multiple modes including campaign, PvP (1v1 and 3v3), cooperative play, tournaments, and skirmish. Each faction has access to hero units with unique abilities, super weapons including nuclear strikes, and a deep upgrade and modification system.

## Game Modes

### Campaign Mode
Story-driven missions powered by the GAI scripting system. Campaign maps follow a chapter structure (1_2 through 1_6, 3_2, 4_1) with progressively challenging scenarios. Each mission is defined by a sequence of GAI commands that control AI opponents, objectives, tutorial prompts, and victory conditions. The campaign teaches core mechanics through the tutorial system and introduces hero units progressively.

### PvP Mode
Real-time competitive multiplayer with deterministic lockstep synchronization. Available formats include:
- **1v1 PvP**: Standard ranked match using `BattleTemplate` definitions
- **3v3 PvP**: Team-based combat via `BATTLE_3X3_RANDOM_REQUEST`
- **PvP Matchmaking**: Rating-based opponent selection through `CallSiteOps_CreateMatchmaker`

PvP battles feature:
- CRC-based desync detection
- Battle replay recording
- Anti-cheat verification (`AICommVerify`, `AICommSyncTest`)
- Connection quality monitoring (`BattlePvPSocketHeartbeatTimeout`)

### Cooperative Mode
Team-based PvE or PvP through the competition system:
- `COMPETITION_COOP_BATTLE_INVITE_REQUEST` - Invite players
- `COMPETITION_COOP_MATCHING_ADD_REQUEST` - Join matchmaking pool
- `COMPETITION_COOP_BATTLE_CANCEL_REQUEST` - Cancel coop battle
- `COMPETITION_COOP_BAN_REQUEST` - Ban disruptive players

### Tournament Mode
Organized competitive play:
- `CANCEL_JOIN_TOURNAMENT_REQUEST` - Tournament registration
- `COMPETITION_HALL_OF_FAME_REQUEST` - Tournament rankings
- `COMPETITION_RATING_PROFILE_REQUEST` - Player ratings
- `GAICommandTourTable` - Tournament bracket visualization
- `GAICommandFinishBattleByTourTable` - Tournament battle completion

### Skirmish Mode
Custom battles with configurable parameters through `com.geargames.aow.entities.skirmish`.

## Core Gameplay Mechanics

### Base Construction

Players build their base from a Construction Yard, placing structures on a grid-based map. Construction follows these steps:

1. Select building from `BuildingsConstrComponent` menu
2. Validate placement (`BuildingCanNotBeBuiltHere`, `BuildingIsOutOfConstructionArea`)
3. Position building (`BuildingPlacement`, `BuildingsAutoPlacement`)
4. Construction begins with `BuildingConstr` tracking progress
5. Building appears at reduced functionality during construction
6. `BuildingComplete` signals full operational status

**Construction Constraints**:
- `CONFEDERATION_MAX_BUILDING_SIZE` - Maximum building footprint
- `CONSTR_ARMOR_DIVIDER` - Reduced armor during construction
- `BuildingStunOn/Off` - Building is stunned during certain operations
- `CalcBuildingCountLimit` - Maximum number of buildings
- `BuildingLimitations*` - Per-type building limits

### Resource Management

**Energy System**: Buildings require energy to operate. The energy grid connects Power Stations to consuming buildings:
- `BuildingEnergyNeedStat` - Energy consumption per building
- `BuildingEnergyProductionStat` - Energy generation
- `ACT_ENERGY_GEN` / `ACT_ENERGY_REGEN` - Energy stats
- `Energy`, `EnergyMax`, `EnergyRegenValue`, `EnergyForAds` - Energy parameters
- Energy shortage causes buildings to shut down (stun effect)

**Gold/Currency**: Primary currency for building and unit production:
- `GAICommandGold` - Grant gold in scripts
- `MINI_PROMO_CATEGORY_GOLD` - Gold promotion category

**Uranium**: Premium resource for super weapons and hero abilities:
- `UranumBattleModel` - Uranium battle state
- `GAICommandTutorialFinishConditionUraniumRefill` - Uranium refill tutorial
- `GAICommandTutorialFinishConditionUraniumSpend` - Uranium spend tutorial
- `com.geargames.aow.entities.uw` - Uranium weapon entities
- `com.geargames.aow.messages.uw` - Uranium weapon messages

**Boost Resources**: Temporary enhancements:
- `BoostActive` - Active boost instance
- `BoostBonusInfo` - Boost bonus details
- `BoostBlinkInfo` - Boost visual indicator
- `BoostsPreferredAdd/Reset` - Preferred boost management
- `BattleBoostCategories` - Boost category organization

### Unit Production and Control

**Production Flow**:
1. Select production building (Barracks, Factory, Air Factory, Shipyard)
2. Click `ButtonBuildingOrderUnit1/2/3` for available unit
3. `AICommBuyUnit` sent to server
4. Unit produced over time in building queue
5. Unit spawns at building rally point
6. `AICommCancelBuyUnit` can cancel production

**Unit Selection**:
- `AddSelectUnitsByPolygon` / `AddSelectUnitsByRectangle` - Area selection
- `AddUnitToSelection` / `AddUnitsToSelection` - Add to existing selection
- `SelectCentralUnit` - Select center unit in group
- `SelectAllUnitsOnMapWithSettings` - Select all units
- `GAICommandSelectionClear` - Clear selection (GAI)

**Unit Commands**:
- Move: `AICommUnitsMove`
- Stop: `AICommUnitsStop`
- Hold Position: `AICommUnitsHoldPosition`
- Bombard: `AICommUnitsBombard`
- Patrol: `AICommUnitsPatrolTargeting`
- Special: `AICommUnitsSpec`
- Psionic: `AICommUnitsPsionic`
- Load/Unload Transport: `AICommUnitsLoadTransport/UnloadTransport`
- Bomber Targeting: `AICommUnitBombersTargeting`
- Fighter Guard: `AICommFightersGuard`
- Aircraft Rebase: `AICommAircraftRebase`
- Mine Lay/Sweep: `AICommMineLay/MineSweep`

### Hero System

Heroes are powerful unique units with active and passive abilities:

**Hero Acquisition**:
- Heroes trained at Hero Buildings (`BuildingTypeHero`)
- `AICommHeroActivate` - Activate a trained hero
- `AICommHeroActivateAndBuy` - Purchase and activate
- `HeroBuyChecker` - Purchase validation
- `AvailableHeroSlotCount` - Available hero slots
- `HeroSlotModels` - Hero slot data
- `RankForHero` / `RankForOpenHero` - Hero unlock requirements

**Hero Abilities**:
- `AICommHeroAbilityActive` - Trigger hero active ability
- `ACTIVE_ABILITY_WEAPON_INDEX` - Active ability weapon slot
- `AbilityWeaponId` / `ActiveAbilityWeaponId` - Ability weapon identifiers
- `AbilityStoppedHeroStunned` - Stun when ability interrupted
- Hero ability effects (per-hero VFX documented in Units.md)

**Hero Energy**:
- `AICommHeroBatteryBuy` - Purchase hero energy
- `AICommHeroEnergyRefill` - Refill hero energy
- `BomberEnergyPercForTakeOff` - Energy threshold for bomber takeoff

**Hero Upgrades**:
- `IsHeroMaxUpgradeCount` - Maximum upgrade level check
- `IsEnoughHeroCardsToUpgrade` - Card requirement check
- `HeroCards` - Hero card inventory
- `UpdateHeroInfos` - Hero info refresh

**Hero UI**:
- `UIHero1SelectButton` / `UIHero1UseAbilityButton` - Hero 1 controls
- `UIHero2SelectButton` / `UIHero2UseAbilityButton` - Hero 2 controls
- `UIHero3SelectButton` / `UIHero3UseAbilityButton` - Hero 3 controls
- Up to 3 hero slots per player

### Super Weapons

**Nuclear Strike**:
- `AICommNuclearLaunch` - Launch nuclear weapon
- `AttackSuperWeaponNuclearTap` - Nuclear attack input
- `BuildingListNuclearSilo` - Nuclear silo building
- `boom_expl5_s5_nuke/nuke_rocket/nuke_water` - Nuclear explosion VFX
- `eff_rocket_nuke_launch` - Launch VFX

**Space Strike** (orbital weapon):
- `AttackSuperWeaponSpaceTap` - Space weapon input
- `boom_expl5_s5_space/space_ray/space_water` - Space weapon VFX
- `eff_space_1/super_launch/super_launch_wait/super_wait/super_work` - Space weapon VFX
- `IsSuperWeaponReady` - Super weapon readiness check

**Implosion Weapon**:
- `AICommImplosion` - Implosion attack

### Fog of War

The fog of war system controls battlefield visibility:
- `ActivateFog` / `DoSetFogVisible` - Fog control
- `BattleCellFoggyState` - Cell fog state
- `BattleFogRenderer` - Fog rendering
- `GAICommandFogOpener/FogOpenerRemove` - Scripted fog control
- `CreateStatsForFog` - Fog visibility stats
- `BuEraseFogged` - Building erases fog
- `Battle_IsLiquidFogEnabled` - Liquid fog feature toggle
- `Battle_IsNewFogVisibleStateLogicEnabled` - Fog logic toggle
- `OverridesFog` - Override fog for specific units

### Boost System

Boosts provide temporary battle advantages:
- `AICommBoostBuyAndApply` - Purchase and apply boost
- `AICommBoost` - Apply boost effect
- `BOOST_APPLY_IN_BATTLE_KEY_ADD` - In-battle boost application
- `BattleBoostCategories` - Boost category classification
- `BoostsPreferredAdd/Reset` - Preferred boost management

### Minimap System

The minimap provides battlefield overview:
- Dedicated minimap bundles per map (9 total)
- `BattleGridDrawer` - Grid overlay
- `Battle_IsNewMinimapMarksEnabled` - Enhanced minimap marks
- `BuildingMinimapColor` - Building color coding

## Meta-Game Progression

### Career System
- `CareerStone` - Career milestone stones
- `CareerUp` - Career level advancement
- `CareerRewardItem` - Career reward items

### Battle Pass
- `BattlePassInfo` - Current season info
- `BattlePassPremium` - Premium track
- `BattlePassPoints` - Point accumulation
- `BattlePassProfileInfo` - Player progress
- `BattlePassReward` - Reward items
- `BattlePassScale` - Reward scaling

### Achievement System
- `AchievementConfiguration` - Achievement definitions
- `AchievementLevel` - Achievement tiers
- `AchievementReached` - Completion tracking
- `AchievementStatistics` - Player statistics

### Daily Rewards
- `panel_entrance_14_day` - 14-day login reward
- `panel_entrance_30_day_premium` - 30-day premium reward
- `DailyEntrance` - Daily login tracking

### Black Market
- `BlackMarketConfiguration` - Market inventory
- `BlackMarketGoods` - Available items
- `BlackMarketConfigurationUpdateRequest/Answer` - Market refresh

### Crate System
- `CRATE_REQUEST` - Open crate
- `CRATE_WINS_REQUEST/ANSWER` - Crate win history
- `CRATE_DATE_REWIND_REQUEST/ANSWER` - Rewind crate timer
- `BoxItem` - Crate item definition
- `BoxRewardMessage` - Reward notification
