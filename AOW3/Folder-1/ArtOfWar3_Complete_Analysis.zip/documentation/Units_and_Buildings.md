# Art of War 3: Complete Unit and Building Encyclopedia

## CONFEDERATION UNITS

### Infantry

#### Assault Trooper (突击兵)
| Attribute | Value |
|-----------|-------|
| Role | Light infantry, reconnaissance, patrol |
| Weapons | Automatic rifle + grenade launcher |
| Primary Target | Infantry |
| Armor Class | Light (Defense Equipment I) |
| Strengths | Fast production, good for scouting and patrols, versatile against infantry |
| Weaknesses | Vulnerable to vehicles and area damage |
| Produced At | Barracks |
| Tech Requirements | Barracks Level 1 |

#### Heavy Assault Trooper (重型突击兵)
| Attribute | Value |
|-----------|-------|
| Role | Anti-vehicle infantry |
| Weapons | Anti-tank rocket launcher |
| Primary Target | Vehicles, Structures |
| Armor Class | Light (Defense Equipment I) |
| Strengths | Significant damage to vehicles and structures, effective counter to armored units |
| Weaknesses | Slow fire rate, vulnerable to anti-infantry weapons |
| Produced At | Barracks |
| Tech Requirements | Barracks Level 2 |

#### Firepower Assault Trooper (火力突击兵)
| Attribute | Value |
|-----------|-------|
| Role | Close-quarters anti-infantry specialist |
| Weapons | Flamethrower/short-range weapon |
| Special | Jetpack-equipped for rapid positioning |
| Primary Target | Infantry (devastating at close range) |
| Armor Class | Light (Defense Equipment I) |
| Strengths | Can close distance rapidly via jetpack, annihilates infantry clusters |
| Weaknesses | Very short range, vulnerable during approach |
| Produced At | Barracks |
| Tech Requirements | Barracks Level 3 |

### Vehicles

#### Fortress (堡垒)
| Attribute | Value |
|-----------|-------|
| Role | Support logistics vehicle, infantry cover |
| Weapons | Machine gun + flamethrower |
| Special | Mine detection capability |
| Primary Target | Infantry, Mines (detection) |
| Armor Class | Heavy (Defense Equipment III) |
| Strengths | Heavy armor provides mobile cover for infantry, detects mines, dual weapons |
| Weaknesses | Slow, vulnerable to anti-armor weapons |
| Produced At | Assault Vehicle Factory |
| Tech Requirements | Factory Level 1 |

#### Warhammer / Hammer (战锤)
| Attribute | Value |
|-----------|-------|
| Role | Fast medium tank |
| Weapons | 99mm armor-piercing gun on rotating turret |
| Primary Target | Vehicles, Structures |
| Armor Class | Medium (Defense Equipment II) |
| Strengths | Highly mobile, fires accurately while moving, rotating turret allows firing on the move |
| Weaknesses | Lighter armor than heavy tanks, vulnerable to air units |
| Produced At | Assault Vehicle Factory |
| Tech Requirements | Factory Level 2 |

#### Zeus (宙斯)
| Attribute | Value |
|-----------|-------|
| Role | Heavy assault tank |
| Weapons | Thermoelectric cannon + missile launcher (ground & low-flying targets) |
| Primary Target | All ground targets, low-flying aircraft |
| Armor Class | Heavy (Defense Equipment III) |
| Strengths | Impenetrable armor, dual weapon system, can engage low-flying aircraft |
| Weaknesses | Very slow, high cost, vulnerable to long-range artillery and air units |
| Produced At | Assault Vehicle Factory |
| Tech Requirements | Factory Level 3 |

### Special Vehicles

#### Hurricane / Cyclone (飓风)
| Attribute | Value |
|-----------|-------|
| Role | Anti-air vehicle |
| Weapons | Anti-air missile system |
| Special | Double efficiency when stationary |
| Primary Target | Aircraft |
| Armor Class | Medium (Defense Equipment II) |
| Strengths | Excellent air defense, doubles effectiveness when stationary (deployed mode) |
| Weaknesses | Must be stationary for full effectiveness, limited ground combat ability |
| Produced At | Special Vehicle Factory |
| Tech Requirements | Factory Level 1 |

#### Torrent (激流)
| Attribute | Value |
|-----------|-------|
| Role | Long-range artillery (MLRS) |
| Weapons | Multiple rocket launcher, wide-area barrage |
| Special | Siege mode required to fire |
| Primary Target | Structures, clustered units |
| Armor Class | Medium (Defense Equipment II) |
| Strengths | Extremely long range, wide area damage, devastating against buildings |
| Weaknesses | Siege mode only (immobile while firing), very vulnerable in close combat, minimum range |
| Produced At | Special Vehicle Factory |
| Tech Requirements | Factory Level 2 |

#### Energy Shield (能量护盾)
| Attribute | Value |
|-----------|-------|
| Role | Support vehicle, armor enhancement |
| Special | Generates energy field enhancing armor of nearby allied units |
| Duration | Short duration, requires recharge time |
| Armor Class | Medium (Defense Equipment II) |
| Strengths | Can dramatically increase survivability of nearby units, excellent in combined arms pushes |
| Weaknesses | Limited duration, recharge cooldown, no direct attack, fragile alone |
| Produced At | Special Vehicle Factory |
| Tech Requirements | Factory Level 3 |

### Aviation

#### Whirlwind (旋风)
| Attribute | Value |
|-----------|-------|
| Role | Reconnaissance helicopter |
| Weapons | Machine gun + submarine detection equipment |
| Primary Target | Infantry, Submarines (detection) |
| Armor Class | Light (Defense Equipment I) |
| Strengths | Submarine detection, intelligence gathering, mobile scout |
| Weaknesses | Vulnerable to most ground units and anti-air, light armament |
| Produced At | Avia Factory |
| Fuel | Unlimited (helicopter) |
| Tech Requirements | Factory Level 1 |

#### Vertex (天顶)
| Attribute | Value |
|-----------|-------|
| Role | Air superiority fighter |
| Weapons | Self-homing missiles |
| Special | Variable thrust vectoring engine |
| Primary Target | Aircraft, Ground units |
| Armor Class | Light (Defense Equipment I) |
| Strengths | Exceptional maneuverability, self-homing missiles, air-to-air dominance |
| Weaknesses | Weak armor, limited fuel — must return to Airport to refuel |
| Produced At | Avia Factory |
| Requires | Airport |
| Tech Requirements | Factory Level 2 + Airport |

#### Thor (雷神)
| Attribute | Value |
|-----------|-------|
| Role | Heavy strategic bomber |
| Weapons | Devastating bomb load |
| Special | One bomb load per flight |
| Primary Target | Structures, clustered units |
| Armor Class | Medium (Defense Equipment II) |
| Strengths | Heavy armor, penetrates deep into enemy bases, devastating infrastructure strikes |
| Weaknesses | One bomb per sortie (must return to Airport), slow, high cost |
| Produced At | Avia Factory |
| Requires | Airport |
| Tech Requirements | Factory Level 3 + Airport |

### Navy

#### Delta (三角)
| Attribute | Value |
|-----------|-------|
| Role | Amphibious light assault boat |
| Weapons | Medium-caliber automatic cannon |
| Primary Target | Infantry, Light vehicles |
| Armor Class | Light (Defense Equipment I) |
| Strengths | Amphibious (can assault from water), high mobility |
| Weaknesses | Light armament, vulnerable to warships |
| Produced At | Shipyard |
| Tech Requirements | Shipyard Level 1 |

#### Viking (维京)
| Attribute | Value |
|-----------|-------|
| Role | Anti-warship destroyer |
| Weapons | Triple-barreled thermoelectric naval gun + Gauss torpedoes |
| Special | Underwater detection system |
| Primary Target | Warships, Submarines |
| Armor Class | Medium (Defense Equipment II) |
| Strengths | Can detect and engage submarines, effective anti-ship platform |
| Weaknesses | Vulnerable to air attacks, slower than light ships |
| Produced At | Shipyard |
| Tech Requirements | Shipyard Level 2 |

#### Poseidon (波塞冬)
| Attribute | Value |
|-----------|-------|
| Role | Heavy missile cruiser |
| Weapons | Long-range siege missiles + surface-to-air missiles |
| Special | Can attack ground targets from beyond visual range |
| Primary Target | Structures, Ground units, Aircraft |
| Armor Class | Heavy (Defense Equipment III) |
| Strengths | Extreme range siege capability, anti-air missiles, devastating bombardment |
| Weaknesses | Very slow, extremely expensive, vulnerable to submarines |
| Produced At | Shipyard |
| Tech Requirements | Shipyard Level 3 |

---

## RESISTANCE UNITS

### Infantry

#### Rifleman (步枪兵)
| Attribute | Value |
|-----------|-------|
| Role | Basic infantry, guerrilla fighter |
| Weapons | Personal combat rifle + electronic smoke grenades |
| Special | Can secretly traverse dense forests; smoke grenades reduce enemy accuracy |
| Primary Target | Infantry |
| Armor Class | Light (Defense Equipment I) |
| Strengths | Forest traversal stealth, smoke grenades for cover, versatile |
| Weaknesses | Standard infantry durability, weak against vehicles |
| Produced At | Barracks |
| Tech Requirements | Barracks Level 1 |

#### Grenadier (掷弹兵)
| Attribute | Value |
|-----------|-------|
| Role | Anti-vehicle infantry |
| Weapons | Personal grenade launcher |
| Special | Can hide in jungles for ambush |
| Primary Target | Vehicles, Structures |
| Armor Class | Light (Defense Equipment I) |
| Strengths | Jungle stealth for ambush, significant damage to vehicles/structures |
| Weaknesses | Slow fire rate, vulnerable when detected |
| Produced At | Barracks |
| Tech Requirements | Barracks Level 2 |

#### Sniper (狙击手)
| Attribute | Value |
|-----------|-------|
| Role | Long-range anti-armor infantry |
| Weapons | 12.7mm "Cobra" sniper rifle |
| Special | Hits weak points of armored units at maximum range |
| Primary Target | Armored units, Infantry (at range) |
| Armor Class | Light (Defense Equipment I) |
| Strengths | Devastating at range, can damage armored units by hitting weak points, extreme range |
| Weaknesses | Extremely vulnerable in close combat, slow fire rate, low HP |
| Produced At | Barracks |
| Tech Requirements | Barracks Level 3 |

### Vehicles

#### Prairie Wolf / Coyote (郊狼)
| Attribute | Value |
|-----------|-------|
| Role | Ultra-light reconnaissance vehicle |
| Weapons | Light machine gun |
| Primary Target | Infantry |
| Armor Class | Light (Defense Equipment I) |
| Strengths | Extremely fast even off-road, excellent scout, cheap to produce |
| Weaknesses | Very light armor and armament, cannot stand in direct combat |
| Produced At | Assault Vehicle Factory |
| Tech Requirements | Factory Level 1 |

#### Armadillo (犰狳)
| Attribute | Value |
|-----------|-------|
| Role | Versatile medium combat vehicle |
| Weapons | Rapid-fire autocannon |
| Special | Can lay minefields |
| Primary Target | Infantry, Light vehicles |
| Armor Class | Medium (Defense Equipment II) |
| Strengths | Sturdy armor + high mobility, mine-laying capability, very versatile |
| Weaknesses | Not effective against heavy armor |
| Produced At | Assault Vehicle Factory |
| Tech Requirements | Factory Level 2 |

#### Jaguar (美洲豹)
| Attribute | Value |
|-----------|-------|
| Role | Dual-mode heavy tank |
| Weapons | Heavy cannon |
| Special | Travel mode (fast, fires while moving, tougher armor) / Siege mode (doubled firepower) |
| Primary Target | Vehicles, Structures |
| Armor Class | Heavy (Defense Equipment III) |
| Strengths | Combines mobility with devastating firepower, tougher armor in march mode, siege mode for demolishing defenses |
| Weaknesses | Completely vulnerable to air units, must choose between mobility and firepower |
| Produced At | Assault Vehicle Factory |
| Tech Requirements | Factory Level 3 |

### Special Vehicles

#### Porcupine (豪猪)
| Attribute | Value |
|-----------|-------|
| Role | Anti-air vehicle |
| Weapons | Omnidirectional missile launcher + machine gun |
| Special | Instant lock-on targeting |
| Primary Target | Aircraft, Ground units |
| Armor Class | Medium (Defense Equipment II) |
| Strengths | Can engage both air and ground, instant lock-on, no deployment time needed |
| Weaknesses | Less specialized than faction counterpart |
| Produced At | Special Vehicle Factory |
| Tech Requirements | Factory Level 1 |

#### Mammoth (猛犸)
| Attribute | Value |
|-----------|-------|
| Role | Long-range artillery |
| Weapons | Extremely long-range howitzer |
| Special | Siege mode required to fire |
| Primary Target | Structures, clustered units |
| Armor Class | Medium (Defense Equipment II) |
| Strengths | Extreme range, devastating against buildings, area damage |
| Weaknesses | Siege mode only, very slow movement, vulnerable in close combat |
| Produced At | Special Vehicle Factory |
| Tech Requirements | Factory Level 2 |

#### Chameleon (变色龙)
| Attribute | Value |
|-----------|-------|
| Role | Stealth support vehicle |
| Special | Active camouflage generates ionized fog barrier concealing allied units |
| Effect | Enemy electronics cannot detect hidden units; only scouts entering the fog can reveal them |
| Armor Class | Medium (Defense Equipment II) |
| Strengths | Unique stealth mechanic, can hide entire army, devastating for ambush tactics |
| Weaknesses | No direct attack, fog is localized, scouts can penetrate the barrier |
| Produced At | Special Vehicle Factory |
| Tech Requirements | Factory Level 3 |

### Aviation

#### Dragonfly (蜻蜓)
| Attribute | Value |
|-----------|-------|
| Role | Reconnaissance/assault helicopter |
| Weapons | Machine gun + guided missiles |
| Primary Target | Infantry, Light vehicles |
| Armor Class | Light (Defense Equipment I) |
| Strengths | Guided missiles, versatile recon and assault platform |
| Weaknesses | Vulnerable to anti-air, light armor |
| Produced At | Avia Factory |
| Fuel | Unlimited (helicopter) |
| Tech Requirements | Factory Level 1 |

#### Hawk (鹰)
| Attribute | Value |
|-----------|-------|
| Role | 5th-generation multirole fighter |
| Weapons | Air-to-air and air-to-ground ordnance |
| Primary Target | Aircraft, Ground units |
| Armor Class | Light (Defense Equipment I) |
| Strengths | Strikes both ground and air, versatile fighter-bomber |
| Weaknesses | Slight disadvantage in air-to-air vs Vertex (weight/maneuverability), limited fuel |
| Produced At | Avia Factory |
| Requires | Airport |
| Tech Requirements | Factory Level 2 + Airport |

#### Albatross (信天翁)
| Attribute | Value |
|-----------|-------|
| Role | Heavy strategic bomber |
| Weapons | Devastating bomb load |
| Special | One bomb per sortie, nearly indestructible |
| Primary Target | Structures, clustered units |
| Armor Class | Heavy (Defense Equipment III) |
| Strengths | Withstands multiple anti-air missile hits, nearly indestructible, survives to deliver payload |
| Weaknesses | One bomb per sortie, must return to Airport, high cost |
| Produced At | Avia Factory |
| Requires | Airport |
| Tech Requirements | Factory Level 3 + Airport |

### Navy

#### Caiman (凯门鳄)
| Attribute | Value |
|-----------|-------|
| Role | Fast naval combat vessel |
| Weapons | Machine gun |
| Special | Can lay naval mines |
| Primary Target | Infantry, Light ships |
| Armor Class | Light (Defense Equipment I) |
| Strengths | High speed, naval mine-laying capability, hit-and-run tactics |
| Weaknesses | Light armament, vulnerable to destroyers |
| Produced At | Shipyard |
| Tech Requirements | Shipyard Level 1 |

#### Alligator (鳄鱼)
| Attribute | Value |
|-----------|-------|
| Role | Heavy combat ship |
| Weapons | Dual naval guns + anti-air missile launcher |
| Primary Target | Ships, Aircraft |
| Armor Class | Heavy (Defense Equipment III) |
| Strengths | Heavy armor while being most agile in its class, anti-air capability, versatile |
| Weaknesses | Slower than light ships, high cost |
| Produced At | Shipyard |
| Tech Requirements | Shipyard Level 2 |

#### Barracuda (梭鱼)
| Attribute | Value |
|-----------|-------|
| Role | Stealth submarine |
| Weapons | Vertical missile launch system + torpedoes |
| Special | Invisible when submerged; detected only by Viking, Whirlwind, or Torpedo Platforms |
| Primary Target | Warships, Coastal structures |
| Armor Class | Medium (Defense Equipment II) |
| Strengths | Can destroy enemy bases from coast, invisible when submerged, torpedoes threaten all warships |
| Weaknesses | Detectable by specific units/platforms, slower when submerged |
| Produced At | Shipyard |
| Tech Requirements | Shipyard Level 3 |

---

## HERO UNITS

### Confederation Heroes

| Hero | Tier | Key Abilities | Counter |
|------|------|--------------|---------|
| **Cerberus** | T1 | Jump jets, machine gun, grenade, knife attacks, fly death ability | Wolverine |
| **Seraphim** | T2 | Switch between air/ground mode, kara weapon, lazergun, turbine thrust | Salamander |
| **Psion** | T2 | Psi-energy wave attacks (active/passive), attack speed reduction on enemies | - |
| **Solaris** | T2 | Speed-based, gun, impulse, lightning attacks, charge ability | - |
| **Atlas** | T3 | Passive shield blocking incoming attacks, barrage, gun, immortality effect | Leviathan (nuclear) |
| **Confozord** | T3 | Ultimate weapon of retribution, massive assembled super-unit | - |

### Resistance Heroes

| Hero | Tier | Key Abilities | Counter |
|------|------|--------------|---------|
| **Wolverine** | T1 | Machine gun with acceleration, counters Cerberus | - |
| **Salamander** | T2/T3 | Missile barrages, turbo mode, counters Seraphim, amphibious | - |
| **Bison** | T3 | Can defeat Leviathan and Atlas in combat, powerful ground hero | - |
| **Leviathan** | T3 | Air + nuclear + ground arms, main auto-cannons, nuclear rocket | Atlas (passive shield) |

### Additional Hero Units (from VFX assets)

| Hero | Weapons/Abilities |
|------|------------------|
| **Coiltank** | Chain lightning, ball projectile, nova blast, electrodes |
| **Cryotank** | Frost bomb, cryo gun, nova freeze |
| **Gatling** | Explosive rounds, gatling gun, smoke aura |
| **Railgun** | March mode, quake mode, siege mode |
| **Beholder** | Lazer beam, scanner sweep |
| **Wasp** | Acid spray, rocket, flying aura (appears to be flying unit) |
| **Codomash** | Turret deployment, active/passive ability toggle |

---

## BUILDINGS

### Administrative Buildings (Both Factions)

| Building | Purpose | Cost Resource | Dependencies |
|----------|---------|--------------|-------------|
| **Headquarters** | Strategic center. Upgrading unlocks higher-tier buildings and units. | Supplies + Power | Starting building |
| **Construction Yard** | Constructs, upgrades, and repairs all buildings | Supplies | Headquarters |
| **Power Plant** | Generates Power capacity. Each building has energy cost. | Supplies | Headquarters |
| **Supply Center** | Generates Supplies continuously. Core economy building. | Supplies + Power | Headquarters + Power Plant |

### Military Buildings (Both Factions)

| Building | Produces | Upgrade Levels | Dependencies |
|----------|----------|---------------|-------------|
| **Barracks** | Infantry (3 types) | 1→2→3 (unlocks units) | Power Plant + Supply Center |
| **Assault Vehicle Factory** | Combat vehicles (3 types) | 1→2→3 (unlocks units) | Barracks |
| **Special Vehicle Factory** | Support/special vehicles (3 types) | 1→2→3 (unlocks units) | Assault Vehicle Factory |
| **Avia Factory** | Helicopters and fighters | 1→2→3 (unlocks units) | Barracks |
| **Airport** | Refueling and repair for fixed-wing aircraft | 1 level | Avia Factory |
| **Shipyard** | Naval units (must be built in water) | 1→2→3 (unlocks units) | Barracks |

### Hero Production Buildings

| Building | Faction | Produces | Resource |
|----------|---------|----------|----------|
| **X-Facility** | Confederation | Hero units | Uranium |
| **Prototype Factory** | Resistance | Hero units | Uranium |

### Superweapon Buildings

| Building | Faction | Effect | Charge Time |
|----------|---------|--------|-------------|
| **Aerial Strike System** | Confederation | Orbital satellite strike | Long charge, higher damage per strike |
| **Intercontinental Missile Launcher** | Resistance | Nuclear missile | Faster than Space System, less durable |

### Defensive Buildings

#### Confederation Defenses
| Building | Target | Special |
|----------|--------|---------|
| **Bunker** | Infantry/Light vehicles | Armored garrison |
| **Rocket Launch Tower** | Vehicles/Infantry | Long-range |
| **Anti-Air Center** | Aircraft | Long-range fixed AA |
| **Torpedo Launch Platform** | Naval + Aircraft | Torpedoes + anti-air |
| **Wall** | Blocks ground units | Requires strategy purchase |

#### Resistance Defenses
| Building | Target | Special |
|----------|--------|---------|
| **Sniper Tower** | Infantry/Armor | Monitoring and area protection |
| **Cannon Tower** | Heavy armor | Anti-heavy-armor specialist |
| **Anti-Air Tower** | Aircraft | Fixed anti-air |
| **Naval Platform** | All targets | Fast-firing AA + anti-ship + torpedoes + underwater detection |
| **Wall** | Blocks ground units | Requires strategy purchase |

### Building Upgrade System

All military and administrative buildings have 3 upgrade levels. Each level:
- Increases production speed (for production buildings)
- Unlocks new unit types (at specific levels)
- Increases HP and armor
- May increase energy consumption

Building construction time is approximately 40 seconds base. Upgrade times are longer and scale with level. Premium accounts can manually complete upgrades 30 minutes before the timer expires.
