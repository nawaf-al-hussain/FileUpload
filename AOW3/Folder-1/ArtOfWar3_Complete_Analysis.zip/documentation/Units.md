# Art of War 3: Global Conflict — Complete Unit Encyclopedia

> **Document Version:** 1.0  
> **Source:** Reverse-engineered from APK analysis (Unity IL2CPP metadata, Addressables catalog) and community data  
> **Last Updated:** 2024  

---

## Table of Contents

1. [Overview](#overview)
2. [Armor & Damage Classification](#armor--damage-classification)
3. [Confederation Units](#confederation-units)
   - [Infantry](#confederation-infantry)
   - [Vehicles](#confederation-vehicles)
   - [Special Vehicles](#confederation-special-vehicles)
   - [Aviation](#confederation-aviation)
   - [Navy](#confederation-navy)
   - [Superweapon](#confederation-superweapon)
4. [Resistance Units](#resistance-units)
   - [Infantry](#resistance-infantry)
   - [Vehicles](#resistance-vehicles)
   - [Special Vehicles](#resistance-special-vehicles)
   - [Aviation](#resistance-aviation)
   - [Navy](#resistance-navy)
   - [Superweapon](#resistance-superweapon)
5. [Hero Units](#hero-units)
   - [Confederation Heroes](#confederation-heroes)
   - [Resistance Heroes](#resistance-heroes)
   - [Other Hero Units (VFX-derived)](#other-hero-units-vfx-derived)
6. [Faction Comparison Matrix](#faction-comparison-matrix)
7. [Unit Counters & Synergies](#unit-counters--synergies)

---

## Overview

Art of War 3: Global Conflict features two distinct factions — the **Confederation** (Alliance Army) and the **Resistance** (Rebellion Army) — each with a full roster of approximately 15+ standard units, 6+ hero units, and 1 superweapon. The unit design philosophy mirrors classic RTS asymmetry: the Confederation emphasizes technological superiority, heavy armor, and brute-force firepower, while the Resistance relies on speed, stealth, guerrilla tactics, and tactical versatility.

Every unit in the game falls into one of five production categories: **Infantry**, **Vehicles**, **Special Vehicles**, **Aviation**, or **Navy**. Each category requires a specific production building (Barracks, Assault Vehicle Factory, Special Vehicle Factory, Avia Factory, or Shipyard respectively). Aviation units additionally require an Airport for refueling and re-arming.

Units are further classified by their **Defense Equipment** tier (I, II, or III), which determines how much damage they take from different weapon types. This three-tier armor system creates a rock-paper-scissors dynamic where weapon effectiveness varies dramatically against light, medium, and heavy armor targets.

---

## Armor & Damage Classification

The game employs a multi-layered armor and damage system that is fundamental to understanding unit interactions on the battlefield. Every unit is assigned a Defense Equipment type, and every weapon has distinct damage multipliers against each armor tier.

### Defense Equipment Tiers

| Tier | Classification | Typical Units | Characteristics |
|------|---------------|---------------|-----------------|
| **Defense Equipment I** | Light Armor | Infantry, recon vehicles, light boats | Low HP, high speed, vulnerable to all anti-armor weapons |
| **Defense Equipment II** | Medium Armor | Standard tanks, special vehicles, destroyers | Balanced HP/speed, moderate resistance to light weapons |
| **Defense Equipment III** | Heavy Armor | Heavy tanks, cruisers, hero units (T3) | High HP, slow speed, resistant to light/medium weapons |

### Attack Target Categories

Weapons are also classified by the types of targets they can engage. This determines what a unit can and cannot fire upon:

| Target Type | Description | Engaged By |
|-------------|-------------|------------|
| **Bombers** | Heavy aircraft on bombing runs | Anti-Air Center, Anti-Air Tower, fighters, Porcupine |
| **Fighters** | Air-superiority and multirole aircraft | Anti-Air Center, Anti-Air Tower, fighters, Porcupine |
| **Helicopters** | Rotary-wing aircraft | Anti-Air Center, Anti-Air Tower, fighters, Porcupine |
| **Land Units** | All ground-based units | Most ground weapons, bombers |
| **Warships** | Surface naval vessels | Naval guns, torpedoes, coastal artillery |
| **Submarines** | Submerged naval units | Detection systems + torpedoes, Viking, depth charges |

### Damage Multiplier Model (Estimated)

Based on observed gameplay behavior and reverse-engineered weapon parameters, damage multipliers approximately follow this pattern:

| Weapon Type vs. Armor | Light (DE-I) | Medium (DE-II) | Heavy (DE-III) |
|----------------------|:---:|:---:|:---:|
| Anti-Infantry (Rifle, MG) | 100% | 50% | 25% |
| Anti-Tank (AP Rocket, HEAT) | 70% | 100% | 130% |
| Artillery (Howitzer, Rocket) | 120% | 100% | 80% |
| Thermoelectric (Confed. specialty) | 60% | 110% | 140% |
| Sniper (Precision) | 150% | 80% | 60% |
| Naval Gun | 80% | 100% | 110% |
| Torpedo | 90% | 120% | 100% |
| Superweapon | 200%+ | 200%+ | 200%+ |

> **Note:** Exact multiplier values are stored in server-side configuration and may vary with balance patches. The above represents approximate observed ratios.

---

## Confederation Units

### Confederation Infantry

Infantry units are produced at the **Barracks** and require a Power Plant and Supply Center to be constructed first. Confederation infantry is generally more expensive but better equipped than their Resistance counterparts, trading stealth capabilities for raw firepower.

#### Assault Trooper (突击兵)

| Property | Value |
|----------|-------|
| **Production Building** | Barracks |
| **Armor Class** | Defense Equipment I (Light) |
| **Primary Weapon** | Automatic Rifle |
| **Secondary Weapon** | Grenade Launcher |
| **Primary Role** | Anti-Infantry |
| **Secondary Role** | Reconnaissance, Patrol |
| **Stealth** | None |
| **Special Abilities** | None |
| **Speed** | Medium (standard infantry pace) |

The Assault Trooper is the backbone of Confederation ground forces. Equipped with an automatic rifle for sustained anti-infantry fire and a grenade launcher for engaging light vehicles and clustered enemies, this unit serves as the primary reconnaissance and patrol unit for the faction. While not as specialized as other infantry, the Assault Trooper's versatility makes them cost-effective for early-game map control and screening operations. Their grenade launcher gives them a secondary anti-structure capability, allowing small groups to harass unguarded expansions. However, they lack the stealth capabilities of Resistance infantry, making them vulnerable to ambushes in forested terrain.

#### Heavy Assault Trooper (重型突击兵)

| Property | Value |
|----------|-------|
| **Production Building** | Barracks |
| **Armor Class** | Defense Equipment I (Light) |
| **Primary Weapon** | Anti-Tank Rocket Launcher |
| **Primary Role** | Anti-Vehicle |
| **Secondary Role** | Anti-Structure |
| **Stealth** | None |
| **Special Abilities** | None |
| **Speed** | Slow (heavy weapon burden) |

The Heavy Assault Trooper is the Confederation's dedicated anti-armor infantry. Armed with a powerful anti-tank rocket launcher, this unit deals significant damage to vehicles and structures, making it essential for defending against enemy armor pushes. The rocket's high damage against Defense Equipment II and III targets means that even a small squad of Heavy Assault Troopers can pose a credible threat to enemy tank columns. Their primary weakness is their vulnerability to anti-infantry weapons and their slow movement speed, which makes them susceptible to being outmaneuvered by fast Resistance vehicles like the Prairie Wolf and Jaguar. In defensive formations, they are most effective when positioned behind Wall segments or inside Bunkers where their fragility is mitigated.

#### Firepower Assault Trooper (火力突击兵)

| Property | Value |
|----------|-------|
| **Production Building** | Barracks |
| **Armor Class** | Defense Equipment I (Light) |
| **Primary Weapon** | Close-Range Flamethrower/Incendiary |
| **Primary Role** | Anti-Infantry (Close Range) |
| **Secondary Role** | Shock Assault |
| **Stealth** | None |
| **Special Abilities** | Jetpack — rapidly close distance to targets |
| **Speed** | Fast (with jetpack), Medium (on foot) |

The Firepower Assault Trooper is a unique and devastating infantry unit equipped with a jetpack that allows rapid closure of distance to enemy positions. Once in close range, their weapon annihilates infantry squads with terrifying efficiency. The jetpack ability fundamentally changes how this unit is used — rather than slowly advancing under fire, the Firepower Assault Trooper can jet across open ground and engage enemies before they can react. This makes them exceptional at clearing garrisoned Bunkers, flushing Snipers from elevated positions, and breaking through infantry screens protecting enemy anti-armor units. Their weakness is their light armor and the brief vulnerability window during the jetpack approach. If the enemy has sufficient anti-infantry firepower, the Firepower Assault Trooper may be cut down before reaching effective range. Smart commanders use terrain or smoke to mask their approach vector.

---

### Confederation Vehicles

Vehicle units are produced at the **Assault Vehicle Factory**. Confederation vehicles are generally characterized by heavier armor, slower speeds, and superior firepower compared to Resistance vehicles. They favor direct, head-on engagements where their armor and firepower can be brought to bear.

#### Fortress (堡垒)

| Property | Value |
|----------|-------|
| **Production Building** | Assault Vehicle Factory |
| **Armor Class** | Defense Equipment II (Medium) — likely higher effective HP due to "heavy armor" |
| **Primary Weapon** | Machine Gun (anti-infantry) |
| **Secondary Weapon** | Flamethrower (close-range area denial) |
| **Primary Role** | Support / Logistics |
| **Secondary Role** | Infantry Escort, Mine Detection |
| **Stealth** | None |
| **Special Abilities** | Mine Detection — reveals enemy mines in vicinity |
| **Speed** | Slow |

The Fortress is a support-oriented logistics vehicle that serves as the Confederation's primary infantry escort. Its heavy armor provides cover for advancing infantry, while its machine gun and flamethrower combination makes it lethal against enemy infantry and light vehicles at close range. The mine detection ability is a critical tactical tool against the Resistance's Armadillo (which can lay minefields), allowing the Fortress to safely lead formations through potentially mined terrain. In combined-arms formations, the Fortress typically takes point, absorbing damage while infantry and heavier vehicles fire from behind. The flamethrower is particularly effective against garrisoned structures and jungle-concealed Resistance infantry, as it can flush enemies from cover. However, the Fortress is vulnerable to anti-tank weapons and should never be sent into battle without support from anti-armor units.

#### Warhammer / Hammer (战锤)

| Property | Value |
|----------|-------|
| **Production Building** | Assault Vehicle Factory |
| **Armor Class** | Defense Equipment II (Medium) |
| **Primary Weapon** | 99mm Armor-Piercing Gun (rotating turret) |
| **Primary Role** | Fast Assault / Flanking |
| **Secondary Role** | Anti-Vehicle, Skirmishing |
| **Stealth** | None |
| **Special Abilities** | Fires accurately while moving |
| **Speed** | Fast |

The Warhammer is the Confederation's fast, highly mobile light tank and represents one of the faction's most tactically flexible units. Its 99mm armor-piercing gun on a rotating turret delivers consistent damage against medium-armored targets, and uniquely among Confederation vehicles, it can fire accurately while on the move. This "fire on the move" capability is a significant tactical advantage — the Warhammer can kite slower enemy units, perform hit-and-run attacks on enemy expansions, and retreat while still dealing damage. In the Confederation's generally slow army, the Warhammer is the premier flanking and skirmishing unit. It excels at exploiting gaps in enemy lines, hunting down vulnerable special vehicles like the Mammoth howitzer, and providing rapid response to enemy raids. Its medium armor provides reasonable survivability, but it should avoid direct engagement with heavy tanks like the Resistance Jaguar in siege mode. The Warhammer is also effective in wolf-packs of 3-4 units, which can quickly eliminate isolated targets and retreat before reinforcements arrive.

#### Zeus (宙斯)

| Property | Value |
|----------|-------|
| **Production Building** | Assault Vehicle Factory |
| **Armor Class** | Defense Equipment III (Heavy) |
| **Primary Weapon** | Thermoelectric Cannon |
| **Secondary Weapon** | Missile Launcher (ground targets + low-flying aircraft) |
| **Primary Role** | Heavy Assault / Breakthrough |
| **Secondary Role** | Anti-Air (low-flying), Base Siege |
| **Stealth** | None |
| **Special Abilities** | Missile launcher can engage low-flying aircraft |
| **Speed** | Very Slow |

The Zeus is the pinnacle of Confederation armored warfare — a heavy assault tank with near-impenetrable armor and devastating dual-purpose weaponry. Its thermoelectric cannon is the faction's most powerful anti-armor weapon, capable of destroying medium-armored vehicles in just a few hits and dealing catastrophic damage to heavy-armored targets. The secondary missile launcher adds remarkable versatility, engaging both ground targets and low-flying aircraft, making the Zeus one of the few heavy tanks with organic anti-air capability. This means the Zeus can advance without dedicated anti-air escort against helicopter threats, though it remains vulnerable to high-altitude bomber strikes. The Zeus's primary limitation is its extreme slowness — it is the slowest unit in the Confederation roster. This makes it susceptible to being flanked, outmaneuvered, or focused by long-range artillery before it can close distance. Smart commanders protect their Zeus with Energy Shields for additional durability and screen it with Warhammers and infantry to prevent flanking. When a Zeus reaches firing position, however, very few units can survive sustained engagement.

---

### Confederation Special Vehicles

Special Vehicles are produced at the **Special Vehicle Factory**. These units provide critical support functions — anti-air defense, long-range artillery, and force enhancement — that are essential to a well-rounded army composition.

#### Hurricane / Cyclone (飓风)

| Property | Value |
|----------|-------|
| **Production Building** | Special Vehicle Factory |
| **Armor Class** | Defense Equipment II (Medium) |
| **Primary Weapon** | Anti-Air Missiles / Autocannon |
| **Primary Role** | Anti-Air Defense |
| **Secondary Role** | Area Denial (Air) |
| **Stealth** | None |
| **Special Abilities** | Double efficiency when stationary (deployed mode) |
| **Speed** | Medium (mobile), 0 (deployed) |

The Hurricane is the Confederation's mobile anti-air platform, designed to detect and shoot down aerial targets with lethal efficiency. In its mobile configuration, it moves at a reasonable pace and can provide anti-air cover on the march. However, its true power is unlocked when deployed into stationary mode, which doubles its fire rate and tracking efficiency. This makes the Hurricane exceptionally effective when positioned near critical structures or in defensive formations. Against Resistance air assets — particularly the Hawk fighter and Albatross bomber — the Hurricane is an essential counter. A pair of deployed Hurricanes can create a no-fly zone that forces enemy aircraft to either avoid the area or accept heavy losses. The tactical decision of when to deploy and when to stay mobile is critical: a deployed Hurricane cannot retreat from ground threats, so it must be protected by other units. The double-efficiency mechanic encourages a defensive, positional playstyle that aligns with the Confederation's overall design philosophy.

#### Torrent (激流)

| Property | Value |
|----------|-------|
| **Production Building** | Special Vehicle Factory |
| **Armor Class** | Defense Equipment II (Medium) |
| **Primary Weapon** | Multiple Rocket Launcher |
| **Primary Role** | Long-Range Artillery / Siege |
| **Secondary Role** | Area Denial, Base Destruction |
| **Stealth** | None |
| **Special Abilities** | Siege Mode only — must deploy to fire, cannot fire while moving |
| **Speed** | Slow (mobile), 0 (siege mode) |

The Torrent is the Confederation's long-range artillery platform, capable of delivering devastating wide-area barrages from beyond the range of most defensive structures. It operates exclusively in siege mode — it must deploy into a stationary position before it can fire, and cannot fire while moving. This creates a significant vulnerability window during deployment and repositioning. Once set up, however, the Torrent rains destruction across a large area, making it ideal for softening enemy fortifications before a push, destroying clustered buildings, and forcing the enemy to spread out their defenses. The Torrent's rockets deal area-of-effect damage, making them effective against infantry formations and closely packed buildings. Its extreme range means it can often fire from behind the safety of friendly lines, but it must be protected from fast flanking units that can close distance and exploit its inability to fight in close combat. The recommended formation places Warhammers and infantry between the Torrent and the enemy, with a Hurricane nearby for air cover.

#### Energy Shield (能量护盾)

| Property | Value |
|----------|-------|
| **Production Building** | Special Vehicle Factory |
| **Armor Class** | Defense Equipment II (Medium) |
| **Primary Weapon** | None (support unit) |
| **Primary Role** | Force Enhancement / Shield Projection |
| **Secondary Role** | Force Multiplication |
| **Stealth** | None |
| **Special Abilities** | Generates energy field enhancing armor of nearby units; short duration, requires recharge |
| **Speed** | Slow |

The Energy Shield is a force-multiplying support vehicle that projects an energy field enhancing the armor of all nearby allied units. This is a uniquely Confederation technology that has no direct Resistance equivalent. When activated, the energy field temporarily increases the effective armor of all units within its radius, allowing even medium-armored units to withstand hits that would normally destroy them. The ability has a short duration and requires a recharge period between uses, creating a timing-based tactical element. The optimal use of the Energy Shield is to activate it during critical moments — such as when a Zeus column is advancing into enemy anti-tank fire, or when infantry is crossing open ground under sniper fire. The shield's area-of-effect nature means it benefits grouped units most, encouraging the Confederation's natural tendency toward concentrated formations. The Energy Shield itself is vulnerable during its recharge period and has no offensive capability, so it must be protected by the very units it shields.

---

### Confederation Aviation

Aviation units are produced at the **Avia Factory** (Air Force Factory) and require an **Airport** for refueling and re-arming. All aircraft have limited fuel and must return to the Airport periodically. This fuel mechanic adds a strategic layer: aircraft cannot indefinitely patrol an area and must be managed carefully to avoid running out of fuel over enemy territory.

#### Whirlwind (旋风)

| Property | Value |
|----------|-------|
| **Production Building** | Avia Factory |
| **Armor Class** | Defense Equipment I (Light) |
| **Primary Weapon** | Machine Gun |
| **Secondary Ability** | Submarine Detection |
| **Primary Role** | Reconnaissance / Support |
| **Secondary Role** | Anti-Submarine Patrol |
| **Stealth** | None |
| **Special Abilities** | Submarine detection — reveals submerged enemy submarines |
| **Fuel** | Moderate |
| **Landing Requirement** | Airport |

The Whirlwind is the Confederation's light helicopter, serving primarily as a reconnaissance and support platform. Its machine gun provides modest anti-infantry capability, but its true value lies in its submarine detection system, which can reveal submerged enemy submarines that would otherwise be invisible. This makes the Whirlwind an essential naval support unit on water-heavy maps, where the Resistance's Barracuda submarine can devastize Confederation naval forces if left undetected. The Whirlwind is also useful for quick scouting missions, revealing enemy dispositions without committing ground units. However, it is highly vulnerable to anti-air fire and should never linger over enemy positions. Its primary counter is the Resistance Porcupine, which can instantly lock on with omnidirectional missiles. The Whirlwind's moderate fuel capacity means it can patrol for a reasonable duration before needing to return to the Airport.

#### Vertex (天顶)

| Property | Value |
|----------|-------|
| **Production Building** | Avia Factory |
| **Armor Class** | Defense Equipment I (Light) |
| **Primary Weapon** | Self-Homing Missiles |
| **Primary Role** | Air Superiority / Multirole Strike |
| **Secondary Role** | Anti-Air, Anti-Ground |
| **Stealth** | None |
| **Special Abilities** | Variable thrust vectoring engine — exceptional maneuverability; self-homing missiles |
| **Fuel** | Limited — must return to Airport |
| **Landing Requirement** | Airport |

The Vertex is the Confederation's air superiority fighter, featuring variable thrust vectoring engines that give it exceptional maneuverability in dogfights. Its self-homing missiles allow it to engage both aerial and ground targets with high accuracy, making it a true multirole platform. In air-to-air combat, the Vertex's maneuverability and homing missiles give it an edge against the Resistance Hawk, particularly in turning engagements. Against ground targets, it can perform precision strikes on high-value targets like the Chameleon or Mammoth. The Vertex's critical limitation is its weak armor and limited fuel supply. A single sustained anti-air engagement can destroy it, and it must carefully manage fuel to avoid being stranded over enemy territory. The Airport dependency means that losing an Airport effectively grounds all Vertex fighters, making Airport protection a strategic priority. Commanders typically use Vertices in coordinated strikes — sending them in to eliminate key targets and immediately recalling them before enemy anti-air can respond.

#### Thor (雷神)

| Property | Value |
|----------|-------|
| **Production Building** | Avia Factory |
| **Armor Class** | Defense Equipment II (Medium) — exceptionally durable for an aircraft |
| **Primary Weapon** | Heavy Bomb Load |
| **Primary Role** | Strategic Bombing / Infrastructure Destruction |
| **Secondary Role** | Deep Strike |
| **Stealth** | None |
| **Special Abilities** | Heavy armor — can penetrate deep into enemy bases; devastating infrastructure strikes |
| **Fuel** | Limited — one bomb load per flight |
| **Landing Requirement** | Airport only |

The Thor is the Confederation's heavy bomber, designed to penetrate deep into enemy territory and deliver devastating strikes against infrastructure. Its heavy armor allows it to withstand anti-air fire that would destroy lighter aircraft, making it the only Confederation aircraft capable of surviving a bombing run over a well-defended base. Each Thor sortie carries one bomb load, meaning it must return to the Airport after each attack run to rearm. This makes each Thor strike a calculated decision — commanders must choose their targets carefully, prioritizing high-value structures like Superweapon buildings, production facilities, or the Headquarters. The Thor is most effective when used in conjunction with diversionary attacks that draw enemy anti-air away from the primary target. It is also devastating against clustered buildings where its bomb's area of effect can damage multiple structures simultaneously. The Resistance counter to the Thor is the Albatross in air-to-air combat or concentrated anti-air fire from Sniper Towers and Anti-Air Towers.

---

### Confederation Navy

Naval units are produced at the **Shipyard** (Dockyard), which must be built in water. Naval combat is map-dependent; on maps with significant water bodies, naval dominance can be decisive. The Confederation navy emphasizes heavy firepower and long-range engagement.

#### Delta (三角)

| Property | Value |
|----------|-------|
| **Production Building** | Shipyard |
| **Armor Class** | Defense Equipment I (Light) |
| **Primary Weapon** | Medium-Caliber Automatic Cannon |
| **Primary Role** | Amphibious Assault / Fast Attack |
| **Secondary Role** | Coastal Raiding |
| **Stealth** | None |
| **Special Abilities** | Amphibious — can assault from water onto land |
| **Speed** | High |

The Delta is the Confederation's amphibious light assault boat, combining high mobility with the unique ability to assault from water directly onto land. This amphibious capability makes the Delta a versatile raider that can approach from unexpected directions — crossing rivers, launching from coastlines, and striking inland targets that may lack land-side defenses. Its medium-caliber automatic cannon is effective against light armor and infantry, making it useful for harassing supply lines and undefended expansions. The Delta's high speed allows it to quickly reposition across water, but its light armor means it cannot survive sustained engagement with dedicated anti-ship weapons. On maps with extensive waterways, a group of Deltas can be used to flank enemy positions, attack coastal buildings, and create diversions while the main force attacks from a different direction. The Delta's amphibious nature also makes it useful for establishing beachheads during amphibious operations.

#### Viking (维京)

| Property | Value |
|----------|-------|
| **Production Building** | Shipyard |
| **Armor Class** | Defense Equipment II (Medium) |
| **Primary Weapon** | Triple-Barreled Thermoelectric Naval Gun |
| **Secondary Weapon** | Gauss Torpedoes |
| **Primary Role** | Anti-Warship / Surface Combat |
| **Secondary Role** | Anti-Submarine |
| **Stealth** | None |
| **Special Abilities** | Underwater detection system — can detect submerged submarines |
| **Speed** | Medium |

The Viking is the Confederation's premier surface combatant, designed as an anti-warship destroyer with formidable anti-submarine capabilities. Its triple-barreled thermoelectric naval gun delivers devastating damage to surface ships, while its Gauss torpedoes provide an effective underwater weapon against submarines. The integrated underwater detection system is the Viking's most strategically significant feature — it is one of only two units (along with the Whirlwind helicopter) that can detect submerged Resistance Barracudas. On naval maps, Viking superiority is essential for maintaining sea control and protecting the slow Poseidon cruisers from submarine attack. The Viking's medium armor provides reasonable survivability in surface engagements, and its medium speed allows it to respond to threats across a naval theater. In fleet formations, Vikings typically screen ahead of Poseidons, engaging enemy surface ships and hunting submarines while the cruisers provide long-range fire support.

#### Poseidon (波塞冬)

| Property | Value |
|----------|-------|
| **Production Building** | Shipyard |
| **Armor Class** | Defense Equipment III (Heavy) |
| **Primary Weapon** | Long-Range Siege Missiles (ground attack) |
| **Secondary Weapon** | Surface-to-Air Missiles |
| **Primary Role** | Naval Siege / Long-Range Bombardment |
| **Secondary Role** | Anti-Air Defense |
| **Stealth** | None |
| **Special Abilities** | Can attack ground targets from beyond visual range; carries SAMs |
| **Speed** | Very Slow |

The Poseidon is the Confederation's heavy missile cruiser and represents the pinnacle of naval warfare technology. Its long-range siege missiles can attack ground targets from beyond the range of most defensive structures, making it a floating artillery platform capable of devastating enemy bases from the safety of open water. This capability is uniquely powerful on maps where bases are accessible from coastlines — a Poseidon positioned offshore can systematically destroy buildings without ever coming under return fire. The secondary surface-to-air missile system provides organic anti-air defense, making the Poseidon resistant to aerial attack. However, the Poseidon is extremely slow, making it vulnerable to fast naval raiders and submarines if not escorted by Vikings. The Poseidon's strategic value is immense on water-heavy maps; controlling the sea with a Poseidon effectively denies the enemy their coastal buildings and can turn the tide of an entire match. It is the naval equivalent of the Zeus in terms of firepower and armor, and like the Zeus, it requires careful escort to reach its full potential.

---

### Confederation Superweapon

#### Aerial Strike System / Space System (Orbital Satellite Strike)

| Property | Value |
|----------|-------|
| **Production Building** | Aerial Strike System (Superweapon Building) |
| **Armor Class** | N/A (structure-based) |
| **Effect** | Orbital satellite strikes target area with devastating energy beam |
| **Charge Time** | Extended (several minutes) |
| **Damage** | Catastrophic — destroys most units and heavily damages structures |
| **Area of Effect** | Large radius |
| **VFX Scale** | s5 (second largest effect scale in the game) |

The Confederation's superweapon is the Aerial Strike System, which calls down orbital satellite strikes on a targeted area. Once the superweapon building is constructed and fully charged, the player can designate a target location anywhere on the map (within revealed territory) and unleash a devastating energy beam from orbit. The strike deals catastrophic damage across a large radius, capable of wiping out entire army formations or severely damaging a base cluster. The charge time is significant (typically several minutes of real-time gameplay), which means the weapon can only be used sparingly and must be timed for maximum impact. Strategic uses include: destroying a concentrated enemy army, breaking a fortified position, eliminating an enemy superweapon before it fires, or decimating an enemy economy cluster. The superweapon's VFX at scale s5 indicates a massive, visually spectacular effect — second only to the nuclear explosion in visual intensity. The counter to the Aerial Strike System is to destroy the superweapon building before it charges, or to spread units and structures to minimize the area-of-effect damage.

---

## Resistance Units

### Resistance Infantry

Resistance infantry is produced at the **Barracks** and shares the same building prerequisites as the Confederation (Power Plant + Supply Center). The defining characteristic of Resistance infantry is their ability to **hide in forests and jungles**, making them invisible to enemy units that don't have direct line of sight. This stealth mechanic is fundamental to the Resistance's guerrilla warfare playstyle and enables devastating ambush tactics.

#### Rifleman (步枪兵)

| Property | Value |
|----------|-------|
| **Production Building** | Barracks |
| **Armor Class** | Defense Equipment I (Light) |
| **Primary Weapon** | Personal Combat Rifle |
| **Secondary Weapon** | Electronic Smoke Grenades |
| **Primary Role** | Anti-Infantry / Scout |
| **Secondary Role** | Ambush, Area Denial |
| **Stealth** | Can secretly traverse dense forests — invisible while in forest/jungle tiles |
| **Special Abilities** | Electronic Smoke Grenades — reduce enemy accuracy in the affected area |
| **Speed** | Medium (standard infantry pace) |

The Rifleman is the Resistance's foundational infantry unit and embodies the faction's guerrilla warfare philosophy. Unlike the Confederation Assault Trooper, the Rifleman can secretly traverse dense forests and jungles, becoming invisible to enemy units that lack direct visual contact. This allows Riflemen to move through map terrain that Confederation units cannot safely traverse, creating opportunities for flanking maneuvers, reconnaissance, and ambush. The electronic smoke grenades add another layer of tactical utility — when thrown, they create a smoke cloud that reduces enemy accuracy, allowing Resistance forces to advance under cover or retreat from unfavorable engagements. The smoke mechanic synergizes exceptionally well with the Sniper, who can fire from within or behind smoke with relative impunity while enemies struggle to hit back. Riflemen are most effective when used in coordination with the forest terrain that dominates many maps, using hit-and-run tactics to harass the enemy before melting back into the trees.

#### Grenadier (掷弹兵)

| Property | Value |
|----------|-------|
| **Production Building** | Barracks |
| **Armor Class** | Defense Equipment I (Light) |
| **Primary Weapon** | Personal Grenade Launcher |
| **Primary Role** | Anti-Vehicle / Anti-Structure |
| **Secondary Role** | Ambush, Demolition |
| **Stealth** | Can hide in jungles for ambush — invisible while in jungle tiles |
| **Special Abilities** | Jungle ambush — can attack from concealment without revealing position immediately |
| **Speed** | Slow-Medium |

The Grenadier is the Resistance's anti-armor infantry counterpart to the Confederation's Heavy Assault Trooper, but with a fundamentally different tactical profile thanks to jungle stealth. Armed with a personal grenade launcher, the Grenadier deals significant damage to vehicles and structures, making it the primary infantry counter to Confederation armor. The ability to hide in jungles transforms the Grenadier from a simple anti-armor unit into a deadly ambush predator. A squad of Grenadiers concealed in jungle terrain along a common attack route can devastize an advancing Confederation tank column before the enemy even knows they're under attack. This jungle ambush capability forces Confederation players to either avoid jungle terrain entirely (limiting their movement options) or invest in reconnaissance units like the Whirlwind to scout ahead. The Grenadier is also effective against buildings, making it useful for demolishing forward bases and resource structures during raiding operations. Their primary weakness is their vulnerability when caught in open terrain, where their light armor offers no protection against anti-infantry weapons.

#### Sniper (狙击手)

| Property | Value |
|----------|-------|
| **Production Building** | Barracks |
| **Armor Class** | Defense Equipment I (Light) |
| **Primary Weapon** | 12.7mm "Cobra" Sniper Rifle |
| **Primary Role** | Long-Range Anti-Armor / Precision Elimination |
| **Secondary Role** | Harassment, Area Denial |
| **Stealth** | Can hide in forests/jungles |
| **Special Abilities** | Hits weak points of armored units at maximum range — increased damage against armored targets at max range |
| **Speed** | Slow |

The Sniper is arguably the most tactically nuanced infantry unit in the game. Armed with the 12.7mm "Cobra" sniper rifle, this unit deals devastating damage at maximum range by targeting weak points in armored units. This mechanic — increased damage against armored targets at maximum range — inverts the typical infantry-armor relationship and makes the Sniper a credible threat even to heavy tanks like the Zeus. However, the Sniper is extremely vulnerable in close combat; if enemy infantry or fast vehicles close the distance, the Sniper is quickly eliminated. The optimal Sniper tactic involves positioning in forests or jungles at maximum range from enemy approach routes, using stealth to remain undetected while picking off high-value targets. When combined with the Rifleman's smoke grenades, Snipers can fire with relative impunity while enemies struggle to return fire. The Sniper also benefits from the Chameleon's fog barrier, which can conceal an entire Sniper nest from enemy detection. Counter-strategies include using the Firepower Assault Trooper's jetpack to rapidly close distance, or using the Fortress's mine detection to safely approach through terrain.

---

### Resistance Vehicles

Resistance vehicles are produced at the **Assault Vehicle Factory**. They emphasize speed, mobility, and tactical versatility over raw armor and firepower. Many Resistance vehicles have dual modes that allow them to adapt to different combat situations.

#### Prairie Wolf / Coyote (郊狼)

| Property | Value |
|----------|-------|
| **Production Building** | Assault Vehicle Factory |
| **Armor Class** | Defense Equipment I (Light) |
| **Primary Weapon** | Light Machine Gun |
| **Primary Role** | Reconnaissance / Fast Attack |
| **Secondary Role** | Flanking, Harassment |
| **Stealth** | None |
| **Special Abilities** | Ultra-fast even off-road — maintains high speed on all terrain types |
| **Speed** | Extremely Fast |

The Prairie Wolf is the Resistance's ultra-light reconnaissance vehicle, built for pure speed and mobility. It is the fastest ground unit in the game, capable of maintaining extremely high speeds even on off-road terrain where other vehicles slow down significantly. This makes the Prairie Wolf invaluable for scouting, as it can quickly traverse the entire map to reveal enemy positions and dispositions. In combat, the Prairie Wolf's light machine gun is only effective against infantry and other light-armored targets, so it should avoid direct engagement with anything heavier. However, its speed makes it an exceptional harassment unit — it can raid enemy supply lines, attack unprotected resource buildings, and flee before reinforcements arrive. The Prairie Wolf is also useful for "towing" enemy units out of position; by appearing to threaten a flank, it can draw enemy forces away from the main attack vector. In the late game, Prairie Wolves are often used to hunt down retreating enemy units or capture strategic points. Their extreme speed also makes them the best unit for escaping superweapon strikes, as they can often clear the blast radius before the weapon impacts.

#### Armadillo (犰狳)

| Property | Value |
|----------|-------|
| **Production Building** | Assault Vehicle Factory |
| **Armor Class** | Defense Equipment II (Medium) |
| **Primary Weapon** | Rapid-Fire Autocannon |
| **Primary Role** | Versatile Combat / Mine Layer |
| **Secondary Role** | Area Denial, Anti-Infantry |
| **Stealth** | None |
| **Special Abilities** | Can lay minefields — creates persistent mine zones that damage enemy units |
| **Speed** | Fast |

The Armadillo is the Resistance's most versatile vehicle, combining sturdy medium armor, high mobility, and a rapid-fire autocannon with the unique ability to lay minefields. This mine-laying capability is a defining tactical tool for the Resistance, allowing commanders to create defensive zones, deny approach routes, and protect flanks without committing units to garrison duty. Minefields are particularly effective against the Confederation's slow, heavily armored units — a Zeus advancing through an unknown minefield can take crippling damage before reaching engagement range. The Armadillo's autocannon is effective against infantry and light-to-medium armored vehicles, making it a solid all-around combatant. In the Resistance's hit-and-run doctrine, Armadillos often lay mines along likely enemy approach routes before falling back, then return to engage the weakened enemy from a different direction. The primary counter to Armadillo mines is the Confederation Fortress, which can detect and clear minefields. This creates an interesting meta-dynamic where the Fortress (a slow, defensive unit) is the natural counter to the Armadillo (a fast, offensive unit), requiring each faction to adapt their playstyle when facing the other.

#### Jaguar (美洲豹)

| Property | Value |
|----------|-------|
| **Production Building** | Assault Vehicle Factory |
| **Armor Class** | Defense Equipment II (Medium, Travel Mode) / Defense Equipment III (Heavy, Siege Mode — estimated) |
| **Primary Weapon** | Tank Gun (high firepower, doubled in Siege Mode) |
| **Primary Role** | Multi-Role Assault Tank |
| **Secondary Role** | Siege, Mobile Defense |
| **Stealth** | None |
| **Special Abilities** | Travel Mode: fast movement, fires while moving, tough armor. Siege Mode: doubled firepower, reduced mobility |
| **Speed** | Fast (Travel Mode), Very Slow (Siege Mode) |
| **Weakness** | Completely vulnerable to air units — no anti-air capability |

The Jaguar is the Resistance's signature unit and perhaps the most tactically complex vehicle in the game. It operates in two modes: **Travel Mode** and **Siege Mode**. In Travel Mode, the Jaguar functions as a fast tank that can fire accurately while moving, with surprisingly tough armor (actually tougher than in Siege Mode according to game data). This makes it an excellent skirmisher and flanker, able to engage the enemy while maintaining mobility. In Siege Mode, the Jaguar's firepower doubles, making it one of the most devastating ground combat units in the game, capable of going toe-to-toe with the Confederation Zeus in raw damage output. However, Siege Mode dramatically reduces the Jaguar's mobility, and its armor is actually slightly less effective in this configuration.

The Jaguar's critical weakness is its complete vulnerability to air units — it has no anti-air capability whatsoever. This means a Jaguar formation without anti-air support can be decimated by a single Vertex or Hawk. The dual-mode design forces Resistance commanders to make constant tactical decisions: when to push in Travel Mode, when to commit to Siege Mode for maximum damage, and when to disengage. The most effective Jaguar commanders use Travel Mode to reach advantageous positions, then switch to Siege Mode at the decisive moment, and immediately switch back to Travel Mode if the situation changes. This dynamic playstyle perfectly embodies the Resistance's philosophy of adaptability and tactical flexibility.

---

### Resistance Special Vehicles

Resistance Special Vehicles are produced at the **Special Vehicle Factory**. These units provide anti-air defense, long-range artillery, and the faction's unique stealth enhancement capability. Each unit is highly specialized and must be used in coordination with the rest of the army.

#### Porcupine (豪猪)

| Property | Value |
|----------|-------|
| **Production Building** | Special Vehicle Factory |
| **Armor Class** | Defense Equipment II (Medium) |
| **Primary Weapon** | Omnidirectional Missile Launcher (instant lock-on) |
| **Secondary Weapon** | Machine Gun (engages both air and ground) |
| **Primary Role** | Anti-Air / Multi-Target Defense |
| **Secondary Role** | Anti-Ground, Point Defense |
| **Stealth** | None |
| **Special Abilities** | Omnidirectional engagement — can fire in all directions simultaneously; instant lock-on |
| **Speed** | Medium |

The Porcupine is the Resistance's answer to the Confederation Hurricane, but with a fundamentally different design philosophy. While the Hurricane requires deployment for maximum efficiency and engages primarily aerial targets, the Porcupine features an omnidirectional missile launcher with instant lock-on capability that can engage both air and ground targets in all directions simultaneously. This means the Porcupine never needs to face its target — it can fire at enemies approaching from any direction without rotating, making it exceptionally difficult to flank. The instant lock-on capability also means there is no targeting delay, allowing the Porcupine to react immediately to threats. Against aircraft, the Porcupine is devastating — its missiles can track and destroy fighters and bombers with high reliability. Against ground targets, the machine gun provides consistent anti-infantry and anti-light-vehicle fire. The Porcupine is the ideal escort for Jaguar formations, providing the anti-air cover that Jaguars desperately need while also contributing ground fire. Its primary weakness is its moderate armor and the fact that its missiles have limited ammunition that must be replenished over time.

#### Mammoth (猛犸)

| Property | Value |
|----------|-------|
| **Production Building** | Special Vehicle Factory |
| **Armor Class** | Defense Equipment II (Medium) |
| **Primary Weapon** | Extremely Long-Range Howitzer |
| **Primary Role** | Siege Artillery / Base Destruction |
| **Secondary Role** | Area Denial |
| **Stealth** | None |
| **Special Abilities** | Siege Mode only — must deploy to fire; extreme range |
| **Speed** | Slow (mobile), 0 (siege mode) |
| **Weakness** | Extremely vulnerable in close combat due to slow movement and minimal close-range defense |

The Mammoth is the Resistance's long-range howitzer platform, functioning as the factional equivalent to the Confederation Torrent. Like the Torrent, it operates exclusively in Siege Mode — it must deploy into a stationary position before firing and cannot move while firing. The Mammoth's howitzer has extreme range, capable of reaching across significant portions of the map to bombard enemy bases and formations. Its shells deal heavy damage to structures and area-of-effect damage to clustered units. The Mammoth is most effective when used to destroy enemy defensive structures before an assault, soften up enemy positions, and force the enemy to spread their buildings apart. However, the Mammoth is critically vulnerable in close combat — its slow movement speed means it cannot escape from fast units like the Warhammer or Prairie Wolf, and it has minimal close-range defensive capability. This makes the Mammoth a high-value target that the enemy will prioritize eliminating. The recommended tactic is to position the Mammoth behind the main battle line, screened by Jaguars and Porcupines, and to always have a retreat path planned in case the enemy breaks through.

#### Chameleon (变色龙)

| Property | Value |
|----------|-------|
| **Production Building** | Special Vehicle Factory |
| **Armor Class** | Defense Equipment II (Medium) |
| **Primary Weapon** | None (support unit) |
| **Primary Role** | Stealth Enhancement / Area Concealment |
| **Secondary Role** | Electronic Warfare |
| **Stealth** | Active camouflage |
| **Special Abilities** | Generates ionized fog barrier concealing allied units; enemy electronics cannot detect hidden units; only scouts entering the fog can reveal hidden units |
| **Speed** | Slow |

The Chameleon is perhaps the most strategically unique unit in the game and the centerpiece of the Resistance's stealth-based playstyle. It uses active camouflage to generate an ionized fog barrier that conceals all allied units within its radius. This fog is not merely visual — enemy electronic detection systems cannot penetrate it, meaning that units hidden by the Chameleon are invisible to all forms of remote detection. The only way to reveal hidden units is to physically send a scout unit into the fog barrier, at which point concealed units become visible to that scout's team. This creates a powerful tactical dynamic: the Chameleon can hide an entire army, an artillery position, or a base approach from enemy observation, forcing the opponent to commit reconnaissance units to risky forward positions. The Chameleon is most devastating when used to conceal a Jaguar siege position, a Mammoth artillery emplacement, or a Sniper nest. The combination of Chameleon fog + Snipers is particularly feared, as enemy units approaching the fog are picked off at range before they can reveal the hidden forces. Counter-strategies include using fast, expendable scouts to penetrate the fog, using area-of-effect weapons to blindly target suspected positions, or destroying the Chameleon itself to collapse the fog barrier.

---

### Resistance Aviation

Resistance aviation units follow the same production model as the Confederation: produced at the **Avia Factory** and requiring an **Airport** for refueling. Resistance aircraft tend to be more versatile but slightly less specialized than their Confederation counterparts.

#### Dragonfly (蜻蜓)

| Property | Value |
|----------|-------|
| **Production Building** | Avia Factory |
| **Armor Class** | Defense Equipment I (Light) |
| **Primary Weapon** | Machine Gun |
| **Secondary Weapon** | Guided Missiles |
| **Primary Role** | Reconnaissance / Aerial Assault |
| **Secondary Role** | Light Ground Attack |
| **Stealth** | None |
| **Special Abilities** | Guided missiles provide moderate anti-vehicle capability |
| **Fuel** | Moderate |
| **Landing Requirement** | Airport |

The Dragonfly is the Resistance's light helicopter, serving as both a reconnaissance platform and a light aerial assault unit. Compared to the Confederation Whirlwind, the Dragonfly trades submarine detection capability for guided missiles, giving it a more offensive role. The guided missiles allow the Dragonfly to engage light and medium armored vehicles with moderate effectiveness, making it useful for harassing enemy vehicle columns and supporting ground assaults. However, the Dragonfly's light armor makes it highly vulnerable to anti-air fire, and it should avoid prolonged engagements over enemy positions. In the Resistance's guerrilla warfare doctrine, the Dragonfly excels at quick strike-and-fade missions — approaching from an unexpected direction, launching missiles at a high-value target, and retreating before anti-air units can respond. The Dragonfly is also useful for providing aerial vision over Chameleon fog barriers, allowing hidden ground forces to see enemies approaching the barrier without revealing their own positions.

#### Hawk (鹰)

| Property | Value |
|----------|-------|
| **Production Building** | Avia Factory |
| **Armor Class** | Defense Equipment I (Light) |
| **Primary Weapon** | Multirole Weapon System |
| **Primary Role** | Air Superiority / Ground Strike |
| **Secondary Role** | Anti-Air, Multirole |
| **Stealth** | None |
| **Special Abilities** | 5th-gen heavy fighter — strikes both ground and air targets |
| **Fuel** | Limited — must return to Airport |
| **Landing Requirement** | Airport |

The Hawk is the Resistance's 5th-generation heavy fighter, designed as a true multirole combat aircraft that can engage both ground and air targets with equal effectiveness. In air-to-air combat, the Hawk's advanced avionics and heavy armament make it a formidable opponent, though the Confederation Vertex's superior maneuverability can be an advantage in dogfights. Against ground targets, the Hawk delivers precision strikes with heavy ordnance, making it effective against vehicles, structures, and infantry concentrations. The Hawk's versatility means it can respond to any threat on the battlefield, but its light armor and limited fuel require careful management. Like all fighters, the Hawk must return to the Airport to refuel and rearm, creating a vulnerability window where the Resistance player lacks air cover. The optimal use of the Hawk involves rotating multiple aircraft so that at least one is always available while others are rearming. The Hawk is the primary aerial counter to the Confederation Thor bomber, as it can intercept and destroy the slower, less maneuverable bomber before it reaches its target.

#### Albatross (信天翁)

| Property | Value |
|----------|-------|
| **Production Building** | Avia Factory |
| **Armor Class** | Defense Equipment III (Heavy) — exceptionally durable aircraft |
| **Primary Weapon** | Heavy Bomb Load |
| **Primary Role** | Strategic Bombing / Aerial Fortress |
| **Secondary Role** | Deep Strike, Diversion |
| **Stealth** | None |
| **Special Abilities** | Nearly indestructible — can withstand multiple anti-air missile hits |
| **Fuel** | Limited — one bomb load per flight |
| **Landing Requirement** | Airport only |

The Albatross is the Resistance's heavy bomber and the counterpart to the Confederation Thor. What sets the Albatross apart is its extraordinary durability — it is described as a "nearly indestructible aerial fortress" that can withstand multiple anti-air missile hits and still complete its bombing run. This makes the Albatross arguably the most effective bomber in the game, as it can penetrate even heavily defended airspace to deliver its payload. The Albatross carries one bomb load per sortie and must return to the Airport after each attack, making target selection critical. The most effective Albatross targets are the Confederation's superweapon building, the Zeus production facility, and the Headquarters. The Albatross's durability means it can be used more aggressively than the Thor — it can fly directly over enemy anti-air positions rather than trying to avoid them. However, it is still vulnerable to concentrated fire from multiple anti-air units and can be intercepted by fighters. The Albatross is also expensive and slow to produce, so losing one is a significant setback.

---

### Resistance Navy

Resistance naval units are produced at the **Shipyard** (Dockyard). The Resistance navy emphasizes speed, stealth, and asymmetric naval warfare, with the submarine Barracuda being a uniquely powerful strategic asset.

#### Caiman (凯门鳄)

| Property | Value |
|----------|-------|
| **Production Building** | Shipyard |
| **Armor Class** | Defense Equipment I (Light) |
| **Primary Weapon** | Machine Gun |
| **Primary Role** | Fast Naval Combat / Mine Layer |
| **Secondary Role** | Coastal Defense, Harassment |
| **Stealth** | None |
| **Special Abilities** | High-speed capability; can lay naval mines |
| **Speed** | Very High |

The Caiman is the Resistance's fast naval combat unit, designed for hit-and-run naval engagements and mine warfare. Its high-speed capability allows it to outrun most other naval units, making it ideal for flanking maneuvers, quick raids on enemy shipyards, and rapid repositioning. The mine-laying ability is a significant tactical tool — naval mines can deny narrow waterways, protect coastlines from amphibious assault, and create kill zones when combined with other naval units. The Caiman's machine gun is effective against other light naval units and can damage medium-armored ships in sustained engagements, but it lacks the firepower to threaten heavy warships directly. In the Resistance's naval doctrine, Caimans typically screen ahead of Alligators and Barracudas, laying mines to shape the naval battlefield and drawing enemy fire while heavier units maneuver into position. The Caiman's extreme speed also makes it useful for scouting enemy naval dispositions and retreating to report findings.

#### Alligator (鳄鱼)

| Property | Value |
|----------|-------|
| **Production Building** | Shipyard |
| **Armor Class** | Defense Equipment II (Medium) |
| **Primary Weapon** | Dual Naval Guns |
| **Secondary Weapon** | Anti-Air Missile Launcher |
| **Primary Role** | Multi-Role Surface Combatant |
| **Secondary Role** | Anti-Air Defense, Fleet Escort |
| **Stealth** | None |
| **Special Abilities** | Heavy armor combined with surprising agility — most agile in its class |
| **Speed** | Medium-Fast |

The Alligator is the Resistance's multi-role surface combatant, combining dual naval guns and an anti-air missile launcher in a platform that is surprisingly agile despite its heavy armor. This agility is the Alligator's distinguishing feature — it can outmaneuver the Confederation Viking in close naval combat while still absorbing significant damage. The dual naval guns provide consistent anti-ship firepower, while the anti-air missile launcher gives the Alligator organic anti-air capability, making it a self-sufficient escort for Barracuda submarines and Caiman raiders. In fleet actions, the Alligator serves as the backbone of Resistance naval forces, engaging enemy surface ships while providing anti-air cover. Its agility allows it to dodge torpedoes and close distance with enemy vessels, where its dual guns can deliver devastating broadsides. The Alligator's primary weakness is its moderate armor — while more durable than the Caiman, it cannot withstand sustained engagement with the Poseidon's siege missiles or the Viking's thermoelectric guns. It is most effective when used in wolf-packs of 2-3 units that can concentrate fire on individual targets.

#### Barracuda (梭鱼)

| Property | Value |
|----------|-------|
| **Production Building** | Shipyard |
| **Armor Class** | Defense Equipment II (Medium) |
| **Primary Weapon** | Vertical Missile Launch System (ground attack) |
| **Secondary Weapon** | Torpedoes (anti-ship) |
| **Primary Role** | Submarine Siege / Strategic Naval Asset |
| **Secondary Role** | Anti-Ship, Coastal Bombardment |
| **Stealth** | Invisible when submerged — cannot be detected by most units |
| **Special Abilities** | Can destroy enemy bases from coast; invisible when submerged; torpedoes threaten all warships |
| **Speed** | Medium |

The Barracuda is the Resistance's most strategically powerful naval unit and one of the most unique units in the entire game. As a submarine, it is invisible when submerged, making it undetectable by most units. Only the Confederation Viking (with its underwater detection system) and the Whirlwind helicopter (with its submarine detection) can reveal a submerged Barracuda. This stealth capability makes the Barracuda a terror on naval maps — it can approach enemy coastlines undetected, surface to launch vertical missiles at ground targets, and submerge again before the enemy can respond. The Barracuda's torpedoes threaten all warships, and its vertical missile launch system allows it to bombard enemy bases from the coast, making it a dual-threat strategic asset. The Barracuda is the naval equivalent of the Chameleon in terms of information denial — the mere possibility of a Barracuda being present forces the Confederation player to invest in Viking production and maintain naval patrols, diverting resources from other priorities. When a Barracuda is confirmed to be operating in an area, it can paralyze enemy naval movement and force defensive postures. The primary counter is aggressive Viking patrol and Whirlwind overwatch, but this requires constant attention and resource investment.

---

### Resistance Superweapon

#### Intercontinental Missile Launcher Tower (Nuclear Missile)

| Property | Value |
|----------|-------|
| **Production Building** | Intercontinental Missile Launcher Tower (Superweapon Building) |
| **Armor Class** | N/A (structure-based) |
| **Effect** | Launches a nuclear intercontinental ballistic missile at target area |
| **Charge Time** | Extended (several minutes) |
| **Damage** | Catastrophic — destroys virtually everything in the blast radius |
| **Area of Effect** | Massive radius |
| **VFX Scale** | s5 (largest effect scale in the game — nuclear explosion) |

The Resistance's superweapon is the Intercontinental Missile Launcher Tower, which fires a nuclear ICBM at a designated target area. The nuclear explosion is the most devastating single attack in the game, creating a massive blast radius that destroys virtually all units and structures caught within it. The VFX at scale s5 is the largest and most visually impressive effect in the entire game — a full nuclear explosion with mushroom cloud, shockwave, and radiation effects. Like the Confederation's Aerial Strike System, the nuclear launcher requires several minutes to charge, and the building itself is a high-priority target for the opponent. The strategic implications of the nuclear launcher are profound: it forces the enemy to either destroy the launcher before it fires or to spread their forces so widely that the nuclear strike cannot inflict decisive losses. The nuclear launcher is particularly effective against the Confederation's tendency to concentrate forces in powerful formations — a well-timed nuclear strike can eliminate an entire Zeus-led army. The Resistance must protect the launcher building carefully, as losing it after significant charge time represents a massive investment wasted.

---

## Hero Units

Hero units are powerful, unique units that require **Uranium** — a special resource — to produce. They are built at faction-specific hero production buildings: the **X-Facility** for the Confederation and the **Prototype Factory** for the Resistance. Heroes are tiered (T1, T2, T3), with higher tiers being more powerful but also more expensive. Hero units represent significant investments and can single-handedly turn the tide of battle when used correctly.

### Confederation Heroes

#### Cerberus (Tier 1)

| Property | Value |
|----------|-------|
| **Production Building** | X-Facility |
| **Armor Class** | Defense Equipment II (Medium) |
| **Primary Weapon** | Machine Gun |
| **Secondary Weapon** | Grenade |
| **Melee Weapon** | Knife Attacks |
| **Primary Role** | Ground Combat Hero |
| **Special Abilities** | Jump Jets — can leap across terrain and obstacles |
| **Tier** | 1 (Entry-level hero) |

Cerberus is the Confederation's entry-level hero unit, designed for aggressive ground combat. The jump jet ability allows Cerberus to traverse terrain obstacles, close distance rapidly, and escape unfavorable engagements — a mobility advantage that makes it difficult to pin down. In combat, Cerberus cycles between its machine gun (sustained anti-infantry fire), grenade (area damage against clustered enemies), and knife attacks (high burst damage in melee range). This combination makes Cerberus effective against all ground unit types, though it excels against infantry and light vehicles. As a T1 hero, Cerberus is relatively affordable in terms of Uranium cost and serves as the first hero most Confederation players will field. It is directly countered by the Resistance's Wolverine hero.

#### Seraphim (Tier 2)

| Property | Value |
|----------|-------|
| **Production Building** | X-Facility |
| **Armor Class** | Variable (air/ground modes) |
| **Primary Weapon** | Kara Weapon System |
| **Secondary Weapon** | Lazer Gun |
| **Primary Role** | Multi-Mode Combat Hero |
| **Special Abilities** | Switches between air and ground mode — can fly or fight on the ground |
| **Tier** | 2 |

Seraphim is a versatile T2 hero that can switch between air and ground combat modes. In air mode, Seraphim can fly over terrain and engage aerial targets with the Kara weapon system. In ground mode, it uses the lazer gun for powerful anti-armor damage. This dual-mode capability makes Seraphim one of the most flexible heroes in the game, able to respond to any tactical situation. The air mode is particularly useful for scouting, flanking, and engaging enemy aircraft, while the ground mode provides sustained damage output against armored targets. The mode-switching mechanic requires tactical awareness — switching modes takes time and leaves Seraphim briefly vulnerable. The Resistance counter to Seraphim is the Salamander hero.

#### Psion (Tier 2)

| Property | Value |
|----------|-------|
| **Production Building** | X-Facility |
| **Armor Class** | Defense Equipment II (Medium) |
| **Primary Weapon** | Psi-Energy Attacks |
| **Secondary Weapon** | Wave Attacks |
| **Primary Role** | Psionic Warfare Hero |
| **Special Abilities** | Active wave attack (directed psi-blast) and passive wave attack (pulsing area damage) |
| **Tier** | 2 |

Psion is the Confederation's psionic warfare hero, using psi-energy as its primary weapon system. Its active wave attack is a directed psi-blast that deals heavy damage to a specific target, while its passive wave attack creates a pulsing area-of-effect damage field around the Psion. This passive ability means that Psion is always dealing damage to nearby enemies, making it effective against clustered infantry and light vehicles. The active ability can be used to focus down high-value targets. Psion's combat profile favors engagement against groups of weaker units rather than one-on-one duels with heavy armor. Its VFX includes distinctive psi-energy visual effects with wave propagation animations.

#### Solaris (Tier 2)

| Property | Value |
|----------|-------|
| **Production Building** | X-Facility |
| **Armor Class** | Defense Equipment II (Medium) |
| **Primary Weapon** | Gun |
| **Secondary Weapon** | Impulse Attack |
| **Tertiary Weapon** | Lightning Attack |
| **Primary Role** | Speed-Based Combat Hero |
| **Special Abilities** | High-speed combat with multiple weapon systems |
| **Tier** | 2 |

Solaris is a speed-oriented T2 hero that combines rapid movement with a diverse arsenal of weapon systems. The gun provides consistent ranged damage, the impulse attack delivers a burst of kinetic energy, and the lightning attack chains between nearby enemies. This multi-weapon design makes Solaris effective against a wide range of targets, and its speed allows it to quickly reposition to engage the most threatening enemy units. The lightning attack's chain effect is particularly devastating against infantry formations and closely spaced enemy units.

#### Atlas (Tier 3)

| Property | Value |
|----------|-------|
| **Production Building** | X-Facility |
| **Armor Class** | Defense Equipment III (Heavy) |
| **Primary Weapon** | Barrage Weapon |
| **Secondary Weapon** | Gun |
| **Primary Role** | Heavy Combat Robot / Ultra-Durable Frontline Hero |
| **Special Abilities** | Passive shield that blocks incoming attacks — significant portion of incoming damage is absorbed |
| **Tier** | 3 |

Atlas is the Confederation's T3 heavy combat robot and one of the most durable units in the entire game. Its passive shield is a defining ability — it automatically blocks a significant portion of incoming attacks, making Atlas nearly unkillable in sustained combat. This shield is particularly effective against the Resistance Leviathan's auto-cannons, giving Atlas a direct counter relationship with that hero. In combat, Atlas uses its barrage weapon for area suppression and its gun for consistent damage output. As a T3 hero, Atlas requires a massive Uranium investment but can single-handedly hold a frontline against overwhelming enemy forces. The counter to Atlas is the Resistance Bison hero, which is specifically designed to defeat heavy armored targets.

#### Confozord (Tier 3)

| Property | Value |
|----------|-------|
| **Production Building** | X-Facility |
| **Armor Class** | Defense Equipment III (Heavy) |
| **Primary Weapon** | "The Ultimate Weapon of Retribution" — assembled super-unit |
| **Primary Role** | Superweapon Hero / Game-Ender |
| **Special Abilities** | Massive assembled super-unit — combination of multiple components |
| **Tier** | 3 (Ultimate) |

Confozord is the Confederation's ultimate hero unit — a massive assembled super-unit described as "The Ultimate Weapon of Retribution." The assembly mechanic suggests that Confozord may require multiple components or units to be combined, making it the most expensive and time-consuming hero to produce. When completed, Confozord is presumably the most powerful combat unit in the Confederation arsenal, capable of turning the tide of any engagement. The exact mechanics of Confozord's assembly and combat abilities are among the most closely guarded secrets in the game's meta, as few players have the resources and time to field this unit in competitive play.

---

### Resistance Heroes

#### Wolverine (Tier 1)

| Property | Value |
|----------|-------|
| **Production Building** | Prototype Factory |
| **Armor Class** | Defense Equipment II (Medium) |
| **Primary Weapon** | Machine Gun with Acceleration |
| **Primary Role** | Ground Combat Hero / Cerberus Counter |
| **Special Abilities** | Weapon acceleration — increases fire rate over time; specifically designed to counter Cerberus |
| **Tier** | 1 (Entry-level hero) |

Wolverine is the Resistance's T1 hero and the direct counter to the Confederation's Cerberus. Its machine gun features an acceleration mechanic that increases fire rate over time, meaning the longer Wolverine stays in combat, the more damage it outputs. This ramping damage profile makes Wolverine exceptionally dangerous in sustained engagements, as its DPS increases continuously. Against Cerberus, Wolverine's acceleration allows it to outpace Cerberus's damage output in extended fights. The tactical implication is that Wolverine should be committed to fights rather than used for hit-and-run tactics — retreating resets the acceleration bonus.

#### Bison (Tier 3)

| Property | Value |
|----------|-------|
| **Production Building** | Prototype Factory |
| **Armor Class** | Defense Equipment III (Heavy) |
| **Primary Role** | Heavy Assault Hero / Anti-Hero Specialist |
| **Special Abilities** | Can defeat Leviathan and Atlas in direct combat — specifically designed as anti-heavy-hero counter |
| **Tier** | 3 |

Bison is the Resistance's T3 anti-hero specialist, explicitly designed to defeat the game's heaviest hero units. Its ability to defeat both Leviathan (the Resistance's own T3 hero) and Atlas (the Confederation's T3 heavy robot) in direct combat makes it the ultimate hero-killer. Bison's combat profile prioritizes raw damage against high-armor targets, likely featuring armor-piercing or shield-breaking abilities that negate the defensive advantages of T3 heroes. In the meta, Bison serves as a hard counter to any hero-centric strategy, forcing opponents to support their heroes with conventional units rather than relying on hero-unit dominance.

#### Leviathan (Tier 3)

| Property | Value |
|----------|-------|
| **Production Building** | Prototype Factory |
| **Armor Class** | Defense Equipment III (Heavy) |
| **Primary Weapon** | Main Auto-Cannons |
| **Secondary Weapons** | Air Arms, Nuclear Arms, Ground Arms |
| **Primary Role** | Tri-Domain Super Hero |
| **Special Abilities** | Operates in air, ground, and nuclear strike modes; countered by Atlas' passive shield |
| **Tier** | 3 |

Leviathan is the Resistance's most versatile T3 hero, capable of operating across all three combat domains — air, ground, and nuclear strike. Its main auto-cannons provide consistent damage, while its air arms, nuclear arms, and ground arms give it engagement options against virtually any target type. This makes Leviathan one of the most flexible heroes in the game. However, it has a critical counter relationship with the Confederation's Atlas — Atlas's passive shield specifically negates Leviathan's auto-cannon damage, making the otherwise devastating Leviathan ineffective in direct combat against Atlas. This counter relationship means that the Resistance player must protect their Leviathan from Atlas using other units like Bison, while the Confederation player will try to position Atlas to intercept the Leviathan.

#### Salamander (Tier 2/T3)

| Property | Value |
|----------|-------|
| **Production Building** | Prototype Factory |
| **Armor Class** | Defense Equipment II-III |
| **Primary Weapon** | Deadly Missiles |
| **Primary Role** | Anti-Air Hero / Seraphim Counter |
| **Special Abilities** | Launches deadly missiles; specifically designed to counter Seraphim |
| **Tier** | 2/T3 |

Salamander is the Resistance's missile-focused hero, designed primarily as a counter to the Confederation's Seraphim. Its deadly missiles can track and destroy both aerial and ground targets, making it particularly effective against Seraphim's air mode. Salamander's missile armament also makes it effective against conventional aircraft and vehicles, giving it broad utility beyond its anti-hero role. The tier classification is uncertain (T2 or T3), suggesting it may be a high-T2 or low-T3 unit depending on balance considerations.

---

### Other Hero Units (VFX-derived)

These hero units are identified from the game's VFX asset catalog rather than from explicit unit descriptions. Their exact roles and mechanics are inferred from their named abilities and visual effects.

#### Coiltank

| Property | Value |
|----------|-------|
| **Identified Abilities** | Chain Lightning, Ball Attack, Nova Attack, Electrodes |
| **Inferred Role** | Electric/AoE damage dealer |
| **Inferred Faction** | Unknown (electric effects suggest Confederation technology) |

Coiltank appears to be an electricity-themed hero with chain lightning (bouncing between targets), ball attack (projectile), nova attack (point-blank area burst), and electrode deployment (stationary area denial). The chain lightning suggests strong anti-infantry capability, while the nova and electrode abilities provide area control.

#### Cryotank

| Property | Value |
|----------|-------|
| **Identified Abilities** | Frost Bomb, Gun, Nova |
| **Inferred Role** | Cryogenic control/damage hero |
| **Inferred Faction** | Unknown (ice effects could fit either faction) |

Cryotank uses cryogenic weaponry including frost bombs (area slow/damage), a standard gun, and a freezing nova (point-blank area freeze/damage). The frost effects likely slow or immobilize enemies, providing crowd control that synergizes with damage-focused allies.

#### Gatling

| Property | Value |
|----------|-------|
| **Identified Abilities** | Explosive, Gun, Smoke Aura |
| **Inferred Role** | Sustained fire / area denial hero |
| **Inferred Faction** | Unknown |

Gatling appears to be a rapid-fire hero with explosive rounds, a standard gun, and a smoke aura that likely reduces enemy accuracy in an area around the unit. The smoke aura would synergize with the Resistance's existing smoke grenade mechanics.

#### Railgun

| Property | Value |
|----------|-------|
| **Identified Abilities** | March Mode, Quake Mode, Siege Mode |
| **Inferred Role** | Multi-mode artillery/assault hero |
| **Inferred Faction** | Unknown |

Railgun is a multi-mode hero with three distinct configurations: March Mode (mobile, fires while moving), Quake Mode (area seismic damage), and Siege Mode (stationary, maximum damage output). This three-mode design makes Railgun one of the most tactically complex heroes.

#### Beholder

| Property | Value |
|----------|-------|
| **Identified Abilities** | Lazer, Scanner |
| **Inferred Role** | Reconnaissance / precision strike hero |
| **Inferred Faction** | Unknown (scanner suggests intelligence role) |

Beholder combines a laser weapon with a scanning ability, suggesting a reconnaissance-strike hero that can detect hidden units (counter to Chameleon fog and jungle stealth) and eliminate them with precision laser fire.

#### Wasp

| Property | Value |
|----------|-------|
| **Identified Abilities** | Acid, Rocket, Aura |
| **Inferred Role** | Flying damage hero |
| **Inferred Faction** | Unknown (flying unit based on name and ability set) |

Wasp appears to be a flying hero unit with acid (damage-over-time), rocket (burst damage), and an aura (passive area effect). The flying designation makes Wasp the only confirmed flying hero, giving it unique tactical flexibility.

#### Codomash

| Property | Value |
|----------|-------|
| **Identified Abilities** | Turret Deployment (active/passive) |
| **Inferred Role** | Engineer / area control hero |
| **Inferred Faction** | Unknown |

Codomash is an engineer-style hero that can deploy turrets with both active and passive modes. This suggests a defensive area-control playstyle where Codomash fortifies positions with automated turrets that can switch between active (aggressive) and passive (defensive) modes.

---

## Faction Comparison Matrix

### Infantry Comparison

| Role | Confederation | Resistance | Advantage |
|------|:---:|:---:|:---:|
| Anti-Infantry | Assault Trooper | Rifleman | Resistance (stealth + smoke) |
| Anti-Armor | Heavy Assault Trooper | Grenadier | Resistance (jungle ambush) |
| Specialist | Firepower Assault Trooper | Sniper | Draw (jetpack vs. range) |

### Vehicle Comparison

| Role | Confederation | Resistance | Advantage |
|------|:---:|:---:|:---:|
| Support | Fortress | — | Confederation |
| Light Tank | Warhammer | Prairie Wolf | Draw (combat vs. speed) |
| Medium Tank | — | Armadillo | Resistance (versatility) |
| Heavy Tank | Zeus | Jaguar (Siege) | Confederation (raw power) |
| Fast Skirmisher | Warhammer | Jaguar (Travel) | Resistance (mode flexibility) |

### Special Vehicle Comparison

| Role | Confederation | Resistance | Advantage |
|------|:---:|:---:|:---:|
| Anti-Air | Hurricane | Porcupine | Resistance (omnidirectional) |
| Artillery | Torrent | Mammoth | Draw (similar role) |
| Support | Energy Shield | Chameleon | Draw (different roles) |

### Aviation Comparison

| Role | Confederation | Resistance | Advantage |
|------|:---:|:---:|:---:|
| Recon Helicopter | Whirlwind | Dragonfly | Confederation (sub detection) |
| Fighter | Vertex | Hawk | Draw (maneuver vs. versatility) |
| Bomber | Thor | Albatross | Resistance (durability) |

### Navy Comparison

| Role | Confederation | Resistance | Advantage |
|------|:---:|:---:|:---:|
| Fast Attack | Delta | Caiman | Resistance (naval mines) |
| Surface Combat | Viking | Alligator | Draw (anti-sub vs. agility) |
| Strategic | Poseidon | Barracuda | Resistance (stealth) |

---

## Unit Counters & Synergies

### Confederation Key Counters

| Threat | Primary Counter | Secondary Counter |
|--------|----------------|-------------------|
| Resistance infantry in jungle | Firepower Assault Trooper (jetpack) | Fortress (flamethrower flush) |
| Jaguar in Siege Mode | Vertex / Thor (air strike) | Zeus (frontal engagement) |
| Chameleon fog barrier | Whirlwind (scout into fog) | Torrent (blind barrage) |
| Barracuda submarine | Viking (detection + torpedoes) | Whirlwind (detection) |
| Sniper at range | Firepower Assault Trooper (jetpack close) | Energy Shield (armor buff) |
| Nuclear Launcher | Thor (bombing run) | Aerial Strike System (preemptive) |
| Albatross bomber | Hurricane (deployed) | Multiple anti-air units |

### Resistance Key Counters

| Threat | Primary Counter | Secondary Counter |
|--------|----------------|-------------------|
| Zeus heavy tank | Jaguar (Siege Mode) | Grenadier (jungle ambush) |
| Thor bomber | Hawk (intercept) | Porcupine (anti-air) |
| Energy Shield formation | Sniper (weak point hits) | Chameleon (conceal approach) |
| Hurricane (deployed) | Albatross (tank missiles) | Jaguar (Travel Mode flank) |
| Torrent artillery | Prairie Wolf (fast flank) | Sniper (long-range pick) |
| Aerial Strike System | Nuclear Launcher (race) | Albatross (destroy building) |
| Fortress + infantry formation | Grenadier (jungle ambush) | Mammoth (artillery barrage) |

### Key Synergies

| Synergy | Description |
|---------|-------------|
| **Chameleon + Snipers** | Fog barrier conceals Snipers who pick off enemies approaching the fog edge |
| **Chameleon + Mammoth** | Hidden artillery position — enemy cannot locate the source of bombardment |
| **Energy Shield + Zeus** | Shielded Zeus becomes nearly unkillable during push |
| **Rifleman Smoke + Sniper** | Smoke reduces enemy accuracy, allowing Snipers to fire with impunity |
| **Armadillo Mines + Jaguar** | Mines slow/damage approaching enemy, Jaguars clean up weakened targets |
| **Whirlwind + Viking** | Helicopter spots subs, Viking hunts them — complete anti-submarine team |
| **Porcupine + Jaguar** | Porcupine provides anti-air cover, Jaguar provides ground firepower |
| **Caiman Mines + Barracuda** | Mines channel enemy ships into Barracuda's torpedo range |
| **Fortress + Heavy Assault Trooper** | Fortress absorbs damage and detects mines, HAT destroys armor |
| **Warhammer Pack + Vertex** | Warhammers flank, Vertex eliminates anti-air, combined push |

---

*This document is part of the Art of War 3: Global Conflict reverse-engineering documentation suite. For building information, see [Buildings.md](Buildings.md). For gameplay systems, see [Gameplay_Analysis.md](Gameplay_Analysis.md).*
