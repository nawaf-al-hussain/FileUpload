# Art of War 3: Game Runtime Flow

## 1. Game Launch Sequence

```
┌─────────────────────────────────────────────────────────────┐
│                     GAME LAUNCH                              │
│                                                              │
│  1. Android OS launches com.geargames.aow                    │
│  2. Unity Player Activity starts                             │
│  3. IL2CPP Runtime initializes                               │
│  4. Unity Engine loads first scene                           │
│  5. Addressables catalog loads (catalog.json, 773 entries)   │
│  6. Built-in shaders bundle loads                            │
│  7. Default local group assets load                          │
│  8. Platform SDKs initialize:                                │
│     ├── Firebase (Analytics, Crashlytics, Messaging)         │
│     ├── Google Play Services                                 │
│     ├── AppLovin MAX / IronSource (Ads)                      │
│     ├── AppMetrica (Analytics)                               │
│     ├── Adjust (Attribution)                                  │
│     └── TenjinSDK (Analytics)                                │
│  9. StartupManager runs initialization                       │
│ 10. Transition to Logon Scene                                │
└─────────────────────────────────────────────────────────────┘
```

---

## 2. Login Process

```
┌──────────────┐    LoginRequest     ┌──────────────┐
│   Client     │ ──────────────────► │  Main Server │
│              │ ◄────────────────── │              │
│              │    LoginAnswer      │              │
└──────┬───────┘                     └──────────────┘
       │
       ├── New User Path:
       │   ├── RegistrationRequest → RegistrationAnswer
       │   ├── Faction Selection (GUILogonSelectFractionPanel)
       │   │   ├── Confederation (Alliance Army)
       │   │   └── Resistance (Rebellion Army)
       │   ├── GiveStartPackRequest → GiveStartPackAnswer
       │   └── Tutorial Missions (First 6 missions)
       │
       ├── Returning User Path:
       │   ├── SessionRestoreRequest → SessionRestoreAnswer
       │   ├── ResourceRequest → ResourceAnswer (sync state)
       │   └── ReadyToActRequest → ReadyToActAnswer
       │
       ├── Version Check:
       │   ├── Current Version → Continue
       │   └── Outdated Version → GoToUpdateClient
       │
       └── Connection Check:
           ├── ConnectionCheckRequest → ConnectionCheckAnswer
           └── If Failed → GoToRelogin

After Login:
├── Profile Data Sync (Level, Credits, Upgrades, Skills, Hero Info)
├── Chat Room Auto-Join (Fraction, Country, Language)
├── Clan Data Load (if member)
├── Resource Warming (Addressables pre-load)
└── Transition to Main Scene
```

---

## 3. Main Menu Flow

```
┌─────────────────────────────────────────────────┐
│                  MAIN SCENE                      │
│                                                  │
│  ┌─────────┐ ┌─────────┐ ┌─────────┐           │
│  │ Workshop │ │  Clan   │ │  Chat   │           │
│  │(Upgrades)│ │(WorldWar)│ │(7 rooms)│           │
│  └─────────┘ └─────────┘ └─────────┘           │
│  ┌─────────┐ ┌─────────┐ ┌─────────┐           │
│  │ Rating  │ │ Profile │ │  Store  │           │
│  │(Leaderbd)│ │(Achieve)│ │(Billing)│           │
│  └─────────┘ └─────────┘ └─────────┘           │
│  ┌─────────┐ ┌─────────┐ ┌─────────┐           │
│  │Skills   │ │Modific. │ │ Supply  │           │
│  │(Commandr)│ │(UnitMod)│ │(Box/Ads)│           │
│  └─────────┘ └─────────┘ └─────────┘           │
│                                                  │
│  ┌──────────────────────────────────┐            │
│  │         BATTLE BUTTON            │            │
│  │  ReadyToBattleRequest → Match    │            │
│  └──────────────────────────────────┘            │
└─────────────────────────────────────────────────┘
```

---

## 4. Match Creation Flow

### 4.1 PvP 1v1 Matching

```
Player clicks "Battle"
    │
    ▼
ReadyToBattleRequest
    │
    ▼
Server-Side Matching:
├── Evaluate: Skill Level, Rank, Stars, Win Rate
├── Evaluate: Connection Quality
├── Select Optimal Server Region
│
▼
MatchingIsFinished
    │
    ▼
GoToBattleNotification (or BattleButtonStateNotification)
    │
    ▼
AppointStartMessage → ClientGoToBattleNotification
    │
    ▼
Transition to BattleLoading Scene
```

### 4.2 2v2 Co-op Matching

```
Player creates or joins Lobby
├── LobbyCreateRequest → LobbyCreateAnswer
├── LobbyOutcomeInviteRequest (invite partner)
├── Partner receives LobbyIncomeInviteNotification
├── Partner confirms: LobbyIncomeInviteConfirmRequest
│
▼
LobbyBattleStartRequest
    │
    ▼
Server matches against another 2-player team
    │
    ▼
GoToBattleNotification
    │
    ▼
Transition to BattleLoading Scene
```

### 4.3 Tournament Matching

```
Player joins Tournament:
├── JoinCompetitionRequest → JoinCompetitionAnswer
├── Server evaluates TourMatchingCondition
├── Matches based on current tournament winrate only
│
▼
Matching → Battle (same flow as PvP)
```

---

## 5. Match Loading Flow

```
┌───────────────────────────────────────────────────┐
│              BATTLE LOADING SCENE                  │
│                                                    │
│  1. LoginToBattleRequest → LoginToBattleAnswer     │
│     ├── Battle Server Connection Established       │
│     ├── Battle Connect Settings Received           │
│     └── Player Slot Assigned                      │
│                                                    │
│  2. Asset Loading (Addressables)                   │
│     ├── Map Bundle (selected map prefab)           │
│     ├── Minimap Bundle                             │
│     ├── VFX Bundle (explosions, fire, bullets)     │
│     ├── Decoration Bundle (biome-specific)         │
│     ├── Unit Prefabs (faction-specific models)     │
│     └── Building Prefabs (3 levels per building)   │
│                                                    │
│  3. Network Synchronization                        │
│     ├── BattleLoadProgressRequest/Answer           │
│     ├── BattleLoadProgressNotification (opponent)  │
│     ├── CheckConnectionToBattleHosts               │
│     └── Both sides loaded → Start                  │
│                                                    │
│  4. Battle Initialization                           │
│     ├── InitializeBattlePoolsOptimized()           │
│     ├── Map terrain generation                     │
│     ├── Starting position assignment               │
│     ├── Initial entities spawned                   │
│     │   ├── Headquarters (level 1)                 │
│     │   ├── Construction Yard                      │
│     │   └── Initial Supply/Power                   │
│     ├── AI/GAI systems initialized                 │
│     ├── Fog of war initialized                     │
│     └── Audio systems started                      │
│                                                    │
│  5. Transition to Battle Scene                     │
└───────────────────────────────────────────────────┘
```

---

## 6. Gameplay Loop

```
┌─────────────────────────────────────────────────────────────┐
│                    MAIN GAMEPLAY LOOP                         │
│                                                               │
│  ┌──────────────────────────────────────────────────────┐    │
│  │                  TICK-BASED SIMULATION                │    │
│  │                                                      │    │
│  │  Each Tick:                                          │    │
│  │  1. Process Network Commands (from server)           │    │
│  │  2. Process Local Player Commands                    │    │
│  │  3. Update Unit AI (targeting, movement, combat)     │    │
│  │  4. Update Bullet Physics (movement, collision)      │    │
│  │  5. Update Building Production Queues                │    │
│  │  6. Update Resource Generation                      │    │
│  │  7. Update Ability Cooldowns                         │    │
│  │  8. Update Superweapon Charge                        │    │
│  │  9. Check Win/Loss Conditions                        │    │
│  │  10. Sync State to Rendering                         │    │
│  │  11. Send Client Actions to Server                   │    │
│  └──────────────────────────────────────────────────────┘    │
│                                                               │
│  Player Actions:                                              │
│  ├── Select Unit(s) (Tap / Rectangle / Polygon Selection)    │
│  ├── Move Command (Right-click / Tap target)                  │
│  ├── Attack Command (Target enemy)                            │
│  ├── Patrol Command                                           │
│  ├── Build Structure (Construction Yard placement)            │
│  ├── Train Units (Barracks/Factory/Airport/Shipyard)         │
│  ├── Research/Upgrade (Workshop during battle)                │
│  ├── Use Ability (Hero active ability)                        │
│  ├── Activate Superweapon                                     │
│  ├── Set Rally Point                                          │
│  └── Collect Supply Crates                                    │
│                                                               │
│  Resource Loop:                                               │
│  Supply Center → Generates Supplies (continuous)              │
│  Power Plant → Provides Power Capacity (static)               │
│  Supply Crates → Bonus Resources (map pickups)                │
│  Resources → Build Buildings → More Resources → Train Units   │
│                                                               │
│  Combat Loop:                                                 │
│  Unit Acquires Target → Weapon Fires → Bullet Travels        │
│  → Impact → Damage Calculation (armor type) → HP Reduction   │
│  → Unit Death / Building Destruction → Experience/Rewards     │
└─────────────────────────────────────────────────────────────┘
```

---

## 7. Network Synchronization Flow

```
┌──────────┐         ┌──────────┐         ┌──────────┐
│  Client  │         │  Server  │         │  Client  │
│  (P1)    │         │          │         │  (P2)    │
└────┬─────┘         └────┬─────┘         └────┬─────┘
     │                    │                    │
     │ Player Action      │                    │
     │ (Move, Attack,     │                    │
     │  Build, etc.)      │                    │
     ├───────────────────►│                    │
     │                    │ Validate Action    │
     │                    │ Update Game State  │
     │                    │ Broadcast State    │
     │                    ├───────────────────►│
     │                    │                    │
     │ State Update       │                    │
     │◄───────────────────┤                    │
     │                    │                    │
     │ PeriodicTimeSync   │                    │
     ├───────────────────►│                    │
     │ TimeSyncAnswer     │                    │
     │◄───────────────────┤                    │
     │                    │                    │
     │ Ping (keepalive)   │                    │
     ├───────────────────►│                    │
     │ Pong               │                    │
     │◄───────────────────┤                    │
     │                    │                    │
     
Desync Detection:
├── PeriodicTimeSynchronizationUpdate
├── BattleRunCheckerWaitMessage
├── PrepareDesyncButton (debug tool)
└── ClientPausedNotification / ClientResumeNotification
```

---

## 8. Save/Update Operations

```
During Battle:
├── Auto-save battle state (for session restore)
├── BattleLoadProgress periodic sync
└── ClientPausedNotification (app backgrounded)

After Battle:
├── ReturnFromBattleRequest → ReturnFromBattleAnswer
├── BattleResultRequest → BattleResultAnswer
├── Update Profile:
│   ├── SetExperience (XP gained)
│   ├── SetProfileCredits (credits earned)
│   ├── SetStars (rating change)
│   ├── SetSkillPoints (if won)
│   └── SetHeroInfo (hero battle stats)
├── Update Quest Progress
├── Update Achievement Progress
├── Update Career Progression
└── Resource Cleanup

Between Battles:
├── Upgrade Processing:
│   ├── StartUpgradeRequest → StartUpgradeAnswer
│   ├── UpgradeNotification (timer started)
│   ├── AccelerateUpgradeRequest (premium)
│   ├── CompleteActiveUpgradeRequest (timer done)
│   └── SpeedUpActiveUpgradeRequest (speed up)
├── Workshop State Persistence
├── Commander Skill Changes:
│   └── SkillUpgradeRequest → SkillUpgradeAnswer
└── Profile State Auto-sync
```

---

## 9. Match Completion Flow

```
Win/Loss Condition Met
    │
    ▼
BattleFinishNotification (from server)
    │
    ▼
Battle Result Processing:
├── Calculate Battle Statistics
│   ├── Units Killed / Lost
│   ├── Buildings Destroyed / Lost
│   ├── Resources Gathered / Spent
│   ├── Time Elapsed
│   └── Superweapon Usage
│
├── Calculate Rewards:
│   ├── Experience Points
│   ├── Credits
│   ├── Skill Points (win only)
│   ├── Stars (rating change)
│   ├── Quest Progress
│   └── Achievement Progress
│
├── Show Battle Results Screen:
│   ├── Victory/Defeat Animation
│   ├── Score Board
│   ├── Rewards Summary
│   └── Rating Change
│
├── Transition to BattleLogout Scene
│
├── ReturnFromBattleRequest
│
└── Return to Main Scene
    ├── Profile Updated
    ├── Upgrade Timers Continue
    └── Ready for Next Battle
```

---

## 10. Disconnection/Reconnection Flow

```
Connection Lost During Battle:
    │
    ▼
Client detects disconnection
    │
    ├── Option A: Auto-Reconnect
    │   ├── Ping/Pong keepalive fails
    │   ├── Attempt reconnection to battle server
    │   ├── BattleSessionRestoreRequest → BattleSessionRestoreAnswer
    │   └── Resume battle from last synchronized state
    │
    ├── Option B: Battle Resumption
    │   ├── UpdateResumptionBattleActivityCoroutine
    │   ├── WaitingResumptionBattle state
    │   └── UpdateAllBattleResources on resume
    │
    └── Option C: Permanent Disconnect
        ├── ServerIsFinishingItsWork notification
        ├── Battle counted as loss
        └── Return to Main Scene

Connection Lost in Main Scene:
    │
    ▼
GoToRelogin
    │
    ▼
Re-authenticate
    ├── SessionRestoreRequest
    └── Resume from last known state
```
