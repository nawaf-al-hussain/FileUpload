# Art of War 3: Architecture Dependency Graph

## 1. System Overview

Art of War 3: Global Conflict is a Unity 3D mobile RTS game using the IL2CPP scripting backend (metadata version 31). The architecture follows a domain-driven design pattern with clear separation between the game client, network layer, and server infrastructure. The game is built on a client-server model requiring a persistent internet connection, with the client handling rendering, input, and simulation while the server manages authentication, matchmaking, state persistence, and battle arbitration.

The codebase consists of 29,334 types across 141 custom assemblies with 140,824 methods. The primary game logic resides in two key assemblies: `ScriptsAssembly.dll` (core game systems, battle logic, entities) and `Assembly-CSharp.dll` (Unity scene management, plugins). The architecture uses Zenject (dependency injection), UniTask (async/await), UniRx/R3 (reactive extensions), and Unity Addressables for asset management.

---

## 2. Core Entry Points

### Application Lifecycle
| Entry Point | Responsibility |
|------------|---------------|
| `AOW_Assets.Scripts.Startup.Scripts.Managers.StartupManager` | Application bootstrap, initialization sequence |
| `AOW_Assets.Scripts.Startup.Scripts.Managers.StartupSettings` | Startup configuration parameters |
| `com.geargames.aow.scenes.AOWAddressables` | Addressable asset system initialization |
| `AndroidManifest.xml` → `com.geargames.aow.UnityPlayerActivity` | Android entry point |

### Scene Entry Points
| Scene | Entry Class | Purpose |
|-------|------------|---------|
| Startup | `StartupManager` | Boot, asset warmup, platform init |
| Logon | `com.geargames.aow.scenes.logon.*` | Authentication, server selection, faction choice |
| Main | `com.geargames.aow.scenes.main.*` | Hub: workshop, clan, chat, lobby, store |
| Battle | `com.geargames.aow.scenes.battle.BattleScreen` | Real-time RTS gameplay |
| BattleLoading | `com.geargames.aow.scenes.battleloading.*` | Asset loading, connection establishment |
| BattleLogout | `com.geargames.aow.scenes.battlelogout.*` | Post-battle cleanup and results |

---

## 3. Initialization Sequence

```
1. Android OS → UnityPlayerActivity
2. Unity Engine → IL2CPP Runtime Initialization
3. StartupManager.Initialize()
   ├── Load Addressables Catalog
   ├── Initialize Zenject Containers
   ├── Platform SDK Init (Firebase, Ads, Analytics)
   ├── Check Client Version → GoToUpdateClient (if outdated)
   ├── Connect to Main Server
   └── Session Restore or Login Flow
4. Logon Scene
   ├── LoginRequest → LoginAnswer
   ├── RegistrationRequest → RegistrationAnswer (new users)
   ├── SessionRestoreRequest → SessionRestoreAnswer (returning)
   ├── Faction Selection (GUILogonSelectFractionPanel)
   ├── Download Battle Assets (Addressables)
   └── Transition to Main Scene
5. Main Scene
   ├── Load Player Profile (Account, Upgrades, Skills)
   ├── Initialize Chat System (Multiple Rooms)
   ├── Initialize Clan System
   ├── Warm Resources (Addressables pre-loading)
   └── Ready for Battle
```

---

## 4. Major System Dependency Map

```
┌─────────────────────────────────────────────────────────┐
│                    APPLICATION LAYER                     │
│  StartupManager → Zenject Container → Scene Manager     │
└──────────────────────┬──────────────────────────────────┘
                       │
        ┌──────────────┼──────────────────┐
        ▼              ▼                  ▼
┌──────────────┐ ┌───────────────┐ ┌──────────────┐
│  LOGON/MAIN  │ │    BATTLE     │ │   SERVICES   │
│   SYSTEMS    │ │   SYSTEMS     │ │              │
│──────────────│ │───────────────│ │──────────────│
│ Auth         │ │ BattleScreen  │ │ Ads          │
│ Profile      │ │ LogicService  │ │ Billing      │
│ Chat         │ │ Map/AI/GAI    │ │ Analytics    │
│ Clan         │ │ Entities      │ │ Firebase     │
│ Workshop     │ │ GUI           │ │ Resources    │
│ Lobby        │ │ Network       │ │ Vibro        │
│ Rating       │ │ Effects       │ │ FeatureToggle│
│ Competition  │ │ Audio         │ │ Notifications│
└──────┬───────┘ └──────┬────────┘ └──────┬───────┘
       │                │                  │
       └────────────────┼──────────────────┘
                        ▼
        ┌───────────────────────────────┐
        │        DOMAIN LAYER           │
        │───────────────────────────────│
        │ Account │ Campaign │ Career   │
        │ Skills  │ Workshop │ Rating   │
        │ Chat    │ Clan     │ Comp.    │
        │ PlayerResources │ UiMgmt     │
        │ Tutorial │ ReleaseMgmt        │
        └───────────────┬───────────────┘
                        ▼
        ┌───────────────────────────────┐
        │      NETWORK LAYER            │
        │───────────────────────────────│
        │ Main Server Connection        │
        │ Battle Server Connection      │
        │ Message Serialization         │
        │ RSA/DES Encryption            │
        │ Time Synchronization          │
        │ Ping/Pong Keepalive           │
        └───────────────┬───────────────┘
                        ▼
        ┌───────────────────────────────┐
        │      PERSISTENCE LAYER        │
        │───────────────────────────────│
        │ SQLite Local Database         │
        │ PlayerPrefs / Settings        │
        │ Addressables Cache            │
        │ Resource Dispatcher Cache     │
        └───────────────────────────────┘
```

---

## 5. System-by-System Dependencies

### 5.1 Battle System

The battle system is the most complex subsystem, encompassing simulation, rendering, networking, AI, and user interaction.

**Key Classes and Dependencies:**

| Class | Purpose | Dependencies |
|-------|---------|-------------|
| `BattleScreen` | Main battle scene controller | LogicService, ClientBattleContext, BattleGUI, BattleEffects |
| `ClientBattleContext` | Battle state container | ClientUnitHelper, ClientBuildingHelper, ClientMineHelper |
| `LogicService` | Core simulation tick | Commands, Entities, AI, Map |
| `ClientUnitHelper` | Unit management | ClientUnitPrefabs, EntityDictionary |
| `ClientBuildingHelper` | Building management | ClientBuildingPrefabs, Construction logic |
| `ClientMineHelper` | Mine system | ClientMinePrefabs, ClientMineSurfaces |
| `BattleGUI` | Battle interface | UnitSelection, BuildingSet, Cards, Minimap, Boosts |
| `BattleEffects` | VFX system | BattleEffectsMaterialInstantiator, FlashPrefabCreator |

**Data Flow:**
```
Player Input → Input/Gesture Handlers → LogicService.Commands
    → Entity Updates → Rendering System
    → Network Layer → Server Validation
    → State Replication → Client Update
```

### 5.2 Entity Component System

Entities in battle use a component-based architecture:

| Component | Purpose |
|-----------|---------|
| `LinearBulletEngine` | Straight-line projectile movement |
| `BallisticBulletEngine` | Arc trajectory projectile |
| `AdjustableBallisticBulletEngine` | Variable arc trajectory |
| `SelfDirectedBulletEngine` | Homing missile behavior |
| `ChainLightingBulletEngine` | Chain lightning weapon effect |
| `AuraEffectController` | Aura buff/debuff application |
| `ShieldEmitPrefabSettings` | Energy shield visual setup |
| `FoggerEmitPrefabSettings` | Fog barrier (Chameleon) setup |
| `BulletPrefabSettings` | Projectile visual configuration |
| `ModelBulletPrefabSettings` | 3D model projectile setup |
| `PsiTankBulletSettings` | Psi-energy attack configuration |
| `GatlingDeathEffectController` | Gatling spinning death animation |

### 5.3 Network System

The network layer manages two distinct connections: a persistent main server connection and ephemeral battle server connections.

**Main Server Connection:**
- Persistent TCP/WebSocket connection
- Handles: Auth, Profile, Chat, Clan, Workshop, Lobby, Matchmaking
- Messages use Request/Answer pattern with optional Notifications
- Encryption: RSA/DES for sensitive operations

**Battle Server Connection:**
- Established per-match via `LoginToBattleRequest`
- Handles: Commands, State Sync, Time Sync, Battle Results
- Tick-based synchronization with `PeriodicTimeSynchronizationUpdate`
- Disconnection handling via `BattleSessionRestore`

**Message Categories (189+ message types):**
| Category | Count | Key Messages |
|----------|-------|-------------|
| Authentication | 8 | Login, Registration, Session Restore, Choose Profile |
| Battle | 16 | Start, Finish, Load Progress, Results, Replay, Logout |
| Lobby | 22 | Create, Start, Invite, Change Mission, Cancel Matching |
| Profile | 18 | Set Level, Credits, Upgrade, Tokens, Stars, Skills, Hero Info |
| Upgrade | 8 | Start, Accelerate, Cancel, Complete, Speed Up |
| Clan | 40+ | Create, Leave, Change, History, Call, Battle List, World War |
| Chat | 50+ | Join/Leave/Post per room type (7 room types) |
| Competition | 25+ | Join, Cancel, Config, Hall of Fame, Battle Pass, Coop |
| Special | 6 | AddEntity, ChangeEntity, DeleteEntity, RSA/DES Packet |

### 5.4 AI System

The AI system operates at multiple levels:

| System | Namespace | Purpose |
|--------|-----------|---------|
| Campaign AI | `com.geargames.aow.scenes.battle.map.ai` | Mission-based scripted AI |
| Skirmish AI | `com.geargames.aow.scenes.battle.map.gai` | General AI for PvP/PvE opponents |
| Unit AI | `com.geargames.aow.scenes.battle.map.gai.commands` | Individual unit behavior (targeting, movement) |
| Bot AI | `com.geargames.aow.entities.battle.bot` | Automated player behavior |
| AI Communication | `com.geargames.aow.entities.battle.aicomm` | Inter-AI coordination messages |

### 5.5 Resource/Asset Loading System

The game uses Unity Addressables for on-demand asset loading with a sophisticated resource dispatch system:

| Component | Purpose |
|-----------|---------|
| `GGAddressablesRuntimeAssembly` | Addressables wrapper |
| `AbstractResourceLoader` / `AbstractResourceLoaderAsync` | Base resource loading |
| `ByteResourceLoaderAsync` | Raw byte data loading |
| `CachedResources` / `CachedResourceInfo` | Resource caching layer |
| `ClientResourceDispatchrerProxyAssembly` | Resource dispatch proxy |
| `DispatcherResources` | Download conditions, progress, adapters, checkers |

**Asset Bundle Groups:**
| Bundle Group | Contents | Load Timing |
|-------------|----------|------------|
| Built-in Shaders | Unity built-in shaders | Startup |
| Maps (8 maps) | Map prefabs, terrain, decorations | Battle loading |
| Minimaps | Minimap textures per map | Battle loading |
| VFX | All particle effects and explosions | Battle loading |
| Decorations (Common) | Shared decorations | Battle loading |
| Decorations (Desert) | Desert biome objects | Battle loading |
| Decorations (Jungle) | Jungle biome objects | Battle loading |
| Default Local Group | Core UI and scene assets | Startup |

### 5.6 Workshop (Meta-Progression) System

The Workshop system manages persistent upgrades between battles:

| Component | Namespace | Purpose |
|-----------|-----------|---------|
| `WorkshopNavigator` | `Domains.Workshop` | UI navigation between sections |
| `PrototypeModel` | `Domains.Workshop.Api` | Unit/building prototype data |
| `PrototypeUpgradeModel` | `Domains.Workshop.Models` | Upgrade slot and level tracking |
| `WeaponStatsFactory` | `Domains.Workshop.Impl.Models.Weapon` | Weapon stat calculation |
| `IPrototypeRepository` | `Domains.Workshop.Api` | Data access for prototypes |
| `IUpgradeService` | `Domains.Workshop.Api` | Upgrade operation service |

**Weapon Stat Categories:**
- `WeaponDamage` - Base damage values
- `WeaponAccuracyStat` - Hit chance
- `WeaponDistanceStat` - Attack range
- `WeaponExplosionRadiusStat` - Area of effect
- `WeaponFireRateStat` - Attacks per second
- `WeaponBombCountStat` - Bombs per sortie
- `MineStats` (Cost, Damage per armor type, Radius, SetTime)
- `SuperWeaponStats` (Cost, CP, Time, Preparation)
- `PsiTankStats` (AttackSpeedReduction, SlowdownDuration)
- `CoilTankMaxTargetsStat` - Chain lightning target count
- `MissileFlightTimeStat` / `LaunchPreparationTimeStat`

---

## 6. Service Manager Map

| Service | Assembly | Responsibilities |
|---------|----------|-----------------|
| Authentication Service | ScriptsAssembly | Login, registration, session management |
| Battle Service | ScriptsAssembly | Match lifecycle, commands, sync |
| Chat Service | ScriptsAssembly | 7 chat room types, moderation |
| Clan Service | ScriptsAssembly | Clan CRUD, World War, members |
| Competition Service | ScriptsAssembly | Tournaments, Battle Pass, Coop |
| Billing Service | GGBillingServiceAssembly | IAP, premium, store |
| Ads Service | ScriptsAssembly | AppLovin MAX, IronSource mediation |
| Resource Service | GGUtilsRuntimeAssembly | Asset loading, caching, dispatch |
| Notification Service | GGNotifications | Push notifications |
| Sign-In Service | GGSignInRuntimeAssembly | Google Play Games, social login |
| Feature Toggle Service | ScriptsAssembly | A/B testing, feature flags |
| Logging Service | LoggerAssembly | Analytics, error reporting |
| Vibro Service | ScriptsAssembly | Haptic feedback |

---

## 7. Third-Party Dependencies

| Library | Version/Assembly | Purpose |
|---------|-----------------|---------|
| Unity Addressables | Unity.Addressables | Asset bundle management |
| Zenject | Zenject.dll | Dependency injection framework |
| UniTask | UniTask.dll | Allocation-free async/await |
| UniRx | UniRx.dll | Reactive extensions for Unity |
| R3 | R3.dll, R3.Unity.dll | Next-gen reactive framework |
| DOTween | DOTween.dll | Animation/tweening |
| DOTween Pro | DOTweenPro.dll | Extended tweening features |
| Odin Inspector | Sirenix.OdinInspector.* | Editor serialization/inspection |
| Newtonsoft.Json | Newtonsoft.Json.dll | JSON serialization |
| SQLite | SQLitePCLRaw.* | Local database |
| Firebase | Firebase.* | Analytics, Crashlytics, Messaging |
| Google Play Services | play-services-* | Billing, Games, Ads, Location |
| AppLovin MAX | (via mediation) | Ad monetization |
| IronSource | (via mediation) | Ad mediation |
| AppMetrica | AppMetrica.dll | Yandex analytics |
| Adjust | Adjust.dll | Attribution tracking |
| Tapjoy | Tapjoy.Plugin.Runtime | Offerwall/rewards |
| ZLinq | ZLinq.dll | LINQ optimization |
| Coffee.UIParticle | Coffee.UIParticle.dll | UI particle effects |
| OSA | OSA.Core.dll | Optimized scroll adapter |
| EasyButtons | EasyButtons.dll | Debug buttons |

---

## 8. Scene Loading Dependencies

```
Startup Scene
    ├── Addressables Catalog Load
    ├── Platform SDK Init (Firebase, Ads SDKs)
    └── → Logon Scene

Logon Scene
    ├── Authentication (Login/Registration/Session)
    ├── Faction Selection
    ├── Asset Pre-loading (UI, Common assets)
    └── → Main Scene

Main Scene
    ├── Profile Data Load
    ├── Chat Room Subscriptions
    ├── Workshop Data Sync
    ├── Addressable Resource Warming
    ├── Battle Start Flow:
    │   ├── ReadyToBattleRequest → Matching
    │   ├── MatchingIsFinished → BattleLoading Scene
    │   └── (or) Lobby Flow → BattleLoading Scene
    └── → BattleLoading Scene

BattleLoading Scene
    ├── LoginToBattleRequest → LoginToBattleAnswer
    ├── Battle Asset Loading (Map, VFX, Units, Buildings)
    ├── Connection Quality Check
    ├── BattleLoadProgress Sync
    └── → Battle Scene

Battle Scene
    ├── BattleScreen.Initialize()
    ├── LogicService Start (Tick Loop)
    ├── AI/GAI Initialization
    ├── Network Command Streaming
    ├── Battle Finish → BattleLogout Scene
    └── → BattleLogout Scene

BattleLogout Scene
    ├── ReturnFromBattleRequest
    ├── Battle Results Processing
    ├── Resource Cleanup
    └── → Main Scene
```
