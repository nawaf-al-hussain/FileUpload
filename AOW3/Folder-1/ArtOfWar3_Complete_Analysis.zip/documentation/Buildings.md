# Art of War 3: Global Conflict — Complete Building Encyclopedia

> **Document Version:** 1.0  
> **Source:** Reverse-engineered from APK analysis (Unity IL2CPP metadata, Addressables catalog) and community data  
> **Last Updated:** 2024  

---

## Table of Contents

1. [Overview](#overview)
2. [Building Mechanics](#building-mechanics)
3. [Administrative Buildings](#administrative-buildings)
4. [Military Production Buildings](#military-production-buildings)
5. [Hero Production Buildings](#hero-production-buildings)
6. [Superweapon Buildings](#superweapon-buildings)
7. [Defensive Buildings](#defensive-buildings)
8. [Building Upgrade System](#building-upgrade-system)
9. [Building Destruction & VFX](#building-destruction--vfx)
10. [Build Order Analysis](#build-order-analysis)

---

## Overview

The building system in Art of War 3: Global Conflict follows classic RTS conventions adapted for mobile play. Buildings are constructed on the battlefield during real-time matches by the **Construction Yard**, and each building serves a specific function — resource generation, unit production, defense, or superweapon deployment. Every building requires **Power** (electricity capacity) to function and **Supplies** (resources) to construct and upgrade.

The game features a **three-level upgrade system** for all buildings, with each level visually represented by distinct models (s1, s2, s3 in the asset catalog). Upgrading buildings increases their production capacity, unlocks new units, and improves defensive statistics. The construction yard must be protected at all costs, as losing it prevents the player from constructing or repairing any buildings.

Buildings are categorized into several functional groups:
- **Administrative** — Resource generation and base management
- **Military Production** — Unit training and deployment
- **Hero Production** — Special hero unit creation
- **Superweapon** — Faction-specific ultimate weapons
- **Defensive** — Fortifications and towers

---

## Building Mechanics

### Construction System

All buildings are constructed by the **Construction Yard**, which is the only unit capable of placing, upgrading, and repairing structures. The Construction Yard must physically move to the construction site to begin work, creating a vulnerability window during which it is exposed to enemy fire. Key construction mechanics include:

| Mechanic | Description |
|----------|-------------|
| **Build Time** | Each building has a construction time that varies by type and level |
| **Supply Cost** | All construction consumes Supplies from the player's stockpile |
| **Power Requirement** | Buildings consume Power capacity; exceeding capacity disables buildings |
| **Placement Rules** | Buildings must be placed within the player's base area (defined by Headquarters radius) |
| **Repair** | Damaged buildings can be repaired by the Construction Yard for a Supply cost |
| **Upgrade** | Buildings can be upgraded to Level 2 and Level 3, unlocking new capabilities |

### Power System

The Power system functions as a **capacity statistic** rather than a consumable resource. Each Power Plant adds to the player's maximum power capacity, and each building consumes a portion of that capacity. If the total power consumption exceeds the capacity, buildings will begin to shut down — typically starting with the most recently constructed building. This creates a critical strategic decision: players must balance Power Plant construction with military building production.

| Power Plant Level | Power Provided | Cumulative Power |
|:--:|:--:|:--:|
| Level 1 | Base capacity | — |
| Level 2 | Increased capacity | — |
| Level 3 | Maximum capacity | — |

> **Strategic Note:** Power Plants are high-priority targets for enemy raids. Destroying a Power Plant can cascade into building shutdowns across the entire base, effectively crippling the opponent's production capability. Protect Power Plants with defensive structures and keep them away from the base perimeter.

### Supply System

Supplies are the primary **consumable resource** in the game, generated continuously by Supply Centers. Supplies are used for:

- Constructing buildings
- Producing units
- Upgrading buildings and units
- Repairing damaged structures

The supply economy is the backbone of the player's war effort. Supply Centers generate supplies at a fixed rate that increases with each upgrade level. Controlling the supply economy — both your own and denying the enemy's — is often the deciding factor in extended matches.

---

## Administrative Buildings

### Headquarters (Command Center)

| Property | Value |
|----------|-------|
| **Function** | Strategic deployment center; base heart |
| **Upgrade Levels** | 3 (s1, s2, s3) |
| **Power Consumption** | High |
| **Armor** | Heavy (structural) |
| **Prerequisites** | None — first building placed |
| **Unlocks** | All other buildings (tech tree root) |

The Headquarters (also referred to as the Command Center) is the most critical building in any base. It serves as the strategic deployment center and the root of the building tech tree. Upgrading the Headquarters is essential for progression, as higher levels unlock the ability to construct more advanced buildings and deploy more powerful troops. The Headquarters also defines the base's build radius — new buildings can only be placed within a certain distance of the Headquarters.

Losing the Headquarters is typically catastrophic. In most game modes, destruction of the Headquarters results in defeat, making it the single most important building to protect. It should be positioned in a defensible location, ideally surrounded by Walls and defensive towers, with the Construction Yard kept nearby for emergency repairs.

**Upgrade Progression:**
- **Level 1 (s1):** Basic functionality; unlocks Construction Yard, Power Plant, Supply Center
- **Level 2 (s2):** Unlocks military production buildings; allows unit production
- **Level 3 (s3):** Unlocks hero production and superweapon buildings; full tech tree access

### Construction Yard

| Property | Value |
|----------|-------|
| **Function** | Constructs, upgrades, and repairs all buildings |
| **Type** | Mobile unit (vehicle) that can move to construction sites |
| **Armor** | Light-Medium |
| **Power Consumption** | Low |
| **Prerequisites** | Headquarters |
| **Produces** | All buildings |

The Construction Yard is the only entity capable of constructing, upgrading, and repairing buildings. It functions as a mobile unit that must physically move to the construction site before beginning work. This mobility is both a strength and a weakness — it allows the Construction Yard to reach any location within the base, but it also means the Construction Yard is vulnerable while moving between sites or while working on exposed buildings.

Key tactical considerations for the Construction Yard:
- **Protection Priority:** The Construction Yard is a high-value target. Losing it means the player cannot build new structures, upgrade existing ones, or repair damaged buildings until a replacement is produced (if the Headquarters is still standing).
- **Build Queue Management:** The Construction Yard can only work on one building at a time. Players must prioritize construction orders carefully.
- **Emergency Repairs:** During enemy attacks, the Construction Yard should be directed to repair critical buildings (Headquarters, Power Plants, defensive towers) rather than completing new construction.
- **Forward Bases:** In advanced strategies, the Construction Yard can be used to build forward structures near the front lines, but this exposes it to enemy fire.

### Power Plant

| Property | Value |
|----------|-------|
| **Function** | Generates electricity; increases maximum power capacity |
| **Upgrade Levels** | 3 (s1, s2, s3) |
| **Power Consumption** | None (generates power) |
| **Power Generation** | Increases with each level |
| **Prerequisites** | Headquarters |
| **Armor** | Light (structural) |

The Power Plant is the foundation of the base's power infrastructure. Every building in the game requires power to function, and the Power Plant is the only source of power capacity. The power system is a **capacity model** — Power Plants increase the maximum power capacity, and buildings consume a portion of that capacity. If power consumption exceeds capacity, buildings begin to shut down in reverse construction order.

**Upgrade Progression:**
- **Level 1 (s1):** Provides base power capacity; sufficient for early-game buildings
- **Level 2 (s2):** Significantly increased capacity; supports military production buildings
- **Level 3 (s3):** Maximum capacity; required for superweapon buildings and full base development

**Strategic Considerations:**
- Power Plants should be constructed early and often — running out of power mid-game is a common mistake
- Multiple Power Plants are typically required to support a fully developed base
- Power Plants are priority raid targets; destroying one can cascade into building shutdowns
- Placement should be defensible but not so concentrated that a single superweapon strike can destroy multiple Power Plants

### Supply Center

| Property | Value |
|----------|-------|
| **Function** | Generates Supplies (primary resource) for construction, unit production, and repairs |
| **Upgrade Levels** | 3 (s1, s2, s3) |
| **Power Consumption** | Moderate |
| **Supply Generation** | Increases with each level |
| **Prerequisites** | Headquarters |
| **Armor** | Light (structural) |

The Supply Center is the economic engine of the base, continuously generating Supplies that are used for every aspect of the war effort. Unlike Power (which is a capacity statistic), Supplies are a consumable resource that is spent and must be continuously replenished. The rate of supply generation determines the player's economic throughput — how quickly they can produce units, construct buildings, and recover from losses.

**Upgrade Progression:**
- **Level 1 (s1):** Base supply generation rate; supports early-game unit production
- **Level 2 (s2):** Increased generation rate; supports mid-game army composition
- **Level 3 (s3):** Maximum generation rate; required for late-game heavy unit production

**Strategic Considerations:**
- Supply Centers are the most economically impactful buildings — upgrading them early provides compounding returns
- Multiple Supply Centers are recommended for robust economic output
- Supply Centers are high-priority raid targets; destroying them starves the opponent of resources
- The supply generation rate directly determines unit production speed, making Supply Center upgrades critical for timing attacks

---

## Military Production Buildings

### Barracks

| Property | Value |
|----------|-------|
| **Function** | Trains infantry units |
| **Upgrade Levels** | 3 (s1, s2, s3) |
| **Power Consumption** | Moderate |
| **Prerequisites** | Power Plant + Supply Center |
| **Armor** | Medium (structural) |
| **Produces** | All infantry units |

The Barracks is the primary infantry production building for both factions. It requires both a Power Plant and Supply Center to be constructed before it can be built, making it a mid-tier building in the tech tree. The Barracks trains all infantry units, with higher upgrade levels unlocking more advanced infantry types.

**Confederation Barracks Production:**
| Level | Units Unlocked |
|:--:|------|
| Level 1 | Assault Trooper |
| Level 2 | Heavy Assault Trooper |
| Level 3 | Firepower Assault Trooper |

**Resistance Barracks Production:**
| Level | Units Unlocked |
|:--:|------|
| Level 1 | Rifleman |
| Level 2 | Grenadier |
| Level 3 | Sniper |

**Strategic Note:** Infantry produced at the Barracks are the most cost-effective units in the game per resource spent. While individually weak, a mass of infantry can overwhelm armored units through sheer numbers, especially when using faction-specific advantages (Confederation: Firepower Assault Trooper jetpack charges; Resistance: jungle ambush tactics). Barracks should be positioned near the front of the base for rapid deployment.

### Assault Vehicle Factory

| Property | Value |
|----------|-------|
| **Function** | Produces armored assault vehicles (tanks, light vehicles) |
| **Upgrade Levels** | 3 (s1, s2, s3) |
| **Power Consumption** | High |
| **Prerequisites** | Power Plant + Supply Center |
| **Armor** | Medium (structural) |
| **Produces** | All vehicle-class units |

The Assault Vehicle Factory produces the core combat vehicles for each faction. These vehicles form the backbone of any army composition, providing the armor and firepower needed to challenge enemy positions. Vehicle production consumes more Supplies than infantry but yields significantly more powerful units.

**Confederation Vehicle Factory Production:**
| Level | Units Unlocked |
|:--:|------|
| Level 1 | Fortress |
| Level 2 | Warhammer |
| Level 3 | Zeus |

**Resistance Vehicle Factory Production:**
| Level | Units Unlocked |
|:--:|------|
| Level 1 | Prairie Wolf |
| Level 2 | Armadillo |
| Level 3 | Jaguar |

**Strategic Note:** The Assault Vehicle Factory is typically the first military building players construct after establishing their economy. Vehicle production is essential for map control and base defense. The level 3 units (Zeus and Jaguar) are the most powerful conventional ground units in the game and represent significant power spikes when they enter the battlefield.

### Special Vehicle Factory

| Property | Value |
|----------|-------|
| **Function** | Produces special warfare vehicles (anti-air, artillery, support) |
| **Upgrade Levels** | 3 (s1, s2, s3) |
| **Power Consumption** | High |
| **Prerequisites** | Power Plant + Supply Center + (likely Assault Vehicle Factory) |
| **Armor** | Medium (structural) |
| **Produces** | All special vehicle units |

The Special Vehicle Factory produces support and specialist vehicles that provide critical capabilities beyond raw combat power — anti-air defense, long-range artillery, and force enhancement. These units are essential for a well-rounded army composition but are rarely effective on their own.

**Confederation Special Vehicle Factory Production:**
| Level | Units Unlocked |
|:--:|------|
| Level 1 | Hurricane |
| Level 2 | Torrent |
| Level 3 | Energy Shield |

**Resistance Special Vehicle Factory Production:**
| Level | Units Unlocked |
|:--:|------|
| Level 1 | Porcupine |
| Level 2 | Mammoth |
| Level 3 | Chameleon |

**Strategic Note:** Special vehicles are force multipliers that dramatically increase the effectiveness of the units they support. A Zeus without Energy Shield support is powerful; a Zeus WITH Energy Shield support is nearly unstoppable. Similarly, a Mammoth without Porcupine anti-air cover is vulnerable; a Mammoth WITH Porcupine support is a devastating siege platform. Always pair special vehicles with appropriate combat units.

### Avia Factory (Air Force Factory)

| Property | Value |
|----------|-------|
| **Function** | Produces helicopters and fighter jets |
| **Upgrade Levels** | 3 (s1, s2, s3) |
| **Power Consumption** | Very High |
| **Prerequisites** | Power Plant + Supply Center + (likely higher-tier prerequisites) |
| **Armor** | Medium (structural) |
| **Produces** | All aviation units |
| **Additional Requirement** | Airport for fighter/bomber refueling |

The Avia Factory produces all air units, from reconnaissance helicopters to strategic bombers. Aviation units provide unmatched mobility and strike capability, but they come with significant resource costs and the requirement of an Airport for fighters and bombers. The Avia Factory is one of the most power-intensive buildings in the game, reflecting the technological sophistication of air units.

**Confederation Avia Factory Production:**
| Level | Units Unlocked |
|:--:|------|
| Level 1 | Whirlwind |
| Level 2 | Vertex |
| Level 3 | Thor |

**Resistance Avia Factory Production:**
| Level | Units Unlocked |
|:--:|------|
| Level 1 | Dragonfly |
| Level 2 | Hawk |
| Level 3 | Albatross |

**Strategic Note:** Air power is a significant investment — the Avia Factory, Airport, and individual aircraft all require substantial resources. However, the strategic flexibility of air units (ability to bypass terrain, strike anywhere on the map) makes them invaluable in the mid-to-late game. A common mistake is building the Avia Factory without also constructing an Airport, which grounds all fighters and bombers immediately after production.

### Airport

| Property | Value |
|----------|-------|
| **Function** | Refueling and repair station for fighter jets and bombers |
| **Upgrade Levels** | 3 (s1, s2, s3) |
| **Power Consumption** | High |
| **Prerequisites** | Avia Factory |
| **Armor** | Medium (structural) |
| **Capacity** | Limited number of aircraft per Airport |

The Airport is a critical support structure for any air-focused strategy. Fighter jets and bombers have limited fuel and can only carry one bomb load per sortie (for bombers), requiring them to return to the Airport periodically for refueling and re-arming. Without an Airport, these units become grounded and useless after their initial fuel is spent.

**Airport Mechanics:**
- Aircraft automatically return to the nearest Airport when fuel is low
- The Airport repairs damaged aircraft and refuels them
- Bombers are re-armed with a new bomb load
- Airports have a limited capacity — too many aircraft may require multiple Airports
- Losing an Airport while aircraft are in flight results in those aircraft crashing when fuel runs out

**Strategic Note:** Airport placement is a critical decision. Airports positioned near the front lines allow for faster turnaround times (more sorties per minute), but they are also more vulnerable to enemy attack. Airports positioned deep in the base are safer but result in longer flight times to and from the combat zone. Most competitive players build at least two Airports — one safe rear Airport and one forward Airport for rapid strike capability.

### Shipyard (Dockyard)

| Property | Value |
|----------|-------|
| **Function** | Produces naval units |
| **Upgrade Levels** | 3 (s1, s2, s3) |
| **Power Consumption** | High |
| **Prerequisites** | Power Plant + Supply Center |
| **Armor** | Medium (structural) |
| **Placement** | Must be built in water |
| **Produces** | All naval units |

The Shipyard is unique among production buildings because it must be constructed in water rather than on land. This makes the Shipyard a map-dependent building — on maps with limited water access, naval production may not be feasible. On maps with significant water bodies, however, naval dominance can be decisive.

**Confederation Shipyard Production:**
| Level | Units Unlocked |
|:--:|------|
| Level 1 | Delta |
| Level 2 | Viking |
| Level 3 | Poseidon |

**Resistance Shipyard Production:**
| Level | Units Unlocked |
|:--:|------|
| Level 1 | Caiman |
| Level 2 | Alligator |
| Level 3 | Barracuda |

**Strategic Note:** Shipyard placement determines the extent of naval operations. A Shipyard placed in a sheltered bay is easier to defend but limits naval deployment options. A Shipyard placed in open water provides better access to the naval theater but is more vulnerable to attack. The Shipyards themselves are significant targets — destroying an enemy Shipyard eliminates their ability to replace naval losses.

---

## Hero Production Buildings

### X-Facility (Confederation)

| Property | Value |
|----------|-------|
| **Function** | Produces hero units using Uranium |
| **Upgrade Levels** | 3 (s1, s2, s3) |
| **Power Consumption** | Very High |
| **Prerequisites** | Headquarters Level 3 + advanced tech |
| **Armor** | Heavy (structural) |
| **Resource** | Uranium (special resource) |
| **Produces** | Cerberus (T1), Seraphim (T2), Psion (T2), Solaris (T2), Atlas (T3), Confozord (T3) |

The X-Facility is the Confederation's hero production building, representing the pinnacle of their technological capabilities. It produces hero units using Uranium — a special resource that is significantly rarer and more valuable than Supplies. The X-Facility's naming convention (X = experimental) reflects the Confederation's approach to hero units as technologically advanced super-soldiers and combat robots.

**Hero Production by Upgrade Level:**
| Level | Heroes Unlocked |
|:--:|------|
| Level 1 | Cerberus (T1) |
| Level 2 | Seraphim (T2), Psion (T2), Solaris (T2) |
| Level 3 | Atlas (T3), Confozord (T3) |

**Strategic Note:** The X-Facility is an extremely high-value target. Its destruction not only prevents further hero production but also represents a massive resource investment lost. Protect the X-Facility with your strongest defensive emplacements. The Uranium cost of hero units means that the player must carefully choose which heroes to produce based on the current game state and enemy composition.

### Prototype Factory (Resistance)

| Property | Value |
|----------|-------|
| **Function** | Produces hero units using Uranium |
| **Upgrade Levels** | 3 (s1, s2, s3) |
| **Power Consumption** | Very High |
| **Prerequisites** | Headquarters Level 3 + advanced tech |
| **Armor** | Heavy (structural) |
| **Resource** | Uranium (special resource) |
| **Produces** | Wolverine (T1), Salamander (T2/T3), Leviathan (T3), Bison (T3) |

The Prototype Factory is the Resistance's hero production building. Unlike the Confederation's X-Facility, which produces technologically advanced super-soldiers, the Prototype Factory produces battle-hardened heroes that rely on raw combat prowess and tactical versatility. The naming convention (Prototype = field-tested) reflects the Resistance's approach of refining proven combat concepts rather than experimenting with new technology.

**Hero Production by Upgrade Level:**
| Level | Heroes Unlocked |
|:--:|------|
| Level 1 | Wolverine (T1) |
| Level 2 | Salamander (T2/T3) |
| Level 3 | Leviathan (T3), Bison (T3) |

**Strategic Note:** The Prototype Factory mirrors the X-Facility in terms of strategic importance and resource requirements. The Resistance hero roster is generally more combat-focused and direct than the Confederation's, with heroes like Wolverine and Bison designed to counter specific enemy heroes rather than providing utility.

---

## Superweapon Buildings

### Aerial Strike System / Space System (Confederation)

| Property | Value |
|----------|-------|
| **Function** | Orbital satellite strike system |
| **Charge Time** | Several minutes (exact timing server-configured) |
| **Damage** | Catastrophic — massive area of effect |
| **VFX Scale** | s5 (second largest in game) |
| **Power Consumption** | Extreme |
| **Prerequisites** | Headquarters Level 3 + X-Facility |
| **Armor** | Very Heavy (structural) |
| **Resource** | Supplies for construction; charges over time |

The Aerial Strike System is the Confederation's superweapon building, enabling devastating orbital satellite strikes against any target on the map. The building itself is massive and expensive, requiring the highest tier of tech infrastructure to construct. Once built, it begins charging automatically; when fully charged, the player can designate a target area for the orbital strike.

**Operational Mechanics:**
- The building charges over time once constructed
- When fully charged, a target can be designated anywhere on revealed map territory
- The orbital strike deals catastrophic damage in a large radius
- After firing, the building begins recharging for the next strike
- The building can be destroyed by the enemy to prevent firing
- The VFX for the orbital strike is at scale s5, indicating a massive visual effect with energy beam, ground impact, and shockwave

**Counter-Strategy:**
The primary counter to the Aerial Strike System is to destroy the building before it can fire. This can be accomplished through direct assault, bombing runs (Albatross), or the Resistance's own Nuclear Launcher. If the building cannot be destroyed, the alternative is to spread forces and structures to minimize the area-of-effect damage. Intelligence is key — knowing when the enemy's superweapon is close to firing allows the defending player to evacuate high-value units from likely target areas.

### Intercontinental Missile Launcher Tower (Resistance)

| Property | Value |
|----------|-------|
| **Function** | Nuclear intercontinental missile launch |
| **Charge Time** | Several minutes (exact timing server-configured) |
| **Damage** | Catastrophic — massive area of effect with nuclear explosion |
| **VFX Scale** | s5 (largest in game — nuclear explosion) |
| **Power Consumption** | Extreme |
| **Prerequisites** | Headquarters Level 3 + Prototype Factory |
| **Armor** | Very Heavy (structural) |
| **Resource** | Supplies for construction; charges over time |

The Intercontinental Missile Launcher Tower is the Resistance's superweapon building, firing a nuclear ICBM at any target on the map. The nuclear explosion is the single most devastating attack in the game, with the largest area of effect and the highest damage output. The VFX at scale s5 is the most visually spectacular effect in the entire game — a full nuclear explosion complete with mushroom cloud, shockwave, and radiation effects.

**Operational Mechanics:**
- The building charges over time once constructed
- When fully charged, a target can be designated anywhere on the map
- The nuclear missile travels across the map to the target and detonates
- The explosion destroys virtually everything within the blast radius
- After firing, the building begins recharging
- The missile can be observed traveling across the map, giving alert players a brief window to evacuate units from the impact zone
- The building can be destroyed by the enemy to prevent firing

**Counter-Strategy:**
The nuclear launcher's primary counter is the same as the Aerial Strike System — destroy the building before it fires. The nuclear missile has a travel time (unlike the instantaneous orbital strike), which provides a brief warning that can allow players to move units out of the predicted impact zone. However, the blast radius is so large that complete evacuation is often impossible. The most effective counter is a preemptive strike on the launcher building using the Albatross bomber, a hero unit, or the Confederation's own Aerial Strike System.

---

## Defensive Buildings

Defensive buildings are critical for base protection and area denial. Each faction has a unique set of defensive structures that complement their playstyle — the Confederation favors fortified positions with bunkers and rocket towers, while the Resistance emphasizes precision with sniper towers and cannon emplacements.

### Confederation Defensive Buildings

#### Bunker

| Property | Value |
|----------|-------|
| **Function** | Garrisonable defensive structure for infantry |
| **Weapon** | Garrisoned infantry fire from within |
| **Armor** | Heavy (fortified structure) |
| **Power Consumption** | Low |
| **Upgrade Levels** | 3 (s1, s2, s3) |
| **Garrison Capacity** | Increases with level |

The Bunker is the Confederation's primary infantry fortification. Garrisoned infantry inside the Bunker gain significant damage resistance and can fire their weapons through firing slits. The Bunker is particularly effective when garrisoned with Heavy Assault Troopers, who can engage vehicles from the safety of the fortification. The Bunker's heavy structural armor makes it resistant to all but the most powerful attacks, and it serves as a strong point around which defensive lines can be anchored.

**Tactical Uses:**
- Garrison with Heavy Assault Troopers for anti-vehicle defense
- Garrison with Assault Troopers for anti-infantry screening
- Position at choke points and base approaches
- Use as forward observation posts with garrisoned infantry
- Combine with Wall segments to create fortified lines

#### Rocket Launch Tower

| Property | Value |
|----------|-------|
| **Function** | Anti-vehicle missile tower |
| **Weapon** | Rockets — effective against medium and heavy armor |
| **Armor** | Medium (structural) |
| **Power Consumption** | Moderate |
| **Upgrade Levels** | 3 (s1, s2, s3) |
| **Range** | Long |

The Rocket Launch Tower is the Confederation's primary anti-vehicle defensive structure. Its rockets deal significant damage to medium and heavy armored targets, making it essential for defending against enemy tank pushes. The tower's long range allows it to engage enemy vehicles before they reach the base perimeter. However, it is less effective against infantry (due to slow tracking against small targets) and cannot engage aircraft.

**Optimal Placement:**
- Behind Wall segments where it can fire over the walls
- Overlooking likely vehicle approach routes
- Near Power Plants and Supply Centers for economic defense
- In overlapping fields of fire with other towers for concentrated damage

#### Anti-Air Center

| Property | Value |
|----------|-------|
| **Function** | Anti-aircraft defense installation |
| **Weapon** | Surface-to-air missiles |
| **Armor** | Medium (structural) |
| **Power Consumption** | Moderate |
| **Upgrade Levels** | 3 (s1, s2, s3) |
| **Range** | Long |
| **Engages** | Bombers, fighters, helicopters |

The Anti-Air Center is the Confederation's dedicated anti-aircraft defensive structure. It automatically detects and engages enemy aircraft within its range with surface-to-air missiles. The Anti-Air Center is essential for protecting the base from bombing runs and aerial reconnaissance. Multiple Anti-Air Centers should be positioned to create overlapping coverage zones that make it dangerous for enemy aircraft to approach the base.

**Coverage Strategy:**
- Position around the Headquarters for VIP protection
- Place near Superweapon building to prevent bombing runs
- Create anti-air corridors that force enemy aircraft into kill zones
- Combine with Hurricane mobile anti-air for layered defense

#### Torpedo Launch Platform

| Property | Value |
|----------|-------|
| **Function** | Naval defense installation |
| **Weapon** | Torpedoes — anti-ship |
| **Armor** | Heavy (structural, water-resistant) |
| **Power Consumption** | Moderate |
| **Upgrade Levels** | 3 (s1, s2, s3) |
| **Placement** | Must be built in or near water |
| **Engages** | Warships, submarines (with detection) |

The Torpedo Launch Platform is the Confederation's naval defense structure, built in or near water to protect the coastline from naval assault. Its torpedoes are effective against all naval vessels, including submarines when supported by detection units. The platform is a critical defensive asset on water-heavy maps where enemy naval forces can threaten coastal buildings.

### Resistance Defensive Buildings

#### Sniper Tower

| Property | Value |
|----------|-------|
| **Function** | Long-range precision fire tower |
| **Weapon** | Sniper rifle — high damage, long range, slow fire rate |
| **Armor** | Medium (structural) |
| **Power Consumption** | Low |
| **Upgrade Levels** | 3 (s1, s2, s3) |
| **Range** | Very Long |
| **Effective Against** | Armored units (weak point targeting) |

The Sniper Tower is the Resistance's counterpart to the Confederation Bunker, but with a fundamentally different approach. Instead of garrisoning infantry, the Sniper Tower houses an automated sniper system that targets weak points on armored units at very long range. This makes it exceptionally effective against enemy vehicles — a Sniper Tower can significantly damage or destroy approaching tanks before they reach the base. However, its slow fire rate makes it less effective against swarms of infantry.

**Comparison to Bunker:**
| Feature | Sniper Tower | Bunker |
|---------|:---:|:---:|
| Range | Very Long | Medium |
| Damage per Shot | Very High | Medium (depends on garrison) |
| Fire Rate | Slow | Fast (depends on garrison) |
| Anti-Armor | Excellent | Moderate |
| Anti-Infantry | Poor | Excellent |
| Flexibility | Fixed weapon | Adaptable (change garrison) |

#### Cannon Tower

| Property | Value |
|----------|-------|
| **Function** | Anti-vehicle cannon emplacement |
| **Weapon** | Heavy cannon — high damage against armored targets |
| **Armor** | Heavy (structural) |
| **Power Consumption** | Moderate |
| **Upgrade Levels** | 3 (s1, s2, s3) |
| **Range** | Medium-Long |

The Cannon Tower is the Resistance's primary anti-vehicle defensive structure, fulfilling a similar role to the Confederation's Rocket Launch Tower. However, the Cannon Tower uses a direct-fire cannon rather than rockets, resulting in different tactical characteristics — faster projectile speed, no minimum range, but less area damage. The cannon is highly effective against individual heavy targets but may struggle against spread-out formations.

#### Anti-Air Tower

| Property | Value |
|----------|-------|
| **Function** | Anti-aircraft defense tower |
| **Weapon** | Anti-air missiles/guns |
| **Armor** | Medium (structural) |
| **Power Consumption** | Moderate |
| **Upgrade Levels** | 3 (s1, s2, s3) |
| **Range** | Long |
| **Engages** | Bombers, fighters, helicopters |

The Anti-Air Tower is the Resistance's anti-aircraft defensive structure, serving the same function as the Confederation's Anti-Air Center. The key difference is in the weapon system — the Resistance Anti-Air Tower may use a combination of missiles and guns for faster target acquisition, reflecting the faction's emphasis on rapid response.

#### Naval Platform

| Property | Value |
|----------|-------|
| **Function** | Naval defense installation |
| **Weapon** | Naval guns/torpedoes |
| **Armor** | Heavy (structural, water-resistant) |
| **Power Consumption** | Moderate |
| **Upgrade Levels** | 3 (s1, s2, s3) |
| **Placement** | Must be built in or near water |
| **Engages** | Warships, submarines (with detection) |

The Naval Platform is the Resistance's naval defense structure, equivalent to the Confederation's Torpedo Launch Platform. It protects coastal areas from naval assault and can engage surface ships and (with detection support) submarines.

### Shared Defensive Buildings

#### Wall

| Property | Value |
|----------|-------|
| **Function** | Physical barrier that blocks unit movement and absorbs damage |
| **Armor** | Heavy (structural) |
| **Power Consumption** | None |
| **Upgrade Levels** | 3 (s1, s2, s3) |
| **Special** | Both factions have identical Wall structures |

Walls are the most basic defensive structure available to both factions. They block unit movement, forcing enemies to either destroy the Wall or find another path. Walls absorb damage that would otherwise hit more valuable structures or units. While individual Wall segments are not particularly durable, a network of Walls can significantly delay an enemy assault and create kill zones where defensive towers can concentrate fire.

**Wall Placement Strategies:**
- **Perimeter Defense:** Encircle the base with Walls to create a first line of defense
- **Choke Points:** Force enemy units through narrow gaps covered by towers
- **Power Plant Protection:** Wall off Power Plants to prevent raiding
- **Superweapon Enclosure:** Surround the superweapon building with Walls to delay enemy destruction attempts
- **Layered Defense:** Create multiple Wall lines so that breaching one layer still leaves another

---

## Building Upgrade System

All buildings in the game follow a three-tier upgrade system, with each level providing improved functionality and a visually distinct model. The upgrade system is managed by the Construction Yard and costs both Supplies and time.

### Upgrade Progression Model

| Level | Visual | Functionality | Cost | Build Time |
|:--:|:--:|------|------|------|
| **Level 1 (s1)** | Basic structure | Base functionality, basic unit unlocks | Base cost | Base time |
| **Level 2 (s2)** | Expanded structure | Improved stats, mid-tier unit unlocks | ~2x base cost | ~1.5x base time |
| **Level 3 (s3)** | Full structure | Maximum stats, all unit unlocks | ~4x base cost | ~2x base time |

### Tech Tree Dependencies

```
Headquarters (L1)
├── Construction Yard
├── Power Plant (L1→L2→L3)
├── Supply Center (L1→L2→L3)
├── Wall
│
├── [HQ L2 unlocks]
│   ├── Barracks (L1→L2→L3)
│   ├── Assault Vehicle Factory (L1→L2→L3)
│   ├── Special Vehicle Factory (L1→L2→L3)
│   ├── Avia Factory (L1→L2→L3)
│   │   └── Airport (L1→L2→L3)
│   ├── Shipyard (L1→L2→L3)
│   └── Defensive Buildings
│
└── [HQ L3 unlocks]
    ├── X-Facility / Prototype Factory (L1→L2→L3)
    └── Superweapon Building
```

---

## Building Destruction & VFX

The game's VFX asset catalog reveals that every building has distinct construction and destruction visual effects at each of its three levels. This section documents the visual feedback system for building state changes.

### Destruction VFX

| Building Level | Destruction Effect | Description |
|:--:|:--:|------|
| Level 1 (s1) | Small destruction | Light debris, smoke, small fire |
| Level 2 (s2) | Medium destruction | Moderate debris, heavy smoke, fire |
| Level 3 (s3) | Large destruction | Heavy debris, smoke columns, sustained fire |

### Construction VFX

All buildings display construction scaffolding effects during the building process, with the visual complexity increasing for higher-level structures. The Construction Yard emits welding sparks and mechanical sounds during construction.

### Superweapon Destruction

Both superweapon buildings have unique destruction effects when destroyed:
- **Aerial Strike System:** Electrical discharge, energy containment failure, blue-white explosion
- **Nuclear Launcher Tower:** Radiation leak, missile ignition risk, orange-red explosion with radiation cloud

---

## Build Order Analysis

### Confederation Standard Build Order

| Step | Building | Purpose |
|:--:|------|------|
| 1 | Headquarters | Base foundation |
| 2 | Power Plant (L1) | Enable building power |
| 3 | Supply Center (L1) | Start economy |
| 4 | Barracks (L1) | Infantry production for early defense/scouting |
| 5 | Supply Center (L2) | Boost economy for vehicle production |
| 6 | Power Plant (L2) | Support military buildings |
| 7 | Assault Vehicle Factory (L1) | Fortress/Warhammer production |
| 8 | Defensive Buildings | Base protection |
| 9 | Special Vehicle Factory | Anti-air and artillery support |
| 10 | Avia Factory + Airport | Air power |
| 11 | Shipyard (if map requires) | Naval operations |
| 12 | HQ L3 → X-Facility → Superweapon | Late-game tech |

### Resistance Standard Build Order

| Step | Building | Purpose |
|:--:|------|------|
| 1 | Headquarters | Base foundation |
| 2 | Power Plant (L1) | Enable building power |
| 3 | Supply Center (L1) | Start economy |
| 4 | Barracks (L1) | Rifleman production for scouting/ambush |
| 5 | Barracks (L2) | Grenadier unlock for anti-armor ambush |
| 6 | Supply Center (L2) | Boost economy |
| 7 | Assault Vehicle Factory (L1) | Prairie Wolf for fast scouting |
| 8 | Power Plant (L2) | Support military buildings |
| 9 | Special Vehicle Factory (L1) | Porcupine for anti-air cover |
| 10 | Defensive Buildings | Sniper Towers + Cannon Towers |
| 11 | Avia Factory + Airport | Air power |
| 12 | Shipyard (if map requires) | Naval operations |
| 13 | HQ L3 → Prototype Factory → Superweapon | Late-game tech |

### Fast Tech Build Order (Rush to Superweapon)

| Step | Building | Purpose |
|:--:|------|------|
| 1-3 | Standard opening | HQ, Power Plant, Supply Center |
| 4 | Power Plant (L2) | Early power boost |
| 5 | Supply Center (L2) | Economic acceleration |
| 6 | Barracks (L1) | Minimum defense only |
| 7 | HQ L2 | Unlock tech |
| 8 | Power Plant (L3) | Maximum power |
| 9 | Supply Center (L3) | Maximum economy |
| 10 | HQ L3 | Unlock hero/superweapon |
| 11 | Hero Production Building | Hero unit production |
| 12 | Superweapon Building | Rush to superweapon charge |

> **Risk:** This build order leaves the base extremely vulnerable during the mid-game. Opponents who scout the fast tech attempt can punish with early aggression.

---

*This document is part of the Art of War 3: Global Conflict reverse-engineering documentation suite. For unit information, see [Units.md](Units.md). For gameplay systems, see [Gameplay_Analysis.md](Gameplay_Analysis.md).*
