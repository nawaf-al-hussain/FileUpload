# Art of War 3: Asset Catalog

## 1. Asset Bundle Structure

The game uses Unity Addressables with 23 asset bundles containing 773 catalog entries.

### 1.1 Map Bundles

| Bundle | Contents | Size Class |
|--------|----------|-----------|
| built-inmaps_assets_1_2 | Map prefab for scenario 1_2 | Large |
| built-inmaps_assets_1_3 | Map prefab for scenario 1_3 | Large |
| built-inmaps_assets_1_4 | Map prefab for scenario 1_4 | Large |
| built-inmaps_assets_1_5 | Map prefab for scenario 1_5 | Large |
| built-inmaps_assets_1_6 | Map prefab for scenario 1_6 | Large |
| built-inmaps_assets_3_2 | Map prefab for scenario 3_2 | Large |
| built-inmaps_assets_4_1 | Map prefab for scenario 4_1 | Large |
| built-inmaps_assets_pvp_11 | PvP map prefab | Large |

### 1.2 Minimap Bundles

| Bundle | Contents |
|--------|----------|
| built-inminimaps_assets_1_2 through pvp_11 | PNG minimap per map |
| built-inminimaps_assets_minimap_empty | Empty minimap placeholder |

### 1.3 Shared Bundles

| Bundle | Contents |
|--------|----------|
| 6fa4f6a0b6639b945af95f3940a532e6_unitybuiltinshaders | Unity built-in shaders |
| built-invfx_assets_all | All VFX prefabs and materials |
| decorations-common_assets_all | Shared decorations (roads, bridges, houses) |
| decorations-desert_assets_all | Desert biome decorations |
| decorations-jungle_assets_all | Jungle biome decorations |
| defaultlocalgroup_assets_all | Core UI and startup assets |

---

## 2. VFX Assets

### 2.1 Explosion Effects (Scale s0-s6)

| Category | Variants | Purpose |
|----------|----------|---------|
| boom_expl1_s0_ground/veh/water | 3 | Smallest explosions |
| boom_expl1_s1_ground/veh/water | 3 + _l variants | Small explosions |
| boom_expl1_s2_ground/veh/water | 3 | Medium explosions |
| boom_expl1_s3_ground/veh/water | 3 + _l variants | Large explosions |
| boom_expl1_s4_ground/veh/water/veh_water | 4 | Extra large |
| boom_expl1_s5_ground/water | 2 | Massive explosions |
| boom_expl1_s6_ground | 1 | Maximum scale |
| boom_expl2_s1/s3_ground/veh | 3 | Secondary explosions |
| boom_expl3_s1/s2/s3/s4_ground/veh | 6 | Tertiary explosions |
| boom_expl4_s1_ground | 1 | Fourth type |
| boom_expl5_s5_nuke/nuke_rocket/nuke_water/space/space_ray/space_water/water_only | 7 | Superweapon effects |

### 2.2 Rifle Fire Effects

| Category | Variants |
|----------|----------|
| boom_rifle1_s1_ground/inf/veh/water | 4 |
| boom_rifle1_s2_ground/inf/veh/water | 4 |
| boom_rifle1_s3_ground/inf/veh/water | 4 |
| boom_rifle1_s4_ground/veh/water | 3 |

### 2.3 Building Destruction Effects

| Effect | Levels |
|--------|--------|
| bld_building1_s1/s2/s3 | 3 construction levels |
| bld_destroy1_s1/s2/s3 | 3 destruction levels |
| bld_destroy2_s2_w/s3_w | 2 water destruction |
| boom_bld_1, boom_bld_expl1_s1/s2/s3 | Building explosions |
| boom_bld_expl2_s2_w/s3_w | Water building explosions |
| debris_bld_s1/s2/s3 | 3 debris levels |

### 2.4 Projectile Visuals

| Category | Variants |
|----------|----------|
| bul_rifle1/2_s1/s2/s3/s4/s5 | Infantry weapon projectiles |
| bul_tank1_s1/s2/s3, bul_tank2/3/4 | Tank shells |
| bul_rocket1/2/3/4_s1/s2/s3 | Rockets (including nuke) |
| bul_bomb1/2 | Bomber bombs |
| bul_grenade1/2 | Grenadier grenades |
| bul_torpedo1/2/2_hidden/3/4 | Naval torpedoes |
| bul_ufo_lazergun | Beholder laser |
| bul_psitank_active/wave/wave_passive | Psion psi-energy |
| bul_wasp_s1 | Wasp projectile |
| bul_rocket_leviaphan | Leviathan nuclear rocket |
| bul_rocket_small_salamander | Salamander rockets |

### 2.5 Hero Effects

Complete per-hero VFX sets including:
- **Fire effects**: hero_fire_[hero]_[weapon] (muzzle flash, firing VFX)
- **Bullet effects**: hero_bul_[hero]_[weapon] (projectile models/particles)
- **Impact effects**: hero_impact_[hero]_[weapon]_[surface] (hit VFX per surface type)
- **Death effects**: hero_[hero]_death (unique death animations)
- **Ability effects**: hero_[hero]_[ability] (special ability VFX)
- **Idle effects**: hero_idle_[hero]_[component] (passive visual elements)
- **Turbine effects**: hero_[hero]_turbine_* (flying heroes: Seraphim, Leviathan)

---

## 3. Map/Environment Assets

### 3.1 Desert Biome

| Asset Type | Files |
|-----------|-------|
| Models | desert_bridge, desert_dry_grass, desert_dry_trees, desert_ground_grass, desert_houses, desert_objects, desert_road_angle, desert_road_mirror, desert_road_up, desert_stones, desert_thorn |
| Materials | desert_mat_decoration_bridges, desert_mat_decoration_cutout, desert_mat_decoration_diffuse, desert_mat_decoration_diffuse2 |
| Textures | tex_ground_desert, tex_ground_desert_alpha, tex_objects_desert, tex_objects_desert_alpha, tex_terrain_desert |

### 3.2 Jungle Biome

| Asset Type | Files |
|-----------|-------|
| Models | jungle_3dgras, jungle_bent_trees, jungle_border_bushes, jungle_bridge_wide, jungle_bridges, jungle_bush, jungle_goingup_planes, jungle_ground_grass, jungle_houses, jungle_middlepath_stones, jungle_objekts_atlas, jungle_palm_hight/low, jungle_road_angle/mirror/up, jungle_roads, jungle_rock_tree, jungle_stone, jungle_tree_low/ultralow/underbrush/hight, jungle_under_brushes, jungle_waterlily |
| Materials | jungle_mat_decoration_bridges, jungle_mat_decoration_diffuse2, jungle_mat_decorations_cutout, jungle_mat_decorations_diffuse |
| Textures | tex_ground_jungle, tex_ground_jungle_02, tex_objects_jungle, tex_objects_jungle_2, tex_objects_jungle_alpha, tex_terrain_jungle |

### 3.3 Shared Environment

| Asset | Purpose |
|-------|---------|
| Cloud prefab + materials | Animated cloud shadows |
| Flag materials | Faction flag rendering |
| War objects + materials | Destroyed/damaged environment |
| Water materials/shaders | Water rendering |
| tex_cloud | Cloud shadow texture |

---

## 4. Shader Assets

| Shader | Purpose |
|--------|---------|
| Landscape.shader | Terrain rendering |
| OpaqueFloraMask.shader | Opaque vegetation (desert) |
| TransparentFloraMask.shader | Transparent vegetation (jungle) |
| AOW Water.shader | Water surface rendering |
| Water Waves.shader | Animated water waves |
| fx_effect.mat | General effect material |
| fx_fire_additive*.mat | Additive fire blending |
| fx_fire_offset*.mat | Offset fire rendering |
| fx_shield.mat | Energy shield rendering |
| fx_displacement.mat | Distortion effects |
| fx_dissolve.mat | Dissolve/shimmer effects |

---

## 5. UI Assets

| Asset | Purpose |
|-------|---------|
| panel_select_faction.prefab | Faction selection screen |
| window_magic.prefab | Settings/debug window |
| animation_battle_defeat/win.prefab | Battle result animations |
| animation_battle_roundswitch.prefab | Round transition animation |
| panel_entrance_14_day/30_day*.prefab | Daily entrance reward panels |

---

## 6. Audio Assets

Audio is managed through the `AudioToolkit` system with these components:
- `AudioBattleSoundsHandler`: Battle sound effects
- `AudioBattleVoicesUtils`: Unit voice lines
- `AudioGroups`: Sound group management
- `AudioDurationAdjuster`: Audio timing
- `GUIPlayTriggeredSound`: UI sound triggers

Sound categories:
- Battle SFX: Explosions, gunfire, rockets, construction
- Unit Voices: Selection, movement, attack, death responses
- UI Sounds: Button clicks, notifications, menu transitions
- Music: Battle music, menu music, victory/defeat themes
- Ambient: Environmental sounds per biome

---

## 7. Animation Assets

| Category | Count | Types |
|----------|-------|-------|
| Explosion animations | 5 | boom_bld_expl1_s3, boom_bld_expl2_s3_w, boom_unit_expl4_s3_a |
| Fire animations | 8 | fire_rifle1/2_s2/s3/s4, fire_rifle2_s4_fighter |
| Rocket animations | 6 | bul_rocket1/2_s2_1/2/3 |
| Hero animations | 5 | hero_cerber_impact, hero_beholder_scanner, anim_hero_impact_beholder_scanner, hero_bld_grade1/2/3_f2, eff_sparks2/22 |
| Special animations | 4 | anim_pot_of_gold_collect, anim_rocet_boom, anim_rocet_lanch, eff_star01_1 |
| Smoke animations | 1 | smoke_factory2.anim |
