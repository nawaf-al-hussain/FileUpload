# Art of War 3: Multiplayer Architecture Analysis

## 1. Network Architecture Overview

Art of War 3 uses a **client-server architecture** with two distinct connection types: a persistent main server connection for meta-game operations and ephemeral battle server connections for real-time gameplay. The game requires a constant, stable internet connection and follows an always-online model.

### Architecture Diagram

```
┌──────────────────────────────────────────────────────────┐
│                      CLIENT                              │
│  ┌─────────────┐  ┌──────────────┐  ┌───────────────┐  │
│  │ Main Server  │  │ Battle Server│  │  Chat Server  │  │
│  │ Connection   │  │ Connection   │  │  Connection   │  │
│  └──────┬───────┘  └──────┬───────┘  └───────┬───────┘  │
│         │                 │                   │          │
│  ┌──────┴─────────────────┴───────────────────┴───────┐  │
│  │              Network Message Layer                  │  │
│  │  Serialization | Encryption (RSA/DES) | Compression │  │
│  └────────────────────────┬───────────────────────────┘  │
│                           │                              │
│  ┌────────────────────────┴───────────────────────────┐  │
│  │              Game Logic / Simulation                 │  │
│  │  BattleScreen → LogicService → Entities → AI/GAI   │  │
│  └────────────────────────────────────────────────────┘  │
└──────────────────────────────────────────────────────────┘
                            │
                    ┌───────┴───────┐
                    │   INTERNET    │
                    └───────┬───────┘
                            │
        ┌───────────────────┼───────────────────┐
        ▼                   ▼                   ▼
┌──────────────┐  ┌──────────────┐  ┌──────────────┐
│  Main Server │  │ Battle Server│  │  Chat Server │
│  (Persistent)│  │ (Per-Match)  │  │ (Persistent) │
│──────────────│  │──────────────│  │──────────────│
│ Auth         │  │ Game State   │  │ Chat Rooms   │
│ Profile Mgmt │  │ Tick Sim     │  │ Moderation   │
│ Matching     │  │ Command Arb  │  │ Translation  │
│ Upgrades     │  │ Sync/Desync  │  │ Friends      │
│ Clans        │  │ Results      │  │ Ignore Lists │
│ Rating       │  │ Reconnection │  │ Ban System   │
│ Store/Billing│  │              │  │              │
│ Tournaments  │  │              │  │              │
└──────────────┘  └──────────────┘  └──────────────┘
        │                   │                   │
        └───────────────────┼───────────────────┘
                            ▼
                    ┌──────────────┐
                    │   Database   │
                    │  (Persistent │
                    │   Storage)   │
                    └──────────────┘
```

---

## 2. Authentication Flow

```
Client                          Server
  │                               │
  │  LoginRequest                 │
  │  (credentials/device ID)      │
  ├──────────────────────────────►│
  │                               │ Validate credentials
  │                               │ Load/create account
  │  LoginAnswer                  │
  │◄──────────────────────────────┤
  │  (session token, profile)     │
  │                               │
  │  OR (if session exists):      │
  │                               │
  │  SessionRestoreRequest        │
  │  (session token)              │
  ├──────────────────────────────►│
  │                               │ Validate session
  │  SessionRestoreAnswer         │
  │◄──────────────────────────────┤
  │  (full profile state)         │
  │                               │
  │  ConnectionCheckRequest       │
  ├──────────────────────────────►│
  │  ConnectionCheckAnswer        │
  │◄──────────────────────────────┤
  │                               │
  │  TimeSyncRequest              │
  ├──────────────────────────────►│
  │  TimeSyncAnswer               │
  │◄──────────────────────────────┤
  │  (server time for sync)       │
```

**Error Paths:**
- Invalid credentials → LoginAnswer with error code
- Expired session → GoToRelogin
- Outdated client → GoToUpdateClient
- Server maintenance → ServerIsFinishingItsWork

---

## 3. Matchmaking Flow

### 3.1 PvP 1v1

```
Client                          Server
  │                               │
  │  ReadyToBattleRequest         │
  ├──────────────────────────────►│
  │                               │ Add to matchmaking queue
  │                               │ Evaluate candidates:
  │                               │ - Skill level
  │                               │ - Rank/Stars
  │                               │ - Win rate
  │                               │ - Connection quality
  │                               │ Select optimal server region
  │                               │
  │  MatchingIsFinished           │
  │◄──────────────────────────────┤
  │  (opponent info, server)      │
  │                               │
  │  AppointStartMessage          │
  │◄──────────────────────────────┤
  │                               │
  │  ClientGoToBattleNotification │
  │◄──────────────────────────────┤
  │                               │
  │  (Transition to BattleLoading)│
```

### 3.2 Lobby (2v2)

```
Player A                    Server                    Player B
  │                           │                          │
  │  LobbyCreateRequest       │                          │
  ├──────────────────────────►│                          │
  │  LobbyCreateAnswer        │                          │
  │◄──────────────────────────┤                          │
  │                           │                          │
  │  LobbyOutcomeInviteReq    │                          │
  ├──────────────────────────►│ LobbyIncomeInviteNotif   │
  │                           ├─────────────────────────►│
  │                           │                          │
  │                           │ LobbyIncomeInviteConfReq │
  │                           │◄─────────────────────────┤
  │  LobbyInviteConfirmNotif  │                          │
  │◄──────────────────────────┤                          │
  │                           │                          │
  │  LobbyBattleStartRequest  │                          │
  ├──────────────────────────►│ Match vs enemy team      │
  │                           │                          │
  │  GoToBattleNotification   │ GoToBattleNotification   │
  │◄──────────────────────────┤─────────────────────────►│
```

---

## 4. Battle Session Lifecycle

```
┌──────────────────────────────────────────────────────────┐
│                   BATTLE SESSION LIFECYCLE                │
│                                                          │
│  1. ESTABLISHMENT                                        │
│     ├── LoginToBattleRequest → LoginToBattleAnswer       │
│     ├── Battle server connection established             │
│     ├── Player slot assigned (side, color, position)     │
│     └── Battle connect settings received                 │
│                                                          │
│  2. LOADING                                              │
│     ├── Asset loading (map, units, buildings, VFX)       │
│     ├── BattleLoadProgressRequest/Answer                 │
│     ├── BattleLoadProgressNotification (opponent)        │
│     ├── CheckConnectionToBattleHosts                     │
│     └── Both players loaded → StartingBattle             │
│                                                          │
│  3. GAMEPLAY                                             │
│     ├── Tick-based simulation                            │
│     ├── Command streaming (player actions)               │
│     ├── PeriodicTimeSynchronizationUpdate                │
│     ├── Ping/Pong keepalive                              │
│     ├── State synchronization                            │
│     └── Desync detection and correction                  │
│                                                          │
│  4. COMPLETION                                           │
│     ├── Win/Loss condition triggered                     │
│     ├── BattleFinishNotification                         │
│     ├── BattleResultRequest → BattleResultAnswer         │
│     ├── Battle statistics calculated                     │
│     └── Rewards distributed                              │
│                                                          │
│  5. CLEANUP                                              │
│     ├── BattleLogoutRequest                              │
│     ├── ReturnFromBattleRequest                          │
│     ├── Assets unloaded                                  │
│     └── Return to Main Scene                             │
└──────────────────────────────────────────────────────────┘
```

---

## 5. Synchronization Model

The game uses a **server-authoritative tick-based synchronization** model:

### Tick System
- The server runs a deterministic simulation at a fixed tick rate
- Client sends commands (actions) to the server
- Server validates commands, updates game state, broadcasts to all clients
- Clients render the server-confirmed state

### State Replication
```
Client Command → Server Validation → State Update → Broadcast to All Clients
```

### Time Synchronization
- `PeriodicTimeSynchronizationUpdate` runs continuously
- `TimeSyncRequest` / `TimeSyncAnswer` for clock alignment
- `Ping` messages for latency measurement
- Server selects optimal region based on connection quality

### Desync Handling
- `BattleRunCheckerWaitMessage` monitors simulation consistency
- `PrepareDesyncButton` (debug) for manual desync detection
- `CheckConnectionToBattleHosts` verifies connectivity
- If desync detected: state resynchronization from server

---

## 6. Network Message Protocol

### Message Structure
All messages follow a Request/Answer or Notification pattern:
- **Request/Answer**: Client initiates, server responds (e.g., LoginRequest → LoginAnswer)
- **Notification**: Server pushes to client (e.g., BattleFinishNotification)
- **ComplexMessage**: Multi-part messages for large data transfers

### Encryption
- `RsaDesPacketRequest` / `RsaDesPacketAnswer`: RSA+DES hybrid encryption for sensitive operations (authentication, billing)
- Regular game traffic may use standard TLS/SSL transport encryption

### Message Categories (189+ types)

| Category | Request Types | Answer Types | Notification Types |
|----------|--------------|-------------|-------------------|
| Authentication | 4 | 4 | 0 |
| Battle | 6 | 6 | 4 |
| Lobby | 12 | 12 | 6 |
| Profile/Account | 8 | 8 | 4 |
| Upgrade | 5 | 5 | 2 |
| Clan | 20+ | 20+ | 8+ |
| Chat (7 types) | 35+ | 35+ | 10+ |
| Competition | 10+ | 10+ | 5+ |
| Hero | 5 | 5 | 0 |
| Billing | 5 | 5 | 2 |
| Special | 3 | 3 | 0 |
| Time/Connection | 3 | 3 | 0 |
| Daily/Entrance | 8 | 8 | 3 |
| Quest | 5 | 5 | 4 |
| Rating | 6 | 6 | 0 |

---

## 7. Reconnection System

```
Disconnection Detected
    │
    ├── Automatic Reconnection Attempt
    │   ├── ClientPausedNotification (app backgrounded)
    │   ├── Reconnect to battle server
    │   ├── BattleSessionRestoreRequest → BattleSessionRestoreAnswer
    │   ├── State resynchronization
    │   ├── UpdateResumptionBattleActivityCoroutine
    │   ├── WaitingResumptionBattle state
    │   └── Resume gameplay
    │
    └── Failed Reconnection
        ├── ServerIsFinishingItsWork
        ├── Battle counted as loss
        └── Return to Main Scene
```

---

## 8. Anti-Cheat Architecture

Based on the observed architecture, the following anti-cheat measures are present:

1. **Server-Authoritative Model**: All game state changes are validated server-side. Client commands are verified before execution.
2. **RSA/DES Encryption**: Sensitive operations use hybrid encryption to prevent packet injection.
3. **Time Synchronization**: Continuous time sync prevents speed hacks.
4. **Desync Detection**: Server monitors simulation consistency.
5. **Client Validation**: `GoToUpdateClient` forces client updates; outdated clients cannot connect.
6. **Special Commands**: `AddEntity`, `ChangeEntity`, `DeleteEntity` are server-side only operations sent via `SpecialCommandMessage`.

---

## 9. Session State Machine

```
┌──────────┐  Login   ┌──────────┐  Match   ┌──────────┐
│ LOGON    │─────────►│ MAIN     │─────────►│ MATCHING │
│          │          │ (Lobby)  │          │          │
└──────────┘          └────┬─────┘          └────┬─────┘
                           │                     │
                           │  GoToRelogin        │  MatchFound
                           ▼                     ▼
                      ┌──────────┐         ┌──────────┐
                      │ RELOGON  │         │ BATTLE   │
                      │          │         │ LOADING  │
                      └──────────┘         └────┬─────┘
                                                │
                                                │  Loaded
                                                ▼
                                           ┌──────────┐
                                           │ BATTLE   │
                                           │ GAMEPLAY │
                                           └────┬─────┘
                                                │
                                                │  Finish
                                                ▼
                                           ┌──────────┐
                                           │ BATTLE   │
                                           │ LOGOUT   │
                                           └────┬─────┘
                                                │
                                                │  Return
                                                ▼
                                           ┌──────────┐
                                           │ MAIN     │
                                           │ (Results)│
                                           └──────────┘
```
