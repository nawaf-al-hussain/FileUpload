# Art of War 3: Gameplay Systems Analysis

## 1. Core RTS Systems

### 1.1 Unit Movement and Pathfinding

The game implements a tile-based pathfinding system with the map divided into a grid. Units navigate using A*-style pathfinding with terrain considerations. The `CellScheduleStack` entity manages movement queuing, allowing units to chain waypoints. Infantry units can traverse forests (Resistance infantry have stealth in forests), while vehicles are restricted to open terrain and roads. Naval units are constrained to water tiles, and amphibious units like the Delta can transition between land and water.

Movement speeds vary significantly by unit type. Light reconnaissance vehicles like the Prairie Wolf are extremely fast even off-road, while heavy tanks like the Zeus and Poseidon cruiser are very slow. The Jaguar tank has a unique dual-mode system: Travel Mode provides fast movement with firing-on-the-move capability, while Siege Mode immobilizes the unit but doubles firepower.

### 1.2 Fog of War

The fog of war system was significantly updated in recent versions. Unexplored territory is completely hidden from the player. Enemy bases and supply containers are not displayed until scouted. The Chameleon unit creates a localized fog barrier that hides allied units from enemy detection. Only scout units that physically enter the Chameleon's fog can reveal hidden units. This makes the Chameleon a uniquely powerful strategic tool for ambush tactics.

Vision range varies by unit type. Aircraft have large vision radii, while submarines have limited surface vision when submerged. The Whirlwind helicopter serves as a mobile scout with submarine detection capability.

### 1.3 Unit Selection and Control

The game implements a classic PC RTS control scheme adapted for mobile:
- **Tap Selection**: Select individual units
- **Rectangle Selection**: Drag to select multiple units (AddSelectUnitsByRectangle)
- **Polygon Selection**: Advanced multi-point selection (SelectUnitsByPolygon)
- **Double-Tap**: Select all units of the same type on screen
- **Select All**: Select all units on the map with specific settings
- **Central Unit**: Selected group has a central/reference unit (SelectCentralUnit)

Commands include move, attack, patrol, and rally point setting. The `GroupUnits` system manages formation and movement coordination for selected groups.

---

## 2. Economy System

### 2.1 Resource Types

| Resource | Generation | Usage | Storage |
|----------|-----------|-------|---------|
| **Supplies** | Supply Centers (continuous generation) | Construction, unit production, building repairs, upgrades | Effectively unlimited (increases with Supply Centers) |
| **Power** | Power Plants (capacity, not consumable) | Required to operate buildings (each building has energy cost) | Power Plant capacity limit |
| **Uranium** | Meta-progression | Hero unit activation in battle | Battery system |
| **Credits** | Battle rewards, daily entrance | Various upgrades and purchases | Account-bound |
| **Gold** | Premium purchases | Speed up upgrades, premium items | Account-bound |
| **Skill Points** | Winning battles | Commander skill upgrades | Account-bound |
| **Tokens** | Battle rewards, events | Special purchases | Account-bound |
| **Speed-Ups** | Events, store | Accelerate upgrade timers | Inventory |

### 2.2 Economy Flow During Battle

```
Power Plant → Provides Power Capacity
    ↓
Supply Center → Generates Supplies (rate increases with level/upgrade)
    ↓
Supplies → Build Structures → Expand Economy
    ↓
Supplies → Train Units → Military Power
    ↓
Supply Crates (Map Pickups) → Bonus Resources
    ↓
CollectSupplyBox → Immediate resource injection
```

### 2.3 Income Formulas

Supply generation rate is determined by:
- Base rate per Supply Center level
- Workshop upgrades (Resource Planning speed bonus)
- Commander Skill bonuses
- Number of Supply Centers (diminishing returns: 7th Supply Center only adds ~30-50 resources/minute at Rank 18)

### 2.4 Building Cost Structure

Buildings have a tiered cost structure:
- Base construction cost: ~40 seconds build time
- Upgrade costs scale exponentially with level
- Energy costs increase per building and level
- Strategic decisions required: economy vs. military investment

---

## 3. Combat System

### 3.1 Damage Calculation

The combat system uses an armor-class-based damage model:

```
Damage = BaseWeaponDamage × ArmorModifier × UpgradeMultiplier

Where:
- BaseWeaponDamage: Determined by weapon type and workshop upgrades
- ArmorModifier: Varies by target armor class (Light/Medium/Heavy)
- UpgradeMultiplier: From Workshop weapon upgrades
```

Key damage-related classes:
- `CalculateWeaponArmorDamage`: Core damage calculation
- `WeaponDamage` / `WeaponDamageHeavyValue`: Damage stat containers
- `CreateDamageForMediumArmor` / `CreateLiteDamage` / `CreateSuperWeaponMediumDamage`: Damage factory methods
- `GetArmorMeta`: Armor metadata lookup
- `SafeSetDamageStat`: Thread-safe damage modification

### 3.2 Armor Classes

| Armor Class | Defense Equipment | Typical Units |
|-------------|------------------|---------------|
| Light (I) | Defense Equipment I | Infantry, Light vehicles, Helicopters, Scouts |
| Medium (II) | Defense Equipment II | Medium tanks, Artillery, Anti-air, Destroyers |
| Heavy (III) | Defense Equipment III | Heavy tanks, Bombers, Cruisers, Fortresses |

### 3.3 Weapon Target Types

| Target Type | Description | Weapon Behavior |
|-------------|-------------|----------------|
| Bombers | Fixed-wing bomber aircraft | Intercepted by AA, fighter patrols |
| Fighters | Fixed-wing fighter aircraft | Air-to-air engagement |
| Helicopters | Rotary-wing aircraft | Vulnerable to AA, can be engaged by most units |
| Land Units | All ground forces | Standard ground combat |
| Warships | Surface naval vessels | Engaged by naval, air, and coastal weapons |
| Submarines | Submerged naval units | Only detectable by specific units/platforms |

### 3.4 Projectile System

The game implements multiple bullet engine types, each with distinct physics:

| Engine Type | Behavior | Used By |
|-------------|----------|---------|
| `LinearBulletEngine` | Straight-line travel to target | Rifles, machine guns, tank cannons |
| `BallisticBulletEngine` | Arc trajectory | Artillery, mortars, howitzers |
| `BallisticHighBulletEngine` | High arc trajectory | Long-range artillery |
| `AdjustableBallisticBulletEngine` | Variable arc | Mortar-type weapons |
| `SelfDirectedBulletEngine` | Homing projectile | Missiles, torpedoes |
| `ChainLightingBulletEngine` | Chain lightning between targets | Coiltank, PsiTank |

### 3.5 Special Weapon Mechanics

**Mines**: Laid by Armadillo (land mines) and Caiman (naval mines). Mine stats include cost, damage per armor type, explosion radius, and set time. Mines are invisible until triggered or detected by Fortress.

**Superweapons**: Each faction has a unique superweapon that charges over time during battle:
- Confederation: Space Strike System — Orbital satellite strike, higher damage per strike, longer charge
- Resistance: Nuclear Missile Launcher — Nuclear missile, faster fire rate, less durable structure

**Hero Abilities**: Hero units have active and passive abilities with cooldowns:
- `OnAbilityCooldownHandler`: Manages ability cooldown timers
- `AbilityReactOn` / `AbilityReactOff`: Toggle ability state
- `ExecuteOnAbilityReaction`: Execute ability effects
- `AuraEffectController`: Apply aura effects to nearby units

### 3.6 Accuracy and Range

- `WeaponAccuracyStat`: Determines hit probability, upgraded via Workshop
- `WeaponDistanceStat`: Attack range, varies by weapon type
- Aircraft have fuel limitations (must return to Airport)
- Artillery has minimum range (cannot fire at close targets)
- Some units double efficiency when stationary (Hurricane/Cyclone)

---

## 4. Construction System

### 4.1 Building Placement

Buildings are placed by the Construction Yard on a grid system. Key constraints:
- Buildings must be placed within the construction zone around the Headquarters
- Buildings require Power capacity (Power Plant must support energy cost)
- Naval buildings (Shipyard) must be placed adjacent to water
- Building placement is verified by `CheckBuildingsConnector` for connectivity
- Free positions found by `GetFreePosition` / `GetNearestPositionToBuilding`

### 4.2 Build Queues

Each production building maintains a build queue:
- Barracks: Infantry units (queue of 1-5 units)
- Vehicle Factories: Vehicles (queue of 1-3 units)
- Avia Factory: Aircraft (queue of 1-3 units)
- Shipyard: Naval units (queue of 1-3 units)
- Airport: Refueling queue for returning aircraft

Production speed is determined by:
- Base production time per unit
- Workshop upgrade multiplier
- Building level
- Commander skill bonuses

### 4.3 Tech Requirements

Building dependencies form a tech tree:
```
Headquarters
└── Construction Yard
    ├── Power Plant
    ├── Supply Center (requires Power Plant)
    └── Barracks (requires Power Plant + Supply Center)
        ├── Assault Vehicle Factory
        │   └── Special Vehicle Factory
        ├── Avia Factory
        │   └── Airport
        └── Shipyard
```

---

## 5. Progression Systems

### 5.1 Workshop (Meta-Progression)

The Workshop is the primary between-battle progression system. Players permanently upgrade units and buildings:

| Upgrade Category | Stats Affected |
|-----------------|---------------|
| Unit HP | Health increase per upgrade level |
| Unit Armor | Damage reduction per armor type |
| Unit Damage | Weapon damage per armor type |
| Production Speed | Build/train time reduction |
| Weapon Range | Attack distance increase |
| Weapon Accuracy | Hit probability increase |
| Weapon Fire Rate | Attacks per second increase |
| Explosion Radius | Area of effect size |
| Mine Stats | Cost, damage, radius, set time |
| Superweapon | Cost, CP, charge time, preparation |
| Hero Stats | Hero-specific upgrades |

### 5.2 Commander Skills

Commander Skills provide battle-wide bonuses:
- Earned by winning battles (Skill Points)
- Multiple "Commander Skill Series" available
- Skills can influence: unit speed, damage, armor, economy, superweapon charge rate
- SkillUpgradeRequest → SkillUpgradeAnswer
- Tournament-specific skill resets available

### 5.3 Career/Rank System

- Profile levels increase with experience
- Stars represent PvP rating
- Leagues group players by skill level
- Rank determines matchmaking bracket
- `NextProfileLevelNotification` / `NextProfileRankNotification`

---

## 6. AI System

### 6.1 Campaign AI

Campaign AI follows scripted mission logic:
- Pre-defined unit compositions and attack waves
- Trigger-based behavior (on timer, on player action, on area entry)
- Difficulty scaling between Easy and Hard modes
- Reinforcement scheduling
- Victory/defeat condition monitoring

### 6.2 Skirmish/PvP AI

The GAI (Game AI) system provides:
- Strategic decision-making (build order, economy management)
- Tactical combat decisions (unit composition, positioning)
- Target prioritization (high-value targets, weak units)
- Resource management (expansion, defense balance)

### 6.3 Unit AI

Individual unit AI handles:
- Target acquisition (`GetWeaponBasedFlarePrepareClip`, target prioritization)
- Aggro range and engagement logic
- Auto-attack behavior when idle
- Return fire when attacked
- Firing-while-moving (Warhammer) vs. siege-mode-only (Torrent, Mammoth)

---

## 7. Faction Asymmetry

### Confederation Playstyle
- **Direct Combat Superiority**: Zeus + Energy Shield ground push is extremely hard to stop
- **Air Dominance**: Vertex + Thor combination dominates airspace
- **Technological Edge**: Energy Shield provides unique defensive buff
- **Naval Power**: Poseidon cruiser provides unmatched siege range from water
- **Weakness**: Expensive units, slow build-up, predictable strategies

### Resistance Playstyle
- **Stealth and Ambush**: Chameleon fog + forest-hidden infantry enable devastating surprise attacks
- **Speed and Mobility**: Jaguar dual-mode, Prairie Wolf scouting, fast flanking
- **Mine Warfare**: Armadillo and Caiman mine-laying for area denial
- **Submarine Threat**: Barracuda invisible submarine provides naval stealth advantage
- **Weakness**: Less durable in direct confrontation, requires micro-management for stealth tactics

### Balance Considerations
- Confederation generally favored in direct combat
- Resistance favored in strategic/stealth play
- Community regularly discusses faction imbalance
- Frequent balance updates adjust unit stats between factions
- New hero units can shift the meta significantly
