# Art of War 3: Data Flow Analysis

## 1. User Input Data Flow

```
Touch/Click Input
    │
    ▼
Input/Gesture Handlers (com.geargames.aow.scenes.battle.map.input.gesturehandlers)
    │
    ├── Unit Selection Gestures
    │   ├── Tap → Select Unit
    │   ├── Drag Rectangle → AddSelectUnitsByRectangle
    │   ├── Drag Polygon → SelectUnitsByPolygon
    │   └── Double-Tap → Select Same Type
    │
    ├── Command Gestures
    │   ├── Tap Ground → Move Command
    │   ├── Tap Enemy → Attack Command
    │   ├── Tap Building → Build/Interact
    │   └── Long Press → Context Menu
    │
    ▼
LogicService.Commands (com.geargames.aow.scenes.battle.logicservice.commands)
    │
    ├── Validate Command
    │   ├── Check resources
    │   ├── Check range
    │   ├── Check cooldown
    │   └── Check prerequisites
    │
    ├── Send to Server (Network Layer)
    │   └── Client Action → Server Validation
    │
    ├── Apply Locally (Client Prediction)
    │   └── Immediate visual feedback
    │
    └── Server Confirmation
        └── Final state update
```

---

## 2. Resource Collection Data Flow

```
Supply Center (Building)
    │
    ├── Generates Supplies per tick
    │   ├── Base rate determined by level
    │   ├── Modified by Workshop upgrades
    │   └── Modified by Commander Skills
    │
    ▼
Player Resource State
    │
    ├── Update UI (Supply counter)
    │   ├── Trigger availability checks
    │   │   ├── Can build unit? (cost check)
    │   │   ├── Can build building? (cost + power check)
    │   │   └── Can upgrade? (cost + timer check)
    │   │
    │   └── BindResourceSystem → UI updates
    │
    ▼
Supply Crate Collection (Map Pickup)
    │
    ├── CollectSupplyBox action
    ├── VFX: eff_collect_box / eff_collect_container / eff_collect_tree
    │
    ▼
Economy System
    │
    ├── IsLackResources check
    ├── CalculateCost for actions
    └── AddResource / ChangeSupplyState
```

---

## 3. Combat Data Flow

```
Unit Acquires Target (AI or Player Command)
    │
    ▼
Weapon System
    │
    ├── Check Target Validity
    │   ├── Weapon range check (WeaponDistanceStat)
    │   ├── Target type check (WeaponTarget: land/air/sea/sub)
    │   ├── Cooldown check (WeaponFireRateStat)
    │   └── Line of sight check (fog of war)
    │
    ▼
Weapon Fires
    │
    ├── Create Bullet Entity
    │   ├── Select Bullet Engine Type:
    │   │   ├── LinearBulletEngine (direct fire)
    │   │   ├── BallisticBulletEngine (artillery arc)
    │   │   ├── SelfDirectedBulletEngine (homing)
    │   │   └── ChainLightingBulletEngine (chain)
    │   │
    │   ├── Select Bullet Prefab:
    │   │   ├── bul_rifle1_s1/s2/s3 (infantry rifles)
    │   │   ├── bul_tank1_s1/s2/s3 (tank shells)
    │   │   ├── bul_rocket1/2/3_s* (rockets)
    │   │   ├── bul_bomb1/2 (bombers)
    │   │   ├── bul_torpedo1/2/3/4 (naval)
    │   │   ├── bul_grenade1/2 (grenadiers)
    │   │   └── hero-specific bullets
    │   │
    │   └── Spawn VFX: fire_rifle*, fire_tank*, etc.
    │
    ▼
Bullet Travel
    │
    ├── Movement (per engine type)
    ├── Collision Detection
    │
    ▼
Impact / Damage Calculation
    │
    ├── CalculateWeaponArmorDamage
    │   ├── Base Damage × Armor Modifier
    │   │   ├── Light Armor: Full damage
    │   │   ├── Medium Armor: Reduced damage
    │   │   └── Heavy Armor: Further reduced
    │   ├── × Upgrade Multiplier (Workshop)
    │   └── × Commander Skill Modifier
    │
    ├── Apply Damage to Target
    │   ├── OnUnitTakingDamage event
    │   ├── addCommandUnitDamage event
    │   ├── DelayedHideHealthBar (timer)
    │   └── ShowUniqueHitEffect (impact VFX)
    │
    ▼
Health System
    │
    ├── HP Reduction
    │   ├── GetNormalizedHealth (for health bar)
    │   ├── ShowHealthBar (on damage taken)
    │   └── DelayedHideHealthBar (after no damage)
    │
    ├── HP reaches 0 → Unit Death
    │   ├── ClientUnitDeath event
    │   ├── Death Animation/VFX
    │   │   ├── boom_unit_expl* (unit explosions)
    │   │   ├── boom_rifle* (infantry death)
    │   │   └── hero_*_death (hero-specific)
    │   ├── Entity cleanup
    │   └── Statistics update
    │
    └── Building Destruction
        ├── BuildingDestroyed entity
        ├── bld_destroy*_s* (destruction VFX)
        ├── debris_bld_s* (debris particles)
        └── rubble left on map
```

---

## 4. Ability/Hero Data Flow

```
Hero Unit Produced (X-Facility / Prototype Factory)
    │
    ├── Consumes Uranium Resource
    │   ├── HeroEnergyAccelerateBatteryRequest (if needed)
    │   └── HeroUraniumDebugRequest (debug)
    │
    ▼
Hero Active in Battle
    │
    ├── Passive Ability
    │   │   ├── Always active (e.g., Atlas passive shield)
    │   │   ├── AuraEffectController applies effects
    │   │   └── Automatic trigger on conditions
    │   │
    ├── Active Ability
    │   │   ├── Player activates via UI
    │   │   ├── OnAbilityCooldownHandler check
    │   │   │   ├── On cooldown → Cannot use
    │   │   │   └── Ready → Execute ability
    │   │   ├── AbilityReactOn → Activate
    │   │   ├── ExecuteOnAbilityReaction → Apply effects
    │   │   ├── Start cooldown timer
    │   │   └── AbilityReactOff → Deactivate
    │   │
    │   └── Ability Effects
    │       ├── Damage (hero_fire_*, hero_impact_*, hero_bul_*)
    │       ├── Shield (hero_atlant_immortality, spec_shield_*)
    │       ├── Stealth (hero_beholder_scanner)
    │       ├── Buff/Debuff (eff_stat_buff_armor/health)
    │       ├── Area Effect (hero_codomash_active_ability)
    │       └── Transformation (hero_seraphim_turbine_up/down)
    │
    ▼
Hero Death
    │
    ├── hero_*_death VFX
    ├── hero_seraphim_boom_air_death (air mode death)
    ├── hero_leviaphan_death (Leviathan explosion)
    └── Cannot be revived (Uranium cost lost)
```

---

## 5. Network Data Flow

```
Client Action
    │
    ▼
Command Serialization
    │
    ├── Command Type (Move, Attack, Build, Train, Ability)
    ├── Target Entity ID / Position
    ├── Timestamp (client time)
    └── Additional Parameters
    │
    ▼
Network Layer (com.geargames.aow.scenes.battle.network)
    │
    ├── Encrypt if sensitive (RSA/DES for billing, auth)
    ├── Send to Battle Server
    │
    ▼
Server Processing
    │
    ├── Validate command
    ├── Update game state
    ├── Calculate results
    ├── Broadcast to all clients
    │
    ▼
Client Update
    │
    ├── Receive server state
    ├── Reconcile with local prediction
    ├── Update entities
    ├── Update UI
    │
    ▼
Rendering Update
    │
    ├── Update positions
    ├── Update animations
    ├── Update VFX
    └── Update health bars / UI
```

---

## 6. Meta-Progression Data Flow

```
Battle End
    │
    ▼
Result Calculation
    │
    ├── Win/Loss
    ├── Experience earned
    ├── Credits earned
    ├── Skill Points earned (win only)
    ├── Star rating change
    │
    ▼
ReturnFromBattleRequest → ReturnFromBattleAnswer
    │
    ▼
Profile Update
    │
    ├── SetExperience → Level up check → NextProfileLevelNotification
    ├── SetProfileCredits → Update currency
    ├── SetStars → Rating change → NextLeagueNotification
    ├── SetSkillPoints → Available for Commander Skills
    └── SetHeroInfo → Hero statistics update
    │
    ▼
Workshop Interaction
    │
    ├── StartUpgradeRequest
    │   ├── Select prototype to upgrade
    │   ├── Select upgrade slot
    │   ├── Verify cost (credits, time)
    │   └── StartUpgradeAnswer (timer begins)
    │
    ├── Upgrade Progress
    │   ├── ActiveUpgradeNotification (timer running)
    │   ├── SpeedUpActiveUpgradeRequest (use speed-up item)
    │   ├── AccelerateUpgradeRequest (premium)
    │   │   ├── AdsAccelerateUpgradeRequest (watch ad)
    │   │   └── SpeedUpAccelerateUpgradeRequest (gold)
    │   └── CompleteActiveUpgradeRequest (timer done)
    │
    └── Upgrade Complete
        ├── UpgradeAnswer (success)
        ├── Stat improvement applied
        └── UI update
```

---

## 7. Save/Persistence Data Flow

```
Local Data (SQLite + PlayerPrefs)
    │
    ├── Player Settings
    │   ├── GameplaySettings (resolution, quality)
    │   ├── GGPlayerSettingBool/Float
    │   ├── AudioSettings
    │   └── HotkeyInfo
    │
    ├── Cached Resources
    │   ├── Addressables cache
    │   └── DeserializeCachedResources
    │
    └── Local Account State
        └── Session tokens

Server-Side Persistence (Database)
    │
    ├── Account
    │   ├── Profile (name, avatar, level, experience)
    │   ├── Faction choice
    │   ├── Resources (credits, gold, tokens, uranium)
    │   └── Statistics (wins, losses, rating)
    │
    ├── Upgrades
    │   ├── Per-prototype upgrade levels
    │   ├── Active upgrade timers
    │   └── Upgrade history
    │
    ├── Commander Skills
    │   ├── Skill cards owned
    │   ├── Skill series progress
    │   └── Skill point allocation
    │
    ├── Career Progress
    │   ├── Episode completion
    │   ├── Mission stars
    │   └── Campaign state
    │
    ├── Clan
    │   ├── Membership
    │   ├── Contributions
    │   └── World War participation
    │
    └── Social
        ├── Friends list
        ├── Chat ignore lists
        └── Recruiting info
```
