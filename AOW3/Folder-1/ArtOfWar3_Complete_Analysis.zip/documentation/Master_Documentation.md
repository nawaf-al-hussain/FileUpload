# Art of War 3: Global Conflict — Master Documentation

## Table of Contents

1. [Executive Summary](#1-executive-summary)
2. [Game Overview](#2-game-overview)
3. [Technical Architecture](#3-technical-architecture)
4. [Gameplay Systems](#4-gameplay-systems)
5. [Unit Encyclopedia](#5-unit-encyclopedia)
6. [Building Encyclopedia](#6-building-encyclopedia)
7. [Hero Units](#7-hero-units)
8. [Campaign System](#8-campaign-system)
9. [Multiplayer Architecture](#9-multiplayer-architecture)
10. [Network Protocol](#10-network-protocol)
11. [Economy and Progression](#11-economy-and-progression)
12. [AI Systems](#12-ai-systems)
13. [Asset Pipeline](#13-asset-pipeline)
14. [Data and Persistence](#14-data-and-persistence)
15. [Recreation Blueprint](#15-recreation-blueprint)
16. [Cross-Reference Index](#16-cross-reference-index)

---

## 1. Executive Summary

Art of War 3: Global Conflict is a mobile real-time strategy game developed by Gear Games, Ltd., built on the Unity 3D engine with an IL2CPP scripting backend. The game features two distinct factions (Confederation and Resistance), each with 15 standard units, 14 buildings, 3 hero unit tiers, and a unique superweapon. The game supports 1v1 and 2v2 PvP, campaign missions (~100 total), tournaments, clan wars, and a training mode.

The technical architecture follows a domain-driven design with Zenject dependency injection, server-authoritative networking, and Unity Addressables for on-demand asset loading. The client communicates via a persistent main server connection for meta-game operations and ephemeral battle server connections for real-time gameplay, using a tick-based synchronization model with client prediction.

This documentation was produced through complete APK reverse engineering of version 6.5.22 (package: com.geargames.aow, 188MB, 6,456 files) combined with extensive web research from official sources, community wikis, patch notes, and developer communications. It contains enough detail for a developer to understand and recreate the game's systems without needing to inspect the APK or search the internet.

---

## 2. Game Overview

### 2.1 Basic Information

| Field | Value |
|-------|-------|
| Full Title | Art of War 3: Global Conflict |
| Developer | Gear Games, Ltd. (CEO: Artem Shumsky) |
| Publisher | Gear Games, Ltd. (Global); Tencent Games (China, terminated Feb 2023) |
| Engine | Unity 3D with IL2CPP (metadata version 31) |
| Platforms | iOS (13.0+), Android (4.0+) |
| Package ID | com.geargames.aow |
| Version Analyzed | 6.5.22 |
| File Size | 188.6 MB |
| Genre | Real-Time Strategy (RTS) |
| Model | Free-to-play with in-app purchases |
| Connection | Always-online, client-server |
| Release | iOS ~2016-2017, Android followed |

### 2.2 Factions

**Confederation (Alliance Army)**: "We tried to build a new and perfect world without wars and violence. But today, we must rise in arms against the global threat. We have the newest technologies and most powerful military vehicles." Playstyle: High technology, powerful weapons, heavy armor, direct confrontation.

**Resistance (Rebellion Army)**: "We are the liberation army. We are fighting for freedom, justice, and our human rights. Our strength lies in speed, stealth and surprise. Our weapons are reliable and tested by time." Playstyle: Speed, stealth, surprise attacks, guerrilla tactics, forest concealment, fog mechanics.

### 2.3 Codebase Statistics

| Metric | Value |
|--------|-------|
| Total Types (IL2CPP) | 29,334 |
| Total Methods | 140,824 |
| Custom Assemblies | 141 |
| Network Message Types | 189+ |
| Game-specific Types | 9,516 |
| Asset Catalog Entries | 773 |
| Asset Bundles | 23 |
| Map Scenarios | 8 |
| Key Namespaces | 150+ (com.geargames.aow.* + Domains.*) |

---

## 3. Technical Architecture

### 3.1 Engine and Framework Stack

| Component | Technology | Purpose |
|-----------|-----------|---------|
| Game Engine | Unity 3D (IL2CPP backend) | Core rendering, physics, scene management |
| Dependency Injection | Zenject | Service resolution, modular architecture |
| Async Framework | UniTask | Allocation-free async/await |
| Reactive Framework | UniRx + R3 | Event-driven data flow |
| Animation | DOTween / DOTweenPro | Tweening and animation |
| Serialization | Newtonsoft.Json, Odin Inspector | Data serialization |
| Asset Management | Unity Addressables | On-demand asset loading |
| Local Database | SQLite (SQLitePCLRaw) | Local persistence |
| Analytics | Firebase Analytics + AppMetrica | Usage tracking |
| Crashlytics | Firebase Crashlytics | Error reporting |
| Ads | AppLovin MAX + IronSource | Ad mediation |
| Billing | Google Play Billing + Huawei HMS | In-app purchases |
| Push Notifications | Firebase Messaging + GGNotifications | Push alerts |
| Social | Google Play Games | Social features |

### 3.2 Assembly Structure

Key game assemblies (from ScriptingAssemblies.json):

| Assembly | Purpose |
|----------|---------|
| ScriptsAssembly.dll | Core game logic, battle, entities, GUI, AI, network messages |
| Assembly-CSharp.dll | Unity scene scripts, plugins, particle scaler |
| MegamapAssembly.dll | Map editor and detail brushes |
| Entities.dll | Entity component system |
| NetworkBase.dll | Network infrastructure |
| ClientConfiguration.dll | Client configuration |
| ClientRemoteParams.dll | Remote parameter management |
| LoggerAssembly.dll | Logging framework |
| ResourcesBase.dll | Resource management base |
| ResourceDispatcher.dll | Resource loading dispatch |
| LocalizationBase.dll | Localization system |

### 3.3 Scene Architecture

| Scene | Namespace | Purpose |
|-------|-----------|---------|
| Startup | AOW_Assets.Scripts.Startup | App boot, SDK init |
| Logon | com.geargames.aow.scenes.logon | Auth, faction select, settings |
| Main | com.geargames.aow.scenes.main | Hub: workshop, clan, chat, lobby, store |
| Battle | com.geargames.aow.scenes.battle | Core RTS gameplay |
| BattleLoading | com.geargames.aow.scenes.battleloading | Asset loading, connection |
| BattleLogout | com.geargames.aow.scenes.battlelogout | Post-battle cleanup |
| Relogon | com.geargames.aow.scenes.relogon | Re-authentication |

### 3.4 Domain-Driven Design

The codebase uses DDD with the following bounded contexts:

- **Domains.Account**: Player account, game mechanics, league management
- **Domains.Authorization**: Login, registration, faction selection
- **Domains.Campaign**: Episode and mission progression
- **Domains.Career**: Career/rank progression and rewards
- **Domains.Chat**: Multi-room chat system (7 room types)
- **Domains.Clan**: Clan management, World War
- **Domains.Competition**: Tournaments, Battle Pass, co-op matching
- **Domains.PlayerResources**: Resource management
- **Domains.Rating**: Leaderboards and ranking
- **Domains.Skills**: Commander skills and card system
- **Domains.Tutorial**: Tutorial system
- **Domains.UiManagement**: Dynamic window management
- **Domains.Workshop**: Persistent unit/building upgrades (weapon stats, modifications)
- **Domains.ReleaseManagement**: A/B testing, feature flags

---

## 4. Gameplay Systems

### 4.1 Core RTS Mechanics

**Direct Control System**: Classic PC RTS control scheme adapted for mobile. Players can select individual units by tapping, select groups by rectangle or polygon dragging, and issue move, attack, and patrol commands. Multi-selection supports up to full-army control with a central unit reference.

**Fog of War**: True fog of war where unexplored territory is completely hidden. Enemy bases and supply containers are not displayed until scouted. The Chameleon unit creates a localized ionized fog barrier that conceals allied units from enemy detection; only scouts entering the fog can reveal hidden units.

**Rally Path System**: Players can set rally paths for newly produced units. Multi-lane formation operations are supported with free unit deployment.

**Aircraft Fuel System**: Fixed-wing aircraft (Vertex, Thor, Hawk, Albatross) have limited fuel and must return to the Airport for refueling and repairs. Helicopters (Whirlwind, Dragonfly) do not require airports and have unlimited flight time.

**Submarine Stealth**: Submarines (Barracuda) are invisible when submerged. Only specific detection units (Viking, Whirlwind) and defensive platforms (Torpedo Launch Platform, Naval Platform) can detect submerged submarines.

**Superweapons**: Each faction has a unique superweapon that charges over time during battle. The Confederation's Space Strike System delivers an orbital satellite strike with higher damage per strike but longer charge time. The Resistance's Nuclear Missile Launcher fires nuclear missiles with faster fire rate but less structural durability.

### 4.2 Combat System

**Armor/Damage Model**: Three armor classes (Light/Medium/Heavy) with weapon damage varying by target armor type. Each weapon has separate damage values against each armor class.

**Damage Formula** (reconstructed):
```
Final Damage = BaseWeaponDamage(ArmorClass) × UpgradeMultiplier × CommanderSkillModifier
```

**Projectile Physics**: Six bullet engine types provide distinct projectile behaviors:
1. Linear: Direct fire for rifles and tank guns
2. Ballistic: Arc trajectory for artillery
3. Ballistic High: High arc for long-range artillery
4. Adjustable Ballistic: Variable arc for specialized weapons
5. Self-Directed: Homing projectiles for missiles and torpedoes
6. Chain Lightning: Multi-target chain effect for Coiltank/PsiTank

**Mine System**: Mines can be laid by Armadillo (land) and Caiman (naval). Mine stats include cost, damage per armor type (light/medium/heavy), explosion radius, and set time. The Fortress has mine detection capability.

### 4.3 Economy

**Dual Resource System**: Supplies (generated continuously by Supply Centers) and Power (capacity provided by Power Plants). Every building has an energy cost, and constructing beyond power capacity is impossible until more Power Plants are built.

**Supply Generation**: Rate determined by Supply Center level, Workshop upgrades (Resource Planning), and Commander Skills. Diminishing returns at higher Supply Center counts (7th center adds only ~30-50 resources/minute at Rank 18).

**Supply Crates**: Scattered across maps as bonus pickups. Collection triggers VFX (eff_collect_box, eff_collect_container, eff_collect_tree).

**Building Construction**: Approximately 40 seconds base time. Upgrade times are longer and scale with level. Premium accounts can complete upgrades 30 minutes before timer expiry.

---

## 5. Unit Encyclopedia

### 5.1 Confederation Units (15 standard + heroes)

**Infantry**: Assault Trooper (anti-infantry), Heavy Assault Trooper (anti-vehicle), Firepower Assault Trooper (jetpack CQB)

**Vehicles**: Fortress (support + mine detection), Warhammer (fast medium tank), Zeus (heavy assault tank)

**Special Vehicles**: Hurricane (anti-air, double efficiency stationary), Torrent (MLRS artillery, siege mode), Energy Shield (armor buff aura)

**Aviation**: Whirlwind (recon helicopter + sub detection), Vertex (fighter, limited fuel), Thor (bomber, one bomb per sortie)

**Navy**: Delta (amphibious assault), Viking (destroyer + sub detection), Poseidon (missile cruiser, extreme range)

**Superweapon**: Space Strike System (orbital satellite)

### 5.2 Resistance Units (15 standard + heroes)

**Infantry**: Rifleman (forest stealth + smoke grenades), Grenadier (jungle ambush), Sniper (long-range anti-armor)

**Vehicles**: Prairie Wolf (ultra-light recon), Armadillo (mine layer), Jaguar (dual-mode tank: travel/siege)

**Special Vehicles**: Porcupine (AA + ground), Mammoth (long-range howitzer, siege mode), Chameleon (fog barrier stealth)

**Aviation**: Dragonfly (recon helicopter), Hawk (multirole fighter, limited fuel), Albatross (nearly indestructible bomber)

**Navy**: Caiman (fast mine layer), Alligator (heavy destroyer), Barracuda (stealth submarine)

**Superweapon**: Nuclear Missile Launcher

---

## 6. Building Encyclopedia

### 6.1 Administrative (Both Factions)

| Building | Function | Dependencies |
|----------|----------|-------------|
| Headquarters | Core building, unlocks higher tiers | Starting |
| Construction Yard | Builds/upgrades/repairs structures | HQ |
| Power Plant | Provides power capacity | HQ |
| Supply Center | Generates supplies continuously | HQ + Power Plant |

### 6.2 Military (Both Factions)

| Building | Produces | Levels | Requires |
|----------|----------|--------|----------|
| Barracks | Infantry (3 types) | 3 | Power Plant + Supply Center |
| Assault Vehicle Factory | Combat vehicles (3 types) | 3 | Barracks |
| Special Vehicle Factory | Support vehicles (3 types) | 3 | Assault Vehicle Factory |
| Avia Factory | Helicopters/Fighters (3 types) | 3 | Barracks |
| Airport | Refueling/repairs | 1 | Avia Factory |
| Shipyard | Naval units (3 types) | 3 | Barracks |

### 6.3 Faction-Specific Buildings

**Confederation**: X-Facility (hero production), Aerial Strike System (superweapon), Bunker, Rocket Launch Tower, Anti-Air Center, Torpedo Launch Platform

**Resistance**: Prototype Factory (hero production), Intercontinental Missile Launcher (superweapon), Sniper Tower, Cannon Tower, Anti-Air Tower, Naval Platform

**Both**: Wall (defensive blocker, requires strategy purchase)

---

## 7. Hero Units

### 7.1 Confederation Heroes

| Hero | Tier | Key Mechanics |
|------|------|--------------|
| Cerberus | T1 | Jump jets, machine gun, grenade, knife, fly-death |
| Seraphim | T2 | Air/ground mode switch, kara + lazergun, turbine |
| Psion | T2 | Psi-energy waves (active/passive), attack speed slow |
| Solaris | T2 | Speed-based, gun + impulse + lightning |
| Atlas | T3 | Passive shield blocks attacks, barrage, immortality |
| Confozord | T3 | Ultimate weapon of retribution |

### 7.2 Resistance Heroes

| Hero | Tier | Key Mechanics |
|------|------|--------------|
| Wolverine | T1 | Machine gun with acceleration, counters Cerberus |
| Salamander | T2/T3 | Missile barrages, turbo, amphibious |
| Bison | T3 | Defeats Atlas and Leviathan in combat |
| Leviathan | T3 | Air + nuclear + ground, nuclear rocket |

### 7.3 Additional Hero Units

Coiltank (chain lightning), Cryotank (frost), Gatling (explosive), Railgun (3 modes), Beholder (laser + scanner), Wasp (flying, acid), Codomash (turret deployment)

---

## 8. Campaign System

### 8.1 Structure

- Total missions: ~100 (approximately 50 per faction)
- First 6 missions: Tutorial (forced progression)
- Two difficulty levels: Easy and Hard
- Three-star clearance system with corresponding rewards

### 8.2 Mission Types

- Squad combat (infantry-only missions)
- Base defense (protect HQ against waves)
- Supply escort (protect resource convoys)
- Strategic point capture (hold positions)
- Enemy base destruction (offensive missions)

### 8.3 Progression

Campaign completion unlocks buildings and upgrades for multiplayer. Each mission has objectives, story events, triggers, AI behavior scripts, reinforcement schedules, and victory/defeat conditions. Campaign missions gradually introduce all building types and unit capabilities.

---

## 9. Multiplayer Architecture

### 9.1 Game Modes

| Mode | Players | Description |
|------|---------|-------------|
| 1v1 PvP | 2 | Standard ranked/unranked |
| 2v2 Co-op | 4 (2v2) | Team battles via lobby system |
| Tournament | 2+ | Ranked, bi-weekly, unique rules |
| Clan War | Many | Monday-Wednesday, minimum 20 kills |
| Training | 2 | Free, equal upgrades |
| Modifications | 2+ | Equal level (Rank 18, Series 10) |

### 9.2 Matchmaking

Server-side evaluation of: skill level, rank, stars, win rate, connection quality. Server selects optimal region. Tournament matching based solely on current tournament winrate.

### 9.3 Maps

8 built-in maps (1_2, 1_3, 1_4, 1_5, 1_6, 3_2, 4_1, pvp_11) with desert and jungle biomes. Maps feature land, sea, and air battle zones with supply crates scattered throughout.

---

## 10. Network Protocol

### 10.1 Architecture

Two-tier connection model: persistent main server (auth, profile, chat, clan, matchmaking) and ephemeral battle servers (game simulation, command relay, state sync). Server-authoritative with client prediction.

### 10.2 Message Pattern

All messages follow Request → Answer (synchronous) or Notification (async push) patterns. ComplexMessage for large data. RSA/DES encryption for sensitive operations.

### 10.3 Key Message Flows

- **Authentication**: LoginRequest → LoginAnswer → SessionRestoreRequest → SessionRestoreAnswer
- **Battle**: ReadyToBattleRequest → MatchingIsFinished → LoginToBattleRequest → LoginToBattleAnswer → (gameplay) → BattleFinishNotification → BattleResultRequest → BattleResultAnswer → ReturnFromBattleRequest
- **Lobby**: LobbyCreateRequest → LobbyOutcomeInviteRequest → LobbyIncomeInviteConfirmRequest → LobbyBattleStartRequest
- **Upgrade**: StartUpgradeRequest → UpgradeNotification → CompleteActiveUpgradeRequest → UpgradeAnswer
- **Time Sync**: PeriodicTimeSynchronizationUpdate, TimeSyncRequest/Answer, Ping/Pong

### 10.4 Reconnection

BattleSessionRestoreRequest → BattleSessionRestoreAnswer enables mid-battle reconnection. UpdateResumptionBattleActivityCoroutine manages the resumption state.

---

## 11. Economy and Progression

### 11.1 Resources

| Resource | Source | Use |
|----------|--------|-----|
| Supplies | Supply Centers (battle) | Construction, units, repairs |
| Power | Power Plants (capacity) | Building operation |
| Uranium | Meta-progression | Hero activation |
| Credits | Battle rewards | Upgrades |
| Gold | Premium | Speed-ups |
| Skill Points | Battle wins | Commander skills |
| Tokens | Events | Special purchases |

### 11.2 Workshop (Meta-Progression)

Persistent upgrades across battles: unit HP, armor, damage, production speed, weapon range, accuracy, fire rate, explosion radius, mine stats, superweapon stats. Upgrades are time-gated with premium speed-up options.

### 11.3 Commander Skills

Skill Points earned by winning battles. Multiple skill series available. Skills influence battle parameters (speed, damage, armor, economy, superweapon charge rate). Tournament-specific skill resets available.

---

## 12. AI Systems

### 12.1 Campaign AI

Scripted mission logic with trigger-based behavior, pre-defined attack waves, difficulty scaling, and reinforcement scheduling.

### 12.2 Skirmish/PvP AI (GAI)

Strategic decision-making (build order, economy), tactical combat (unit composition, positioning), target prioritization, and resource management.

### 12.3 Unit AI

Target acquisition, aggro range, auto-attack, return fire, firing-while-moving vs. siege-mode behavior.

---

## 13. Asset Pipeline

### 13.1 Addressables System

23 asset bundles with 773 catalog entries. Built-in maps load per-battle. VFX, decorations, and biome-specific assets loaded on demand during battle loading. Default local group and shaders loaded at startup.

### 13.2 Asset Categories

- Maps: 8 scenarios with prefabs and minimaps
- VFX: 200+ effect prefabs (explosions s0-s6, projectiles, hero effects, building effects)
- Models: Desert (12 models), Jungle (22 models), War objects (3 models)
- Materials: 30+ materials for effects, decorations, terrain
- Shaders: Landscape, FloraMask, Water, effect shaders
- UI: Faction selection, battle animations, daily entrance panels

---

## 14. Data and Persistence

### 14.1 Client-Side

- SQLite via SQLitePCLRaw for local caching
- PlayerPrefs for settings (gameplay, audio, hotkeys)
- Addressables cache for downloaded assets
- Session tokens for authentication

### 14.2 Server-Side

- Full account state (profile, resources, upgrades, skills)
- Upgrade timers and progression state
- Clan data and World War state
- Chat history and moderation records
- Match history and statistics
- Billing and transaction records

---

## 15. Recreation Blueprint

### 15.1 Recommended Stack

Unity 2022.3 LTS, C# with IL2CPP, Custom TCP + Protobuf networking, PostgreSQL + Redis, Unity Addressables, Zenject/VContainer, UniTask, R3, DOTween, JWT + OAuth2 authentication.

### 15.2 Key Architecture Decisions

1. Server-authoritative model for competitive integrity
2. Tick-based simulation at fixed rate for determinism
3. Domain-driven design for modularity and testability
4. Addressables for on-demand asset loading (reduces initial download)
5. Client prediction with server reconciliation for responsive controls
6. Zenject DI for loose coupling and testability

### 15.3 Data Model

Core entities: Unit (with prototype, weapons, abilities), Building (with production queue), Bullet (with engine type), Account (with profile, upgrades, skills), BattleState (with tick, players, entities). Full model specification available in Recreation_Blueprint.md.

---

## 16. Cross-Reference Index

### Documents in This Package

| Document | Content |
|----------|---------|
| Architecture_Dependency_Graph.md | System dependencies, initialization, service map |
| Class_Relationship_Map.md | Inheritance, interfaces, managers, factories |
| Game_Runtime_Flow.md | Launch, login, match, gameplay, completion flows |
| Data_Flow_Analysis.md | Input, resource, combat, ability, network flows |
| Multiplayer_Architecture.md | Network model, protocol, synchronization |
| Units_and_Buildings.md | Complete encyclopedia with stats |
| Gameplay_Analysis.md | Core RTS, economy, combat, progression systems |
| Asset_Catalog.md | All 773 assets, VFX, maps, shaders |
| Recreation_Blueprint.md | Architecture, data models, gameplay loop spec |
| Master_Documentation.md | This document — comprehensive reference |

### Key Source Files in APK

| File | Purpose |
|------|---------|
| assets/aa/catalog.json | Addressable asset catalog (773 entries) |
| assets/aa/AddressablesLink/link.xml | Type preservation for IL2CPP stripping |
| assets/bin/Data/Managed/Metadata/global-metadata.dat | IL2CPP type metadata (29,334 types) |
| assets/bin/Data/ScriptingAssemblies.json | Assembly list (244 assemblies) |
| assets/bin/Data/boot.config | Unity boot configuration |
| classes.dex through classes8.dex | Java/Kotlin bytecode (8 DEX files) |
| AndroidManifest.xml | Application manifest |
