# Art of War 3: Class Relationship Map

## 1. Inheritance Chains

### 1.1 Core Game Class Hierarchy

```
MonoBehaviour (Unity)
├── BattleScreen
│   ├── BattleEffectsContext
│   └── BattleOptimizator
├── BattlePrefabHelper
├── ClientBattleHelper
├── ClientUnitHelper
├── ClientBuildingHelper
├── ClientMineHelper
├── ClientFirePrefabs
├── FlashPrefabCreator
├── ParticleScaler
└── AudioBattleSoundsHandler

ScriptableObject (Unity)
├── GameplaySettings
├── DesktopHotkeysSettings
├── CrpBattlePoolsControllerSettings
├── BombersRouteSettings
└── HeroSelectionItems

ZenjectBinding / Installer
├── FactionSelectSectionInstaller
├── TutorialInstaller
├── UiManagementInstaller
├── TextInputWindowInstaller
├── DebugInstaller
└── (Various Domain Installers)
```

### 1.2 Entity Inheritance

```
com.geargames.aow.entities
├── Building
│   ├── BuildingDestroyed
│   ├── BuildingRepair
│   └── BuildingOccupationCellDelegate
├── Bullet
│   └── BulletStack
├── Account
├── Achievement
├── Avatar / AvatarElement
├── BoostType / BuffType / AuraType
├── Coordinate
├── CellScheduleStack
├── CheckPoint
├── Daily
├── Battery (Hero Energy)
└── AdsInfo / AdsParams

com.geargames.aow.entities.battle
├── descriptions (Battle Descriptors)
├── conditions (Win/Loss Conditions)
├── bot (AI Bot Controller)
├── aicomm (AI Communication)
└── flight (Air Unit Movement)
```

### 1.3 Network Message Hierarchy

```
OutgoingMessage (Base)
├── LoginRequest
├── RegistrationRequest
├── SessionRestoreRequest
├── ChooseProfileRequest
├── BattleResultRequest
├── UpgradeRequest / AccelerateUpgradeRequest
├── LobbyCreateRequest / LobbyBattleStartRequest
├── JoinPvpPlayersRequest / JoinToPvPMissionRequest
├── ClanCreateRequest / ClanLeaveRequest / ClanChangeNameRequest
├── ChatPostRequest (Multiple Room Variants)
└── TimeSyncRequest / ConnectionCheckRequest

Answer (Base)
├── LoginAnswer
├── RegistrationAnswer
├── SessionRestoreAnswer
├── UpgradeAnswer / AccelerateUpgradeAnswer
└── (Mirror of each Request)

NotificationMessage (Base)
├── BattleFinishNotification
├── StartBattleNotification
├── GoToBattleNotification
├── UpgradeNotification
├── ClanHistoryNotification
├── ChatPostNotification (Multiple Variants)
└── CompetitionEndNotification

ComplexMessage / ComplexBattleMessage
├── SpecialCommandMessage
├── AddEntity / ChangeEntity / ChangeEntityComplex / DeleteEntity
└── RsaDesPacketRequest / RsaDesPacketAnswer
```

---

## 2. Interface Relationships

### 2.1 Domain Interfaces (Dependency Inversion)

```
Domains.Workshop.Api
├── IWorkshopNavigator
├── IProduceModel
├── IPrototypeAbilityModel
├── IPrototypeAvailabilityModel
├── IPrototypeModel
├── IWeaponTarget
├── IPrototypeRepository
├── IUpgradeService
├── IWorkshopUiModel
├── ICellUpgradeModel
├── IUpgradeRequirements
└── IPrototypeUpgradeModel

Domains.Skills.Api
├── ISkillModel
└── ISkillCardModel

Domains.Clan.Api
├── IClanModel
├── IClanService
└── IClanParticipantModel

Domains.Account.Api
├── IAccountModel
├── IFactionSelectModel
└── IProfileModel

Domains.Campaign.Api
├── ICampaignService
├── IMissionModel
└── IEpisodeModel

Domains.Chat.Api
├── IChatService
├── IChatRoomModel
└── IChatMessageModel

Domains.Competition.Api
├── ICompetitionService
├── ICompetitionModel
└── IBattlePassModel

Domains.UiManagement.Api
├── IUIModel<T>
├── IDynamicWindowDispatcher
├── ITextInputWindowBuilder
├── IClientUnlockModel
└── ITabListSource<T>
```

### 2.2 Service Locator Pattern (via Zenject)

The game uses Zenject for dependency injection. Key bindings:

```
Container.Bind<IWorkshopNavigator>().To<WorkshopNavigator>()
Container.Bind<IPrototypeRepository>().To<PrototypeRepository>()
Container.Bind<IUpgradeService>().To<UpgradeService>()
Container.Bind<IClientUnlockModel>().To<ClientUnlockModel>()
Container.Bind<IDynamicWindowDispatcher>().To<TextInputWindowDispatcher>()
```

---

## 3. Manager/Singleton Systems

### 3.1 Manager Classes (Service Pattern)

| Manager | Responsibility | Scope |
|---------|---------------|-------|
| `StartupManager` | App initialization sequence | Global |
| `BattleScreen` | Battle scene lifecycle | Battle Scene |
| `ClientBattleContext` | Battle state management | Battle Scene |
| `BattleOptimizator` | Performance optimization | Battle Scene |
| `BattlePrefabHelper` | Prefab loading/instantiation | Battle Scene |
| `ClientBattlePools` | Object pooling for battle entities | Battle Scene |
| `ClientFirePrefabs` | Weapon fire effect pooling | Battle Scene |
| `ClientUnitPrefabs` | Unit visual prefab management | Battle Scene |
| `ClientBuildingPrefabs` | Building visual prefab management | Battle Scene |
| `ClientMinePrefabs` | Mine visual prefab management | Battle Scene |
| `CachedResources` | Resource caching layer | Global |
| `BattleQualitySetter` | Graphics quality management | Battle Scene |
| `EntityDictionary<T>` | Fast entity lookup by ID | Battle Scene |

### 3.2 Factory Pattern

| Factory | Product |
|---------|---------|
| `GUILoadingWindowFactory` | Loading screen instances |
| `SlotUpgradesModelFactory` | Upgrade slot data models |
| `IPrototypeWeaponListFactory` → `PrototypeWeaponListFactory` | Weapon lists for prototypes |
| `IWeaponStatsFactory<T>` → `WeaponStatsFactory` / `MineStatsFactory` | Weapon stat calculations |

---

## 4. Composition Relationships

### 4.1 Battle Entity Composition

```
Battle Entity (Unit/Building)
├── Transform Component (Position, Rotation, Scale)
├── Visual Component (Mesh, Material, Animator)
├── Health Component (HP, Armor, Shield)
├── Weapon Component(s)
│   ├── Damage Stats (per armor type)
│   ├── Range / Distance
│   ├── Fire Rate / Cooldown
│   ├── Accuracy
│   ├── Explosion Radius (if applicable)
│   └── Bullet Engine Type (Linear, Ballistic, SelfDirected, ChainLightning)
├── Movement Component
│   ├── Speed (Travel/Siege mode for Jaguar)
│   ├── Pathfinding Data
│   └── Fuel (Aircraft only)
├── Ability Component (Heroes)
│   ├── Active Ability
│   ├── Passive Ability
│   └── Cooldown Timer
├── Aura Component (if applicable)
│   ├── Effect Type (Shield, Speed, Armor)
│   ├── Radius
│   └── Duration
└── AI Component
    ├── Targeting Logic
    ├── Aggro Range
    └── Behavior State Machine
```

### 4.2 Player Account Composition

```
Account
├── Profile (Name, Avatar, Level, Experience)
├── Faction (Confederation / Resistance)
├── Rank / Rating (Stars, League)
├── Resources
│   ├── Credits (Soft Currency)
│   ├── Gold (Hard Currency)
│   ├── Tokens
│   ├── Uranium (Hero Resource)
│   └── Skill Points
├── Upgrades (Workshop)
│   ├── Unit Upgrades (per prototype)
│   ├── Building Upgrades (per type)
│   └── Active Upgrade Timers
├── Commander Skills
│   ├── Active Skill Cards
│   └── Skill Series Progress
├── Career Progression
│   ├── Episode Completion
│   └── Mission Stars
├── Clan Membership
├── Achievements
├── Daily Entrance Rewards
├── Modifications (Unit Mods)
└── Battle Statistics
    ├── Win Rate
    ├── Total Battles
    ├── PvP / PvE Record
    └── Clan War Stats
```

---

## 5. God Classes / Large Systems

The following classes have high method counts and likely serve as god classes or central coordinators:

| Class | Method Count (approx) | Role |
|-------|----------------------|------|
| `BattleScreen` | 50+ | Battle scene orchestrator |
| `ClientBattleHelper` | 40+ | Client-side battle coordination |
| `LogicService` | 35+ | Core simulation tick and command processing |
| `ClientUnitHelper` | 30+ | Unit lifecycle and management |
| `ClientBuildingHelper` | 25+ | Building lifecycle and management |
| `WorkshopNavigator` | 20+ | Workshop UI navigation |
| `WeaponStatsFactory` | 20+ | Weapon stat calculation hub |

---

## 6. Registry Pattern

| Registry | Contents |
|----------|----------|
| `BattleEntityIndex` | Fast lookup of all entities in battle |
| `EntityDictionary<T>` | Generic entity dictionary by type |
| `AbilityNamePrefabPair` | Maps ability names to prefabs |
| `ActionPrefabCollection` | Registry of battle action prefabs |
| `HeroSelectionPrefabCollection` | Hero selection screen prefabs |
| `CachedResources` | Loaded resource cache registry |
| `AudioGroups` | Sound group registry |

---

## 7. Event/Observer Pattern

The game uses both UniRx/R3 reactive patterns and traditional C# events:

**Reactive Streams:**
- Profile state changes → UI updates
- Upgrade completion → Notification system
- Chat messages → Room subscribers
- Battle state changes → GUI updates
- Resource changes → UI binding

**Event Handlers:**
- `addCommandUnitDamage` / `addCommandBuildingHealthChanged` - Battle damage events
- `OnUnitTakingDamage` - Unit damage callback
- `OnAbilityCooldownHandler` - Hero ability cooldown event
- `AbilityReactOn` / `AbilityReactOff` - Ability state changes
- `BuildingContextMenuUpdate` / `UnitContextMenuUpdate` - Context menu events
