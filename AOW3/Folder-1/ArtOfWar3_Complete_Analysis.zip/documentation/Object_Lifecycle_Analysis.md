# Object Lifecycle Analysis

## Art of War 3: Global Conflict — Entity Lifecycle Documentation

**Package**: `com.geargames.aow` | **Version**: 6.5.22 | **Engine**: Unity 3D (IL2CPP)

---

## 1. Overview

The game manages multiple object lifecycles that span from application-level singletons to per-frame bullet instances. Understanding these lifecycles is essential for reverse engineering because the creation, mutation, and destruction patterns reveal the game's memory management strategy, pooling behavior, and state synchronization mechanisms.

All object lifecycles operate within the Zenject dependency injection container, which governs instantiation and disposal. Objects that survive scene transitions are bound in the `StaticContext`, while scene-scoped objects are bound in `SceneContext` and destroyed on scene unload.

---

## 2. Application-Level Object Lifecycle

These objects are created at startup and persist for the entire application session.

### 2.1 Account Lifecycle

The `Account` object is the most persistent entity in the game, spanning the entire session from login to application termination.

```
┌─────────────────────────────────────────────────────────────────┐
│                    ACCOUNT LIFECYCLE                            │
│                                                                 │
│  CREATION (Login/Registration)                                  │
│     │                                                           │
│     ├── LoginRequest / RegistrationRequest sent                 │
│     ├── Server validates → LoginAnswer / RegistrationAnswer     │
│     ├── Account object instantiated with server state           │
│     ├── Session token stored in SQLite                          │
│     ├── Zenject binds Account as singleton in StaticContext     │
│     │                                                           │
│  ACTIVE SESSION                                                 │
│     │                                                           │
│     ├── Profile mutations via Set* messages:                    │
│     │    ├── SetProfileLevel (XP thresholds)                    │
│     │    ├── SetProfileCredits (currency changes)               │
│     │    ├── SetProfileTokens (premium currency)                │
│     │    ├── SetProfileUpgrade (upgrade completion)             │
│     │    ├── SetStars (achievement progress)                    │
│     │    ├── SetExperience (XP gain)                            │
│     │    ├── SetHeroInfo (hero unlock/level)                    │
│     │    ├── SetSkillPoints (skill allocation)                  │
│     │    ├── SetSkills (skill activation)                       │
│     │    ├── SetRerollKeys (shop reroll currency)               │
│     │    ├── SetSpeedUps (time skip currency)                   │
│     │    └── SetTickets (event entry currency)                  │
│     │                                                           │
│     ├── Career progression (Career domain)                      │
│     ├── Clan membership changes                                 │
│     ├── Resource gains/losses (PlayerResources domain)          │
│     │                                                           │
│  SUSPENSION (App backgrounded)                                  │
│     │                                                           │
│     ├── ConnectionCheckRequest/Answer heartbeat                 │
│     ├── Session restore if timeout exceeded                     │
│     │                                                           │
│  RESTORATION (Session restore)                                  │
│     │                                                           │
│     ├── SessionRestoreRequest { session_token }                 │
│     ├── Server validates → SessionRestoreAnswer { account }     │
│     ├── Account state refreshed from server                     │
│     └── Local SQLite cache updated                              │
│     │                                                           │
│  DESTRUCTION (Logout / App kill)                                │
│     │                                                           │
│     ├── Session token invalidated                               │
     ├── SQLite cache persists (for offline restore)
│     └── Zenject container disposes Account                      │
└─────────────────────────────────────────────────────────────────┘
```

**Memory Pattern**: The Account object is a fat singleton that holds references to all player-owned entities. It is never garbage collected during a session. Its sub-objects (Career, ArmyMatrix, etc.) are loaded lazily via UniTask when first accessed.

### 2.2 Network Connection Lifecycle

```
Application Start
     │
     ▼
DNS Resolution → TCP Connect to game server
     │
     ├── RsaDesPacketRequest (key exchange)
     ├── DES session key established
     │
     ▼
ACTIVE CONNECTION
     │
     ├── Heartbeat: Ping (1 Hz)
     ├── Health: ConnectionCheckRequest/Answer (adaptive frequency)
     ├── Clock: TimeSyncRequest/Answer (0.1 Hz)
     │
     ├── Server-initiated redirects:
     │    ├── GoToMainServer (server migration)
     │    ├── GoToRelogin (session expired)
     │    └── GoToUpdateClient (version mismatch)
     │
     ▼
DISCONNECTION
     │
     ├── Planned: Logout sequence
     ├── Unplanned: Network error → Reconnection flow
     └── Server-forced: GoToRelogin
```

---

## 3. Battle-Level Object Lifecycles

Battle objects have a well-defined lifecycle bounded by the battle session. They are created when the battle starts and destroyed when it ends.

### 3.1 Unit Lifecycle

```
┌─────────────────────────────────────────────────────────────────┐
│                    UNIT LIFECYCLE                               │
│                                                                 │
│  CREATION                                                       │
│     │                                                           │
│     ├── Produced by building (Barracks/Factory)                 │
│     │    ├── LogicService processes BuildUnit command           │
│     │    ├── Unit object instantiated from UnitType             │
│     │    ├── Initial position set to building rally point       │
│     │    └── AddEntity message sent to opponent client          │
│     │                                                           │
│     ├── Hero deployment (from ArmyMatrix)                       │
│     │    ├── Placed at start of battle or via ability           │
│     │    └── Full health + all abilities available              │
│     │                                                           │
│  IDLE STATE                                                     │
│     │                                                           │
│     ├── Awaiting commands at rally point                        │
│     ├── Auto-acquire targets if enemy in range                  │
│     ├── Auto-defend if attacked                                 │
│     └── Aura effects applied to nearby allies (AuraType)        │
│     │                                                           │
│  MOVEMENT                                                       │
│     │                                                           │
│     ├── Path calculated via CellScheduleStack                    │
│     ├── Transform updated per tick (interpolated for render)    │
│     ├── Collision avoidance with other units                    │
│     └── Movement speed affected by buffs/debuffs                │
│     │                                                           │
│  COMBAT                                                         │
│     │                                                           │
│     ├── Weapon target selection (EWeaponTarget: Air/Ground/All) │
│     ├── Attack cycle: Aim → Fire → Cooldown                     │
│     ├── Bullet spawned from weapon stats                        │
│     ├── Damage calculated: WeaponDamage × modifiers             │
│     ├── Armor mitigation: Light/Medium/Heavy                    │
│     ├── BuffType effects (attack speed, damage, armor)          │
│     ├── BoostType effects (temporary power-ups)                 │
│     │                                                           │
│     ├── Special ability activation:                             │
│     │    ├── Cerberus: Jump jet (reposition), Knife trail       │
│     │    ├── Atlas: Shield, Immortality                         │
│     │    ├── Psion: Attack speed reduction wave                 │
│     │    ├── Coiltank: Chain lightning (MaxTargetsStat)         │
│     │    └── etc.                                               │
│     │                                                           │
│  DAMAGE RECEIVED                                                │
│     │                                                           │
│     ├── Shield absorbs first (if Atlas or shield buff)          │
│     ├── Armor reduces damage                                    │
│     ├── Health reduced                                          │
│     ├── ChangeEntity message sent to opponent                   │
│     └── Visual feedback: health bar, hit flash                  │
│     │                                                           │
│  DEATH                                                          │
│     │                                                           │
│     ├── Health reaches 0                                        │
│     ├── UnitDeath behavior triggered:                           │
│     │    ├── Cerberus: Fly death animation                      │
│     │    ├── Standard units: Explosion/debris                   │
│     │    └── Hero units: Special death VFX                      │
│     │                                                           │
│     ├── DeleteEntity message sent to opponent                   │
│     ├── BulletStack and components returned to pool             │
│     ├── Unit removed from ClientBattleContext                   │
│     └── Death event published to UniRx stream                   │
└─────────────────────────────────────────────────────────────────┘
```

**Pooling**: Units and their components are pooled via Zenject's `MemoryPool` pattern. When a unit dies, its `GameObject` is deactivated and returned to the pool. When a new unit is produced, it is fetched from the pool and re-initialized with new state. This prevents garbage collection spikes during heavy battles.

### 3.2 Building Lifecycle

```
┌─────────────────────────────────────────────────────────────────┐
│                   BUILDING LIFECYCLE                            │
│                                                                 │
│  PLACEMENT                                                      │
│     │                                                           │
│     ├── Player selects BuildingType from Build Panel            │
│     ├── Valid placement check:                                  │
│     │    ├── BuildingSizeParameter (grid footprint)             │
│     │    ├── BuildingOccupationCellDelegate (cell availability) │
│     │    ├── Resource cost check (PlayerResources)              │
│     │    └── Placement rules (distance from base, etc.)         │
│     │                                                           │
│     ├── Building object instantiated                            │
│     ├── BuildingSetLocation (anchor to grid)                    │
│     ├── Coordinate assigned                                     │
│     ├── AddEntity message sent to opponent                      │
│     │                                                           │
│  CONSTRUCTION                                                   │
│     │                                                           │
│     ├── Build time countdown (varies by type/level)             │
│     ├── Visual: scaffolding / construction animation            │
│     ├── AccelerateUpgradeRequest (speed-up item)                │
│     └── Construction complete → Building operational            │
│     │                                                           │
│  OPERATIONAL                                                    │
│     │                                                           │
│     ├── Production buildings:                                   │
│     │    ├── Production queue (unit types, build times)         │
│     │    ├── Rally point management                             │
│     │    └── Production progress per tick                       │
│     │                                                           │
│     ├── Defensive buildings:                                    │
│     │    ├── Target acquisition (WeaponDistance, WeaponAccuracy) │
│     │    ├── Attack cycle (WeaponFireRate)                      │
│     │    └── Bullet spawning per attack                         │
│     │                                                           │
│     ├── Superweapon buildings:                                  │
│     │    ├── Charge accumulation (Cp per tick)                  │
│     │    ├── SuperWeaponStats (Cost, Time, SpaceStrikePrepTime) │
│     │    └── Launch sequence when fully charged                 │
│     │                                                           │
│     ├── Mine buildings:                                         │
│     │    ├── MineStats (Cost, Damage*, Radius, SetTime)         │
│     │    ├── MineComponent lifecycle                            │
│     │    └── ClientMineHelper management                        │
│     │                                                           │
│     └── Support buildings:                                      │
│          ├── Aura effects (AuraEffectController)                │
│          ├── Healing / supply / buff provision                  │
│          └── ShieldEmitPrefabSettings (shield VFX)              │
│     │                                                           │
│  DAMAGE & REPAIR                                                │
│     │                                                           │
│     ├── Health reduced by attacks                               │
│     ├── BuildingRepair (auto or manual repair)                  │
│     ├── BuildingDestroyed threshold reached:                    │
│     │    ├── Ruins state (may be repairable)                    │
│     │    ├── ChangeEntity message (health state)                │
│     │    └── Visual: destruction VFX, rubble                    │
│     │                                                           │
│  UPGRADE                                                        │
│     │                                                           │
│     ├── UpgradeRequest sent                                     │
│     ├── Upgrade in progress (timed)                             │
│     ├── SpeedUpActiveUpgradeRequest / CompleteActiveUpgrade     │
│     ├── CancelUpgradeRequest (refund)                           │
│     ├── UpgradeNotification (completion)                        │
│     └── BuildingLevelType advances, stats updated               │
│     │                                                           │
│  DESTRUCTION (battle end or manual)                             │
│     │                                                           │
│     ├── Building object returned to pool                        │
│     ├── DeleteEntity message sent                               │
│     └── Removed from ClientBattleContext                        │
└─────────────────────────────────────────────────────────────────┘
```

### 3.3 Bullet Lifecycle

Bullets are the shortest-lived objects in the game, typically existing for only a few frames to a few seconds.

```
┌─────────────────────────────────────────────────────────────────┐
│                   BULLET LIFECYCLE                              │
│                                                                 │
│  CREATION                                                       │
│     │                                                           │
│     ├── BulletStack pool fetch (pre-allocated)                  │
│     ├── BulletPrefabSettings applied (visual, speed, damage)    │
│     ├── BulletEngine assigned based on BulletEngineType:        │
│     │    ├── LinearBulletEngine → straight line                 │
│     │    ├── BallisticBulletEngine → parabolic arc              │
│     │    ├── SelfDirectedBulletEngine → homing trajectory       │
│     │    ├── AdjustableBallisticBulletEngine → variable arc     │
│     │    └── ChainLightingBulletEngine → instant chain          │
│     │                                                           │
│     ├── BulletTargetType set (single target, area, chain)       │
│     ├── Origin position = attacker's weapon muzzle              │
│     └── Target position = target's current coordinate           │
│     │                                                           │
│  FLIGHT                                                         │
│     │                                                           │
│     ├── Per-tick position update via BulletEngine               │
│     ├── LinearEngine: pos += direction × speed × dt             │
│     ├── BallisticEngine: pos += gravity × t² + velocity × t     │
│     ├── SelfDirectedEngine: pos += seek(target) × speed × dt    │
│     ├── AdjustableBallisticEngine: variable arc calculation      │
│     ├── ChainLightingEngine: instant hit + chain to next target │
│     │                                                           │
│     ├── MissileFlightTimeStat (timed missiles)                  │
│     ├── LaunchPreparationTimeStat (delayed launch)              │
│     │                                                           │
│  IMPACT / EXPIRATION                                            │
│     │                                                           │
│     ├── Target hit:                                             │
│     │    ├── WeaponDamage applied to target                     │
│     │    ├── WeaponExplosionRadiusStat (AoE damage)             │
│     │    ├── WeaponBombCountStat (cluster munitions)            │
│     │    ├── Mine damage: DamageForLight/Medium/HeavyArmor      │
│     │    ├── Psion: AttackSpeedReduction debuff                 │
│     │    ├── Coiltank: Chain to MaxTargetsStat additional units │
│     │    └── Cryotank: Freeze effect                            │
│     │                                                           │
│     ├── Max range exceeded (miss)                               │
│     ├── Timer expired (self-destruct)                           │
│     │                                                           │
│     ├── VFX: explosion, impact flash, smoke                    │
│     ├── Bullet returned to BulletStack pool                     │
│     └── BulletPrefabSettings cleared for reuse                  │
└─────────────────────────────────────────────────────────────────┘
```

**Bullet Pooling**: Bullets are the most frequently created/destroyed objects. The `BulletStack` implements a ring buffer pool that pre-allocates bullet instances at battle start. Typical pool sizes range from 50-200 depending on map size and player count. Pool exhaustion triggers a "recycle oldest" policy.

---

## 4. Session-Level Object Lifecycles

### 4.1 Lobby Lifecycle

```
Lobby Creation
     │
     ├── LobbyCreateRequest → LobbyCreateAnswer { lobby_id }
     ├── Lobby participants join via invite or matching
     ├── LobbyInviteRequest/Answer/Cancel/Reject
     ├── LobbyChangeMissionRequest/Answer/Notification
     ├── ReadyToBattleRequest/Answer (per player)
     │
     ├── Cancellation paths:
     │    ├── LobbyCancelMatchingRequest/Answer
     │    └── LobbyLeaveRequest/Answer
     │
     └── LobbyBattleStartRequest/Answer → Battle starts
```

### 4.2 Upgrade Lifecycle (Workshop Domain)

```
Upgrade Initiated
     │
     ├── UpgradeRequest { building_id, upgrade_type }
     ├── UpgradeAnswer { upgrade_id, completion_time }
     │
     ├── Upgrade in progress:
     │    ├── Timer counts down (server-authoritative)
     │    ├── AccelerateUpgradeRequest (speed-up item)
     │    ├── SpeedUpActiveUpgradeRequest (partial speed-up)
     │    ├── CancelUpgradeRequest (abort, partial refund)
     │    └── CompleteActiveUpgradeRequest (instant with premium)
     │
     ├── UpgradeNotification (auto-completion at timer end)
     │
     └── New BuildingLevelType unlocked, stats recalculated
```

### 4.3 Competition Lifecycle

```
Competition Start (scheduled)
     │
     ├── CompetitionConfiguration (rules, duration, tiers)
     ├── CompetitionJoin (player enters)
     ├── CompetitionUpdate (periodic standing notifications)
     ├── CoopMatching (cooperative mode pairing)
     │
     ├── During competition:
     │    ├── Battles affect competition rating
     │    ├── BattlePass progress tracked
     │    └── Rating updates via Rating domain
     │
     ├── CompetitionEnd (scheduled)
     ├── HallOfFame (top performers recorded)
     └── Rewards distributed via PlayerResources domain
```

---

## 5. Memory Pool Architecture

The game uses extensive object pooling to prevent GC spikes on mobile devices. The IL2CPP backend helps with GC pressure, but Unity's Boehm GC still requires careful management of managed heap allocations.

| Pool | Pre-allocation | Max Size | Recycle Policy | Trigger |
|------|---------------|----------|---------------|---------|
| BulletStack | 100-200 | 500 | Oldest first | Battle start |
| Unit pool | 50-100 | 300 | LRU | Battle start |
| Building pool | 20-40 | 100 | LRU | Battle start |
| VFX pool (per effect) | 10-30 | 100 | Oldest first | Battle start |
| Command pool | 50 | 200 | FIFO | Battle start |
| Network message pool | 100 | 500 | Ring buffer | App start |
| GUI panel pool | 5-10 per type | 20 | LRU | Scene start |

All pools are managed by Zenject's `MemoryPool<T>` implementation, which integrates with UniTask for async pool warming. Pool sizes are configured per device performance tier via the `ReleaseManagement` domain's A/B testing system.

---

## 6. Entity State Transitions

### 6.1 Unit State Machine

```
                    ┌──────────┐
                    │  SPAWNED │
                    └────┬─────┘
                         │
                    ┌────▼─────┐
           ┌───────│   IDLE   │◄──────────┐
           │       └────┬─────┘           │
           │            │                  │
           │       ┌────▼─────┐           │
           │       │ MOVING   │───────────┤
           │       └────┬─────┘           │
           │            │                  │
           │       ┌────▼─────┐           │
           │       │ ATTACKING│───────────┤
           │       └────┬─────┘           │
           │            │                  │
           │       ┌────▼─────┐           │
           │       │ ABILITY  │───────────┤
           │       └────┬─────┘           │
           │            │                  │
           │       ┌────▼─────┐           │
           └──────►│ STUNNED  │───────────┘
                   └────┬─────┘
                        │
                   ┌────▼─────┐
                   │  DYING   │
                   └────┬─────┘
                        │
                   ┌────▼─────┐
                   │  DEAD    │ → Returned to pool
                   └──────────┘
```

### 6.2 Building State Machine

```
┌──────────┐     ┌──────────────┐     ┌─────────────┐
│ PLANNING │────►│ CONSTRUCTING │────►│ OPERATIONAL │
└──────────┘     └──────┬───────┘     └──────┬──────┘
                       │                     │
                  CancelUpgrade          ┌────▼──────┐
                       │                 │ DAMAGED   │
                       ▼                 └────┬──────┘
                  ┌──────────┐               │
                  │ CANCELLED│          BuildingRepair
                  └──────────┘               │
                                        ┌────▼──────┐
                                        │ DESTROYED │
                                        └────┬──────┘
                                             │
                                        ┌────▼──────┐
                                        │ UPGRADING │──► OPERATIONAL (new level)
                                        └───────────┘
```

---

## 7. Lifecycle Event Publishing

Entity lifecycle events are published through the UniRx/R3 reactive system, allowing decoupled subscribers to react to state changes:

```
Entity Event Publishers:
 ├── Unit.OnSpawned → UnitSelectionPanel, Minimap, AI
 ├── Unit.OnDamaged → HealthBar, DamageNumber, VFX
 ├── Unit.OnDeath → KillFeed, Statistics, PoolManager
 ├── Building.OnPlaced → Map, OpponentClient, Minimap
 ├── Building.OnDamaged → HealthBar, RepairPanel
 ├── Building.OnDestroyed → Statistics, PoolManager, Map
 ├── Building.OnUpgraded → Workshop, StatsPanel
 ├── Bullet.OnImpact → Target (damage), VFX, PoolManager
 └── Battle.OnFinished → RewardsScreen, Career, Rating, PlayerResources
```

This event-driven architecture ensures that the battle logic remains decoupled from visual presentation and UI updates. The UniRx observable pattern allows multiple subscribers without tight coupling, and the R3 `ReactiveProperty<T>` pattern enables efficient change detection for UI binding.
