# Art of War 3: Recreation Blueprint

## 1. System Architecture for Recreation

### 1.1 Recommended Technology Stack

| Layer | Technology | Rationale |
|-------|-----------|-----------|
| Game Engine | Unity 2022.3 LTS | Original uses Unity; best compatibility for recreation |
| Scripting | C# with IL2CPP | Match original architecture |
| Networking | Custom TCP + Protobuf | Server-authoritative model |
| Database | PostgreSQL + Redis | Persistent + cache layers |
| Asset Management | Unity Addressables | Match original asset pipeline |
| DI Framework | Zenject/VContainer | Match original dependency injection |
| Async | UniTask | Match original async patterns |
| Reactive | R3 | Match original reactive framework |
| Animation | DOTween | Match original tween system |
| Authentication | JWT + OAuth2 | Modern auth with device ID fallback |
| Matchmaking | Custom matchmaking service | Match original skill-based system |
| Chat | WebSocket-based chat service | Match original multi-room system |
| Analytics | Custom + Firebase | Match original analytics |
| Ads Mediation | AppLovin MAX + IronSource | Match original ad stack |

### 1.2 High-Level Architecture

```
┌─────────────────────────────────────────────────────────┐
│                    CLIENT APPLICATION                    │
│  ┌──────────┐ ┌──────────┐ ┌──────────┐ ┌──────────┐  │
│  │ Startup  │ │  Logon   │ │   Main   │ │  Battle  │  │
│  │  Scene   │ │  Scene   │ │  Scene   │ │  Scene   │  │
│  └──────────┘ └──────────┘ └──────────┘ └──────────┘  │
│  ┌────────────────────────────────────────────────────┐ │
│  │              Domain Layer (DDD)                    │ │
│  │  Account │ Campaign │ Career │ Workshop │ Skills   │ │
│  │  Chat    │ Clan     │ Competition │ Rating        │ │
│  └────────────────────────────────────────────────────┘ │
│  ┌────────────────────────────────────────────────────┐ │
│  │              Network Layer                         │ │
│  │  Main Server Conn │ Battle Server Conn │ Chat     │ │
│  └────────────────────────────────────────────────────┘ │
└─────────────────────────────────────────────────────────┘
                         │
                    ┌────┴────┐
                    │ INTERNET │
                    └────┬────┘
                         │
┌────────────────────────┼────────────────────────┐
│              SERVER INFRASTRUCTURE               │
│  ┌──────────┐ ┌──────────┐ ┌──────────┐        │
│  │   Auth   │ │  Game    │ │  Battle  │        │
│  │ Service  │ │ Service  │ │ Service  │        │
│  └──────────┘ └──────────┘ └──────────┘        │
│  ┌──────────┐ ┌──────────┐ ┌──────────┐        │
│  │  Match   │ │  Chat    │ │  Clan    │        │
│  │ Service  │ │ Service  │ │ Service  │        │
│  └──────────┘ └──────────┘ └──────────┘        │
│  ┌──────────┐ ┌──────────┐                      │
│  │ Billing  │ │Analytics │                      │
│  │ Service  │ │ Service  │                      │
│  └──────────┘ └──────────┘                      │
│                                                  │
│  ┌──────────┐ ┌──────────┐                      │
│  │PostgreSQL│ │  Redis   │                      │
│  │(Persist) │ │ (Cache)  │                      │
│  └──────────┘ └──────────┘                      │
└──────────────────────────────────────────────────┘
```

---

## 2. Object Model

### 2.1 Core Data Models

```csharp
// Base Entity
public abstract class Entity {
    public int Id { get; set; }
    public EntityType Type { get; set; }
    public float X { get; set; }
    public float Y { get; set; }
    public int OwnerId { get; set; }
    public int TeamId { get; set; }
}

// Unit
public class Unit : Entity {
    public int PrototypeId { get; set; }
    public Faction Faction { get; set; }
    public ArmorClass ArmorClass { get; set; }
    public float MaxHp { get; set; }
    public float CurrentHp { get; set; }
    public float Speed { get; set; }
    public float VisionRange { get; set; }
    public Weapon[] Weapons { get; set; }
    public Ability Ability { get; set; } // Heroes only
    public UnitMode Mode { get; set; } // Travel/Siege for Jaguar
    public float Fuel { get; set; } // Aircraft only
    public bool IsSubmerged { get; set; } // Submarines only
    public bool IsInFog { get; set; } // Chameleon fog
    public float ShieldPoints { get; set; } // Atlas passive shield
    public UnitState State { get; set; }
}

// Building
public class Building : Entity {
    public BuildingType BuildingType { get; set; }
    public int Level { get; set; }
    public float MaxHp { get; set; }
    public float CurrentHp { get; set; }
    public float PowerConsumption { get; set; }
    public ProductionQueue ProductionQueue { get; set; }
    public float ProductionSpeed { get; set; }
    public BuildingState State { get; set; } // Constructing/Active/Upgrading/Destroyed
}

// Weapon
public class Weapon {
    public int WeaponId { get; set; }
    public WeaponTarget TargetType { get; set; }
    public BulletEngineType EngineType { get; set; }
    public float DamageLight { get; set; }
    public float DamageMedium { get; set; }
    public float DamageHeavy { get; set; }
    public float Range { get; set; }
    public float FireRate { get; set; }
    public float Accuracy { get; set; }
    public float ExplosionRadius { get; set; }
    public int BombCount { get; set; } // Bombers
    public float Cooldown { get; set; }
    public float CurrentCooldown { get; set; }
}

// Bullet/Projectile
public class Bullet : Entity {
    public BulletEngineType EngineType { get; set; }
    public int TargetEntityId { get; set; }
    public float Speed { get; set; }
    public float Damage { get; set; }
    public float ExplosionRadius { get; set; }
    public bool IsHoming { get; set; }
}

// Player Account
public class Account {
    public int Id { get; set; }
    public string Name { get; set; }
    public Faction Faction { get; set; }
    public int Level { get; set; }
    public int Experience { get; set; }
    public int Stars { get; set; }
    public int Credits { get; set; }
    public int Gold { get; set; }
    public int Tokens { get; set; }
    public int Uranium { get; set; }
    public int SkillPoints { get; set; }
    public League League { get; set; }
    public Dictionary<int, int> UpgradeLevels { get; set; }
    public SkillCard[] SkillCards { get; set; }
    public ClanMembership Clan { get; set; }
}

// Battle State
public class BattleState {
    public int BattleId { get; set; }
    public BattleType Type { get; set; }
    public PlayerState[] Players { get; set; }
    public int MapId { get; set; }
    public int Tick { get; set; }
    public float SuperWeaponCharge[] { get; set; }
    public BattlePhase Phase { get; set; }
}

// Player State (in battle)
public class PlayerState {
    public int PlayerId { get; set; }
    public Faction Faction { get; set; }
    public float Supplies { get; set; }
    public float PowerCapacity { get; set; }
    public float PowerUsed { get; set; }
    public List<Unit> Units { get; set; }
    public List<Building> Buildings { get; set; }
}
```

### 2.2 Enumerations

```csharp
public enum Faction { Confederation, Resistance }
public enum ArmorClass { Light, Medium, Heavy }
public enum WeaponTarget { Bomber, Fighter, Helicopter, Land, Warship, Submarine }
public enum BulletEngineType { Linear, Ballistic, BallisticHigh, AdjustableBallistic, SelfDirected, ChainLightning }
public enum UnitMode { Travel, Siege }
public enum UnitState { Idle, Moving, Attacking, Producing, Dying }
public enum BuildingState { Constructing, Active, Upgrading, Destroyed }
public enum BattleType { PvP1v1, PvP2v2, Campaign, Skirmish, Tournament, Training }
public enum BattlePhase { Loading, Countdown, Active, Paused, Finished }
public enum League { Bronze, Silver, Gold, Platinum, Diamond, Master, Grandmaster }
```

---

## 3. Gameplay Loop Specification

### 3.1 Match Lifecycle

```
1. LOADING (30-60 seconds)
   ├── Load map assets
   ├── Initialize player positions
   ├── Spawn initial buildings (HQ, Construction Yard)
   └── Synchronize all players

2. COUNTDOWN (3-5 seconds)
   ├── Display countdown timer
   └── Players can observe but not act

3. ACTIVE GAMEPLAY (variable, 5-30 minutes)
   ├── Tick-based simulation (20-30 ticks/second)
   ├── Resource generation every tick
   ├── Unit AI processes every tick
   ├── Player commands processed every tick
   ├── Superweapon charges gradually
   ├── Win condition check every tick:
   │   ├── All enemy buildings destroyed → Victory
   │   └── All own buildings destroyed → Defeat
   └── Timer limit reached → Sudden death or draw

4. POST-GAME
   ├── Calculate statistics
   ├── Award experience and resources
   ├── Update ratings
   └── Return to main menu
```

### 3.2 Progression Lifecycle

```
1. NEW PLAYER
   ├── Select faction
   ├── Complete tutorial (6 missions)
   ├── Receive starter pack
   └── Begin career progression

2. EARLY GAME (Level 1-10)
   ├── Learn basic mechanics via campaign
   ├── Unlock basic units and buildings
   ├── First PvP battles
   └── Start Workshop upgrades

3. MID GAME (Level 10-30)
   ├── Advanced unit unlocks
   ├── Hero unit introduction
   ├── Commander Skills development
   ├── Clan participation
   └── Tournament entry

4. LATE GAME (Level 30+)
   ├── Full unit roster access
   ├── Max Workshop upgrades pursuit
   ├── Competitive PvP ranking
   ├── Clan War participation
   └── Meta optimization
```

---

## 4. RTS Framework Specification

### 4.1 Input System

```csharp
public interface IInputHandler {
    void OnTap(Vector2 position);
    void OnDragStart(Vector2 start);
    void OnDragUpdate(Vector2 start, Vector2 current);
    void OnDragEnd(Vector2 start, Vector2 end);
    void OnLongPress(Vector2 position);
    void OnDoubleTap(Vector2 position);
    void OnPinch(float delta);
}

// Gesture handlers route to:
public interface ICommandIssuer {
    void IssueMoveCommand(Unit[] units, Vector2 target);
    void IssueAttackCommand(Unit[] units, Entity target);
    void IssuePatrolCommand(Unit[] units, Vector2[] waypoints);
    void IssueBuildCommand(BuildingType type, Vector2 position);
    void IssueTrainCommand(Building factory, UnitType type);
    void IssueAbilityCommand(Unit hero, Ability ability, Vector2 target);
    void IssueSuperweaponCommand(Vector2 target);
}
```

### 4.2 Rendering System

- Unity URP/HDRP pipeline
- Object pooling for units, bullets, effects
- Level-of-detail system for distant units
- Terrain rendering with custom Landscape shader
- Water rendering with custom Water/Waves shader
- Flora rendering with FloraMask shaders (opaque/transparent)
- Particle systems for explosions, fire, smoke
- Trail renderers for projectiles and movement

### 4.3 Simulation System

- Fixed tick rate (server-authoritative)
- Deterministic simulation for replay
- Entity-component architecture
- AI subsystem (strategic + tactical + unit-level)
- Pathfinding grid with terrain costs
- Fog of war with visibility calculations

### 4.4 Networking System

- Server-authoritative model
- Client prediction for responsive controls
- Tick-based state synchronization
- Command relay through server
- Reconnection with state restore
- Desync detection and correction
- Encrypted authentication and billing
