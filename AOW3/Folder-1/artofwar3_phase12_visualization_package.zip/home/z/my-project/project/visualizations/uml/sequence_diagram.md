# Art of War 3: Global Conflict — Sequence Diagrams

> Interaction diagrams for key game flows, derived from IL2CPP method analysis.

---

## (a) Battle Initialization Flow

Shows the complete flow from matchmaking acceptance through battle scene loading.

```mermaid
sequenceDiagram
    autonumber
    actor Player
    participant MainGUI as Main GUI
    participant Match as Matchmaking Service
    participant MainSrv as Main Server
    participant BOrch as Battle Orchestrator
    participant BSrv as Battle Server
    participant BLoad as BattleLoading Scene
    participant BScene as Battle Scene
    participant Logic as LogicService
    participant Net as NetworkProvider

    Player->>MainGUI: Click "Find Match"
    MainGUI->>Match: StartMatchmaking(faction, rating)
    Match->>MainSrv: CSMatchmakingRequest(authToken, faction, rating)
    MainSrv-->>Match: SCMatchmakingPending(matchId, queuePosition)
    MainSrv->>MainSrv: Find opponent (ELO ±200)
    MainSrv-->>Match: SCMatchFound(battleId, battleServerHost, port)
    Match->>MainGUI: OnMatchFound(battleInfo)
    MainGUI->>Player: Show "Battle Found!" dialog

    Player->>MainGUI: Accept match
    MainGUI->>BLoad: Transition to BattleLoading scene
    Note over BLoad: Scene: AOW_Assets.Scenes.BattleLoading.Scripts.Network

    BLoad->>Net: CheckConnectionToBattleHosts(hostList)
    Net->>BSrv: PingPongAsync(host1)
    BSrv-->>Net: Pong (latency: 45ms)
    Net->>BSrv: PingPongAsync(host2)
    BSrv-->>Net: Pong (latency: 120ms)
    Net-->>BLoad: Best host: host1 (45ms)

    BLoad->>Net: Connect(battleServerHost, port)
    Net->>BSrv: CSLoginToBattle(sessionToken, battleId)
    BSrv->>BOrch: ValidateSession(sessionToken)
    BOrch->>MainSrv: VerifyPlayerToken(authToken)
    MainSrv-->>BOrch: TokenValid(playerId)
    BOrch-->>BSrv: SessionValidated(playerId, battleId)
    BSrv-->>Net: SCLoginAccepted(battleId, playerSlot)
    
    BLoad->>Net: CSBattleLogon(authToken, selectedFaction)
    BSrv->>BSrv: RegisterPlayer(playerSlot, faction)
    BSrv-->>Net: SCBattleLogonConfirmed(mapId, seed, playerData[])

    BLoad->>BScene: Transition to Battle scene
    Note over BScene: Scene: AOW_Assets.Scenes.Battle.Scripts
    BScene->>Logic: BattleInitialize(battleConfig)
    Logic->>Logic: CreateBattleMap(mapId, seed)
    Logic->>Logic: SpawnStartingEntities(faction, startPosition)
    Logic->>Logic: InitializeFOW(playerId)
    Logic->>Logic: StartSimulationLoop()
    Logic-->>BScene: OnBattleLoaded()
    BScene->>Player: Battle started!
```

---

## (b) Unit Command Processing

Shows how a unit move/attack command flows through client input, network, server simulation, and back to client state sync.

```mermaid
sequenceDiagram
    autonumber
    actor Player
    participant Input as InputHandler
    participant Ctrl as PlayerController
    participant Sel as Selection System
    participant Net as NetworkProvider
    participant BSrv as Battle Server
    participant Sim as Battle Simulator
    participant Path as Pathfinder
    participant Dmg as Damage System
    participant Sync as Battle Sync
    participant Logic as LogicService (Client)
    participant FOW as Fog of War

    Player->>Input: Right-click on map position
    Input->>Ctrl: OnCommandIssued(moveCommand)
    
    alt Units selected
        Ctrl->>Sel: GetSelectedUnits()
        Sel-->>Ctrl: selectedUnits[]
    else No units selected
        Ctrl->>Sel: SelectUnitsByRectangle(selectionRect)
        Sel->>Sel: SelectCentralUnit(candidates)
        Sel-->>Ctrl: selectedUnits[]
    end

    Ctrl->>Ctrl: Determine command type (move/attack)
    
    alt Move Command
        Ctrl->>Net: Send CSUnitCommand(unitIds, MoveTo, targetPos)
        Net->>BSrv: CSUnitCommand serialized
        BSrv->>Sim: ProcessCommand(tick, playerId, command)
        Sim->>Path: FindPath(unit.position, targetPos)
        Path-->>Sim: path (waypoints[])
        Sim->>Sim: SetUnitPath(unit, path)
        Sim->>Sync: GenerateStateSnapshot(tick)
    else Attack Command
        Ctrl->>Net: Send CSUnitCommand(unitIds, Attack, targetEntityId)
        Net->>BSrv: CSUnitCommand serialized
        BSrv->>Sim: ProcessCommand(tick, playerId, command)
        
        loop Each tick while in range
            Sim->>Dmg: CalculateWeaponArmorDamage(weapon, targetArmor)
            Dmg->>Dmg: calcShooter(shooter, target)
            Dmg->>Dmg: calcFireDistanceMisc(distance)
            Dmg-->>Sim: damageInfo (finalDamage)
            Sim->>Sim: ApplyDamage(target, damageInfo)
            
            alt Target destroyed
                Sim->>Sim: DestroyUnit(target)
                Sim->>FOW: UpdateVisibility(remainingUnits)
            end
        end
        
        Sim->>Sync: GenerateStateSnapshot(tick)
    end

    Sync-->>Net: SCBattleState(tick, entitySnapshots[])
    Net->>Logic: OnBattleStateReceived(state)
    Logic->>Logic: ReconcileClientState(snapshots)
    Logic->>Logic: UpdateEntityPositions(snapshots)
    Logic->>FOW: UpdateVisibility(playerUnits)
    Logic-->>Player: Visual update (units move/attack)
```

---

## (c) Multiplayer Authentication

Shows the complete authentication flow from app launch through social login to session establishment.

```mermaid
sequenceDiagram
    autonumber
    actor Player
    participant Startup as Startup Manager
    participant Auth as Auth Service
    participant MainSrv as Main Server
    participant DB as Player Database
    participant Redis as Redis Cache
    participant Firebase as Firebase Auth
    participant Config as Config Manager
    participant Assets as Asset Loader

    Player->>Startup: Launch app
    Startup->>Startup: InitializeZenjectContainer()
    Startup->>Config: LoadConfigsAsync()
    Config->>Assets: LoadAddressables("game_config")
    Assets-->>Config: GameConfig loaded
    Startup->>Firebase: InitializeFirebase()
    Firebase-->>Startup: Firebase ready

    alt First Launch / No Stored Token
        Startup->>Auth: ShowLoginScreen()
        Auth->>Player: Display login options
        
        alt Google Sign-In
            Player->>Auth: Tap "Sign in with Google"
            Auth->>Firebase: SignInWithGoogle()
            Firebase-->>Auth: FirebaseToken (JWT)
        else Facebook Sign-In
            Player->>Auth: Tap "Sign in with Facebook"
            Auth->>Firebase: SignInWithFacebook()
            Firebase-->>Auth: FirebaseToken (JWT)
        else Guest Login
            Player->>Auth: Tap "Play as Guest"
            Auth->>Firebase: SignInAnonymously()
            Firebase-->>Auth: FirebaseToken (JWT)
        end

        Auth->>MainSrv: CSAuthRequest(firebaseToken, deviceId)
        MainSrv->>Firebase: VerifyToken(firebaseToken)
        Firebase-->>MainSrv: TokenValid(uid, provider)
        MainSrv->>DB: FindPlayerByFirebaseUid(uid)
        
        alt New Player
            DB-->>MainSrv: Player not found
            MainSrv->>DB: CreatePlayer(uid, provider, deviceId)
            DB-->>MainSrv: playerId (new)
        else Existing Player
            DB-->>MainSrv: Player record found
        end
        
        MainSrv->>Redis: StoreSession(sessionToken, playerId, TTL=24h)
        MainSrv-->>Auth: SCAuthResponse(sessionToken, playerId, isNewPlayer)
        Auth->>Auth: StoreTokenLocally(sessionToken)
    else Stored Token Available
        Auth->>Auth: LoadStoredToken()
        Auth->>MainSrv: CSAuthRequest(storedToken, deviceId)
        MainSrv->>Redis: ValidateSession(storedToken)
        
        alt Token Valid
            Redis-->>MainSrv: Session valid (playerId)
            MainSrv->>DB: LoadPlayerProfile(playerId)
            DB-->>MainSrv: Player profile
            MainSrv-->>Auth: SCAuthResponse(sessionToken, playerId, isNewPlayer=false)
        else Token Expired
            Redis-->>MainSrv: Session expired
            MainSrv-->>Auth: SCAuthError(tokenExpired)
            Note over Auth: Falls back to "First Launch" flow
        end
    end

    Auth->>Startup: OnAuthenticated(playerId)
    Startup->>Config: DownloadPlayerSpecificConfigs()
    Startup->>MainSrv: CSPlayerDataRequest(sessionToken)
    MainSrv->>DB: LoadFullPlayerData(playerId)
    DB-->>MainSrv: Full player data (resources, clan, workshop, etc.)
    MainSrv-->>Startup: SCPlayerDataResponse(fullData)
    Startup->>Startup: Transition to Main Scene
```

---

## (d) Building Construction

Shows the complete flow from selecting a building type through placement, construction, and completion.

```mermaid
sequenceDiagram
    autonumber
    actor Player
    participant GUI as Battle HUD
    participant Ctrl as PlayerController
    participant Econ as Economy System
    participant Res as Resource Manager
    participant Net as NetworkProvider
    participant BSrv as Battle Server
    participant Sim as Battle Simulator
    participant Map as Battle Map
    participant EntityMgmt as Entity System
    participant Bldg as Building

    Player->>GUI: Open build menu
    GUI->>GUI: Display available buildings (filtered by faction)
    Player->>GUI: Select building type (e.g., Barracks)
    GUI->>Ctrl: OnBuildSelected(BuildingType.Barracks)
    
    Ctrl->>Econ: CalculateCost(BuildingType.Barracks)
    Econ->>Res: HasEnoughResources(costs[])
    
    alt Insufficient Resources
        Res-->>Econ: false
        Econ-->>Ctrl: CannotAfford
        Ctrl-->>GUI: Show "Not enough resources" message
        GUI-->>Player: Red flash on resource bar
    else Sufficient Resources
        Res-->>Econ: true
        Econ-->>Ctrl: CanAfford
        Ctrl-->>GUI: Enter placement mode
        GUI-->>Player: Show building ghost (translucent preview)
        
        loop Placement adjustment
            Player->>GUI: Move cursor to position
            GUI->>Map: IsPathable(position, buildingFootprint)
            Map-->>GUI: valid/invalid
            GUI-->>Player: Green (valid) / Red (invalid) ghost
        end
        
        Player->>GUI: Click to confirm placement
        GUI->>Ctrl: OnBuildConfirmed(BuildingType, position)
        Ctrl->>Net: CSBuildingCommand(Build, BuildingType, position)
        Net->>BSrv: CSBuildingCommand serialized
        BSrv->>Sim: ProcessBuildingCommand(tick, playerId, command)
        
        Sim->>Res: SpendResources(costs[])
        Res-->>Sim: Resources spent
        
        Sim->>EntityMgmt: AddBuilding(BuildingType, position, playerId)
        EntityMgmt->>Bldg: Create as PreBuilding (foundation)
        Bldg-->>EntityMgmt: preBuilding entity
        EntityMgmt-->>Sim: building created
        
        Sim->>Map: MarkFootprintOccupied(position, footprint)
        Sim->>Sim: SetConstructionTimer(buildTime)
        
        Sim-->>Net: SCBattleState (with new pre-building)
        Net->>Ctrl: State updated
        Ctrl-->>GUI: Show construction progress bar
        GUI-->>Player: Building foundation visible, progress bar
        
        loop Construction ticks
            Sim->>Bldg: Construct() - increment progress
            Bldg->>Bldg: ConstructionProgress += delta / buildTime
            Sim-->>Net: SCBattleState (progress update)
        end
        
        Sim->>Bldg: BuildingComplete()
        Bldg->>Bldg: IsComplete = true
        Bldg->>Bldg: ActivateAbilities()
        Bldg->>Bldg: EnableUnitQueue()
        
        alt Building has weapons (turret)
            Bldg->>Bldg: ActivateWeapons()
        end
        
        Sim-->>Net: SCBattleState (building complete)
        Net->>Ctrl: State updated
        Ctrl-->>GUI: Show building complete animation
        GUI-->>Player: Building operational, ready to use
    end
```

---

## (e) Superweapon Launch

Shows the superweapon charge, targeting, launch, and impact resolution flow.

```mermaid
sequenceDiagram
    autonumber
    actor Player
    participant GUI as Battle HUD
    participant SWPanel as SuperWeapon Panel
    participant Ctrl as PlayerController
    participant SW as SuperWeapon Entity
    participant Net as NetworkProvider
    participant BSrv as Battle Server
    participant Sim as Battle Simulator
    participant Dmg as Damage System
    participant Map as Battle Map
    participant FOW as Fog of War

    Note over SW: SuperWeapon charges over time<br/>from SuperWeapon building
    loop Charge accumulation
        SW->>SW: UpdateSuperWeaponState()
        SW->>SW: ChargeProgress += delta / chargeTime
        SW-->>SWPanel: OnChargeProgressChanged(progress)
        SWPanel-->>Player: Progress bar fills up
    end

    SW->>SWPanel: ChargeProgress >= 1.0 (Ready!)
    SWPanel-->>Player: SuperWeapon ready indicator (flashing icon)

    Player->>SWPanel: Click superweapon button
    SWPanel->>Ctrl: OnSuperWeaponLaunchRequested()
    Ctrl-->>GUI: Enter targeting mode
    GUI-->>Player: Show targeting reticle over map

    Player->>GUI: Click target position on map
    GUI->>Ctrl: OnSuperWeaponTargetSelected(targetPos)
    
    Ctrl->>SW: GetAbilityRadius(superWeaponAbility)
    SW-->>Ctrl: radius (blast area)
    Ctrl-->>GUI: Show blast radius preview
    Player->>GUI: Confirm launch

    GUI->>Ctrl: OnSuperWeaponLaunchConfirmed(targetPos)
    Ctrl->>Net: CSUnitCommand(superWeaponIds, SuperWeaponLaunch, targetPos)
    Net->>BSrv: CSUnitCommand serialized
    BSrv->>Sim: ProcessCommand(tick, playerId, superWeaponLaunch)

    Sim->>SW: SuperWeaponLaunch(targetPos)
    SW->>SW: WeaponFlarePrepare()
    SW->>SW: ChargeProgress = 0 (reset charge)
    
    Note over SW: Launch delay for dramatic effect<br/>and enemy warning

    Sim-->>Net: SCBattleState (launch initiated, flare visible)
    Net->>Ctrl: State updated
    Ctrl-->>GUI: Show launch warning to ALL players
    GUI-->>Player: "SUPERWEAPON INCOMING!" alert

    alt Launch delay period
        SW->>SW: UpdateSuperWeaponState() (countdown)
        Sim-->>Net: SCBattleState (countdown ticks)
        Note over Player: Enemy sees flare<br/>and has brief time to react
    end

    Sim->>SW: Impact resolved
    SW->>Dmg: CreateSuperWeaponMediumDamage()
    Dmg-->>SW: superWeaponDamageInfo

    SW->>Map: GetEntitiesInRange(targetPos, blastRadius)
    Map-->>SW: entitiesInBlast[]

    loop Each entity in blast radius
        SW->>Dmg: CalculateWeaponArmorDamage(weapon, entity.armor)
        Dmg->>Dmg: Apply distance falloff
        Dmg-->>SW: finalDamage for entity
        SW->>SW: ApplyDamage(entity, finalDamage)
        
        alt Entity destroyed
            SW->>Sim: DestroyUnit/DestroyBuilding(entity)
            Sim->>FOW: UpdateVisibility()
        end
    end

    Sim->>SW: RemoveTrainedSuperWeapon()
    Sim-->>Net: SCBattleState (impact resolved, casualties)
    Net->>Ctrl: State updated
    Ctrl-->>GUI: Show impact explosion VFX
    GUI-->>Player: Explosion animation, damage numbers

    Note over SW: SuperWeapon building starts<br/>recharging from 0%
    SW->>SWPanel: ChargeProgress = 0
    SWPanel-->>Player: Charge bar resets, cooldown begins
```

---

## Explanation

These five sequence diagrams capture the **most critical interaction flows** in Art of War 3:

### (a) Battle Initialization
The most complex flow in the game — spans **3 scenes** (Main → BattleLoading → Battle), **2 server clusters** (Main + Battle), and involves latency-based host selection (`CheckConnectionToBattleHosts`), dual authentication (`CSLoginToBattle` + `CSBattleLogon`), and deterministic map seeding. Key insight: the BattleLoading scene exists specifically to handle the async network handshake before entering the simulation.

### (b) Unit Command Processing
Demonstrates the **authoritative server model**: the client sends commands (`CSUnitCommand`), the server simulates, and broadcasts state back (`SCBattleState`). The client performs client-side prediction for responsiveness but reconciles with server state. The damage calculation pipeline (`calcShooter` → `calcFireDistanceMisc` → `CalculateWeaponArmorDamage`) is entirely server-side to prevent cheating.

### (c) Multiplayer Authentication
Multi-path authentication supporting Google, Facebook, and guest login via Firebase. The system uses **session tokens with 24-hour TTL** stored in Redis, with local token caching for seamless re-login. The startup sequence initializes Zenject, loads configs from Addressables, and sets up Firebase before showing any UI.

### (d) Building Construction
Real-time strategy pattern: resource check → ghost placement → server validation → construction timer → completion. The `PreBuilding` state creates a non-functional foundation that can be destroyed by enemies during construction. The `CalculateCost` → `HasEnoughResources` → `SpendResources` pipeline ensures atomic resource transactions.

### (e) Superweapon Launch
The game's dramatic climax — involves a charge phase (minutes of gameplay), targeting phase with blast radius preview, launch with a dramatic delay (`WeaponFlarePrepare`) that warns all players, and area-of-effect damage resolution with distance falloff. After impact, the superweapon building resets to 0% charge, creating a strategic timing element.
