# Recreation Mapping: Building System

## Purpose

The Building System manages the construction, operation, upgrade, and destruction of all structures in Art of War 3: Global Conflict. Each faction has 14 buildings serving distinct roles: resource generation (Supply Center, Power Plant), unit production (Barracks, Factory, Shipyard, Airfield), tech advancement (Tech Center, specialized labs), base defense (Turrets, Walls), and superweapons (Nuclear Silo, Chameleon Tower). Buildings are the anchor of the RTS economy-production loop and define the player's strategic position on the map. The system handles placement validation, construction progress with builder unit assignment, production queues for unit training, power grid management (buildings consume/produce power), upgrade tiers that unlock advanced units and abilities, and building destruction with area denial and rubble mechanics.

## Inputs

- **Player Input**: Build placement clicks, production queue orders, upgrade requests, rally point setting
- **Economy System**: Resource cost validation and deduction for construction and production
- **Unit System**: Builder units assigned to construction, produced units spawning at rally points
- **Combat System**: Damage to buildings, destruction events
- **Upgrade/Tech System**: Building tier requirements, unlock conditions
- **Power Grid**: Power production and consumption balance
- **Network System**: Synchronized build orders and production state

## Outputs

- **Building Entities**: Constructed structures placed on the game map
- **Production Queue State**: Units being trained with progress bars
- **Power Balance**: Net power (production - consumption) displayed in HUD
- **Tech Unlocks**: Notifications that new units/buildings/upgrades are available
- **Rally Point Indicators**: Visual markers showing where produced units will move
- **Destruction Events**: Building death triggers for defeat condition checks and rubble

## Dependencies

- **Economy System**: For resource cost deduction and supply validation
- **Unit System**: For unit production and builder assignment
- **Combat System**: For building damage and destruction
- **Power Grid Subsystem**: For energy production/consumption tracking
- **Pathfinding System**: For placement validation (no blocking navmesh)
- **Network System**: For construction synchronization

## Internal Logic

The Building System uses a state machine per building: `PLANNED → CONSTRUCTING → ACTIVE → UPGRADING → ACTIVE (upgraded) → DESTROYED`. Construction requires a builder unit moving to the site and "building" — the construction progress advances proportionally to the number of builders assigned. Each building has a `BuildingDefinition` ScriptableObject containing: cost, build time, power consumption/production, available production items (for factories), tech tree requirements, and upgrade path.

Production queues in factories (Barracks, Factory, Shipyard, Airfield) follow a sequential model: only one unit trains at a time, but up to 5 can be queued. The production timer advances each tick based on the unit's build time, modified by any build-rate upgrades. When complete, the unit spawns at the rally point (a world position set by the player). If the factory is destroyed while producing, the queued unit's cost is partially refunded.

The power grid is a global per-player calculation: `netPower = sum(powerProduction) - sum(powerConsumption)`. If net power is negative, all buildings operate at reduced efficiency (production speed halved, turret fire rate reduced, defense structures disabled). This creates a strategic imperative to protect power plants. The power state is recalculated whenever a building is constructed, destroyed, or upgraded.

Building placement uses a grid-snapping system with validation checks: the placement preview shows a ghost of the building that snaps to the nearest valid grid cell, turns red if overlapping obstacles or other buildings, and confirms green when valid. Placement also checks navmesh connectivity to ensure the building doesn't trap friendly units.

## Pseudocode

```
class BuildingSystem:
    buildings: Map<BuildingID, Building>
    buildQueue: List<BuildRequest>
    powerGrid: PowerGrid

    function requestBuild(player, buildingType, gridPosition):
        definition = BuildingDefinitions.get(buildingType)
        if not economySystem.canAfford(player, definition.cost):
            return BUILD_FAIL_NO_RESOURCES
        if not isValidPlacement(gridPosition, definition.footprint):
            return BUILD_FAIL_INVALID_LOCATION
        if not techTree.hasRequiredTech(player, definition.techRequirement):
            return BUILD_FAIL_TECH_LOCKED
        economySystem.deduct(player, definition.cost)
        building = createBuilding(definition, player.faction, gridPosition)
        building.state = CONSTRUCTING
        building.buildProgress = 0.0
        buildings.put(building.id, building)
        eventBus.emit(BuildingStartedEvent(building))
        return BUILD_SUCCESS

    function assignBuilder(building, builderUnit):
        building.assignedBuilders.add(builderUnit)
        builderUnit.state = BUILDING
        builderUnit.target = building

    function updateConstruction(deltaTime):
        for building in buildings.where(b => b.state == CONSTRUCTING):
            buildRate = BASE_BUILD_RATE * building.assignedBuilders.size()
            building.buildProgress += buildRate * deltaTime / building.definition.buildTime
            if building.buildProgress >= 1.0:
                building.state = ACTIVE
                powerGrid.recalculate(building.owner)
                eventBus.emit(BuildingCompletedEvent(building))

    function produceUnit(factory, unitType):
        if factory.state != ACTIVE:
            return PRODUCE_FAIL_FACTORY_INACTIVE
        if factory.productionQueue.size() >= MAX_QUEUE_SIZE:
            return PRODUCE_FAIL_QUEUE_FULL
        unitDef = UnitDefinitions.get(unitType)
        if not factory.definition.canProduce(unitType):
            return PRODUCE_FAIL_WRONG_FACTORY
        if not economySystem.canAfford(factory.owner, unitDef.cost):
            return PRODUCE_FAIL_NO_RESOURCES
        economySystem.deduct(factory.owner, unitDef.cost)
        factory.productionQueue.enqueue(ProductionItem(unitType, unitDef.buildTime))

    function updateProduction(deltaTime):
        for factory in buildings.where(b => b.state == ACTIVE and b.hasProductionQueue):
            if factory.productionQueue.isEmpty():
                continue
            if not powerGrid.hasPower(factory.owner):
                continue  // Low power: production paused
            item = factory.productionQueue.peek()
            powerEfficiency = powerGrid.getEfficiency(factory.owner)
            item.progress += deltaTime * powerEfficiency / item.buildTime
            if item.progress >= 1.0:
                factory.productionQueue.dequeue()
                unit = unitSystem.spawnUnit(item.unitType, factory.faction, factory.rallyPoint)
                eventBus.emit(UnitProducedEvent(unit, factory))

class PowerGrid:
    function recalculate(player):
        production = buildings.where(b => b.owner == player and b.producesPower).sum(b => b.powerOutput)
        consumption = buildings.where(b => b.owner == player and b.consumesPower).sum(b => b.powerCost)
        netPower = production - consumption
        efficiency = netPower >= 0 ? 1.0 : max(0.25, 1.0 + netPower / production)  // Min 25%

    function hasPower(player):
        return getNetPower(player) >= 0

    function getEfficiency(player):
        return netPower >= 0 ? 1.0 : clamp(1.0 + netPower / max(production, 1), 0.25, 1.0)
```

## Modern Implementation Recommendations

| Approach | Recommendation |
|----------|---------------|
| **Best Overall** | **Unity 2023 DOTS/ECS** — `Building` as entity with `ConstructionProgress`, `ProductionQueue : DynamicBuffer<ProductionItem>`, `PowerComponent`. System queries process construction and production in parallel. |
| **Alternative Engine** | **Godot 4 with C#** — `Building : Node3D` with `[Export]` arrays for production items. Use `Timer` nodes for build progress. Signal-based communication for completion events. |
| **Performance-Critical** | **Rust + Bevy ECS** — `BuildingBundle` with components. `DynamicBuffer<ProductionItem>` for queue. `PowerGrid` as a `Resource` (singleton). Clean separation of simulation and rendering. |
| **Custom** | **C++ with Flecs ECS** — Flecs provides fast entity iteration with `flecs::System` for building updates. Build production as a reactive system that triggers on component changes. |

**Key patterns to adopt:**
- Grid-based placement with navmesh-aware validation — essential for RTS base building
- ScriptableObject (or JSON) data definitions for all building stats — never hardcode
- Power grid as a separate subsystem with clear production/consumption events
- Production queue as a ring buffer with cancel/refund logic
- Building state machine with explicit transitions and entry/exit actions
- Object pooling for building ghosts (placement preview) to avoid allocation
