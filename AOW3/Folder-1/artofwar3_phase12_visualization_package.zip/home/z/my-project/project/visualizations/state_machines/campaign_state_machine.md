# Campaign State Machine — Art of War 3: Global Conflict

Campaign progression state machine with mission states, unlock conditions,
completion tracking, difficulty tiers, and chapter progression.

## Primary Campaign State Machine

```mermaid
stateDiagram-v2
    direction TB

    [*] --> Locked : Campaign initialized
    Locked --> Available : Prerequisites met\n[Previous mission Completed OR first mission]

    Available --> InProgress : "Play Mission" pressed\n[Loading battle]
    Available --> Skipped : Skip mission\n[Premium feature / Cheats]
    Available --> Locked : Prerequisites unmet\n[Should not happen - defensive]

    InProgress --> Completed : Victory condition achieved\n[Primary objectives met]
    InProgress --> Failed : Defeat condition met\n[Base destroyed / Timer expired / Objective failed]
    InProgress --> Paused : Player pauses\n[Not in multiplayer campaign]
    InProgress --> Abandoned : Player exits mission\n[Quit to campaign map]

    Paused --> InProgress : Resume mission
    Paused --> Abandoned : Quit while paused

    Failed --> Available : Retry selected\n[No penalty for retry]
    Failed --> Skipped : Skip after multiple failures\n[3+ attempts, premium only]

    Completed --> Completed : Replay mission\n[Optional: improve star rating]

    Skipped --> Available : Next mission unlocked\n[Same as Completed for progression]
    Skipped --> Skipped : Cannot replay skipped\n[Until chapter select unlocked]

    Abandoned --> Available : Return to campaign map\n[No penalty]

    note right of Completed
        Star rating system:
        ★☆☆ : Primary objective only
        ★★☆ : Primary + 1 secondary
        ★★★ : All objectives + time bonus
        Stars unlock bonus rewards
    end note

    note right of Available
        Prerequisites vary:
        - Sequential: Mission N-1 completed
        - Branch: Any of [M1, M2, M3] completed
        - Accumulation: N total stars required
        - Faction: Specific faction mission first
    end note
```

## Chapter Progression

```mermaid
stateDiagram-v2
    direction TB

    state "Chapter 1: Liberation" as Ch1 {
        [*] --> Ch1_M1_Locked : Locked
        Ch1_M1_Locked --> Ch1_M1_Available : Auto-unlocked\n[Chapter 1 start]
        Ch1_M1_Available --> Ch1_M1_Completed : Mission won
        Ch1_M1_Completed --> Ch1_M2_Available : Unlocked

        Ch1_M2_Available --> Ch1_M2_Completed : Mission won
        Ch1_M2_Completed --> Ch1_M3_Available : Unlocked

        Ch1_M3_Available --> Ch1_M3_Completed : Mission won
        Ch1_M3_Completed --> Ch1_Boss_Available : All Ch1 missions done
        Ch1_Boss_Available --> Ch1_Boss_Completed : Boss defeated
    }

    Ch1_Boss_Completed --> Ch2_Start : Chapter 1 complete\n[Cutscene played]

    state "Chapter 2: Resistance" as Ch2 {
        [*] --> Ch2_M1_Available : Auto-unlocked
        Ch2_M1_Available --> Ch2_M1_Completed : Mission won

        Ch2_M1_Completed --> Ch2_M2A_Available : Branch A unlocked
        Ch2_M1_Completed --> Ch2_M2B_Available : Branch B unlocked

        Ch2_M2A_Available --> Ch2_M2A_Completed : Branch A won
        Ch2_M2B_Available --> Ch2_M2B_Completed : Branch B won

        Ch2_M2A_Completed --> Ch2_M3_Available : Either branch completes
        Ch2_M2B_Completed --> Ch2_M3_Available : Either branch completes

        Ch2_M3_Available --> Ch2_M3_Completed : Mission won
        Ch2_M3_Completed --> Ch2_Boss_Available : Unlocked
        Ch2_Boss_Available --> Ch2_Boss_Completed : Boss defeated
    }

    Ch2_Boss_Completed --> Ch3_Start : Chapter 2 complete

    state "Chapter 3: Global Conflict" as Ch3 {
        [*] --> Ch3_M1_Available
        Ch3_M1_Available --> Ch3_M1_Completed
        Ch3_M1_Completed --> Ch3_M2_Available
        Ch3_M2_Available --> Ch3_M2_Completed
        Ch3_M2_Completed --> Ch3_Final_Available
        Ch3_Final_Available --> Ch3_Final_Completed
    }

    Ch3_Final_Completed --> CampaignComplete : All chapters done

    CampaignComplete --> [*] : Campaign finished\n[Epilogue cutscene]
```

## Mission Objective State Machine

```mermaid
stateDiagram-v2
    direction TB

    [*] --> ObjectivePending : Mission starts
    ObjectivePending --> ObjectiveActive : Objective becomes relevant\n[Trigger condition met]
    ObjectivePending --> ObjectiveSkipped : Optional objective ignored\n[Alternative path taken]

    ObjectiveActive --> ObjectiveInProgress : Player working on it\n[Progress > 0%]
    ObjectiveActive --> ObjectiveFailed : Failure condition met\n[Timer expired / Target destroyed]
    ObjectiveActive --> ObjectiveCancelled : Mission path changed\n[Story branching]

    ObjectiveInProgress --> ObjectiveComplete : Success condition met\n[Target destroyed / Area secured / Item collected]
    ObjectiveInProgress --> ObjectiveFailed : Failure condition met
    ObjectiveInProgress --> ObjectiveCancelled : Story branch

    ObjectiveFailed --> MissionFailed : Critical objective failed\n[Primary objective]
    ObjectiveFailed --> ObjectiveActive : Non-critical; mission continues\n[Secondary objective, stars affected]

    ObjectiveComplete --> MissionComplete : All primary objectives complete
    ObjectiveComplete --> BonusUnlocked : Bonus objective complete\n[Special reward]

    ObjectiveSkipped --> [*] : No longer relevant
    ObjectiveCancelled --> [*] : No longer relevant
    BonusUnlocked --> [*] : Reward claimed

    note right of ObjectiveActive
        Objective types:
        - Destroy: Eliminate target(s)
        - Defend: Protect target for duration
        - Escort: Guide unit to destination
        - Capture: Hold position for time
        - Collect: Gather resources/items
        - Build: Construct structures
        - Timed: Complete before timer
        - Stealth: Complete undetected
    end note
```

## Campaign Unlock System

```mermaid
stateDiagram-v2
    direction TB

    [*] --> CheckPrerequisites : Mission selected

    CheckPrerequisites --> CheckChapterPrereq : Check chapter access
    CheckChapterPrereq --> CheckMissionPrereq : Chapter accessible
    CheckChapterPrereq --> ChapterLocked : Previous chapter incomplete

    CheckMissionPrereq --> CheckStarRequirement : Mission prerequisites met
    CheckMissionPrereq --> MissionLocked : Previous mission not completed

    CheckStarRequirement --> CheckResourceRequirement : Star count sufficient
    CheckStarRequirement --> StarDeficit : Need more stars\n[Display star map]

    CheckResourceRequirement --> MissionAvailable : Resources sufficient\n[No cost for campaign]
    CheckResourceRequirement --> ResourceDeficit : Need specific unlock\n[Premium / Special condition]

    MissionAvailable --> InProgress : Start mission

    ChapterLocked --> [*] : Return to map
    MissionLocked --> [*] : Return to map
    StarDeficit --> [*] : Return to replay missions
    ResourceDeficit --> [*] : Return to acquire resource

    note right of StarDeficit
        Star gates per chapter:
        Ch1: No gate (tutorial)
        Ch2: 6 stars from Ch1
        Ch3: 15 stars from Ch1+2
        Ch4: 27 stars from all previous
        Final: All primary objectives
    end note
```

## Faction Campaign Branches

```mermaid
stateDiagram-v2
    direction TB

    [*] --> FactionSelect : Campaign mode entered

    FactionSelect --> ResistanceCampaign : Resistance chosen
    FactionSelect --> CartelCampaign : Cartel chosen

    state "Resistance Campaign" as ResistanceCampaign {
        [*] --> R_Ch1
        R_Ch1 --> R_Ch2 : Liberation complete
        R_Ch2 --> R_Ch3 : Underground complete
        R_Ch3 --> R_Final : Final assault
        R_Final --> [*] : Resistance victory
    }

    state "Cartel Campaign" as CartelCampaign {
        [*] --> C_Ch1
        C_Ch1 --> C_Ch2 : Domination complete
        C_Ch2 --> C_Ch3 : Expansion complete
        C_Ch3 --> C_Final : Global control
        C_Final --> [*] : Cartel victory
    }

    ResistanceCampaign --> FactionSelect : Switch faction\n[Progress preserved]
    CartelCampaign --> FactionSelect : Switch faction\n[Progress preserved]

    note right of FactionSelect
        Faction differences:
        Resistance:
        - Stealth mechanics (forest bonus)
        - Guerrilla tactics
        - Defensive missions
        - Hero: Chameleon (fog barrier)

        Cartel:
        - Brute force (Jaguar tank)
        - Economic advantage
        - Aggressive missions
        - Hero: Superweapon access earlier
    end note
```
