# Recreation Mapping: Campaign System

## Purpose

The Campaign System manages the single-player story experience in Art of War 3: Global Conflict, encompassing two full campaigns (~50 missions each) for the Confederation and Resistance factions. It controls mission sequencing, objective tracking, narrative scripting (dialogue, cutscenes, scripted events), mission-specific win/loss conditions, intermediate rewards (credits, unit unlocks, tech unlocks), and campaign progression persistence. The system bridges the narrative and gameplay layers: it sets up mission scenarios with specific map configurations, starting forces, enemy AI parameters, and scripted sequences that unfold during play. It also handles mission difficulty scaling, optional bonus objectives, and the flow between missions (campaign map with mission nodes).

## Inputs

- **Player Input**: Mission selection, campaign map navigation, difficulty choice
- **Mission Definitions**: Pre-authored mission data (map, objectives, scripts, AI config)
- **Game Systems**: All systems feed state for objective evaluation (units killed, buildings destroyed, areas captured)
- **Persistence System**: Campaign progress, completed missions, earned rewards
- **Dialogue Script Data**: Voice-over lines, subtitle text, timing

## Outputs

- **Mission State**: Current mission progress, objective completion status
- **Scripted Events**: Dialogue triggers, cutscene activations, unit spawn waves
- **Rewards**: Credits, unlocks granted upon mission completion
- **Campaign Progress**: Updated node state on campaign map
- **End-Mission Summary**: Statistics, star rating, rewards display

## Dependencies

- **All Game Systems**: Campaign missions use the full game simulation
- **AI System**: Mission-specific AI behavior and difficulty
- **Persistence System**: For saving campaign progress
- **GUI System**: For campaign map, mission briefings, objective display
- **Audio System**: For voice-overs and music

## Internal Logic

Each campaign mission is defined by a `MissionDefinition` containing: map reference, faction, starting units/buildings, AI opponents with configuration, primary and optional objectives, scripted event timeline, dialogue sequences, and reward table. Missions are authored as data + scripts, not hardcoded.

The objective system supports multiple objective types: `DestroyTarget` (destroy specific building/unit), `SurviveTimer` (survive for N minutes), `CaptureArea` (move units to location), `EscortUnit` (keep a unit alive to destination), `CollectResource` (gather N resources), `BuildStructure` (construct a specific building), and compound objectives (complete A AND B, or A OR B). Objectives are checked every tick against current game state.

The scripting system uses an event-driven timeline: `MissionScript` contains a sequence of `ScriptedEvent` entries, each triggered by a condition (time elapsed, objective state change, area entered, unit health threshold). Events include: spawn enemy wave, trigger dialogue, enable/disable AI, change alliance, reveal map area, grant units, and trigger cutscene.

Campaign progression uses a node-based map: each mission is a node, and completing a mission unlocks connected nodes. Some missions have branching paths (choose mission A or B, leading to different story branches). The campaign map is rendered as a strategic overview with faction-themed art.

## Pseudocode

```
class CampaignSystem:
    currentCampaign: Campaign
    currentMission: Mission
    missionState: MissionState
    scriptedEvents: PriorityQueue<ScriptedEvent>

    function startMission(missionId):
        definition = MissionDefinitions.get(missionId)
        currentMission = Mission(definition)
        missionState = MissionState.IN_PROGRESS
        // Initialize map
        mapSystem.loadMap(definition.mapId)
        // Place starting units and buildings
        for unitDef in definition.startingUnits:
            unitSystem.spawnUnit(unitDef.type, unitDef.faction, unitDef.position)
        for buildingDef in definition.startingBuildings:
            buildingSystem.placeBuilding(buildingDef.type, buildingDef.faction, buildingDef.position)
        // Configure AI opponents
        for aiConfig in definition.aiPlayers:
            aiSystem.configure(aiConfig.playerId, aiConfig.difficulty, aiConfig.behaviorProfile)
        // Set up objectives
        currentMission.primaryObjectives = definition.primaryObjectives.map(o -> Objective(o))
        currentMission.bonusObjectives = definition.bonusObjectives.map(o -> Objective(o))
        // Queue scripted events
        for event in definition.scriptedEvents:
            scriptedEvents.enqueue(event)
        // Start dialogue briefing
        dialogueSystem.playBriefing(definition.briefingDialogue)

    function update(deltaTime):
        if missionState != IN_PROGRESS:
            return
        // Check objectives
        for objective in currentMission.primaryObjectives:
            if not objective.isComplete and objective.checkCondition(gameState):
                objective.isComplete = true
                onObjectiveComplete(objective)
        // Check win/loss
        if allPrimaryObjectivesComplete():
            onMissionWin()
        elif anyFailConditionMet():
            onMissionFail()
        // Process scripted events
        while not scriptedEvents.isEmpty() and scriptedEvents.peek().shouldTrigger(gameState):
            event = scriptedEvents.dequeue()
            executeScriptedEvent(event)

    function onObjectiveComplete(objective):
        guiSystem.showObjectiveComplete(objective)
        audioSystem.playObjectiveCompleteSound()
        // Some objectives trigger events
        for event in objective.completionEvents:
            executeScriptedEvent(event)

    function executeScriptedEvent(event):
        switch event.type:
            case SPAWN_WAVE:
                for unit in event.units:
                    unitSystem.spawnUnit(unit.type, event.faction, unit.position)
                aiSystem.activateWave(event.waveId)
            case TRIGGER_DIALOGUE:
                dialogueSystem.playDialogue(event.dialogueId)
            case REVEAL_AREA:
                fogOfWar.revealArea(event.center, event.radius, event.duration)
            case GRANT_UNITS:
                for unit in event.units:
                    unitSystem.spawnUnit(unit.type, playerFaction, unit.position)
            case CHANGE_DIFFICULTY:
                aiSystem.setDifficulty(event.playerId, event.newDifficulty)
            case PLAY_CUTSCENE:
                cutsceneSystem.play(event.cutsceneId)

    function onMissionWin():
        missionState = COMPLETED
        // Calculate star rating
        stars = calculateStars(currentMission)
        // Grant rewards
        rewards = currentMission.definition.rewards
        if stars >= 3:
            rewards += currentMission.definition.bonusRewards
        economySystem.grantCredits(player, rewards.credits)
        // Unlock next missions
        for nextMission in currentMission.definition.unlocks:
            campaignMap.unlockNode(nextMission)
        persistenceSystem.saveCampaignProgress(currentCampaign.id, currentMission.id, stars)
        guiSystem.showMissionComplete(stars, rewards)
```

## Modern Implementation Recommendations

| Approach | Recommendation |
|----------|---------------|
| **Best Overall** | **Unity 2023 + Timeline + Dialogue System** — Use Unity Timeline for cutscenes and scripted sequences. A custom dialogue system (or Ink integration) for narrative. ScriptableObjects for mission definitions. |
| **Alternative Engine** | **Godot 4 + Dialogic 2** — Dialogic 2 for dialogue and cutscenes. `Resource` subclasses for mission definitions. `AnimationPlayer` for scripted sequences. |
| **Data-Driven** | **Custom Lua scripting layer** — Embed Lua for mission scripting. Missions are data + Lua scripts. Extremely flexible for designers. Use MoonSharp (Unity) or luerl (Erlang) or mlua (Rust). |
| **Rapid Prototyping** | **Ink (inkle) + Unity** — Ink for branching narrative. Unity for gameplay. Clean separation of narrative and simulation. |

**Key patterns to adopt:**
- Mission definitions as data (JSON/ScriptableObject), not code — designers must be able to create missions
- Event-driven scripting with a timeline — conditions trigger events, not frame-by-frame scripts
- Compound objectives with AND/OR logic — reusable objective types combined per mission
- Star rating system with bonus objectives for replayability
- Campaign map as a graph (nodes and edges) — supports branching paths
- Mission scripting should be hot-reloadable for rapid iteration during development
