# Recreation Mapping: Upgrade/Tech System

## Purpose

The Upgrade/Tech System governs technological progression in Art of War 3: Global Conflict, enabling players to unlock superior units, buildings, abilities, and stat bonuses through research investments. It implements a tiered tech tree per faction with branching paths, where each tier unlocks new capabilities and upgrades for existing ones. The system handles research queueing in tech buildings, prerequisite chains (must research A before B), faction-specific tech trees (Confederation and Resistance have distinct tech paths), upgrade effects that modify unit/building stats globally, and the strategic decision-making of tech timing versus military spending. Tech progression is the long-term strategic layer that distinguishes early-game, mid-game, and late-game army compositions and strategies.

## Inputs

- **Player Input**: Research selection from tech tree UI, upgrade activation
- **Building System**: Tech buildings that enable research, upgrade notifications
- **Economy System**: Research cost validation and deduction (supplies + uranium for high-tier)
- **Unit System**: Stat modification requests for upgraded units
- **Combat System**: Damage/armor/range modifier application

## Outputs

- **Research Completions**: Unlocked technologies, available unit/building upgrades
- **Stat Modifiers**: Global modifiers applied to unit types (e.g., +15% damage to all Anti-Tank units)
- **New Build Options**: Unlocked units and buildings in production menus
- **Tech Tree State**: Current research progress, available technologies, locked technologies
- **Visual Indicators**: Tier markers on buildings, upgrade effects on units

## Dependencies

- **Building System**: For tech building construction and operation
- **Economy System**: For research cost deduction
- **Unit System**: For stat modifier application
- **Combat System**: For damage/range modifiers
- **GUI System**: For tech tree display and research UI
- **Network System**: For synchronized research state

## Internal Logic

The tech tree is structured as a directed acyclic graph (DAG) of `TechNode` objects. Each node has: unique ID, display name, description, cost (supplies, uranium, time), prerequisites (list of tech node IDs that must be completed first), tier (T1, T2, T3), faction restriction, and effects (list of `TechEffect` objects). Tech effects include: `StatModifier` (apply multiplier/addend to specific unit stat), `UnitUnlock` (enable production of a unit type), `BuildingUnlock` (enable construction of a building type), `AbilityUnlock` (grant a hero ability), and `ProductionSpeedBonus` (reduce build time in specific factories).

Research is conducted in tech buildings (Tech Center, specialized labs). The player selects a technology from the tech tree UI, and if prerequisites are met and resources are available, the research begins. Research progress advances per-tick based on a timer. Only one research can be active at a time per tech building, but multiple tech buildings can research in parallel (if the player builds multiple).

When research completes, all associated `TechEffect` objects are applied. `StatModifier` effects are stored in a `ModifierRegistry` that the Unit and Combat systems query when calculating stats. For example, when an Anti-Tank unit calculates damage, it asks: `modifierRegistry.getDamageModifier(unitType, faction)` which returns the product of all applicable modifiers (1.0 base × 1.15 for Tier 2 Anti-Tank Upgrade × 1.1 for Faction Bonus = 1.265).

The tier system gates content: Tier 1 (starting tech), Tier 2 (requires Tech Center), Tier 3 (requires Advanced Lab). Superweapons are Tier 3 and require significant uranium investment, making them late-game strategic options.

## Pseudocode

```
class TechSystem:
    techTrees: Map<Faction, TechTree>
    activeResearch: Map<PlayerID, List<ActiveResearch>>
    modifierRegistry: Map<PlayerID, ModifierRegistry>

    function startResearch(player, techNodeId):
        techNode = techTrees[player.faction].getNode(techNodeId)
        // Validate
        if techNode.isComplete(player):
            return RESEARCH_FAIL_ALREADY_DONE
        if not allPrerequisitesMet(player, techNode):
            return RESEARCH_FAIL_PREREQUISITES
        if not economySystem.canAfford(player, techNode.cost):
            return RESEARCH_FAIL_NO_RESOURCES
        // Deduct cost
        economySystem.deduct(player, techNode.cost)
        // Start research timer
        activeResearch[player].add(ActiveResearch(
            techNode = techNode,
            progress = 0.0,
            startTime = gameTime.elapsed
        ))

    function updateResearch(deltaTime):
        for player, researchList in activeResearch:
            for research in researchList:
                research.progress += deltaTime / research.techNode.researchTime
                if research.progress >= 1.0:
                    completeResearch(player, research.techNode)
                    researchList.remove(research)

    function completeResearch(player, techNode):
        techNode.markComplete(player)
        // Apply all effects
        for effect in techNode.effects:
            applyTechEffect(player, effect)
        eventBus.emit(ResearchCompletedEvent(player, techNode))
        guiSystem.showNotification("Research Complete: " + techNode.name)

    function applyTechEffect(player, effect):
        switch effect.type:
            case STAT_MODIFIER:
                modifierRegistry[player].addModifier(
                    effect.targetUnitType,
                    effect.statType,  // DAMAGE, ARMOR, SPEED, RANGE, etc.
                    effect.operation,  // MULTIPLY, ADD
                    effect.value
                )
            case UNIT_UNLOCK:
                buildingSystem.unlockUnit(player, effect.unitType)
            case BUILDING_UNLOCK:
                buildingSystem.unlockBuilding(player, effect.buildingType)
            case ABILITY_UNLOCK:
                heroSystem.unlockAbility(player, effect.abilityId)
            case PRODUCTION_SPEED_BONUS:
                modifierRegistry[player].addProductionBonus(
                    effect.factoryType,
                    effect.speedMultiplier
                )

    function getModifiedStat(player, unitType, statType) -> float:
        baseValue = UnitDefinitions.get(unitType).getStat(statType)
        modifiers = modifierRegistry[player].getModifiers(unitType, statType)
        result = baseValue
        for mod in modifiers:
            if mod.operation == MULTIPLY:
                result *= mod.value
            elif mod.operation == ADD:
                result += mod.value
        return result

class TechNode:
    id: string
    name: string
    tier: TechTier  // T1, T2, T3
    cost: ResourceCost
    researchTime: float  // Seconds
    prerequisites: List<string>  // TechNode IDs
    faction: Faction
    effects: List<TechEffect>
    isCompleteForPlayer: Map<PlayerID, bool>

class TechEffect:
    type: TechEffectType  // STAT_MODIFIER, UNIT_UNLOCK, BUILDING_UNLOCK, etc.
    targetUnitType: UnitType  // For stat modifiers
    statType: StatType  // DAMAGE, ARMOR, SPEED, RANGE, HP
    operation: ModifierOp  // MULTIPLY, ADD
    value: float
    unitType: UnitType  // For unit unlock
    buildingType: BuildingType  // For building unlock
```

## Modern Implementation Recommendations

| Approach | Recommendation |
|----------|---------------|
| **Best Overall** | **Unity 2023 + ScriptableObjects** — `TechNode` as ScriptableObject with references to other TechNodes for prerequisites. `TechTree` as a ScriptableObject collection. Inspector-friendly for designers. |
| **Alternative Engine** | **Godot 4 + Resource system** — `TechNode : Resource` with exported properties. `TechTree` as a JSON file loaded at runtime. Godot's `Resource` system provides similar data-authoring to ScriptableObjects. |
| **Data-Driven** | **JSON/YAML tech tree definitions** — Parse at runtime. Enables modding support and hot-reloading. Use JSON Schema for validation. |
| **Rust + Bevy** | — `TechNode` as a Bevy `Resource`. `ModifierRegistry` as a `Resource` with `HashMap<(UnitType, StatType), Vec<Modifier>>`. Systems query the registry for stat calculations. |

**Key patterns to adopt:**
- DAG (directed acyclic graph) for tech tree — never circular dependencies
- Modifier registry pattern — decouple tech effects from stat consumers
- Multiplicative stacking for percentage modifiers — prevents exponential scaling from additive stacking
- Faction-specific tech trees as separate data assets
- Tier gating via building requirements (Tech Center for T2, Adv Lab for T3)
- Research queue per tech building (not global) — building multiple tech centers enables parallel research
