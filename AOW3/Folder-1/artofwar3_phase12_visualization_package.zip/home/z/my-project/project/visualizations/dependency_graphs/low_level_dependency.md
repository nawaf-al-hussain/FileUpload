# Art of War 3: Global Conflict — Low-Level Dependency Graph

> Class-level dependencies (~75 key classes) grouped by namespace. Extracted from IL2CPP decompilation (29,334 types, 140,824 methods, 141 assemblies).

## Legend

| Style | Meaning |
|-------|---------|
| Red border | Core / critical class |
| Orange dashed border | Bottleneck class (high fan-in) |
| Blue fill | Battle namespace |
| Green fill | Infrastructure / services |
| Purple fill | Domain / social |
| Yellow fill | Third-party wrapper |

---

## Mermaid Class Dependency Graph

```mermaid
graph TD
    %% ═══════════════════════════════════════════════════════
    %%  NAMESPACE: com.geargames.aow.core
    %% ═══════════════════════════════════════════════════════
    subgraph Core["com.geargames.aow.core"]
        GSM["GameStateManager"]
        DI["ZenjectContainer"]
        SCOR["SceneOrchestrator"]
        GOBJ["GameObjectFactory"]
        RESM["ResourceManager"]
        POOL["ObjectPoolManager"]
        EVBUS["EventBus"]
        COROUT["CoroutineRunner"]
    end

    %% ═══════════════════════════════════════════════════════
    %%  NAMESPACE: com.geargames.aow.scenes.battle
    %% ═══════════════════════════════════════════════════════
    subgraph Battle["com.geargames.aow.scenes.battle"]
        BS["BattleScreen"]
        LS["LogicService"]
        BGUI["BattleGUI"]
        BCTRL["BattleController"]
        BRULE["BattleRuleEngine"]
        BSTAT["BattleStateTracker"]
        BSYNC["BattleSyncManager"]
        BREPLAY["BattleReplaySystem"]
    end

    %% ═══════════════════════════════════════════════════════
    %%  NAMESPACE: com.geargames.aow.scenes.battle.gui
    %% ═══════════════════════════════════════════════════════
    subgraph BattleGUI_NS["com.geargames.aow.scenes.battle.gui"]
        GBLU["GUIBattleListUpgrade"]
        GBHU["GUIBattleHud"]
        GBMINI["GUIMinimap"]
        GBSEL["GUISelectionPanel"]
        GBPROD["GUIProductionQueue"]
        GBTOOL["GUIQuickToolbar"]
    end

    %% ═══════════════════════════════════════════════════════
    %%  NAMESPACE: com.geargames.aow.scenes.battle.network
    %% ═══════════════════════════════════════════════════════
    subgraph BattleNet["com.geargames.aow.scenes.battle.network"]
        CSLB["CSLoginToBattle"]
        SCBR["SCBattleResult"]
        CSORD["CSOrderUnit"]
        CSBUILD["CSBuildStructure"]
        NPROV["NetworkProvider"]
        NCRYPT["NetworkEncryption"]
        NSERI["ProtobufSerializer"]
        NCONN["ConnectionManager"]
        NPERS["PersistentConnection"]
        NEPH["EphemeralConnection"]
    end

    %% ═══════════════════════════════════════════════════════
    %%  NAMESPACE: com.geargames.aow.entities
    %% ═══════════════════════════════════════════════════════
    subgraph Entities["com.geargames.aow.entities"]
        UENT["UnitEntity"]
        BENT["BuildingEntity"]
        EBASE["EntityBase"]
        ECOMP["EntityComponent"]
        HCOMP["HealthComponent"]
        WCOMP["WeaponComponent"]
        MCOMP["MovementComponent"]
        VCOMP["VisibilityComponent"]
        EREG["EntityRegistry"]
    end

    %% ═══════════════════════════════════════════════════════
    %%  NAMESPACE: com.geargames.aow.scenes.battle.map
    %% ═══════════════════════════════════════════════════════
    subgraph Map["com.geargames.aow.scenes.battle.map"]
        TMAP["TileMap"]
        TCELL["TileCell"]
        FOW["FogOfWar"]
        PATHF["AStarPathfinder"]
        NAVM["NavMeshAdapter"]
    end

    %% ═══════════════════════════════════════════════════════
    %%  NAMESPACE: com.geargames.aow.scenes.battle.map.ai
    %% ═══════════════════════════════════════════════════════
    subgraph AI_NS["com.geargames.aow.scenes.battle.map.ai"]
        AIBRAIN["AIBrainController"]
        AISUP["AIStrategicPlanner"]
        AITAC["AITacticalExecutor"]
        AIECO["AIEconomyManager"]
        AIUNIT["AIUnitController"]
    end

    %% ═══════════════════════════════════════════════════════
    %%  NAMESPACE: com.geargames.aow.economy
    %% ═══════════════════════════════════════════════════════
    subgraph Economy["com.geargames.aow.economy"]
        RSH["ResourceServiceHelper"]
        RPOOL["ResourcePool"]
        COST["CostCalculator"]
        PRODC["ProductionChain"]
    end

    %% ═══════════════════════════════════════════════════════
    %%  NAMESPACE: com.geargames.aow.scenes.main
    %% ═══════════════════════════════════════════════════════
    subgraph Main["com.geargames.aow.scenes.main"]
        MHUB["MainHubScreen"]
        MNAV["MainNavigation"]
        MBATT["MainBattleList"]
        MSTORE["MainStoreScreen"]
    end

    %% ═══════════════════════════════════════════════════════
    %%  NAMESPACE: Domains.Workshop
    %% ═══════════════════════════════════════════════════════
    subgraph Workshop["Domains.Workshop"]
        WSCR["WorkshopScreen"]
        WUPG["WorkshopUpgradeService"]
        WTECH["TechTreeController"]
    end

    %% ═══════════════════════════════════════════════════════
    %%  NAMESPACE: Domains.Clan
    %% ═══════════════════════════════════════════════════════
    subgraph Clan["Domains.Clan"]
        CSCR["ClanScreen"]
        CSVC["ClanService"]
        CCHAT["ClanChatController"]
    end

    %% ═══════════════════════════════════════════════════════
    %%  NAMESPACE: Domains.Chat
    %% ═══════════════════════════════════════════════════════
    subgraph Chat["Domains.Chat"]
        CHSCR["ChatScreen"]
        CHSVC["ChatService"]
        CHMSG["MessageProcessor"]
    end

    %% ═══════════════════════════════════════════════════════
    %%  NAMESPACE: Domains.Skills
    %% ═══════════════════════════════════════════════════════
    subgraph Skills["Domains.Skills"]
        SKSCR["SkillsScreen"]
        SKSVC["SkillService"]
        SKTREE["SkillTreeController"]
    end

    %% ═══════════════════════════════════════════════════════
    %%  NAMESPACE: Domains.Profile
    %% ═══════════════════════════════════════════════════════
    subgraph Profile["Domains.Profile"]
        PSCR["ProfileScreen"]
        PSVC["ProfileService"]
        PPROG["ProgressionTracker"]
    end

    %% ═══════════════════════════════════════════════════════
    %%  NAMESPACE: com.geargames.aow.persistence
    %% ═══════════════════════════════════════════════════════
    subgraph Persistence["com.geargames.aow.persistence"]
        DBM["DatabaseManager"]
        SQH["SQLiteHelper"]
        DREP["DataRepository"]
        CSER["CacheSerializer"]
    end

    %% ═══════════════════════════════════════════════════════
    %%  NAMESPACE: com.geargames.aow.assets
    %% ═══════════════════════════════════════════════════════
    subgraph Assets["com.geargames.aow.assets"]
        ALDR["AddressableLoader"]
        ACAT["AssetCatalog"]
        ABUN["BundleManager"]
        ACCH["AssetCache"]
    end

    %% ═══════════════════════════════════════════════════════
    %%  NAMESPACE: com.geargames.aow.analytics
    %% ═══════════════════════════════════════════════════════
    subgraph Analytics["com.geargames.aow.analytics"]
        ANMGR["AnalyticsManager"]
        FIREV["FirebaseEventHandler"]
        APME["AppMetricaEventHandler"]
    end

    %% ═══════════════════════════════════════════════════════
    %%  NAMESPACE: com.geargames.aow.audio
    %% ═══════════════════════════════════════════════════════
    subgraph Audio["com.geargames.aow.audio"]
        AUDM["AudioManager"]
        AUDS["AudioSourcePool"]
        AUDF["SoundFXPlayer"]
    end

    %% ═══════════════════════════════════════════════════════
    %%  DEPENDENCY EDGES
    %% ═══════════════════════════════════════════════════════

    %% Core → Core
    GSM --> DI
    GSM --> EVBUS
    SCOR --> GSM
    GOBJ --> POOL
    GOBJ --> RESM

    %% Scene Orchestrator → Screens
    SCOR --> BS
    SCOR --> MHUB

    %% Battle Screen cluster
    BS --> LS
    BS --> BGUI
    BS --> BCTRL
    BS --> BSYNC
    BS --> BREPLAY
    BCTRL --> BRULE
    BCTRL --> BSTAT

    %% Logic Service → Entity / Map / AI / Economy
    LS --> EREG
    LS --> TMAP
    LS --> AIBRAIN
    LS --> RSH
    LS --> BSYNC

    %% Battle GUI → GUI components
    BGUI --> GBLU
    BGUI --> GBHU
    BGUI --> GBMINI
    BGUI --> GBSEL
    BGUI --> GBPROD
    BGUI --> GBTOOL

    %% GUI components → Logic Service / Entity
    GBLU --> LS
    GBHU --> BSTAT
    GBSEL --> EREG
    GBPROD --> BENT
    GBTOOL --> LS

    %% Battle Network
    CSLB --> NPROV
    SCBR --> NPROV
    CSORD --> NPROV
    CSBUILD --> NPROV
    NPROV --> NCRYPT
    NPROV --> NSERI
    NPROV --> NCONN
    NCONN --> NPERS
    NCONN --> NEPH
    BSYNC --> CSLB
    BSYNC --> SCBR

    %% Entities
    UENT --> EBASE
    BENT --> EBASE
    EBASE --> ECOMP
    HCOMP --> ECOMP
    WCOMP --> ECOMP
    MCOMP --> ECOMP
    VCOMP --> ECOMP
    EREG --> UENT
    EREG --> BENT

    %% Map / Pathfinding
    TMAP --> TCELL
    FOW --> TMAP
    PATHF --> TMAP
    NAVM --> TMAP

    %% AI → entities, map, economy, pathfinding
    AIBRAIN --> AISUP
    AIBRAIN --> AITAC
    AIBRAIN --> AIECO
    AISUP --> AITAC
    AISUP --> PATHF
    AITAC --> AIUNIT
    AIUNIT --> UENT
    AIECO --> RSH
    AIECO --> BENT

    %% Economy
    RSH --> RPOOL
    RSH --> COST
    COST --> PRODC

    %% Unit ↔ Building circular
    UENT -.->|🔴 circular| BENT

    %% Battle → Network
    BCTRL --> CSORD
    BCTRL --> CSBUILD

    %% Main hub
    MHUB --> MNAV
    MNAV --> MBATT
    MNAV --> MSTORE
    MNAV --> WSCR
    MNAV --> CSCR
    MNAV --> CHSCR
    MNAV --> SKSCR
    MNAV --> PSCR

    %% Workshop
    WSCR --> WUPG
    WUPG --> WTECH
    WUPG --> RSH
    WTECH --> UENT

    %% Clan
    CSCR --> CSVC
    CSVC --> CCHAT
    CSVC --> NPROV
    CCHAT --> CHSVC

    %% Chat
    CHSCR --> CHSVC
    CHSVC --> CHMSG
    CHSVC --> NPROV

    %% Skills
    SKSCR --> SKSVC
    SKSVC --> SKTREE
    SKTREE --> UENT

    %% Profile
    PSCR --> PSVC
    PSVC --> PPROG
    PSVC --> NPROV
    PPROG --> DREP

    %% Persistence
    DBM --> SQH
    DREP --> DBM
    DREP --> CSER

    %% Assets
    ALDR --> ACAT
    ALDR --> ABUN
    ALDR --> ACCH
    BS --> ALDR
    MHUB --> ALDR
    GOBJ --> ALDR

    %% Analytics
    ANMGR --> FIREV
    ANMGR --> APME
    GSM --> ANMGR

    %% Audio
    BS --> AUDM
    MHUB --> AUDM
    AUDM --> AUDS
    AUDM --> AUDF

    %% Store → Billing (implicit)
    MSTORE --> PSVC

    %% Core runtime used everywhere
    BS --> GSM
    MHUB --> GSM
    NPROV --> GSM
    ALDR --> RESM

    %% ═══════════════════════════════════════════════════════
    %%  STYLES
    %% ═══════════════════════════════════════════════════════
    style GSM fill:#ff4444,stroke:#aa0000,stroke-width:3px,color:#fff
    style LS fill:#ff4444,stroke:#aa0000,stroke-width:3px,color:#fff
    style NPROV fill:#ff4444,stroke:#aa0000,stroke-width:3px,color:#fff
    style EREG fill:#ff4444,stroke:#aa0000,stroke-width:3px,color:#fff
    style ALDR fill:#ff8800,stroke:#cc6600,stroke-width:3px,stroke-dasharray: 5 5,color:#fff
    style RSH fill:#ff8800,stroke:#cc6600,stroke-width:2px,stroke-dasharray: 5 5,color:#fff
    style DBM fill:#ff8800,stroke:#cc6600,stroke-width:2px,stroke-dasharray: 5 5,color:#fff

    style BS fill:#4488ff,stroke:#2244aa,stroke-width:2px,color:#fff
    style BGUI fill:#4488ff,stroke:#2244aa,stroke-width:2px,color:#fff
    style BCTRL fill:#4488ff,stroke:#2244aa,stroke-width:2px,color:#fff
    style BRULE fill:#4488ff,stroke:#2244aa,stroke-width:2px,color:#fff
    style BSTAT fill:#4488ff,stroke:#2244aa,stroke-width:2px,color:#fff
    style BSYNC fill:#4488ff,stroke:#2244aa,stroke-width:2px,color:#fff
    style BREPLAY fill:#4488ff,stroke:#2244aa,stroke-width:2px,color:#fff

    style GBLU fill:#6699ff,stroke:#4477cc,stroke-width:1px,color:#fff
    style GBHU fill:#6699ff,stroke:#4477cc,stroke-width:1px,color:#fff
    style GBMINI fill:#6699ff,stroke:#4477cc,stroke-width:1px,color:#fff
    style GBSEL fill:#6699ff,stroke:#4477cc,stroke-width:1px,color:#fff
    style GBPROD fill:#6699ff,stroke:#4477cc,stroke-width:1px,color:#fff
    style GBTOOL fill:#6699ff,stroke:#4477cc,stroke-width:1px,color:#fff

    style CSLB fill:#44aaff,stroke:#2288dd,stroke-width:2px,color:#fff
    style SCBR fill:#44aaff,stroke:#2288dd,stroke-width:2px,color:#fff
    style CSORD fill:#44aaff,stroke:#2288dd,stroke-width:2px,color:#fff
    style CSBUILD fill:#44aaff,stroke:#2288dd,stroke-width:2px,color:#fff
    style NCRYPT fill:#44aaff,stroke:#2288dd,stroke-width:2px,color:#fff
    style NSERI fill:#44aaff,stroke:#2288dd,stroke-width:2px,color:#fff
    style NCONN fill:#44aaff,stroke:#2288dd,stroke-width:2px,color:#fff
    style NPERS fill:#44aaff,stroke:#2288dd,stroke-width:2px,color:#fff
    style NEPH fill:#44aaff,stroke:#2288dd,stroke-width:2px,color:#fff

    style UENT fill:#44bb44,stroke:#228822,stroke-width:2px,color:#fff
    style BENT fill:#44bb44,stroke:#228822,stroke-width:2px,color:#fff
    style EBASE fill:#44bb44,stroke:#228822,stroke-width:2px,color:#fff
    style ECOMP fill:#44bb44,stroke:#228822,stroke-width:2px,color:#fff
    style HCOMP fill:#44bb44,stroke:#228822,stroke-width:1px,color:#fff
    style WCOMP fill:#44bb44,stroke:#228822,stroke-width:1px,color:#fff
    style MCOMP fill:#44bb44,stroke:#228822,stroke-width:1px,color:#fff
    style VCOMP fill:#44bb44,stroke:#228822,stroke-width:1px,color:#fff

    style TMAP fill:#44bb44,stroke:#228822,stroke-width:2px,color:#fff
    style TCELL fill:#44bb44,stroke:#228822,stroke-width:1px,color:#fff
    style FOW fill:#44bb44,stroke:#228822,stroke-width:1px,color:#fff
    style PATHF fill:#44bb44,stroke:#228822,stroke-width:2px,color:#fff
    style NAVM fill:#44bb44,stroke:#228822,stroke-width:1px,color:#fff

    style AIBRAIN fill:#44bb44,stroke:#228822,stroke-width:2px,color:#fff
    style AISUP fill:#44bb44,stroke:#228822,stroke-width:2px,color:#fff
    style AITAC fill:#44bb44,stroke:#228822,stroke-width:1px,color:#fff
    style AIECO fill:#44bb44,stroke:#228822,stroke-width:1px,color:#fff
    style AIUNIT fill:#44bb44,stroke:#228822,stroke-width:1px,color:#fff

    style RSH fill:#44bb44,stroke:#228822,stroke-width:2px,color:#fff
    style RPOOL fill:#44bb44,stroke:#228822,stroke-width:1px,color:#fff
    style COST fill:#44bb44,stroke:#228822,stroke-width:1px,color:#fff
    style PRODC fill:#44bb44,stroke:#228822,stroke-width:1px,color:#fff

    style MHUB fill:#8844cc,stroke:#6622aa,stroke-width:2px,color:#fff
    style MNAV fill:#8844cc,stroke:#6622aa,stroke-width:2px,color:#fff
    style MBATT fill:#8844cc,stroke:#6622aa,stroke-width:1px,color:#fff
    style MSTORE fill:#8844cc,stroke:#6622aa,stroke-width:1px,color:#fff

    style WSCR fill:#8844cc,stroke:#6622aa,stroke-width:1px,color:#fff
    style WUPG fill:#8844cc,stroke:#6622aa,stroke-width:1px,color:#fff
    style WTECH fill:#8844cc,stroke:#6622aa,stroke-width:1px,color:#fff

    style CSCR fill:#8844cc,stroke:#6622aa,stroke-width:1px,color:#fff
    style CSVC fill:#8844cc,stroke:#6622aa,stroke-width:1px,color:#fff
    style CCHAT fill:#8844cc,stroke:#6622aa,stroke-width:1px,color:#fff

    style CHSCR fill:#8844cc,stroke:#6622aa,stroke-width:1px,color:#fff
    style CHSVC fill:#8844cc,stroke:#6622aa,stroke-width:1px,color:#fff
    style CHMSG fill:#8844cc,stroke:#6622aa,stroke-width:1px,color:#fff

    style SKSCR fill:#8844cc,stroke:#6622aa,stroke-width:1px,color:#fff
    style SKSVC fill:#8844cc,stroke:#6622aa,stroke-width:1px,color:#fff
    style SKTREE fill:#8844cc,stroke:#6622aa,stroke-width:1px,color:#fff

    style PSCR fill:#8844cc,stroke:#6622aa,stroke-width:1px,color:#fff
    style PSVC fill:#8844cc,stroke:#6622aa,stroke-width:1px,color:#fff
    style PPROG fill:#8844cc,stroke:#6622aa,stroke-width:1px,color:#fff

    style DBM fill:#44bb44,stroke:#228822,stroke-width:2px,color:#fff
    style SQH fill:#44bb44,stroke:#228822,stroke-width:1px,color:#fff
    style DREP fill:#44bb44,stroke:#228822,stroke-width:2px,color:#fff
    style CSER fill:#44bb44,stroke:#228822,stroke-width:1px,color:#fff

    style ACAT fill:#dddd44,stroke:#aaaa00,stroke-width:1px,color:#333
    style ABUN fill:#dddd44,stroke:#aaaa00,stroke-width:1px,color:#333
    style ACCH fill:#dddd44,stroke:#aaaa00,stroke-width:1px,color:#333

    style ANMGR fill:#dddd44,stroke:#aaaa00,stroke-width:1px,color:#333
    style FIREV fill:#dddd44,stroke:#aaaa00,stroke-width:1px,color:#333
    style APME fill:#dddd44,stroke:#aaaa00,stroke-width:1px,color:#333

    style AUDM fill:#44bb44,stroke:#228822,stroke-width:2px,color:#fff
    style AUDS fill:#44bb44,stroke:#228822,stroke-width:1px,color:#fff
    style AUDF fill:#44bb44,stroke:#228822,stroke-width:1px,color:#fff

    style DI fill:#ff4444,stroke:#aa0000,stroke-width:2px,color:#fff
    style EVBUS fill:#ff4444,stroke:#aa0000,stroke-width:2px,color:#fff
    style SCOR fill:#ff4444,stroke:#aa0000,stroke-width:2px,color:#fff
    style GOBJ fill:#44bb44,stroke:#228822,stroke-width:1px,color:#fff
    style RESM fill:#ff8800,stroke:#cc6600,stroke-width:2px,stroke-dasharray: 5 5,color:#fff
    style POOL fill:#44bb44,stroke:#228822,stroke-width:1px,color:#fff
    style COROUT fill:#44bb44,stroke:#228822,stroke-width:1px,color:#fff
```

---

## Class Dependency Metrics (Top 15 by Fan-In)

| Class | Namespace | Fan-In | Fan-Out | Role |
|-------|-----------|--------|---------|------|
| **GameStateManager** | core | 5 | 2 | Global state, DI root |
| **LogicService** | scenes.battle | 4 | 5 | Battle simulation kernel |
| **NetworkProvider** | scenes.battle.network | 5 | 4 | All server communication |
| **EntityRegistry** | entities | 3 | 2 | Entity lookup/spawn |
| **AddressableLoader** | assets | 3 | 3 | Content loading gateway |
| **ResourceServiceHelper** | economy | 3 | 2 | Resource operations |
| **BattleScreen** | scenes.battle | 2 | 6 | Battle scene root |
| **MainHubScreen** | scenes.main | 1 | 7 | Main scene root |
| **DatabaseManager** | persistence | 1 | 1 | SQLite access layer |
| **UnitEntity** | entities | 3 | 1 | Core game entity |
| **BuildingEntity** | entities | 2 | 1 | Core game entity |
| **AIBrainController** | map.ai | 1 | 3 | AI decision root |
| **ProfileService** | Domains.Profile | 2 | 2 | Player data service |
| **BattleController** | scenes.battle | 2 | 3 | Battle flow control |
| **EventBus** | core | 2 | 0 | Decoupled event dispatch |

---

## Circular Dependencies Detected

| Class A | Class B | Nature |
|---------|---------|--------|
| `UnitEntity` | `BuildingEntity` | Units reference garrison buildings; buildings reference produced units |
| `BattleScreen` | `BattleGUI` | Screen owns GUI; GUI dispatches back to screen via callbacks |
| `LogicService` | `BattleSyncManager` | Logic drives sync; sync applies server corrections to logic state |
