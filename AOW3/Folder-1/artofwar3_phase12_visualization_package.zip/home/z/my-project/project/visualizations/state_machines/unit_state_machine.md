# Unit State Machine — Art of War 3: Global Conflict

Complete state machine for unit lifecycle covering infantry, vehicles, aircraft, naval, and hero units.
Includes stealth, fuel, abilities, selection, targeting, and unit-type-specific behaviors.

## Primary Unit State Machine

```mermaid
stateDiagram-v2
    direction TB

    [*] --> Spawning : AddUnit()
    Spawning --> Idle : Spawn animation complete

    state "Idle" as Idle {
        [*] --> IdleDefault
        IdleDefault --> IdleSelected : SelectUnitsByRectangle()\n/ SelectCentralUnit()
        IdleSelected --> IdleDefault : Deselect / Click empty ground
    }

    Idle --> Moving : Move command issued
    Idle --> Attacking : Enemy in range & auto-aggro\n[calcShooter() != null]
    Idle --> Patrolling : Patrol command issued
    Idle --> Retreating : Retreat command / HP < retreatThreshold
    Idle --> Stunned : Stun effect applied
    Idle --> AbilityActive : ActivateAbility()
    Idle --> OutOfFuel : Fuel depleted\n[aircraft/vehicle only]
    Idle --> Dying : HP <= 0

    Moving --> Idle : Destination reached
    Moving --> Attacking : Enemy spotted in aggro range\n[calcShooter() acquires target]
    Moving --> Retreating : Retreat command issued
    Moving --> Stunned : Stun effect applied
    Moving --> OutOfFuel : Fuel depleted mid-move
    Moving --> Dying : HP <= 0 during movement

    Attacking --> Idle : Target destroyed & no other targets
    Attacking --> Moving : Target out of range\n/ Move to engage
    Attacking --> Retreating : HP < retreatThreshold
    Attacking --> Stunned : Stun effect applied
    Attacking --> AbilityActive : Ability triggered during combat
    Attacking --> OutOfFuel : Fuel depleted
    Attacking --> Dying : HP <= 0

    Patrolling --> Idle : Patrol cancelled / Stop command
    Patrolling --> Attacking : Enemy in aggro range\n[calcShooter() != null]
    Patrolling --> Retreating : HP < retreatThreshold
    Patrolling --> Stunned : Stun effect applied
    Patrolling --> Dying : HP <= 0

    Retreating --> Idle : Safe distance reached\n/ Rally point reached
    Retreating --> Attacking : Cornered (no retreat path)\n& enemy in range
    Retreating --> Dying : HP <= 0 during retreat
    Retreating --> Stunned : Stun effect applied

    Stunned --> Idle : Stun duration expires
    Stunned --> Dying : HP <= 0 while stunned

    AbilityActive --> Idle : Ability duration expires\n/ DeactivateActiveAbility()
    AbilityActive --> Attacking : Combat ability ends\n& targets remain
    AbilityActive --> Moving : Movement ability ends\n& move target exists
    AbilityActive --> Dying : HP <= 0 during ability

    OutOfFuel --> Idle : Refueled at Airport/Depot\n[Aircraft: must be at Airport]
    OutOfFuel --> Dying : HP <= 0\n[Aircraft: crash if airborne too long]
    OutOfFuel --> Stunned : Stun effect applied

    Dying --> [*] : DestroyUnit()\n/ Death animation complete

    state OutOfFuel {
        [*] --> Grounded : Vehicle/Naval
        [*] --> Hovering : Aircraft (loiter)
        Hovering --> Crashing : Fuel timer expires
        Grounded --> Refueling : At supply source
        Hovering --> Refueling : Landed at Airport
        Refueling --> [*] : Fuel restored
        Crashing --> [*] : Unit destroyed
    }
```

## Unit Type Variants

```mermaid
stateDiagram-v2
    direction TB

    state "Infantry" as Infantry {
        [*] --> InfIdle
        InfIdle --> InfMoving : Move command
        InfIdle --> InfAttacking : Enemy in range
        InfIdle --> InfGarrisoning : Garrison building command
        InfAttacking --> InfIdle : Target destroyed
        InfGarrisoning --> InfIdle : Ungarrison / Building destroyed
        InfIdle --> InfStealthed : In forest tile\n[Resistance faction only]
        InfStealthed --> InfIdle : Attacked / Moved out of forest
        InfStealthed --> InfAttacking : Attack from stealth\n[reveals unit]
    }

    state "Vehicle" as Vehicle {
        [*] --> VehIdle
        VehIdle --> VehMoving : Move command
        VehIdle --> VehAttacking : Enemy in range
        VehIdle --> VehOutOfFuel : Fuel == 0
        VehOutOfFuel --> VehIdle : Refueled at Depot

        state "Jaguar Tank (Dual Mode)" as Jaguar {
            [*] --> TravelMode
            TravelMode --> SiegeMode : Deploy command\n[4s deploy time]
            SiegeMode --> TravelMode : Undeploy command\n[2s undeploy time]
            TravelMode : Move speed normal, Attack damage low
            SiegeMode : Move speed zero, Attack damage high, Range increased
        }
    }

    state "Aircraft" as Aircraft {
        [*] --> AirIdle
        AirIdle --> AirFlying : Launch / Move command
        AirFlying --> AirAttacking : Enemy in range
        AirAttacking --> AirReturning : Ammo depleted / Fuel low
        AirReturning --> AirRefueling : At Airport
        AirRefueling --> AirIdle : Refuel complete
        AirFlying --> AirCrashing : Fuel == 0 & airborne
        AirCrashing --> [*] : Crash (DestroyUnit)
        AirIdle --> AirFlying : Scramble command
        note right of AirRefueling : Must have Airport building\nfor refueling
    }

    state "Naval" as Naval {
        [*] --> NavalIdle
        NavalIdle --> NavalMoving : Move command
        NavalIdle --> NavalAttacking : Enemy in range
        NavalAttacking --> NavalIdle : Target destroyed

        state "Submarine" as Submarine {
            [*] --> Surfaced
            Surfaced --> Submerged : Submerge command\n[stealth active]
            Submerged --> Surfaced : Surface command\n/ Attack initiated
            Submerged : Invisible to enemy\nCan detect other subs
            Surfaced : Visible, can attack surface targets
        }
    }

    state "Hero" as Hero {
        [*] --> HeroIdle
        HeroIdle --> HeroAttacking : Enemy in range
        HeroIdle --> HeroAbilityActive : ActivateAbility()
        HeroAbilityActive --> HeroCooldown : Ability ends\n[OnAbilityCooldownHandler]
        HeroCooldown --> HeroIdle : Cooldown complete\n[GetAbilityStates() == Ready]
        HeroCooldown --> HeroAttacking : Auto-aggro during cooldown

        state "Chameleon Unit" as Chameleon {
            [*] --> ChameleonIdle
            ChameleonIdle --> FogBarrier : Activate fog ability
            FogBarrier : Creates fog barrier area\nBlocks enemy vision
            FogBarrier --> ChameleonIdle : DeactivateActiveAbility()\n/ Duration expires
        }
    }
```

## Unit Selection State Machine

```mermaid
stateDiagram-v2
    direction LR

    [*] --> Unselected : Unit spawned
    Unselected --> Selected : SelectUnitsByRectangle()\nincludes unit
    Unselected --> Selected : Tap/click on unit

    Selected --> Unselected : Deselect all
    Selected --> Unselected : Click empty ground
    Selected --> Unselected : Select other units\n(not in selection rect)

    state "Selected" as Selected {
        [*] --> SingleSelected
        SingleSelected --> MultiSelected : SelectUnitsByRectangle()\nselects additional units
        MultiSelected --> SingleSelected : SelectCentralUnit()\n/ Only central unit kept
        MultiSelected --> SingleSelected : Other units die/deselect
    }

    Selected --> CommandIssued : Move/Attack/Patrol/Ability command
    CommandIssued --> Selected : Command acknowledged\n[unit retains selection]
    CommandIssued --> Unselected : Command fails
```

## Hero Ability State Machine

```mermaid
stateDiagram-v2
    direction TB

    [*] --> Ready : GetAbilityStates() == Ready
    Ready --> Activating : ActivateAbility()\n[Mana/Energy sufficient]
    Ready --> Locked : Prerequisite not met\n[Level too low / Tech not researched]

    Locked --> Ready : Prerequisite fulfilled

    Activating --> Active : Cast time complete
    Activating --> Ready : Cast interrupted\n[Stunned / Silenced]
    Activating --> Ready : Cast cancelled

    Active --> Channeling : Ability type == Channeled
    Active --> Cooldown : Instant ability ends

    Channeling --> Cooldown : Channel complete
    Channeling --> Interrupted : Stunned / Silenced\n/ Moved by CC
    Interrupted --> Cooldown : OnAbilityCooldownHandler()\n[Partial cooldown applies]

    Cooldown --> Ready : Cooldown timer expires
    Cooldown --> ReducedCooldown : Cooldown reduction buff applied
    ReducedCooldown --> Ready : Reduced timer expires

    note right of Active : abilityPassiveWeaponActivate()\nmay trigger passive weapon
    note right of Cooldown : OnAbilityCooldownHandler()\nnotifies AI & UI
```

## Superweapon Launch Sequence

```mermaid
stateDiagram-v2
    direction TB

    [*] --> Standby : Building complete & powered
    Standby --> Arming : Launch command issued\n[Charge cost paid]
    Arming --> Armed : Arming timer complete\n[10s charge time]

    Armed --> Countdown : Confirm launch\n[Target selected]
    Armed --> Standby : Launch cancelled\n[Refund 50% charge]

    Countdown --> Launching : Countdown complete\n[5s uncancelable]
    Countdown --> Standby : Cancelled during countdown\n[No refund]

    Launching --> Impact : Projectile in flight
    Impact --> Cooldown : Impact resolved\n[Damage calculated via\nCalculateWeaponArmorDamage()]

    Cooldown --> Standby : Cooldown complete\n[60s base cooldown]

    Standby --> Disabled_NoPower : Power deficit
    Disabled_NoPower --> Standby : Power restored
    Arming --> Disabled_NoPower : Power lost during arming
    Armed --> Disabled_NoPower : Power lost while armed
```
