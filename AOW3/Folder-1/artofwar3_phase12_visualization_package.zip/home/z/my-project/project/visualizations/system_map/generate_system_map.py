#!/usr/bin/env python3
"""
Generate a high-level system map PNG for Art of War 3: Global Conflict.
Uses matplotlib to create a visual map with nodes, connections, and legends.
"""

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch
import numpy as np

# ====== CONFIGURATION ======
OUTPUT_PATH = "/home/z/my-project/project/visualizations/system_map/system_map.png"
DPI = 200
FIG_W, FIG_H = 28, 18

# Category colors
CAT_COLORS = {
    'core':        '#e74c3c',
    'gameplay':    '#3498db',
    'content':     '#27ae60',
    'multiplayer': '#e67e22',
    'domain':      '#9b59b6',
}

CAT_LABELS = {
    'core':        'CORE RUNTIME',
    'gameplay':    'GAMEPLAY SYSTEMS',
    'content':     'CONTENT SYSTEMS',
    'multiplayer': 'MULTIPLAYER SYSTEMS',
    'domain':      'DOMAIN SYSTEMS',
}

# System definitions: (id, category, label, sublabel, [col, row within category])
SYSTEMS = [
    # Core Runtime - row 0
    ('mainloop',   'core', 'Main Loop',        'Unity Update Cycle',    0, 0),
    ('gamestate',  'core', 'Game State Mgr',    'Scenes & Lifecycle',    1, 0),
    ('renderer',   'core', 'Renderer',          'Unity Pipeline',        2, 0),
    ('input',      'core', 'Input Manager',     'GGInputModule',         3, 0),
    ('resource',   'core', 'Resource Mgr',      'Addressables',          4, 0),

    # Gameplay - rows 1-2
    ('unit',       'gameplay', 'Unit System',       'Creation, Selection, Cmds',  0, 1),
    ('combat',     'gameplay', 'Combat System',     'Damage, Weapons, Armor',     1, 1),
    ('building',   'gameplay', 'Building System',   'Construction, Production',   2, 1),
    ('economy',    'gameplay', 'Economy System',    'Supplies, Power, Gold',      3, 1),
    ('upgrade',    'gameplay', 'Upgrade System',    'Tech Tree, Upgrades',        4, 1),
    ('ai',         'gameplay', 'AI System',         'Strategic & Tactical',       0, 2),
    ('pathfinding','gameplay', 'Pathfinding',       'Grid-Based A*',              1, 2),
    ('fow',        'gameplay', 'Fog of War',        'Vision, Stealth',            2, 2),
    ('mission',    'gameplay', 'Mission System',    'Campaigns, Objectives',       3, 2),

    # Content - row 3
    ('maps',       'content', 'Maps',           '8 Scenarios',           0, 3),
    ('campaigns',  'content', 'Campaigns',      '~100 Missions',         1, 3),
    ('assets',     'content', 'Assets',         '773 Catalog Entries',   2, 3),
    ('ui',         'content', 'UI System',      'Zenject MVP',           3, 3),
    ('audio',      'content', 'Audio System',   'SFX, VO, Music',        4, 3),

    # Multiplayer - rows 0-1 right side
    ('network',    'multiplayer', 'Networking',       'Main & Battle Servers',   6, 0),
    ('sync',       'multiplayer', 'Synchronization',  'Tick Sync, Prediction',   7, 0),
    ('cmdproc',    'multiplayer', 'Command Proc.',    'Validation, Arbitration', 8, 0),
    ('replication','multiplayer', 'Replication',      'State Rep, Desync',       6, 1),
    ('matchmaking','multiplayer', 'Matchmaking',      '1v1, 2v2, Tournament',    7, 1),
    ('chat',       'multiplayer', 'Chat System',      'Rooms, Translation',      8, 1),

    # Domain - rows 2-3 right side
    ('workshop',   'domain', 'Workshop',      'Unit Customization',  6, 2),
    ('clan',       'domain', 'Clan System',   'Creation, Wars',      7, 2),
    ('skills',     'domain', 'Skills System', 'Commander Skills',    8, 2),
    ('rating',     'domain', 'Rating System', 'ELO Ranking',         6, 3),
    ('store',      'domain', 'Store System',  'IAP, Packs',          7, 3),
    ('tournament', 'domain', 'Tournament',    'Brackets, Rewards',   8, 3),
    ('replay',     'domain', 'Replay System', 'Recording, Playback', 6.5, 3.7),
]

# Connections: (from_id, to_id, type) type: 'control', 'data', 'event'
CONNECTIONS = [
    # Control
    ('mainloop','gamestate','control'),
    ('mainloop','renderer','control'),
    ('mainloop','input','control'),
    ('mainloop','resource','control'),
    ('gamestate','unit','control'),
    ('gamestate','building','control'),
    ('gamestate','mission','control'),
    ('ai','unit','control'),

    # Data
    ('input','unit','data'),
    ('unit','pathfinding','data'),
    ('pathfinding','unit','data'),
    ('unit','combat','data'),
    ('combat','unit','data'),
    ('fow','ai','data'),
    ('fow','combat','data'),
    ('economy','building','data'),
    ('economy','unit','data'),
    ('building','unit','data'),
    ('upgrade','unit','data'),
    ('upgrade','building','data'),
    ('resource','assets','data'),
    ('maps','pathfinding','data'),
    ('maps','fow','data'),
    ('campaigns','mission','data'),
    ('workshop','unit','data'),
    ('skills','combat','data'),
    ('skills','unit','data'),
    ('store','economy','data'),
    ('skills','upgrade','data'),
    ('network','sync','data'),
    ('sync','cmdproc','data'),
    ('cmdproc','replication','data'),
    ('network','matchmaking','data'),
    ('network','chat','data'),
    ('rating','matchmaking','data'),
    ('tournament','matchmaking','data'),
    ('clan','chat','data'),
    ('replay','replication','data'),
    ('replay','cmdproc','data'),
    ('replication','unit','data'),
    ('replication','combat','data'),

    # Event
    ('combat','economy','event'),
    ('combat','mission','event'),
    ('mission','gamestate','event'),
    ('unit','ui','event'),
    ('building','unit','event'),
    ('economy','ui','event'),
    ('combat','audio','event'),
    ('building','audio','event'),
    ('matchmaking','gamestate','event'),
    ('tournament','economy','event'),
]

# ====== LAYOUT CALCULATIONS ======
NODE_W = 2.6
NODE_H = 1.1
COL_SPACING = 3.0
ROW_SPACING = 1.6

# Compute positions
positions = {}
for sid, cat, label, sub, col, row in SYSTEMS:
    x = col * COL_SPACING + NODE_W / 2
    y = FIG_H - 1.5 - row * ROW_SPACING - NODE_H / 2
    positions[sid] = (x, y, cat, label, sub)


def draw_system_map():
    fig, ax = plt.subplots(1, 1, figsize=(FIG_W, FIG_H), dpi=DPI)
    fig.patch.set_facecolor('#0f1923')
    ax.set_facecolor('#0f1923')
    ax.set_xlim(-0.5, FIG_W * COL_SPACING / 3 + 1)
    ax.set_ylim(-0.5, FIG_H + 0.5)
    ax.set_aspect('auto')
    ax.axis('off')

    # Title
    ax.text(FIG_W / 2, FIG_H - 0.3,
            'ART OF WAR 3: GLOBAL CONFLICT — SYSTEM MAP',
            ha='center', va='top', fontsize=18, fontweight='bold',
            color='#ecf0f1',
            fontfamily='sans-serif')

    # Draw category group backgrounds
    cat_groups = {}
    for sid, cat, label, sub, col, row in SYSTEMS:
        if cat not in cat_groups:
            cat_groups[cat] = {'min_col': col, 'max_col': col, 'min_row': row, 'max_row': row}
        g = cat_groups[cat]
        g['min_col'] = min(g['min_col'], col)
        g['max_col'] = max(g['max_col'], col)
        g['min_row'] = min(g['min_row'], row)
        g['max_row'] = max(g['max_row'], row)

    for cat, g in cat_groups.items():
        x1 = g['min_col'] * COL_SPACING - 0.3
        y1 = FIG_H - 1.5 - g['min_row'] * ROW_SPACING + NODE_H / 2 + 0.2
        x2 = (g['max_col'] + 1) * COL_SPACING - COL_SPACING + NODE_W + 0.3
        y2 = FIG_H - 1.5 - g['max_row'] * ROW_SPACING - NODE_H / 2 - 0.4
        rect = FancyBboxPatch((x1, y2), x2 - x1, y1 - y2,
                              boxstyle="round,pad=0.15",
                              facecolor=CAT_COLORS[cat] + '15',
                              edgecolor=CAT_COLORS[cat] + '60',
                              linewidth=2,
                              zorder=1)
        ax.add_patch(rect)
        ax.text(x1 + 0.3, y1 - 0.15, CAT_LABELS[cat],
                fontsize=9, fontweight='bold', color=CAT_COLORS[cat],
                va='top', ha='left', zorder=5,
                fontfamily='sans-serif')

    # Draw connections first (behind nodes)
    conn_styles = {
        'control': {'color': '#7f8c8d', 'style': '-',  'width': 1.2, 'alpha': 0.6},
        'data':    {'color': '#5dade2', 'style': '--', 'width': 1.0, 'alpha': 0.5},
        'event':   {'color': '#f39c12', 'style': ':',  'width': 1.5, 'alpha': 0.6},
    }

    for from_id, to_id, ctype in CONNECTIONS:
        if from_id not in positions or to_id not in positions:
            continue
        fx, fy, _, _, _ = positions[from_id]
        tx, ty, _, _, _ = positions[to_id]
        style = conn_styles[ctype]

        # Calculate direction for offset
        dx = tx - fx
        dy = ty - fy
        dist = np.sqrt(dx*dx + dy*dy)
        if dist < 0.01:
            continue

        # Offset start/end to not overlap node boxes
        offset_s = 0.3
        offset_e = 0.3
        sx = fx + dx/dist * offset_s
        sy = fy + dy/dist * offset_s
        ex = tx - dx/dist * offset_e
        ey = ty - dy/dist * offset_e

        ax.annotate('', xy=(ex, ey), xytext=(sx, sy),
                    arrowprops=dict(
                        arrowstyle='->',
                        color=style['color'],
                        linestyle=style['style'],
                        linewidth=style['width'],
                        alpha=style['alpha'],
                        mutation_scale=12,
                        shrinkA=0, shrinkB=0,
                    ),
                    zorder=2)

    # Draw nodes
    for sid, cat, label, sub, col, row in SYSTEMS:
        x, y, _, _, _ = positions[sid]
        color = CAT_COLORS[cat]

        # Node background
        rect = FancyBboxPatch((x - NODE_W/2, y - NODE_H/2), NODE_W, NODE_H,
                              boxstyle="round,pad=0.08",
                              facecolor='#1a2736',
                              edgecolor=color,
                              linewidth=2.5,
                              zorder=3)
        ax.add_patch(rect)

        # Left accent bar
        bar_rect = FancyBboxPatch((x - NODE_W/2 - 0.02, y - NODE_H/2 + 0.05), 0.15, NODE_H - 0.1,
                                  boxstyle="round,pad=0.02",
                                  facecolor=color,
                                  edgecolor='none',
                                  zorder=4)
        ax.add_patch(bar_rect)

        # Title text
        ax.text(x + 0.05, y + 0.12, label,
                ha='center', va='center', fontsize=8, fontweight='bold',
                color='#ecf0f1', zorder=5,
                fontfamily='sans-serif')

        # Subtitle text
        ax.text(x + 0.05, y - 0.2, sub,
                ha='center', va='center', fontsize=6,
                color='#95a5a6', zorder=5,
                fontfamily='sans-serif')

    # Draw legend
    legend_x = 1.0
    legend_y = 1.5

    ax.text(legend_x, legend_y + 0.6, 'LEGEND', fontsize=9, fontweight='bold',
            color='#ecf0f1', fontfamily='sans-serif')

    # Category legend
    for i, (cat, color) in enumerate(CAT_COLORS.items()):
        yp = legend_y - i * 0.45
        ax.plot(legend_x, yp, 'o', color=color, markersize=8, zorder=5)
        ax.text(legend_x + 0.3, yp, CAT_LABELS[cat], fontsize=7,
                color='#ecf0f1', va='center', fontfamily='sans-serif')

    # Connection type legend
    conn_legend_y = legend_y - 5.5 * 0.45
    for i, (ctype, style) in enumerate(conn_styles.items()):
        yp = conn_legend_y - i * 0.45
        ax.plot([legend_x - 0.4, legend_x + 0.4], [yp, yp],
                linestyle=style['style'], color=style['color'],
                linewidth=style['width'] * 2, zorder=5)
        labels = {'control': 'Control Flow', 'data': 'Data Flow', 'event': 'Event Flow'}
        ax.text(legend_x + 0.6, yp, labels[ctype], fontsize=7,
                color='#ecf0f1', va='center', fontfamily='sans-serif')

    # Update order annotation
    update_x = FIG_W - 4.5
    update_y = FIG_H - 2.0
    ax.text(update_x, update_y + 0.4, 'UPDATE ORDER', fontsize=8, fontweight='bold',
            color='#ecf0f1', fontfamily='sans-serif')
    update_steps = [
        '1. Input Processing',
        '2. Network Message Processing',
        '3. AI Tick',
        '4. Unit Movement / Pathfinding',
        '5. Combat Resolution',
        '6. Building Production',
        '7. Economy Update',
        '8. State Synchronization',
        '9. GUI Update',
        '10. Audio Update',
        '11. Render',
    ]
    for i, step in enumerate(update_steps):
        ax.text(update_x, update_y - 0.3 - i * 0.35, step, fontsize=5.5,
                color='#95a5a6', va='center', fontfamily='monospace')

    # Init order annotation
    init_x = FIG_W - 4.5
    init_y = update_y - 0.3 - 11 * 0.35 - 0.8
    ax.text(init_x, init_y + 0.4, 'INIT SEQUENCE', fontsize=8, fontweight='bold',
            color='#ecf0f1', fontfamily='sans-serif')
    init_steps = [
        '1. Unity Engine Startup',
        '2. StartupManager Init',
        '3. Addressables Warm-Up',
        '4. Authentication',
        '5. Server Connection',
        '6. Profile Loading',
        '7. Main Scene Loading',
        '8. GUI Init (Zenject)',
        '9. Battle: Load→Net→Map→Spawn',
    ]
    for i, step in enumerate(init_steps):
        ax.text(init_x, init_y - 0.3 - i * 0.35, step, fontsize=5.5,
                color='#95a5a6', va='center', fontfamily='monospace')

    plt.tight_layout(pad=0.5)
    plt.savefig(OUTPUT_PATH, dpi=DPI, facecolor='#0f1923', edgecolor='none',
                bbox_inches='tight', pad_inches=0.3)
    plt.close()
    print(f"System map saved to: {OUTPUT_PATH}")


if __name__ == '__main__':
    draw_system_map()
