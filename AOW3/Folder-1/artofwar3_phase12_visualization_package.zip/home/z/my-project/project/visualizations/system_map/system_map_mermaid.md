# Art of War 3: Global Conflict — System Map

## Comprehensive Architecture Diagram

This diagram shows ALL major game systems, their interactions, initialization order, and update cycle.

```mermaid
flowchart TB
    %% ===== STYLES =====
    classDef core fill:#e74c3c,stroke:#c0392b,color:#fff,stroke-width:2px
    classDef gameplay fill:#3498db,stroke:#2980b9,color:#fff,stroke-width:2px
    classDef content fill:#27ae60,stroke:#1e8449,color:#fff,stroke-width:2px
    classDef multiplayer fill:#e67e22,stroke:#d35400,color:#fff,stroke-width:2px
    classDef domain fill:#9b59b6,stroke:#8e44ad,color:#fff,stroke-width:2px
    classDef dataFlow fill:none,stroke:#95a5a6,stroke-dasharray:5 5,color:#7f8c8d
    classDef eventFlow fill:none,stroke:#f39c12,color:#f39c12,stroke-width:2px
    classDef controlFlow fill:none,stroke:#2c3e50,color:#2c3e50,stroke-width:2px
    classDef initOrder fill:#ffeaa7,stroke:#f39c12,color:#2c3e50,stroke-width:2px

    %% ===== CORE RUNTIME =====
    subgraph CORE["🔴 CORE RUNTIME"]
        direction TB
        ML["🔄 Main Loop<br/>(Unity Update Cycle)"]
        GSM["🎮 Game State Manager<br/>(Scene Transitions, App Lifecycle)"]
        REN["🖼️ Renderer<br/>(Unity Pipeline, Sprites, 3D, Particles)"]
        INP["👆 Input Manager<br/>(GGInputModule, Touch, Gestures)"]
        RES["📦 Resource Manager<br/>(Addressables, Load/Unload, Cache)"]

        ML --> GSM
        ML --> REN
        ML --> INP
        ML --> RES
    end

    %% ===== GAMEPLAY SYSTEMS =====
    subgraph GAMEPLAY["🔵 GAMEPLAY SYSTEMS"]
        direction TB
        UNIT["⚔️ Unit System<br/>(Creation, Selection, Movement, Commands, Groups)"]
        COMBAT["💥 Combat System<br/>(Damage Calc, Weapon Types, Armor, Targeting)"]
        BLDG["🏗️ Building System<br/>(Construction, Upgrades, Production Queues, Power)"]
        ECON["💰 Economy System<br/>(Supplies, Power, Uranium, Credits, Gold)"]
        UPG["🔬 Upgrade System<br/>(Tech Tree, Unit Upgrades, Building Upgrades)"]
        AI["🧠 AI System<br/>(Strategic AI, Tactical AI, Pathfinding A*, Fog of War)"]
        PATH["🗺️ Pathfinding System<br/>(Grid-Based A*, Terrain Types, Obstacles)"]
        FOW["👁️ Fog of War System<br/>(Vision Ranges, Exploration, Stealth Detection)"]
        MISSION["📋 Mission System<br/>(Campaign Missions, Objectives, Win Conditions)"]
    end

    %% ===== CONTENT SYSTEMS =====
    subgraph CONTENT["🟢 CONTENT SYSTEMS"]
        direction TB
        MAPS["🗺️ Maps<br/>(8 Scenarios, Terrain Generation)"]
        CAMPAIGNS["📖 Campaigns<br/>(~100 Missions, Two Factions)"]
        ASSETS["🎨 Assets<br/>(773 Catalog Entries, 23 Bundles)"]
        UI["🖥️ UI System<br/>(Zenject Presenters, Panels, Windows)"]
        AUDIO["🔊 Audio System<br/>(Battle SFX, VO, Music, DOTween)"]
    end

    %% ===== MULTIPLAYER SYSTEMS =====
    subgraph MULTIPLAYER["🟠 MULTIPLAYER SYSTEMS"]
        direction TB
        NET["🌐 Networking Layer<br/>(Persistent Main Server, Ephemeral Battle Server)"]
        SYNC["🔄 Synchronization Layer<br/>(Tick-Based Sync, Client Prediction)"]
        CMD["📨 Command Processing<br/>(Validation, Arbitration)"]
        REPL["📡 Replication Layer<br/>(State Replication, Desync Detection)"]
        MATCH["🎯 Matchmaking System<br/>(1v1, 2v2, Tournament Matching)"]
        CHAT["💬 Chat System<br/>(Rooms, Moderation, Translation, Friends)"]
    end

    %% ===== DOMAIN SYSTEMS =====
    subgraph DOMAIN["🟣 DOMAIN SYSTEMS"]
        direction TB
        WORKSHOP["🔧 Workshop System<br/>(Unit Customization)"]
        CLAN["🏰 Clan System<br/>(Creation, Management, Wars)"]
        SKILLS["⚡ Skills System<br/>(Commander Skills, Skill Trees)"]
        RATING["🏆 Rating System<br/>(ELO-Based Ranking)"]
        STORE["🛒 Store System<br/>(IAP, Packs, Offers)"]
        TOURNAMENT["🎖️ Tournament System<br/>(Brackets, Rewards)"]
        REPLAY["🎞️ Replay System<br/>(Battle Recording, Playback)"]
    end

    %% ===== CONTROL FLOWS (Solid) =====
    GSM ==>|controls| UNIT
    GSM ==>|controls| BLDG
    GSM ==>|controls| MISSION
    ML ==>|drives| GAMEPLAY
    ML ==>|drives| CONTENT

    %% ===== DATA FLOWS (Dotted) =====
    INP -.->|player input| UNIT
    UNIT -.->|positions| PATH
    PATH -.->|routes| UNIT
    UNIT -.->|target data| COMBAT
    COMBAT -.->|damage results| UNIT
    FOW -.->|visibility| AI
    AI -.->|commands| UNIT
    FOW -.->|visibility| COMBAT
    ECON -.->|resources| BLDG
    ECON -.->|resources| UNIT
    BLDG -.->|production| UNIT
    BLDG -.->|power| ECON
    UPG -.->|buffs| UNIT
    UPG -.->|buffs| BLDG
    RES -.->|assets| ASSETS
    RES -.->|assets| MAPS
    RES -.->|assets| AUDIO
    MAPS -.->|terrain data| PATH
    MAPS -.->|terrain data| FOW

    %% ===== EVENT FLOWS (Colored) =====
    COMBAT -->|unit destroyed| ECON
    COMBAT -->|unit destroyed| MISSION
    MISSION -->|objective complete| GSM
    UNIT -->|selection changed| UI
    BLDG -->|production complete| UNIT
    ECON -->|insufficient resources| UI
    SKILLS -->|activate| COMBAT
    SKILLS -->|activate| UNIT

    %% ===== MULTIPLAYER INTERACTIONS =====
    NET <-->|messages| SYNC
    SYNC <-->|tick data| CMD
    CMD <-->|validated commands| REPL
    REPL <-->|state| GAMEPLAY
    NET <-->|match data| MATCH
    NET <-->|messages| CHAT
    MATCH -->|match found| GSM
    REPL -.->|desync| SYNC

    %% ===== DOMAIN INTERACTIONS =====
    WORKSHOP -.->|customization| UNIT
    CLAN <-->|social| CHAT
    RATING <-->|rank update| MATCH
    RATING <-->|stats| CLAN
    TOURNAMENT <-->|bracket matches| MATCH
    TOURNAMENT -.->|rewards| ECON
    STORE -.->|purchases| ECON
    REPLAY -.->|record| REPL
    REPLAY -.->|record| CMD
    SKILLS -.->|unlocks| UPG

    %% ===== INITIALIZATION ORDER =====
    subgraph INIT["⚡ INITIALIZATION SEQUENCE"]
        direction TB
        I1["1️⃣ Unity Engine Startup"] --> I2["2️⃣ StartupManager Initializes"]
        I2 --> I3["3️⃣ Addressables Warm-Up"]
        I3 --> I4["4️⃣ Authentication (Firebase/Google Play)"]
        I4 --> I5["5️⃣ Server Connection (Main Server)"]
        I5 --> I6["6️⃣ Profile Loading (SQLite + Server Sync)"]
        I6 --> I7["7️⃣ Main Scene Loading"]
        I7 --> I8["8️⃣ GUI System Init (Zenject)"]
        I8 --> I9["9️⃣ Battle Start: Loading → Network Login → Map Gen → Entity Spawn → Battle Loop"]
    end

    %% ===== UPDATE ORDER =====
    subgraph UPDATE["🔁 UPDATE LOOP ORDER"]
        direction TB
        U1["1️⃣ Input Processing"] --> U2["2️⃣ Network Message Processing"]
        U2 --> U3["3️⃣ AI Tick"]
        U3 --> U4["4️⃣ Unit Movement / Pathfinding"]
        U4 --> U5["5️⃣ Combat Resolution"]
        U5 --> U6["6️⃣ Building Production"]
        U6 --> U7["7️⃣ Economy Update"]
        U7 --> U8["8️⃣ State Synchronization"]
        U8 --> U9["9️⃣ GUI Update"]
        U9 --> U10["🔟 Audio Update"]
        U10 --> U11["1️⃣1️⃣ Render"]
        U11 -->|next frame| U1
    end

    %% ===== CLASS ASSIGNMENTS =====
    class ML,GSM,REN,INP,RES core
    class UNIT,COMBAT,BLDG,ECON,UPG,AI,PATH,FOW,MISSION gameplay
    class MAPS,CAMPAIGNS,ASSETS,UI,AUDIO content
    class NET,SYNC,CMD,REPL,MATCH,CHAT multiplayer
    class WORKSHOP,CLAN,SKILLS,RATING,STORE,TOURNAMENT,REPLAY domain
```

## Legend

| Line Style | Meaning | Example |
|---|---|---|
| **Solid Arrow (==>)** | Control Flow — one system directly controls/commands another | Game State Manager → Unit System |
| **Dotted Arrow (-.->)** | Data Flow — data passes between systems | Input Manager ⟶ Unit System |
| **Colored Arrow (--)** | Event Flow — events/triggers between systems | Combat → Economy (unit destroyed) |
| **Bidirectional (<-->)** | Two-way communication | Networking ↔ Synchronization |

## System Categories

| Color | Category | Systems |
|---|---|---|
| 🔴 Red | Core Runtime | Main Loop, Game State Manager, Renderer, Input Manager, Resource Manager |
| 🔵 Blue | Gameplay Systems | Unit, Combat, Building, Economy, Upgrade, AI, Pathfinding, Fog of War, Mission |
| 🟢 Green | Content Systems | Maps, Campaigns, Assets, UI, Audio |
| 🟠 Orange | Multiplayer Systems | Networking, Synchronization, Command Processing, Replication, Matchmaking, Chat |
| 🟣 Purple | Domain Systems | Workshop, Clan, Skills, Rating, Store, Tournament, Replay |

## Key Interaction Patterns

### Player Input Flow
```
Player Touch → Input Manager → Command Queue → Logic Service → Game State → Renderer
```

### Network Command Flow
```
Network Messages → Deserialization → Command Processing → State Update → Replication
```

### Economy Loop
```
Supply Centers → Supplies → Build Structures → More Production → More Supplies
```

### Combat Loop
```
Unit Detects Enemy → Targeting → Weapon Selection → Damage Calculation → Health Update → Death/Persist
```
