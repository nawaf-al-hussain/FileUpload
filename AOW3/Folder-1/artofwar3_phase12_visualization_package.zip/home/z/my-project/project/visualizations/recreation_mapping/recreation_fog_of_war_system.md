# Recreation Mapping: Fog of War System

## Purpose

The Fog of War System controls battlefield visibility, creating the strategic uncertainty that is fundamental to RTS gameplay. It determines which areas of the map each player can see, which are explored but not currently visible (showing terrain but not enemy units), and which are completely unexplored (dark/hidden). Units and buildings provide vision in a radius around them, and the system calculates line-of-sight taking into account terrain elevation, obstacles (cliffs, forests), and stealth mechanics. The system directly impacts gameplay by hiding enemy positions, enabling ambush strategies, and making reconnaissance a critical activity. It also interacts with the Combat System (units cannot attack what they cannot see) and the AI System (AI visibility is difficulty-dependent).

## Inputs

- **Unit System**: Unit positions for vision source calculation
- **Building System**: Building positions (some buildings like radar provide extended vision)
- **Map Terrain Data**: Elevation map, obstacle map for line-of-sight raycasting
- **Stealth/Invisible Units**: Units with stealth capability that reduce or eliminate vision contribution
- **Hero Abilities**: Scout abilities that temporarily reveal areas
- **Superweapon System**: Nuclear launch reveals target area briefly

## Outputs

- **Visibility Grid**: Per-player grid where each cell has state: UNEXPLORED, EXPLORED, VISIBLE
- **Entity Visibility**: Per-unit/building boolean: is this entity visible to this player?
- **Minimap State**: Fog of war overlay for the minimap rendering
- **GUI Rendering State**: Which enemy units/buildings to render (visible), show last-known positions (explored), or hide (unexplored)

## Dependencies

- **Unit System**: For vision source positions
- **Building System**: For building vision and radar extensions
- **Map/Terrain System**: For elevation and obstacle data
- **Combat System**: For target visibility validation
- **AI System**: For AI player visibility calculation
- **GUI/Rendering System**: For fog overlay rendering

## Internal Logic

The Fog of War operates on a 2D grid overlay that subdivides the map into cells (typically 1-2 meter resolution). Each cell has a visibility state per player: `UNEXPLORED` (never seen), `EXPLORED` (previously seen, terrain visible but no live entities), `VISIBLE` (currently within vision range of a friendly unit/building). Visibility is recalculated every frame by iterating all vision sources (friendly units and buildings) and marking cells within their vision radius as VISIBLE. Line-of-sight is checked using a raycasting algorithm against the terrain elevation map — hills and cliffs block vision.

The transition from VISIBLE to EXPLORED happens when a cell leaves the vision range of all friendly sources. The system maintains a "last seen" snapshot: when a cell transitions from VISIBLE to EXPLORED, the positions and types of enemy entities in that cell are recorded as "last known positions." These are rendered as ghosted/dimmer versions in the GUI, giving the player partial information about what was there.

Stealth units have a reduced vision contribution or none at all — they don't reveal fog for the enemy. Some units (scouts, reconnaissance vehicles) have extended vision range. Buildings like radar stations provide persistent vision in a large radius. Hero abilities can temporarily reveal large areas (a "scan" ability).

The system uses a dirty-flag optimization: only recalculate visibility for cells near units that moved, rather than the entire map. For large maps, this reduces computation from O(mapSize) to O(unitCount × visionArea).

## Pseudocode

```
class FogOfWarSystem:
    visibilityGrid: Map<PlayerID, Grid<VisibilityState>>
    lastKnownPositions: Map<PlayerID, Map<CellCoord, Snapshot>>
    terrainMap: ElevationMap

    function updateVisibility(player):
        grid = visibilityGrid[player]
        // Phase 1: Downgrade VISIBLE cells to EXPLORED
        for cell in grid.cells:
            if cell.state == VISIBLE:
                cell.state = EXPLORED
                // Save last known positions
                if cell.hasEnemyEntities:
                    lastKnownPositions[player][cell.coord] = cell.snapshot()

        // Phase 2: Mark cells VISIBLE from each vision source
        sources = getAllVisionSources(player)
        for source in sources:
            if source.isStealthed:
                continue  // Stealth units don't reveal fog
            visionRadius = source.visionRange + source.visionBonus
            cellsInRadius = grid.getCellsInCircle(source.position, visionRadius)
            for cell in cellsInRadius:
                if hasLineOfSight(source.position, cell.center, terrainMap):
                    cell.state = VISIBLE
                    lastKnownPositions[player].remove(cell.coord)  // Clear stale data

    function hasLineOfSight(from, to, terrain) -> bool:
        // Bresenham or DDA raycast across terrain elevation
        steps = distance(from, to)
        for i in range(0, steps, RAY_STEP_SIZE):
            point = lerp(from, to, i / steps)
            elevation = terrain.getElevation(point)
            if elevation > lineHeight(from, to, i / steps):
                return false  // Terrain blocks vision
        return true

    function isVisibleTo(player, worldPosition) -> bool:
        cell = visibilityGrid[player].getCell(worldPosition)
        return cell.state == VISIBLE

    function getEntityVisibility(entity, player) -> VisibilityLevel:
        cell = visibilityGrid[player].getCell(entity.position)
        if cell.state == VISIBLE:
            return FULL_VISIBLE
        elif cell.state == EXPLORED:
            snapshot = lastKnownPositions[player].get(cell.coord)
            if snapshot and snapshot.containsEntity(entity):
                return LAST_KNOWN  // Ghost/dimmer rendering
            return EXPLORED_TERRAIN_ONLY
        else:
            return HIDDEN

    function onScoutAbility(player, center, radius, duration):
        // Temporarily reveal area
        cells = grid.getCellsInCircle(center, radius)
        for cell in cells:
            cell.state = VISIBLE
            cell.temporaryReveal = true
            cell.revealExpiry = gameTime.elapsed + duration
```

## Modern Implementation Recommendations

| Approach | Recommendation |
|----------|---------------|
| **Best Overall** | **Unity 2023 DOTS/ECS** — Fog grid as a `NativeArray<VisibilityState>` per player. `FogUpdateSystem : JobComponentBase` with Burst compilation for parallel vision calculation. `RaycastCommand` for line-of-sight. Render fog as a render texture overlay. |
| **Alternative Engine** | **Godot 4 with C#** — Use `GridMap` or custom `TileMap` layer for fog state. `DirectSpaceState3D` for raycasting LOS. Shader-based fog rendering with a texture uniform updated per frame. |
| **Performance-Critical** | **Rust + Bevy ECS** — Fog grid as `Resource<HashMap<CellCoord, VisibilityState>>`. Parallel job system for vision updates. Compute shader for fog rendering via `bevy_render`. |
| **GPU-Accelerated** | **Custom compute shader** — Upload vision sources to GPU, compute visibility in a compute shader that writes to a fog texture. Extremely fast for dense fog grids. |

**Key patterns to adopt:**
- Dirty-flag optimization: only recalculate near moved units, not the entire map
- Two-pass update: downgrade VISIBLE→EXPLORED first, then upgrade EXPLORED→VISIBLE from sources
- Separate visibility state from rendering — the system produces data, the renderer consumes it
- Line-of-sight via terrain elevation raycasting, not just distance
- Last-known-position snapshots for "explored but not visible" intelligence
- Stealth as a simple flag: stealth units don't contribute to fog reveal
