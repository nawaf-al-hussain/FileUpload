# Recreation Mapping: GUI System

## Purpose

The GUI System manages all user interface elements in Art of War 3: Global Conflict, from the in-game HUD (resource bar, minimap, unit info panel, production queues, ability bars) to out-of-game screens (main menu, campaign map, tech tree viewer, settings, shop, matchmaking lobby). With 1,240 types and 6,200 methods, it is the second-largest system after AI. The game uses Zenject's MVVM-like presenter pattern where `Presenter` classes mediate between game logic (`Model`) and UI views (`View`), enabling reactive updates via UniRx/R3. The system must handle both touch input (mobile primary) and mouse/keyboard (PC), support multiple resolutions and aspect ratios (phones and tablets), and provide responsive real-time feedback during gameplay where the HUD must update at 30+ FPS to show unit health, resource changes, and production progress without noticeable lag.

## Inputs

- **Player Input**: Touch/click events, hotkey presses, scroll, drag, pinch-zoom
- **Game Systems**: State changes from all systems (resources, selection, health, production)
- **Network System**: Connection status, ping, match events
- **Localization**: Language strings for all UI text
- **Asset System**: UI prefabs, textures, fonts

## Outputs

- **Rendered UI**: All visible interface elements
- **Command Dispatch**: Player actions forwarded to game systems (build, produce, move, attack)
- **Feedback**: Tooltips, animations, notifications, error messages
- **Input State**: Current input mode (normal, targeting, placement, menu)

## Dependencies

- **All Game Systems**: GUI displays data from and sends commands to every system
- **Asset System**: For UI prefab loading
- **Localization System**: For text rendering
- **Audio System**: For UI sound effects (clicks, notifications)
- **Network System**: For connection status display

## Internal Logic

The GUI System is organized into layers:

1. **HUD Layer** (always visible during gameplay): Resource bar (supplies, power, uranium), minimap with fog overlay, unit selection info panel (health, damage, armor, abilities), production queue bars on selected factory, ability bar for selected hero, command card (move/attack/patrol/hold buttons), and a contextual build panel when a builder or factory is selected.

2. **Overlay Layer**: Notifications (research complete, under attack, superweapon warning), tooltips, floating combat text (damage numbers), and ping indicators.

3. **Full-Screen Layer**: Pause menu, tech tree viewer, settings, campaign map, shop, match results.

The presenter pattern works as follows: each UI panel has a `Presenter` class that subscribes to reactive game state streams (via UniRx/R3). When game state changes, the presenter receives the update and modifies the view accordingly. For example, `ResourceBarPresenter` subscribes to `economySystem.resourceStream` and updates the resource display whenever the supply count changes. This decouples UI from game logic — the game systems don't know about UI, and UI doesn't directly modify game state.

Input handling uses a priority-based input stack: the top-most active panel consumes input first. During gameplay, the HUD has lowest priority (only consumes clicks on UI elements). When a menu is open, it captures all input. Placement mode (building ghost) captures clicks for placement validation.

The minimap renders a top-down view of the map with: terrain, unit dots (color-coded by faction and type), building icons, fog of war overlay, and camera frustum indicator. Clicking the minimap moves the camera. The minimap is rendered to a render texture at low resolution (256×256) and updated every few frames for performance.

## Pseudocode

```
class GUISystem:
    presenters: List<Presenter>
    inputStack: InputStack
    minimapRenderer: MinimapRenderer
    activePanels: Stack<UIPanel>

    function initialize():
        // Create presenters for all HUD elements
        presenters.add(ResourceBarPresenter(economySystem, resourceBarView))
        presenters.add(SelectionInfoPresenter(unitSystem, selectionInfoView))
        presenters.add(MinimapPresenter(fogOfWar, minimapView))
        presenters.add(ProductionQueuePresenter(buildingSystem, productionView))
        presenters.add(AbilityBarPresenter(heroSystem, abilityBarView))
        presenters.add(CommandCardPresenter(unitSystem, commandCardView))
        presenters.add(NotificationPresenter(notificationView))
        // Subscribe to state streams
        for presenter in presenters:
            presenter.subscribe()

    function update(deltaTime):
        // Process input
        inputEvent = inputStack.processInput()
        if inputEvent:
            dispatchInput(inputEvent)
        // Update minimap (every 3 frames for performance)
        if frameCount % 3 == 0:
            minimapRenderer.updateRender()

    function openPanel(panelType):
        panel = assetSystem.loadUI(panelType)
        activePanels.push(panel)
        inputStack.push(panel.inputHandler)
        panel.onClose = () => closePanel(panelType)

    function closePanel(panelType):
        panel = activePanels.pop()
        inputStack.pop()
        panel.destroy()

// Example Presenter (MVVM pattern)
class ResourceBarPresenter:
    economySystem: EconomySystem
    view: ResourceBarView

    function subscribe():
        economySystem.resourceStream
            .subscribe(onResourceChanged)

    function onResourceChanged(resources):
        view.setSupplies(resources.supplies)
        view.setUranium(resources.uranium)
        view.setPower(resources.power)
        view.setSupplyRate(resources.supplyIncomeRate)

class SelectionInfoPresenter:
    unitSystem: UnitSystem
    view: SelectionInfoView

    function subscribe():
        unitSystem.selectionStream
            .subscribe(onSelectionChanged)

    function onSelectionChanged(selection):
        if selection.isEmpty():
            view.hide()
            return
        if selection.size == 1:
            unit = selection.first()
            view.showSingleUnit(
                name = unit.name,
                health = unit.hp / unit.maxHp,
                damage = unit.stats.damage,
                armor = unit.stats.armor,
                abilities = unit.abilities
            )
        else:
            view.showMultipleUnits(
                count = selection.size,
                averageHealth = avg(selection.map(u => u.hp / u.maxHp)),
                unitTypes = selection.map(u => u.type).distinct()
            )

// Input handling
class InputStack:
    handlers: Stack<InputHandler>

    function processInput() -> InputEvent:
        rawEvent = inputSystem.poll()
        // Top handler gets first chance to consume
        for handler in handlers.topToBottom:
            if handler.handleInput(rawEvent):
                return null  // Consumed
        return rawEvent  // Not consumed, pass to game

class MinimapRenderer:
    minimapTexture: RenderTexture  // 256x256

    function updateRender():
        // Draw terrain (static, cached)
        // Draw fog of war overlay
        for cell in fogOfWar.visibleCells:
            drawMinimapPixel(cell.position, terrainColor)
        // Draw unit dots
        for unit in allUnits:
            if fogOfWar.isVisibleTo(localPlayer, unit):
                color = unit.faction == localPlayer.faction ? ALLY_COLOR : ENEMY_COLOR
                drawMinimapDot(unit.position, color)
        // Draw camera frustum
        drawCameraFrustum(cameraSystem.getFrustum())
```

## Modern Implementation Recommendations

| Approach | Recommendation |
|----------|---------------|
| **Best Overall** | **Unity 2023 + UI Toolkit + R3 (Reactive Extensions)** — UI Toolkit for modern UI authoring (UXML/USS). R3 (successor to UniRx) for reactive data binding. MVVM pattern with presenters. |
| **Alternative Engine** | **Godot 4 + Control nodes + Signals** — Godot's `Control` node hierarchy for UI. Built-in signal system for reactive updates. `Theme` resources for consistent styling. |
| **Web-Like Approach** | **React/TS for UI overlay + Unity for game** — Render UI in a web overlay (Coherent GameFace or similar). React component model for complex UI. |
| **Rust + Bevy + bevy_egui** | — `egui` for immediate-mode UI. Fast iteration. `bevy_egui` plugin integrates with Bevy's ECS. Best for dev tools; may need custom solution for production UI. |

**Key patterns to adopt:**
- MVVM/Presenter pattern — decouple UI from game logic via reactive streams
- Priority-based input stack — panels consume input before the game layer
- Minimap rendered to low-res render texture — updated every N frames, not every frame
- Touch-first design with mouse/keyboard fallback — mobile is primary
- Panel stack for full-screen overlays — push/pop navigation pattern
- Reactive subscriptions (UniRx/R3) — no polling, push-based updates
- Object pooling for floating text and notifications — avoid GC allocation
- Data-driven UI layout (UXML/JSON) — designers can modify layout without code changes
