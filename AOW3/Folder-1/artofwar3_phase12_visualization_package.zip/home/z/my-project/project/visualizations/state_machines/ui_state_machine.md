# UI State Machine — Art of War 3: Global Conflict

UI screen navigation state machine showing all screens, transitions between them,
and the conditions that drive screen changes throughout the application lifecycle.

## Primary UI Navigation State Machine

```mermaid
stateDiagram-v2
    direction TB

    [*] --> Splash : App launched
    Splash --> Login : Tap to start\n/ Auto-login attempted

    Login --> Main : Authentication successful\n[CSLoginToBattle OK]
    Login --> Login : Retry on failure
    Login --> OfflinePrompt : Server unreachable

    OfflinePrompt --> Login : Retry connection
    OfflinePrompt --> Main : Play offline\n[Limited features]

    Main --> BattleLoading : "Battle" → Select mode\n[MP/Campaign/Skirmish]
    Main --> Settings : Settings button
    Main --> Store : Store button
    Main --> Clan : Clan button
    Main --> Profile : Profile button
    Main --> CampaignSelect : "Campaign" button
    Main --> BattleLoading : Quick match

    Settings --> Main : Back / Close
    Store --> Main : Back / Close
    Clan --> Main : Back / Close
    Profile --> Main : Back / Close
    CampaignSelect --> Main : Back

    CampaignSelect --> BattleLoading : Mission selected → Start
    CampaignSelect --> CampaignBriefing : Mission selected → Briefing

    CampaignBriefing --> BattleLoading : "Deploy" button
    CampaignBriefing --> CampaignSelect : Back

    BattleLoading --> Battle : Loading complete\n[Assets & map loaded]
    BattleLoading --> Main : Loading failed\n/ Cancelled

    Battle --> BattlePause : Pause button\n/ Escape key
    Battle --> BattleResult : Victory / Defeat\n[Surrender]
    Battle --> BattleDisconnect : Network lost\n[PingPongAsync timeout]

    BattlePause --> Battle : Resume
    BattlePause --> BattleResult : Surrender confirmed
    BattlePause --> Main : Quit battle\n[Confirmed with dialog]

    BattleResult --> Main : Continue\n[Results acknowledged]
    BattleResult --> Battle : Replay\n[Campaign only]

    BattleDisconnect --> ReconnectingOverlay : Auto-reconnect
    ReconnectingOverlay --> Battle : Reconnection successful
    ReconnectingOverlay --> BattleResult : Reconnection failed\n[Server-determined result]

    Main --> [*] : App closed
```

## Battle UI Overlay State Machine

```mermaid
stateDiagram-v2
    direction TB

    state "Battle HUD" as BattleHUD {
        [*] --> HUD_Normal : Battle starts
        HUD_Normal --> HUD_Paused : Pause button
        HUD_Normal --> HUD_BuildMenu : Building selected\n/ Build button
        HUD_Normal --> HUD_UnitCommands : Units selected
        HUD_Normal --> HUD_AbilityTargeting : Ability activated\n[Awaiting target]
        HUD_Normal --> HUD_SuperweaponTargeting : Superweapon ready\n[Select target area]
        HUD_Normal --> HUD_Notification : Event occurs\n[Under attack / Research complete]
        HUD_Normal --> HUD_Scoreboard : Scoreboard button

        HUD_Paused --> HUD_Normal : Resume
        HUD_Paused --> HUD_SettingsBattle : Settings in battle
        HUD_SettingsBattle --> HUD_Paused : Close

        HUD_BuildMenu --> HUD_Normal : Building placed\n/ Cancel
        HUD_BuildMenu --> HUD_PlacementGhost : Building selected from menu
        HUD_PlacementGhost --> HUD_BuildMenu : Invalid placement\n[Red ghost]
        HUD_PlacementGhost --> HUD_Normal : Building placed\n[Green ghost confirmed]

        HUD_UnitCommands --> HUD_Normal : Deselect units
        HUD_UnitCommands --> HUD_AbilityTargeting : Hero ability button

        HUD_AbilityTargeting --> HUD_Normal : Target selected\n[ActivateAbility() called]
        HUD_AbilityTargeting --> HUD_Normal : Cancel (right-click / Esc)
        HUD_AbilityTargeting --> HUD_Normal : Insufficient mana

        HUD_SuperweaponTargeting --> HUD_Normal : Target confirmed\n[Launch sequence starts]
        HUD_SuperweaponTargeting --> HUD_Normal : Cancel

        HUD_Notification --> HUD_Normal : Dismissed\n/ Auto-fade (3s)
        HUD_Scoreboard --> HUD_Normal : Close
    }
```

## Store UI State Machine

```mermaid
stateDiagram-v2
    direction TB

    [*] --> StoreMain : Enter store
    StoreMain --> StoreFeatured : Featured tab
    StoreMain --> StoreResources : Resources tab
    StoreMain --> StorePremium : Premium tab
    StoreMain --> StoreBundles : Bundles tab

    StoreFeatured --> StoreItemDetail : Item selected
    StoreResources --> StoreItemDetail : Item selected
    StorePremium --> StoreItemDetail : Item selected
    StoreBundles --> StoreItemDetail : Bundle selected

    StoreItemDetail --> PurchaseConfirm : "Buy" pressed\n[Sufficient currency]
    StoreItemDetail --> InsufficientFunds : Not enough currency
    StoreItemDetail --> StoreMain : Back

    InsufficientFunds --> StorePremium : "Get more" button\n[Premium currency needed]
    InsufficientFunds --> StoreItemDetail : Cancel

    PurchaseConfirm --> Purchasing : Confirm purchase
    Purchasing --> PurchaseSuccess : Transaction complete
    Purchasing --> PurchaseFailed : Transaction failed\n[Network / Payment error]
    Purchasing --> PurchaseCancelled : User cancelled\n[Platform payment dialog]

    PurchaseSuccess --> StoreMain : Acknowledged
    PurchaseFailed --> StoreItemDetail : Retry
    PurchaseCancelled --> StoreItemDetail : Back

    StoreMain --> [*] : Exit store
```

## Clan UI State Machine

```mermaid
stateDiagram-v2
    direction TB

    [*] --> ClanMain : Enter clan screen
    ClanMain --> ClanNoClan : Not in a clan
    ClanMain --> ClanDashboard : In a clan

    ClanNoClan --> ClanSearch : "Search Clans"
    ClanNoClan --> ClanCreate : "Create Clan"

    ClanSearch --> ClanSearchResults : Search query entered
    ClanSearchResults --> ClanProfile : Clan selected
    ClanProfile --> ClanApplyConfirm : "Apply" pressed
    ClanApplyConfirm --> ClanApplied : Application sent
    ClanApplied --> ClanMain : Back

    ClanCreate --> ClanCreateForm : "Create" pressed\n[Cost: 1000 gold]
    ClanCreateForm --> ClanDashboard : Clan created\n[Auto-join as leader]

    ClanDashboard --> ClanMembers : "Members" tab
    ClanDashboard --> ClanWars : "Wars" tab
    ClanDashboard --> ClanChat : "Chat" tab
    ClanDashboard --> ClanSettings : "Settings" tab\n[Leader/Officer only]

    ClanMembers --> MemberProfile : Member selected
    MemberProfile --> ClanMembers : Back
    MemberProfile --> PromoteMember : Promote\n[Leader only]
    MemberProfile --> KickMember : Kick\n[Leader/Officer]

    ClanWars --> WarBattle : "Attack" in war
    WarBattle --> ClanWars : Battle complete

    ClanChat --> ClanDashboard : Back
    ClanSettings --> ClanDashboard : Back

    ClanDashboard --> ClanLeaveConfirm : "Leave Clan"
    ClanLeaveConfirm --> ClanNoClan : Confirmed
    ClanLeaveConfirm --> ClanDashboard : Cancelled

    ClanMain --> [*] : Exit clan screen
```

## Profile UI State Machine

```mermaid
stateDiagram-v2
    direction TB

    [*] --> ProfileMain : Enter profile screen
    ProfileMain --> ProfileStats : "Statistics" tab
    ProfileMain --> ProfileAchievements : "Achievements" tab
    ProfileMain --> ProfileHistory : "Battle History" tab
    ProfileMain --> ProfileLoadout : "Loadout" tab

    ProfileStats --> ProfileMain : Back
    ProfileStats : Win/Loss ratio, MMR, Play time, etc.

    ProfileAchievements --> AchievementDetail : Achievement selected
    AchievementDetail --> ProfileAchievements : Back
    AchievementDetail : Progress bar, rewards, description

    ProfileHistory --> BattleReplay : Replay selected
    BattleReplay --> ProfileHistory : Close replay
    ProfileHistory : Recent battles, results, MMR changes

    ProfileLoadout --> LoadoutEdit : "Edit" pressed
    LoadoutEdit --> ProfileLoadout : Save loadout
    LoadoutEdit : Select faction, heroes, abilities

    ProfileMain --> [*] : Exit profile
```

## Settings UI State Machine

```mermaid
stateDiagram-v2
    direction TB

    [*] --> SettingsMain : Enter settings
    SettingsMain --> SettingsAudio : Audio tab
    SettingsMain --> SettingsGraphics : Graphics tab
    SettingsMain --> SettingsControls : Controls tab
    SettingsMain --> SettingsNetwork : Network tab
    SettingsMain --> SettingsAccount : Account tab
    SettingsMain --> SettingsLanguage : Language tab

    SettingsAudio --> AudioMaster : Master volume
    SettingsAudio --> AudioMusic : Music volume
    SettingsAudio --> AudioSFX : SFX volume
    SettingsAudio --> AudioVoice : Voice volume
    AudioMaster --> SettingsAudio : Back
    AudioMusic --> SettingsAudio : Back
    AudioSFX --> SettingsAudio : Back
    AudioVoice --> SettingsAudio : Back

    SettingsGraphics --> GraphicsQuality : Quality preset
    SettingsGraphics --> GraphicsFPS : FPS target
    SettingsGraphics --> GraphicsResolution : Resolution
    GraphicsQuality --> SettingsGraphics : Back
    GraphicsFPS --> SettingsGraphics : Back
    GraphicsResolution --> SettingsGraphics : Back

    SettingsControls --> ControlsRemap : Remap keys\n[PC only]
    SettingsControls --> ControlsSensitivity : Camera sensitivity
    ControlsRemap --> SettingsControls : Back
    ControlsSensitivity --> SettingsControls : Back

    SettingsNetwork --> NetworkStats : Connection stats\n[Ping, packet loss]
    NetworkStats --> SettingsNetwork : Back

    SettingsAccount --> AccountLink : Link accounts\n[Google/Apple/Facebook]
    SettingsAccount --> AccountReset : Reset progress\n[Confirmation required]
    AccountLink --> SettingsAccount : Back
    AccountReset --> SettingsAccount : Cancelled/Confirmed

    SettingsLanguage --> LanguageSelect : Choose language
    LanguageSelect --> SettingsMain : Back

    SettingsMain --> [*] : Close settings
```
