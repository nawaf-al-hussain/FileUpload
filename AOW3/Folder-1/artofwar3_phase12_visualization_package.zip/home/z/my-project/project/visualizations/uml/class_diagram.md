# Art of War 3: Global Conflict — Class Diagram

> Reverse-engineered class hierarchy from IL2CPP binary analysis.  
> 29,334 types · 140,824 methods · Unity 2020 IL2CPP + Zenject DI

## Diagram

```mermaid
classDiagram
    direction TB

    %% ============================================================
    %% ENTITY SYSTEM
    %% ============================================================
    class Entity {
        <<abstract>>
        +ulong EntityId
        +EntityType Type
        +Faction Faction
        +Vector3 Position
        +bool IsAlive
        +Initialize()
        +Destroy()
        +OnTick(float delta)
    }

    class Unit {
        +UnitType UnitType
        +float Health
        +float MaxHealth
        +float Speed
        +float VisionRange
        +bool IsSelected
        +WeaponSlot[] Weapons
        +Ability[] Abilities
        +AddUnit(UnitType type, Vector3 pos)
        +DestroyUnit()
        +SelectUnitsByRectangle(Rect rect) Unit[]
        +SelectUnitsByPolygon(Vector3[] points) Unit[]
        +SelectCentralUnit(Unit[] group) Unit
        +GetActiveAbilityFromUnitType(UnitType t) Ability
        +ApplyUnitTypeModification(Modification mod)
        +MoveTo(Vector3 target)
        +Attack(Entity target)
        +Stop()
        +Patrol(Vector3[] waypoints)
    }

    class Building {
        +BuildingType BuildingType
        +int Level
        +float ConstructionProgress
        +bool IsComplete
        +bool IsPreBuilding
        +ResourceCost[] UpgradeCosts
        +UnitQueue TrainingQueue
        +AddBuilding(BuildingType type, Vector3 pos)
        +Construct()
        +Deconstruct()
        +BuildingComplete()
        +DestroyPreBuilding()
        +GetBuildingLevelName(int level) string
        +CalculateBuildingLevelState(int level) BuildingState
        +Upgrade()
        +TrainUnit(UnitType type)
    }

    class Weapon {
        +WeaponType WeaponType
        +float Damage
        +float FireRate
        +float Range
        +float Accuracy
        +AmmoType AmmoType
        +CalculateWeaponArmorDamage(ArmorType armor) float
        +CreateDamageForMediumArmor() DamageInfo
        +CreateSuperWeaponMediumDamage() DamageInfo
        +WeaponDamageHeavyValue() float
        +calcShooter(Unit shooter, Entity target) HitResult
        +calcFireDistanceMisc(float dist) float
        +Fire(Entity target)
        +Reload()
    }

    class Resource {
        +ResourceType ResourceType
        +float Amount
        +float Capacity
        +float GatherRate
        +AddResource(ResourceType type, float amount)
        +CheckResourceType(ResourceType type) bool
        +SetCosts(ResourceCost[] costs)
        +CalculateCost(ResourceType type, int quantity) ResourceCost
        +CollectSupplyBox(SupplyBox box)
        +LoadResourcesAsync() UniTask
    }

    class Hero {
        +HeroType HeroType
        +Ability[] ActiveAbilities
        +Ability[] PassiveAbilities
        +float Experience
        +int Level
        +ActivateAbility(Ability ability)
        +DeactivateActiveAbility(Ability ability)
        +GetAbilityRadius(Ability ability) float
        +GetAbilityStates() AbilityState[]
        +GetActiveAbilityDescription(Ability a) string
        +FindBuildingWhereHeroInTrainingQueue() Building
        +LevelUp()
        +GainExperience(float xp)
    }

    class SuperWeapon {
        +SuperWeaponType WeaponType
        +float ChargeProgress
        +bool IsReady
        +float LaunchDelay
        +Vector3 Target
        +SuperWeaponLaunch(Vector3 target)
        +WeaponFlarePrepare()
        +UpdateSuperWeaponState()
        +RemoveTrainedSuperWeapon()
        +CancelLaunch()
    }

    class SupplyBox {
        +Vector3 Position
        +ResourceType Content
        +float Amount
        +bool IsCollected
        +Collect() Resource
    }

    Entity <|-- Unit : inheritance
    Entity <|-- Building : inheritance
    Entity <|-- Resource : inheritance
    Entity <|-- SupplyBox : inheritance
    Unit <|-- Hero : inheritance
    Building *-- Weapon : composition (turrets)
    Unit *-- Weapon : composition (unit weapons)
    Unit o-- Ability : aggregation
    Hero o-- Ability : aggregation (more abilities)
    Building o-- SuperWeapon : aggregation (SW building)
    Building *-- UnitQueue : composition
    Resource --> ResourceType : dependency
    SuperWeapon --> Weapon : dependency

    %% ============================================================
    %% ABILITY & DAMAGE SYSTEM
    %% ============================================================
    class Ability {
        <<abstract>>
        +AbilityType Type
        +float Cooldown
        +float Duration
        +bool IsActive
        +Activate()
        +Deactivate()
        +OnTick(float delta)
    }

    class ActiveAbility {
        +float Radius
        +Vector3 TargetPosition
        +ActivateAbility()
        +DeactivateActiveAbility()
        +GetAbilityRadius() float
    }

    class PassiveAbility {
        +float TriggerChance
        +abilityPassiveWeaponActivate()
        +OnTrigger()
    }

    class DamageInfo {
        +float RawDamage
        +float FinalDamage
        +DamageType Type
        +ArmorType TargetArmor
        +Entity Source
        +Entity Target
        +Apply()
    }

    class ArmorType {
        <<enumeration>>
        Light
        Medium
        Heavy
        SuperHeavy
        None
    }

    class DamageType {
        <<enumeration>>
        Kinetic
        Explosive
        Energy
        Fire
        SuperWeapon
    }

    Ability <|-- ActiveAbility : inheritance
    Ability <|-- PassiveAbility : inheritance
    DamageInfo --> ArmorType : dependency
    DamageInfo --> DamageType : dependency
    Weapon --> DamageInfo : creates
    ActiveAbility --> DamageInfo : creates

    %% ============================================================
    %% BATTLE SYSTEM
    %% ============================================================
    class BattleScreen {
        +BattleState State
        +BattleMap Map
        +BattleGUI GUI
        +PlayerController PlayerController
        +AIController[] AIControllers
        +BattleInitialize(BattleConfig config)
        +OnBattleLoaded()
        +OnBattleSessionClick()
        +OnBattleInviteReceived(Invite invite)
        +GoToBattle(BattleConfig config)
        +CancelBattle()
        +PauseBattle()
        +ResumeBattle()
    }

    class LogicService {
        +BattleState State
        +List~Entity~ Entities
        +Pathfinder Pathfinder
        +FOWSystem FogOfWar
        +OnTick(float delta)
        +AddEntity(Entity entity)
        +RemoveEntity(ulong entityId)
        +ProcessCommands()
        +SimulateStep()
        +ResolveCombat()
    }

    class BattleGUI {
        +SelectionPanel SelectionPanel
        +MinimapPanel Minimap
        +ActionPanel Actions
        +ResourceBar Resources
        +SuperWeaponPanel SuperWeapons
        +OnSelectionChanged(Unit[] selected)
        +OnResourceChanged(Resource res)
        +ShowSuperWeaponLaunch(SuperWeapon sw)
    }

    class BattleMap {
        +int Width
        +int Height
        +TileType[,] Tiles
        +List~Entity~ MapEntities
        +GetTileAt(int x, int y) Tile
        +IsPathable(Vector3 from, Vector3 to) bool
        +GetEntitiesInRange(Vector3 center, float radius) Entity[]
    }

    class PlayerController {
        +Player Owner
        +Faction Faction
        +CameraController Camera
        +InputHandler Input
        +OnCommandIssued(Command cmd)
        +SelectUnits(Rect selection)
        +MoveSelectedUnits(Vector3 target)
        +AttackTarget(Entity target)
    }

    class AIController {
        +AIProfile Profile
        +Faction Faction
        +AIBehaviorTree BehaviorTree
        +GAIManager GAIManager
        +OnTick(float delta)
        +EvaluateState()
        +IssueCommand(Command cmd)
    }

    class Pathfinder {
        +NavGrid Grid
        +FindPath(Vector3 from, Vector3 to) Path
        +FindPathAsync(Vector3 from, Vector3 to) UniTask~Path~
        +UpdateObstacles()
    }

    class FOWSystem {
        +bool[,] Revealed
        +bool[,] Visible
        +UpdateVisibility(Unit[] units)
        +IsVisible(Vector3 pos) bool
        +IsRevealed(Vector3 pos) bool
    }

    BattleScreen *-- LogicService : composition
    BattleScreen *-- BattleGUI : composition
    BattleScreen *-- BattleMap : composition
    BattleScreen *-- PlayerController : composition
    BattleScreen o-- AIController : aggregation
    LogicService *-- Pathfinder : composition
    LogicService *-- FOWSystem : composition
    LogicService --> Entity : manages
    BattleGUI --> Unit : displays
    AIController --> GAIManager : uses

    %% ============================================================
    %% NETWORK SYSTEM
    %% ============================================================
    class NetworkProvider {
        +ConnectionState State
        +LatencyMs int
        +IServerConnection Connection
        +ConnectAsync(string host, int port) UniTask
        +Disconnect()
        +SendMessage(CSMessage msg)
        +OnNetworkEvent~T~(Action~T~ handler)
        +CheckConnectionToBattleHosts() UniTask
        +PingPongAsync() UniTask
    }

    class CSMessage {
        <<abstract>>
        +ushort MessageId
        +Serialize() byte[]
        +Deserialize(byte[] data)
    }

    class CSLoginToBattle {
        +string SessionToken
        +int BattleId
        +string PlayerId
    }

    class CSBattleLogon {
        +string AuthToken
        +Faction SelectedFaction
        +int TeamId
    }

    class CSBattleFinish {
        +int BattleId
        +BattleResult Result
        +PlayerStats Stats
    }

    class CSUnitCommand {
        +ulong[] UnitIds
        +CommandType Type
        +Vector3 TargetPosition
        +ulong TargetEntityId
    }

    class CSBuildingCommand {
        +BuildingType Type
        +Vector3 Position
        +BuildingAction Action
    }

    class SCMessage {
        <<abstract>>
        +ushort MessageId
        +Serialize() byte[]
        +Deserialize(byte[] data)
    }

    class SCBattleState {
        +BattleState State
        +EntitySnapshot[] Entities
        +int Tick
    }

    class SCEventNotification {
        +EventType Type
        +string Message
        +Dictionary Data
    }

    NetworkProvider --> CSMessage : sends
    NetworkProvider --> SCMessage : receives
    CSMessage <|-- CSLoginToBattle : inheritance
    CSMessage <|-- CSBattleLogon : inheritance
    CSMessage <|-- CSBattleFinish : inheritance
    CSMessage <|-- CSUnitCommand : inheritance
    CSMessage <|-- CSBuildingCommand : inheritance
    SCMessage <|-- SCBattleState : inheritance
    SCMessage <|-- SCEventNotification : inheritance
    BattleScreen --> NetworkProvider : uses

    %% ============================================================
    %% GUI SYSTEM
    %% ============================================================
    class GUIManagedPresenter {
        <<abstract>>
        +string PanelId
        +bool IsVisible
        +Show()
        +Hide()
        +OnPanelOpened()
        +OnPanelClosed()
        +BindViewModel(ViewModel vm)
    }

    class PanelHolder {
        +RectTransform Container
        +GUIManagedPresenter CurrentPanel
        +List~GUIManagedPresenter~ PanelHistory
        +OpenPanel(string panelId)
        +CloseCurrentPanel()
        +GoBack()
    }

    class MainMenuPresenter {
        +MainMenuViewModel ViewModel
        +OnPlayClicked()
        +OnClanClicked()
        +OnWorkshopClicked()
        +OnChatClicked()
        +OnSettingsClicked()
    }

    class BattleHUDPresenter {
        +BattleHUDViewModel ViewModel
        +OnSelectionChanged(Unit[] units)
        +OnAbilityClicked(Ability ability)
        +OnSuperWeaponClicked(SuperWeapon sw)
        +UpdateResourceDisplay()
    }

    class WorkshopPresenter {
        +WorkshopViewModel ViewModel
        +UnitType SelectedUnit
        +OnUpgradeClicked()
        +OnEquipClicked()
    }

    class ChatPresenter {
        +ChatViewModel ViewModel
        +Channel ActiveChannel
        +OnSendMessage(string msg)
        +OnChannelSwitch(Channel ch)
    }

    class ClanPresenter {
        +ClanViewModel ViewModel
        +OnMemberAction(Player player)
        +OnClanWarDeclared()
    }

    class UIDispatcher {
        +Dictionary~Type, Action~ Handlers
        +Dispatch(UIEvent event)
        +RegisterHandler~T~(Action~T~ handler)
        +UnregisterHandler~T~(Action~T~ handler)
    }

    GUIManagedPresenter <|-- MainMenuPresenter : inheritance
    GUIManagedPresenter <|-- BattleHUDPresenter : inheritance
    GUIManagedPresenter <|-- WorkshopPresenter : inheritance
    GUIManagedPresenter <|-- ChatPresenter : inheritance
    GUIManagedPresenter <|-- ClanPresenter : inheritance
    PanelHolder o-- GUIManagedPresenter : aggregation
    GUIManagedPresenter --> UIDispatcher : uses

    %% ============================================================
    %% DOMAIN SYSTEMS
    %% ============================================================
    class WorkshopDomain {
        +Dictionary~UnitType, UnitUpgrade~ Upgrades
        +List~Modification~ ActiveMods
        +ApplyUnitTypeModification(Modification mod)
        +GetUpgradeLevel(UnitType type) int
        +ResearchUpgrade(UnitType type) UniTask
    }

    class ClanDomain {
        +ClanInfo ClanInfo
        +List~ClanMember~ Members
        +ClanWar[] ActiveWars
        +JoinClan(string clanId) UniTask
        +LeaveClan() UniTask
        +DeclareWar(string targetClanId) UniTask
    }

    class ChatDomain {
        +List~Channel~ Channels
        +Channel ActiveChannel
        +List~Message~ MessageHistory
        +SendMessage(string text) UniTask
        +JoinChannel(ChannelType type) UniTask
        +OnMessageReceived(Message msg)
    }

    class SkillsDomain {
        +SkillTree SkillTree
        +List~Skill~ UnlockedSkills
        +SkillPoint Balance
        +UnlockSkill(SkillId id) UniTask
        +ResetSkills() UniTask
        +GetSkillLevel(SkillId id) int
    }

    WorkshopDomain --> Unit : modifies
    ClanDomain --> Player : manages
    ChatDomain --> NetworkProvider : depends
    SkillsDomain --> Hero : enhances

    %% ============================================================
    %% MANAGERS / SINGLETONS (Zenject Injected)
    %% ============================================================
    class GameManager {
        +GameState CurrentState
        +SceneType ActiveScene
        +Initialize()
        +ChangeScene(SceneType scene) UniTask
        +OnApplicationPause(bool paused)
        +OnApplicationQuit()
    }

    class SceneLoader {
        +SceneType CurrentScene
        +LoadScene(SceneType scene) UniTask
        +LoadBattleScene(BattleConfig config) UniTask
        +UnloadScene(SceneType scene) UniTask
    }

    class ConfigManager {
        +GameConfig Config
        +UnitConfig[] UnitConfigs
        +BuildingConfig[] BuildingConfigs
        +WeaponConfig[] WeaponConfigs
        +LoadConfigsAsync() UniTask
        +GetUnitConfig(UnitType type) UnitConfig
        +GetBuildingConfig(BuildingType type) BuildingConfig
    }

    class ResourceManager {
        +Dictionary~ResourceType, float~ Resources
        +ChangeSupplyState(SupplyState state)
        +AddResource(ResourceType type, float amount)
        +HasEnoughResources(ResourceCost[] costs) bool
        +SpendResources(ResourceCost[] costs) bool
    }

    class FirebaseManager {
        +InitializeFirebase() UniTask
        +LogEvent(string eventName, Dictionary data)
        +SetUserProperty(string key, string value)
        +CrashlyticsLog(string message)
    }

    class DatabaseManager {
        +SQLiteConnection Connection
        +InitializeAsync() UniTask
        +ExecuteQuery(string query) DataTable
        +SaveGameState(GameState state) UniTask
        +LoadGameState() UniTask~GameState~
    }

    GameManager *-- SceneLoader : composition
    GameManager *-- ConfigManager : composition
    GameManager *-- ResourceManager : composition
    GameManager o-- FirebaseManager : aggregation
    GameManager o-- DatabaseManager : aggregation
    GameManager --> NetworkProvider : uses
    SceneLoader --> BattleScreen : creates
```

## Explanation

This class diagram captures the **major class hierarchies** reverse-engineered from the Art of War 3 IL2CPP binary (29,334 types, 140,824 methods). Key architectural observations:

### Entity System
- **`Entity`** is the abstract base for all game objects on the battlefield — units, buildings, resources, and supply boxes all derive from it.
- **`Unit`** extends `Entity` with combat capabilities (weapons, abilities, movement) and includes specialized selection methods (`SelectUnitsByRectangle`, `SelectUnitsByPolygon`, `SelectCentralUnit`).
- **`Hero`** further extends `Unit` with active/passive ability systems, experience tracking, and the unique `FindBuildingWhereHeroInTrainingQueue` method.
- **`Building`** composes `Weapon` (turrets) and `UnitQueue` (training), and aggregates `SuperWeapon` for SW-capable structures.
- **`Weapon`** is composed into both `Unit` and `Building` — this reflects the game's turret system where buildings can have independent weapon systems.

### Battle System
- **`BattleScreen`** is the top-level orchestrator composing `LogicService`, `BattleGUI`, `BattleMap`, and `PlayerController`.
- **`LogicService`** is the simulation engine managing entities, pathfinding, and fog-of-war — it's the "game loop" core.
- **`AIController`** with `GAIManager` represents the game's two AI subsystems (`.ai` for strategic AI, `.gai` for tactical AI).

### Network System
- **`NetworkProvider`** is the central networking hub with `CheckConnectionToBattleHosts` and `PingPongAsync` for connection management.
- **CS/SC message pattern**: Client-to-Server (`CSMessage`) and Server-to-Client (`SCMessage`) form a clean binary protocol hierarchy — `CSLoginToBattle`, `CSBattleLogon`, `CSBattleFinish` for session management; `CSUnitCommand`, `CSBuildingCommand` for gameplay.

### GUI System
- **`GUIManagedPresenter`** is the MVP base class for all UI panels, managed by `PanelHolder` with history navigation.
- **`UIDispatcher`** provides type-safe event dispatching for UI optimization (matching the `com.geargames.aow.ui.dispatchers` namespace).

### Domain Systems
- **Workshop, Clan, Chat, Skills** domains represent the meta-game layer, each with their own persistence and network dependencies.
- These domains are injected via Zenject and operate independently of the battle simulation.

### Manager Layer
- **`GameManager`** is the Zenject-injected root singleton composing scene, config, resource, Firebase, and database managers.
- **`ConfigManager`** loads from Addressables and provides typed access to unit/building/weapon configurations.
- **`DatabaseManager`** uses SQLite for local persistence; **`FirebaseManager`** handles analytics and crash reporting.
