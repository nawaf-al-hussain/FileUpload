# Art of War 3: Global Conflict — Package Diagram

> Namespace dependency map from IL2CPP metadata analysis.  
> Arrows indicate "depends on" / "uses" relationships between packages.

## Diagram

```mermaid
flowchart TB
    %% ============================================================
    %% SCENE PACKAGES (Top Layer)
    %% ============================================================
    subgraph Scenes["Scene Packages"]
        Startup["AOW_Assets.Scenes.Startup.Scripts.Managers<br/><i>App initialization, DI container setup</i>"]
        Logon["com.geargames.aow.scenes.logon<br/><i>Authentication, session establishment</i>"]
        Main["AOW_Assets.Scenes.Main.Scripts<br/><i>Main menu, meta-game UI</i>"]
        MainGUI["AOW_Assets.Scenes.Main.Scripts.GUI<br/><i>Main menu GUI panels</i>"]
        MainDebug["AOW_Assets.Scenes.Main.Scripts.Debug<br/><i>Debug/cheat console</i>"]
        MainInterface["AOW_Assets.Scenes.Main.Scripts.Interface<br/><i>Interface adapters</i>"]
        BattleLoading["AOW_Assets.Scenes.BattleLoading.Scripts.Network<br/><i>Battle pre-load, host connection</i>"]
        Battle["AOW_Assets.Scenes.Battle.Scripts<br/><i>Battle scene root</i>"]
        BattleGUI["AOW_Assets.Scenes.Battle.Scripts.GUI<br/><i>Battle HUD, selection, minimap</i>"]
        BattleNet["AOW_Assets.Scenes.Battle.Scripts.Network<br/><i>In-game network sync</i>"]
        BattleUnity["AOW_Assets.Scenes.Battle.Scripts.Unity<br/><i>Unity lifecycle hooks</i>"]
    end

    %% ============================================================
    %% CORE GAME PACKAGES
    %% ============================================================
    subgraph Core["Core Game Packages"]
        BattleCore["com.geargames.aow.scenes.battle<br/><i>Battle simulation engine</i>"]
        BattleCoreNet["com.geargames.aow.scenes.battle.network<br/><i>Client-server battle protocol</i>"]
        BattleMapAI["com.geargames.aow.scenes.battle.map.ai<br/><i>Strategic AI (planning)</i>"]
        BattleMapGAI["com.geargames.aow.scenes.battle.map.gai<br/><i>Tactical AI (execution)</i>"]
        BattleCoreGUI["com.geargames.aow.scenes.battle.gui<br/><i>Core battle GUI logic</i>"]
    end

    %% ============================================================
    %% ENTITY PACKAGES
    %% ============================================================
    subgraph Entities["Entity Packages"]
        EntitiesCore["com.geargames.aow.entities<br/><i>Unit, Building, Weapon, Resource</i>"]
        EntitiesUnit["com.geargames.aow.entities.units<br/><i>Unit types, movement, combat</i>"]
        EntitiesBuilding["com.geargames.aow.entities.buildings<br/><i>Building types, construction</i>"]
        EntitiesWeapon["com.geargames.aow.entities.weapons<br/><i>Weapon systems, damage calc</i>"]
        EntitiesHero["com.geargames.aow.entities.heroes<br/><i>Hero units, abilities</i>"]
        EntitiesSuperWeapon["com.geargames.aow.entities.superweapons<br/><i>Superweapon launch & state</i>"]
        EntitiesResource["com.geargames.aow.entities.resources<br/><i>Resource nodes, supply</i>"]
    end

    %% ============================================================
    %% DOMAIN PACKAGES
    %% ============================================================
    subgraph Domains["Domain Packages"]
        Workshop["Domains.Workshop<br/><i>Unit upgrades, modifications</i>"]
        Clan["Domains.Clan<br/><i>Clan management, wars</i>"]
        Chat["Domains.Chat<br/><i>Chat channels, messaging</i>"]
        Skills["Domains.Skills<br/><i>Skill trees, hero progression</i>"]
    end

    %% ============================================================
    %% INFRASTRUCTURE PACKAGES
    %% ============================================================
    subgraph Infra["Infrastructure Packages"]
        Config["AOW_Assets.Scripts.Config<br/><i>Game configuration (Addressables)</i>"]
        GUICore["AOW_Assets.Scripts.GUI<br/><i>Loading windows, base GUI</i>"]
        UIDispatcher["com.geargames.aow.ui.dispatchers<br/><i>UI event dispatch optimization</i>"]
        Network["com.geargames.aow.network<br/><i>Transport layer, serialization</i>"]
        Persistence["com.geargames.aow.persistence<br/><i>SQLite, local saves</i>"]
        Analytics["com.geargames.aow.analytics<br/><i>Firebase, metrics</i>"]
    end

    %% ============================================================
    %% EXTERNAL DEPENDENCIES
    %% ============================================================
    subgraph External["External Dependencies"]
        Zenject["Zenject<br/><i>Dependency Injection</i>"]
        UniTask["UniTask<br/><i>Async/await for Unity</i>"]
        UniRx["UniRx / R3<br/><i>Reactive Extensions</i>"]
        DOTween["DOTween<br/><i>Tweening/animation</i>"]
        Addressables["Unity Addressables<br/><i>Asset loading system</i>"]
        SQLite["SQLite<br/><i>Local database</i>"]
        Firebase["Firebase SDK<br/><i>Analytics, Crashlytics</i>"]
    end

    %% ============================================================
    %% DEPENDENCY EDGES
    %% ============================================================

    %% Scene → Core dependencies
    Startup --> Zenject
    Startup --> Config
    Startup --> UniTask

    Logon --> Network
    Logon --> Config
    Logon --> UniTask

    Main --> MainGUI
    Main --> MainDebug
    Main --> MainInterface
    Main --> Workshop
    Main --> Clan
    Main --> Chat
    Main --> Skills
    Main --> Config

    MainGUI --> GUICore
    MainGUI --> UIDispatcher
    MainGUI --> DOTween

    BattleLoading --> BattleCoreNet
    BattleLoading --> Network
    BattleLoading --> Config
    BattleLoading --> UniTask

    Battle --> BattleCore
    Battle --> BattleGUI
    Battle --> BattleNet
    Battle --> BattleUnity
    Battle --> BattleCoreGUI

    BattleGUI --> BattleCoreGUI
    BattleGUI --> UIDispatcher
    BattleGUI --> DOTween
    BattleGUI --> UniRx

    BattleNet --> BattleCoreNet
    BattleNet --> Network

    %% Core → Entity dependencies
    BattleCore --> EntitiesCore
    BattleCore --> BattleMapAI
    BattleCore --> BattleMapGAI
    BattleCore --> UniTask
    BattleCore --> UniRx

    BattleCoreNet --> Network
    BattleCoreNet --> EntitiesCore

    BattleMapAI --> EntitiesCore
    BattleMapAI --> BattleMapGAI

    BattleCoreGUI --> EntitiesCore
    BattleCoreGUI --> UIDispatcher

    %% Entity internal dependencies
    EntitiesCore --> EntitiesUnit
    EntitiesCore --> EntitiesBuilding
    EntitiesCore --> EntitiesWeapon
    EntitiesCore --> EntitiesResource

    EntitiesUnit --> EntitiesWeapon
    EntitiesUnit --> EntitiesHero

    EntitiesBuilding --> EntitiesWeapon
    EntitiesBuilding --> EntitiesSuperWeapon
    EntitiesBuilding --> EntitiesResource

    %% Domain dependencies
    Workshop --> EntitiesCore
    Workshop --> Config
    Workshop --> Network

    Clan --> Network
    Clan --> Persistence

    Chat --> Network
    Chat --> UniTask

    Skills --> EntitiesHero
    Skills --> Config

    %% Infrastructure → External
    Config --> Addressables
    Config --> UniTask

    Network --> UniTask
    Network --> Zenject

    Persistence --> SQLite
    Persistence --> UniTask

    Analytics --> Firebase

    UIDispatcher --> UniRx

    %% Style
    classDef scene fill:#4a90d9,stroke:#2c5f8a,color:#fff
    classDef core fill:#e67e22,stroke:#b5651d,color:#fff
    classDef entity fill:#27ae60,stroke:#1e8449,color:#fff
    classDef domain fill:#8e44ad,stroke:#6c3483,color:#fff
    classDef infra fill:#c0392b,stroke:#922b21,color:#fff
    classDef ext fill:#7f8c8d,stroke:#566573,color:#fff

    class Startup,Logon,Main,MainGUI,MainDebug,MainInterface,BattleLoading,Battle,BattleGUI,BattleNet,BattleUnity scene
    class BattleCore,BattleCoreNet,BattleMapAI,BattleMapGAI,BattleCoreGUI core
    class EntitiesCore,EntitiesUnit,EntitiesBuilding,EntitiesWeapon,EntitiesHero,EntitiesSuperWeapon,EntitiesResource entity
    class Workshop,Clan,Chat,Skills domain
    class Config,GUICore,UIDispatcher,Network,Persistence,Analytics infra
    class Zenject,UniTask,UniRx,DOTween,Addressables,SQLite,Firebase ext
```

## Explanation

This package diagram maps the **namespace dependency graph** of Art of War 3, derived from IL2CPP metadata covering 29,334 types. The architecture follows a layered pattern:

### Layer Architecture

| Layer | Packages | Role |
|-------|----------|------|
| **Scenes** | `AOW_Assets.Scenes.*` | Unity scene-level controllers, each scene has its own scripts namespace |
| **Core** | `com.geargames.aow.scenes.battle.*` | Engine-agnostic battle simulation, AI, and networking |
| **Entities** | `com.geargames.aow.entities.*` | Game entity definitions — the data/model layer |
| **Domains** | `Domains.*` | Meta-game business logic (Workshop, Clan, Chat, Skills) |
| **Infrastructure** | `com.geargames.aow.*` (utilities) | Cross-cutting concerns: config, networking, persistence, UI dispatch |
| **External** | Third-party | Zenject, UniTask, UniRx/R3, DOTween, Addressables, SQLite, Firebase |

### Key Observations

1. **Dual naming convention**: The codebase uses two naming patterns — `AOW_Assets.Scenes.*` for Unity MonoBehaviour scenes and `com.geargames.aow.*` for engine-agnostic core logic. This suggests the team separated Unity-dependent code from portable game logic.

2. **AI is split into two subsystems**: `map.ai` (strategic planning) depends on `map.gai` (tactical execution), forming a hierarchical AI architecture — the strategic layer issues goals, the tactical layer executes them.

3. **Scene isolation**: Each scene has its own GUI, network, and logic sub-packages, minimizing cross-scene coupling. Scene transitions go through `BattleLoading.Scripts.Network` which handles the async connection handoff.

4. **Entity package hierarchy**: `entities.core` depends on all specialized entity sub-packages, while weapons are shared between units and buildings (turrets), reflecting the composition pattern.

5. **Domain independence**: Workshop, Clan, Chat, and Skills are relatively independent packages that only depend on core entities, config, and network — they can be developed and tested in isolation.

6. **UniTask is ubiquitous**: Almost every package depends on UniTask for async operations, making it the most critical dependency after Zenject.
