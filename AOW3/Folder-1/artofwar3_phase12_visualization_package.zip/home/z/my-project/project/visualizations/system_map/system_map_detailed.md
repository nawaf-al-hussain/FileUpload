# Art of War 3: Global Conflict — Detailed System Map

This document provides an exhaustive reference for every system in the game, their interactions, data flows, event flows, control flows, initialization sequence, and update loop.

---

## Table of Contents

1. [Full System Flowchart](#1-full-system-flowchart)
2. [Data Flow Diagram](#2-data-flow-diagram)
3. [Event Flow Diagram](#3-event-flow-diagram)
4. [Control Flow Diagram](#4-control-flow-diagram)
5. [Initialization Sequence Diagram](#5-initialization-sequence-diagram)
6. [Update Loop Diagram](#6-update-loop-diagram)
7. [Cross-System Interaction Matrix](#7-cross-system-interaction-matrix)
8. [System Details](#8-system-details)

---

## 1. Full System Flowchart

Complete architecture showing all systems, subsystems, and their relationships grouped by category.

```mermaid
flowchart TB
    subgraph CORE["🔴 CORE RUNTIME"]
        direction TB
        ML["Main Loop<br/>Unity Update Cycle"]
        GSM["Game State Manager<br/>Scene Transitions & App Lifecycle"]
        REN["Renderer<br/>Unity Pipeline | Sprites | 3D Models | Particles"]
        INP["Input Manager<br/>GGInputModule | Touch | Gestures"]
        RES["Resource Manager<br/>Addressables | Asset Loading/Unloading | Caching"]

        ML -->|drives| GSM
        ML -->|drives| REN
        ML -->|feeds| INP
        ML -->|uses| RES
    end

    subgraph GAMEPLAY["🔵 GAMEPLAY SYSTEMS"]
        direction TB
        subgraph UNITSUB["Unit System"]
            UC["Unit Creation"]
            US["Unit Selection"]
            UM["Unit Movement"]
            UCM["Unit Commands"]
            UG["Unit Groups"]
        end
        subgraph COMBATSUB["Combat System"]
            DC["Damage Calculation"]
            WT["Weapon Types"]
            AR["Armor System"]
            TG["Targeting Logic"]
        end
        subgraph BLDGSUB["Building System"]
            BC["Construction"]
            BU["Building Upgrades"]
            PQ["Production Queues"]
            PW["Power Management"]
        end
        subgraph ECONSUB["Economy System"]
            SUP["Supplies"]
            PWR["Power"]
            URA["Uranium"]
            CRE["Credits"]
            GLD["Gold"]
        end
        subgraph UPGSUB["Upgrade System"]
            TT["Tech Tree"]
            UU["Unit Upgrades"]
            BUU["Building Upgrades"]
        end
        subgraph AISUB["AI System"]
            SAI["Strategic AI"]
            TAI["Tactical AI"]
            AIP["Pathfinding A*"]
            AIF["Fog of War"]
        end
        subgraph PATHSUB["Pathfinding System"]
            GBS["Grid-Based A*"]
            TER["Terrain Types"]
            OBS["Obstacle Handling"]
        end
        subgraph FOWSUB["Fog of War System"]
            VR["Vision Ranges"]
            EXP["Exploration"]
            STL["Stealth Detection"]
        end
        subgraph MISSIONSUB["Mission System"]
            CM["Campaign Missions"]
            OBJ["Objectives"]
            WC["Win Conditions"]
        end
    end

    subgraph CONTENT["🟢 CONTENT SYSTEMS"]
        direction TB
        subgraph MAPSUB["Maps"]
            MS["8 Map Scenarios"]
            TG2["Terrain Generation"]
        end
        subgraph CAMPSUB["Campaigns"]
            FM["~100 Missions"]
            TF["Two Factions"]
        end
        subgraph ASSETSUB["Assets"]
            CE["773 Catalog Entries"]
            BU2["23 Bundles"]
            SP["Sprites"]
            MD["3D Models"]
            AU2["Audio Files"]
        end
        subgraph UISUB["UI System"]
            ZP["Zenject Presenters"]
            PN["Panels"]
            WN["Windows"]
        end
        subgraph AUDIOSUB["Audio System"]
            BS["Battle SFX"]
            VO["Voice Overs"]
            MU["Music"]
            DT["DOTween Animations"]
        end
    end

    subgraph MULTIPLAYER["🟠 MULTIPLAYER SYSTEMS"]
        direction TB
        subgraph NETSUB["Networking Layer"]
            MS2["Persistent Main Server"]
            BS2["Ephemeral Battle Server"]
        end
        subgraph SYNCSUB["Synchronization Layer"]
            TBS["Tick-Based Sync"]
            CP["Client Prediction"]
        end
        subgraph CMDSUB["Command Processing"]
            CV["Command Validation"]
            CA["Arbitration"]
        end
        subgraph REPLSUB["Replication Layer"]
            SR["State Replication"]
            DD["Desync Detection"]
        end
        subgraph MATCHSUB["Matchmaking System"]
            PVP["1v1 Matching"]
            TVT["2v2 Matching"]
            TRN["Tournament Matching"]
        end
        subgraph CHATSUB["Chat System"]
            CR["Chat Rooms"]
            MOD["Moderation"]
            TRS["Translation"]
            FRD["Friends"]
        end
    end

    subgraph DOMAIN["🟣 DOMAIN SYSTEMS"]
        direction TB
        WORKSHOP["Workshop System<br/>Unit Customization"]
        CLAN["Clan System<br/>Creation | Management | Wars"]
        SKILLS["Skills System<br/>Commander Skills | Skill Trees"]
        RATING["Rating System<br/>ELO-Based Ranking"]
        STORE["Store System<br/>IAP | Packs | Offers"]
        TOURNAMENT["Tournament System<br/>Brackets | Rewards"]
        REPLAY["Replay System<br/>Battle Recording | Playback"]
    end

    %% Core to Gameplay
    ML -->|update tick| GAMEPLAY
    GSM -->|scene control| GAMEPLAY
    INP -->|commands| UNITSUB
    RES -->|assets| ASSETSUB
    REN -->|renders| GAMEPLAY

    %% Gameplay internal
    UNITSUB -->|attack orders| COMBATSUB
    COMBATSUB -->|damage results| UNITSUB
    ECONSUB -->|resources| BLDGSUB
    ECONSUB -->|resources| UNITSUB
    BLDGSUB -->|produces| UNITSUB
    UPGSUB -->|enhances| UNITSUB
    UPGSUB -->|enhances| BLDGSUB
    AISUB -->|issues commands| UNITSUB
    PATHSUB -->|routes| UNITSUB
    FOWSUB -->|visibility| AISUB
    FOWSUB -->|visibility| COMBATSUB
    MISSIONSUB -->|triggers| GSM

    %% Content to Gameplay
    MAPSUB -->|terrain| PATHSUB
    MAPSUB -->|vision data| FOWSUB
    CAMPSUB -->|missions| MISSIONSUB
    ASSETSUB -->|models/sprites| UNITSUB
    ASSETSUB -->|models/sprites| BLDGSUB
    AUDIOSUB -->|feedback| COMBATSUB
    UISUB -->|player commands| UNITSUB

    %% Multiplayer to Gameplay
    NETSUB <-->|messages| SYNCSUB
    SYNCSUB <-->|tick data| CMDSUB
    CMDSUB <-->|validated cmds| REPLSUB
    REPLSUB <-->|state| GAMEPLAY
    MATCHSUB -->|match start| GSM
    CHATSUB <-->|messages| NETSUB

    %% Domain to Gameplay
    WORKSHOP -->|customizes| UNITSUB
    SKILLS -->|buffs| COMBATSUB
    SKILLS -->|buffs| UNITSUB
    RATING <-->|rank data| MATCHSUB
    STORE -->|purchases| ECONSUB
    TOURNAMENT <-->|bracket matches| MATCHSUB
    REPLAY -->|records| REPLSUB
    REPLAY -->|records| CMDSUB
    CLAN <-->|social| CHATSUB
```

### Explanation

This flowchart maps every system and its subsystems. Solid lines represent direct dependencies or control relationships. The five major categories are:

- **Core Runtime** (red): Foundation systems that drive everything else
- **Gameplay Systems** (blue): The game logic layer with 9 major subsystems
- **Content Systems** (green): Assets, data, and presentation
- **Multiplayer Systems** (orange): Networked play infrastructure
- **Domain Systems** (purple): Meta-game and monetization features

---

## 2. Data Flow Diagram

Shows how data moves between systems, including what type of data is exchanged.

```mermaid
flowchart LR
    subgraph INPUTS["Data Sources"]
        PLAYER["Player Input"]
        NET_IN["Network Messages"]
        AI_GEN["AI Generated Commands"]
        TIMER["Game Timers"]
    end

    subgraph PROCESSING["Data Processing"]
        INP_MGR["Input Manager<br/><i>Raw input → Commands</i>"]
        DESER["Deserializer<br/><i>Network bytes → Commands</i>"]
        CMD_Q["Command Queue<br/><i>Ordered command buffer</i>"]
        LOGIC["Logic Service<br/><i>Commands → State changes</i>"]
    end

    subgraph STATE["Game State"]
        UNIT_ST["Unit State<br/><i>Position, HP, orders</i>"]
        BLDG_ST["Building State<br/><i>Queue, HP, power</i>"]
        ECON_ST["Economy State<br/><i>Resources, income rate</i>"]
        FOW_ST["Fog of War State<br/><i>Visibility map</i>"]
        TERRAIN_ST["Terrain State<br/><i>Passability, occupancy</i>"]
    end

    subgraph OUTPUTS["Data Outputs"]
        REN_OUT["Renderer<br/><i>Visual representation</i>"]
        NET_OUT["Network Output<br/><i>State replication</i>"]
        AUDIO_OUT["Audio System<br/><i>Sound events</i>"]
        UI_OUT["UI Updates<br/><i>Panel refreshes</i>"]
    end

    PLAYER -->|touch data| INP_MGR
    NET_IN -->|byte streams| DESER
    AI_GEN -->|ai commands| CMD_Q
    TIMER -->|tick events| LOGIC

    INP_MGR -->|player commands| CMD_Q
    DESER -->|validated commands| CMD_Q
    CMD_Q -->|ordered commands| LOGIC

    LOGIC -->|position, hp| UNIT_ST
    LOGIC -->|queue, hp| BLDG_ST
    LOGIC -->|resource delta| ECON_ST
    LOGIC -->|visibility update| FOW_ST
    LOGIC -->|terrain change| TERRAIN_ST

    UNIT_ST -->|transform, sprites| REN_OUT
    BLDG_ST -->|transform, sprites| REN_OUT
    UNIT_ST -->|state snapshot| NET_OUT
    ECON_ST -->|resource display| UI_OUT
    FOW_ST -->|fog overlay| REN_OUT
    UNIT_ST -->|events| AUDIO_OUT
    BLDG_ST -->|events| AUDIO_OUT
    ECON_ST -->|alerts| UI_OUT
```

### Data Flow Explanation

**Primary data pipeline:**
1. **Input sources** (player touch, network, AI, timers) generate raw data
2. **Input Manager** translates raw touch into game commands
3. **Deserializer** translates network bytes into commands
4. **Command Queue** orders all commands for deterministic execution
5. **Logic Service** processes commands and mutates game state
6. **Game State** stores authoritative data for all entities
7. **Outputs** read from game state to render, replicate, sound, and update UI

**Key data types:**
- Commands: MoveCommand, AttackCommand, BuildCommand, TrainCommand, UpgradeCommand
- State: Position (Vector3), Health (float), Resources (int), Visibility (bool[])
- Events: UnitDied, BuildingCompleted, ResourceDepleted, MissionObjectiveMet

---

## 3. Event Flow Diagram

Shows event-driven communication between systems. Events are fired when significant things happen and consumed by interested systems.

```mermaid
flowchart TB
    subgraph EVENT_SOURCES["Event Sources"]
        COMBAT_EVT["💥 Combat Events<br/>UnitDamaged, UnitDestroyed,<br/>AttackStarted, AttackEnded"]
        ECON_EVT["💰 Economy Events<br/>ResourceGained, ResourceSpent,<br/>ResourceDepleted, IncomeTick"]
        BLDG_EVT["🏗️ Building Events<br/>ConstructionStarted, ConstructionComplete,<br/>UpgradeComplete, ProductionComplete"]
        UNIT_EVT["⚔️ Unit Events<br/>UnitCreated, UnitSelected,<br/>UnitMoved, UnitGrouped"]
        MISSION_EVT["📋 Mission Events<br/>ObjectiveStarted, ObjectiveComplete,<br/>MissionWon, MissionLost"]
        NET_EVT["🌐 Network Events<br/>PlayerJoined, PlayerLeft,<br/>DesyncDetected, ConnectionLost"]
        SKILL_EVT["⚡ Skill Events<br/>SkillActivated, SkillCooldownStart,<br/>SkillReady, SkillExpired"]
    end

    subgraph EVENT_BUS["Event Bus / Message System"]
        EB["📡 Central Event Dispatcher<br/><i>Zenject Signal Bus</i>"]
    end

    subgraph CONSUMERS["Event Consumers"]
        UI_CON["🖥️ UI System<br/>→ Updates panels, health bars, resource display"]
        AUDIO_CON["🔊 Audio System<br/>→ Plays SFX, VO, music cues"]
        ECON_CON["💰 Economy System<br/>→ Processes bounties, loot, costs"]
        MISSION_CON["📋 Mission System<br/>→ Checks objective progress"]
        FOW_CON["👁️ Fog of War<br/>→ Updates on unit death/creation"]
        AI_CON["🧠 AI System<br/>→ Reacts to threats, opportunities"]
        NET_CON["🌐 Replication<br/>→ Broadcasts state changes"]
        RATING_CON["🏆 Rating System<br/>→ Updates on match outcomes"]
        REPLAY_CON["🎞️ Replay System<br/>→ Records events for playback"]
    end

    COMBAT_EVT --> EB
    ECON_EVT --> EB
    BLDG_EVT --> EB
    UNIT_EVT --> EB
    MISSION_EVT --> EB
    NET_EVT --> EB
    SKILL_EVT --> EB

    EB --> UI_CON
    EB --> AUDIO_CON
    EB --> ECON_CON
    EB --> MISSION_CON
    EB --> FOW_CON
    EB --> AI_CON
    EB --> NET_CON
    EB --> RATING_CON
    EB --> REPLAY_CON
```

### Event Flow Explanation

Events follow a **publish-subscribe pattern** via Zenject's Signal Bus:

1. **Systems publish events** when game state changes (e.g., Combat publishes `UnitDestroyed`)
2. **Event Bus dispatches** to all registered subscribers
3. **Consumers react** asynchronously — UI refreshes health bars, Audio plays death sounds, Economy awards bounty, Mission checks if this fulfills an objective, AI re-evaluates strategy

**Critical event chains:**
- `UnitDestroyed` → Audio (death SFX) + UI (remove from selection) + Economy (bounty) + Fog of War (recalculate) + Mission (kill count) + Rating (stats)
- `ConstructionComplete` → UI (update building visual) + Economy (power online) + Production (enable queue)
- `DesyncDetected` → Network (resync request) + UI (desync warning) + Replay (mark desync point)
- `SkillActivated` → Combat (apply buff) → UI (cooldown display) → Audio (skill SFX) → Fog of War (reveal if scout skill)

---

## 4. Control Flow Diagram

Shows which systems have direct control authority over other systems. Control flow is top-down: higher-level systems command lower-level ones.

```mermaid
flowchart TB
    subgraph L0["L0: Engine Layer"]
        ML["Main Loop"]
        GSM["Game State Manager"]
    end

    subgraph L1["L1: Service Layer"]
        INP["Input Manager"]
        RES["Resource Manager"]
        NET["Networking Layer"]
        LOGIC["Logic Service"]
    end

    subgraph L2["L2: Game Logic Layer"]
        UNIT["Unit System"]
        COMBAT["Combat System"]
        BLDG["Building System"]
        ECON["Economy System"]
        AI["AI System"]
        UPG["Upgrade System"]
        PATH["Pathfinding System"]
        FOW["Fog of War System"]
        MISSION["Mission System"]
    end

    subgraph L3["L3: Presentation Layer"]
        REN["Renderer"]
        UI["UI System"]
        AUDIO["Audio System"]
    end

    subgraph L4["L4: Domain Layer"]
        WORKSHOP["Workshop"]
        CLAN["Clan"]
        SKILLS["Skills"]
        RATING["Rating"]
        STORE["Store"]
        TOURNAMENT["Tournament"]
        REPLAY["Replay"]
    end

    ML -->|controls| GSM
    GSM -->|controls| LOGIC
    GSM -->|controls| RES
    GSM -->|controls| NET
    INP -->|controls| LOGIC
    NET -->|controls| LOGIC

    LOGIC -->|commands| UNIT
    LOGIC -->|commands| COMBAT
    LOGIC -->|commands| BLDG
    LOGIC -->|commands| ECON
    LOGIC -->|commands| AI
    LOGIC -->|commands| UPG
    LOGIC -->|commands| PATH
    LOGIC -->|commands| FOW
    LOGIC -->|commands| MISSION

    UNIT -->|renders| REN
    COMBAT -->|renders| REN
    BLDG -->|renders| REN
    FOW -->|renders| REN
    UNIT -->|displays| UI
    COMBAT -->|displays| UI
    ECON -->|displays| UI
    BLDG -->|displays| UI
    COMBAT -->|plays| AUDIO
    UNIT -->|plays| AUDIO
    BLDG -->|plays| AUDIO

    L4 -->|influences| L2
    SKILLS -->|buffs| COMBAT
    SKILLS -->|buffs| UNIT
    WORKSHOP -->|customizes| UNIT
    STORE -->|unlocks| ECON
    RATING -->|informs| NET
    TOURNAMENT -->|schedules| NET
    REPLAY -->|reads| LOGIC
    CLAN -->|social| UI
```

### Control Flow Explanation

The architecture follows a **layered control pattern**:

| Layer | Role | Systems |
|---|---|---|
| **L0: Engine** | Top-level orchestration | Main Loop, Game State Manager |
| **L1: Service** | Infrastructure services | Input, Resources, Network, Logic |
| **L2: Game Logic** | Core game simulation | Units, Combat, Buildings, Economy, AI, etc. |
| **L3: Presentation** | Output to player | Renderer, UI, Audio |
| **L4: Domain** | Meta-game features | Workshop, Clan, Skills, Rating, Store, etc. |

**Control always flows downward** — lower layers never command upper layers. When lower layers need to influence upper layers, they use **events** (see Event Flow diagram) or **callback interfaces**.

---

## 5. Initialization Sequence Diagram

Shows the exact order of initialization when the game starts, including the battle start sequence.

```mermaid
sequenceDiagram
    participant UE as Unity Engine
    participant SM as StartupManager
    participant AA as Addressables
    participant AUTH as Authentication<br/>(Firebase/Google Play)
    participant SRV as Main Server
    participant DB as SQLite Cache
    participant SCENE as Main Scene
    participant GUI as GUI System<br/>(Zenject)
    participant BATTLE as Battle Loader

    Note over UE: App Launch
    UE->>SM: 1. Initialize StartupManager
    SM->>AA: 2. Warm-up Addressables
    AA-->>SM: Catalog loaded (773 entries)
    SM->>AUTH: 3. Authenticate Player
    AUTH-->>SM: Auth token received
    SM->>SRV: 4. Connect to Main Server
    SRV-->>SM: Connection established
    SM->>DB: 5a. Load cached profile
    DB-->>SM: Local profile data
    SM->>SRV: 5b. Sync profile with server
    SRV-->>SM: Server profile data
    SM->>SCENE: 6. Load Main Scene
    SCENE-->>SM: Scene ready
    SM->>GUI: 7. Initialize GUI (Zenject)
    GUI-->>SM: All presenters bound

    Note over SM: Main Menu Ready

    Note over BATTLE: Battle Start Sequence
    SM->>BATTLE: Player starts battle
    BATTLE->>BATTLE: 8a. Enter BattleLoading screen
    BATTLE->>SRV: 8b. Login to Battle Server
    SRV-->>BATTLE: Battle server ready
    BATTLE->>AA: 8c. Load map assets
    AA-->>BATTLE: Map assets ready
    BATTLE->>BATTLE: 8d. Generate terrain & obstacles
    BATTLE->>BATTLE: 8e. Spawn initial entities
    BATTLE->>GUI: 8f. Initialize battle UI
    BATTLE->>BATTLE: 8g. Start Battle Loop
```

### Initialization Explanation

**Phase 1: Engine Startup (Steps 1-2)**
- Unity launches and creates the `StartupManager` singleton
- Addressables system loads its catalog (773 entries across 23 bundles)
- Critical bundles are pre-warmed for the loading screen

**Phase 2: Authentication (Step 3)**
- Firebase Auth or Google Play Games Services authenticate the player
- Player ID and auth token are obtained for server communication

**Phase 3: Server Connection (Step 4)**
- Persistent TCP connection established to Main Server
- Session token exchanged, heartbeat initiated

**Phase 4: Profile Loading (Step 5)**
- Local SQLite cache loaded first for instant UI
- Server sync merges remote changes (new purchases, rating updates)
- Conflict resolution: server data wins

**Phase 5: Scene Setup (Steps 6-7)**
- Main scene loaded with all persistent managers
- Zenject container binds all presenters, models, and services
- UI panels instantiated and shown (main menu)

**Phase 6: Battle Start (Step 8)**
- BattleLoading screen shows while:
  - a) Transition screen with loading bar
  - b) Connect to ephemeral battle server
  - c) Load map-specific assets from Addressables
  - d) Generate terrain grid, place obstacles
  - e) Spawn starting units and buildings
  - f) Bind battle-specific UI (HUD, minimap)
  - g) Enter the main battle update loop

---

## 6. Update Loop Diagram

Shows the precise order of operations within each frame/tick during gameplay.

```mermaid
flowchart TB
    START(["🟢 Frame Start"]) --> U1["1️⃣ Input Processing<br/><i>GGInputModule processes touch/gestures<br/>→ Converts to game commands<br/>→ Pushes to Command Queue</i>"]

    U1 --> U2["2️⃣ Network Message Processing<br/><i>Deserialize incoming packets<br/>→ Validate commands<br/>→ Push to Command Queue</i>"]

    U2 --> U3["3️⃣ AI Tick<br/><i>Evaluate strategic goals<br/>→ Generate tactical commands<br/>→ Push AI commands to queue</i>"]

    U3 --> U4["4️⃣ Unit Movement / Pathfinding<br/><i>Process path requests (A*)<br/>→ Move units along paths<br/>→ Check for collisions<br/>→ Update unit positions</i>"]

    U4 --> U5["5️⃣ Combat Resolution<br/><i>Acquire targets (Fog of War check)<br/>→ Select weapons<br/>→ Calculate damage (armor pen, type)<br/>→ Apply damage to HP<br/>→ Check for unit death</i>"]

    U5 --> U6["6️⃣ Building Production<br/><i>Advance production queues<br/>→ Complete trained units<br/>→ Process construction progress<br/>→ Handle power grid updates</i>"]

    U6 --> U7["7️⃣ Economy Update<br/><i>Calculate income rates<br/>→ Apply resource ticks<br/>→ Check resource caps<br/>→ Trigger resource events</i>"]

    U7 --> U8["8️⃣ State Synchronization<br/><i>Serialize game state delta<br/>→ Send to battle server<br/>→ Process server corrections<br/>→ Detect desyncs</i>"]

    U8 --> U9["9️⃣ GUI Update<br/><i>Refresh health bars<br/>→ Update resource display<br/>→ Process panel transitions<br/>→ Animate DOTween sequences</i>"]

    U9 --> U10["🔟 Audio Update<br/><i>Process audio event queue<br/>→ Play battle SFX<br/>→ Trigger voice overs<br/>→ Crossfade music</i>"]

    U10 --> U11["1️⃣1️⃣ Render<br/><i>Submit draw calls<br/>→ Render sprites & 3D models<br/>→ Draw particles<br/>→ Render fog of war overlay<br/>→ Render UI canvas</i>"]

    U11 --> WAIT(["⏳ VSync / Wait for next frame"])
    WAIT --> START

    style U1 fill:#e74c3c,color:#fff
    style U2 fill:#e67e22,color:#fff
    style U3 fill:#9b59b6,color:#fff
    style U4 fill:#3498db,color:#fff
    style U5 fill:#e74c3c,color:#fff
    style U6 fill:#27ae60,color:#fff
    style U7 fill:#f39c12,color:#fff
    style U8 fill:#e67e22,color:#fff
    style U9 fill:#27ae60,color:#fff
    style U10 fill:#9b59b6,color:#fff
    style U11 fill:#3498db,color:#fff
```

### Update Loop Explanation

Each frame executes these 11 steps in strict order. This ensures **deterministic simulation** — critical for multiplayer desync prevention.

**Timing targets:**
- 30 FPS on mobile (33ms per frame)
- 60 FPS on high-end devices (16ms per frame)
- Battle server ticks at 10 Hz (100ms per tick)

**Critical ordering rationale:**
1. Input first — ensures responsive controls
2. Network before AI — server commands have priority
3. AI before movement — AI generates move orders
4. Movement before combat — units must be in position before fighting
5. Combat before production — deaths free up population cap for new units
6. Production before economy — new units affect income
7. Economy before sync — resource state must be final before replication
8. Sync before GUI — display authoritative state only
9. GUI before audio — visual feedback aligns with sound
10. Audio before render — sound events queued for render frame
11. Render last — all state is final, draw everything

---

## 7. Cross-System Interaction Matrix

Shows which systems directly interact with which, and the nature of that interaction.

```mermaid
graph TD
    subgraph MATRIX["Interaction Matrix — Key Connections"]
        %% Unit System connections
        UNIT_C["⚔️ Unit System"] ---|data| COMBAT_C["💥 Combat"]
        UNIT_C ---|data| PATH_C["🗺️ Pathfinding"]
        UNIT_C ---|data| FOW_C["👁️ Fog of War"]
        UNIT_C ---|data| ECON_C["💰 Economy"]
        UNIT_C ---|data| UPG_C["🔬 Upgrades"]
        UNIT_C ---|data| AI_C["🧠 AI"]
        UNIT_C ---|data| UI_C["🖥️ UI"]
        UNIT_C ---|data| WORKSHOP_C["🔧 Workshop"]

        %% Combat connections
        COMBAT_C ---|data| FOW_C
        COMBAT_C ---|events| ECON_C
        COMBAT_C ---|events| MISSION_C["📋 Mission"]
        COMBAT_C ---|events| AUDIO_C["🔊 Audio"]
        COMBAT_C ---|data| SKILLS_C["⚡ Skills"]

        %% Building connections
        BLDG_C["🏗️ Building"] ---|data| ECON_C
        BLDG_C ---|data| UPG_C
        BLDG_C ---|production| UNIT_C

        %% Economy connections
        ECON_C ---|data| STORE_C["🛒 Store"]

        %% Multiplayer connections
        NET_C["🌐 Network"] ---|sync| SYNC_C["🔄 Sync"]
        SYNC_C ---|cmds| CMD_C["📨 Commands"]
        CMD_C ---|state| REPL_C["📡 Replication"]
        REPL_C ---|data| GAMEPLAY_C["🎮 Gameplay"]
        NET_C ---|data| MATCH_C["🎯 Matchmaking"]
        NET_C ---|data| CHAT_C["💬 Chat"]
        MATCH_C ---|data| RATING_C["🏆 Rating"]
        MATCH_C ---|data| TOURNAMENT_C["🎖️ Tournament"]
        REPL_C ---|data| REPLAY_C["🎞️ Replay"]
        CMD_C ---|data| REPLAY_C

        %% Map connections
        MAP_C["🗺️ Maps"] ---|data| PATH_C
        MAP_C ---|data| FOW_C
        CAMPAIGN_C["📖 Campaigns"] ---|data| MISSION_C

        %% Clan connections
        CLAN_C["🏰 Clan"] ---|social| CHAT_C
    end
```

### Interaction Types

| Type | Symbol | Description |
|---|---|---|
| **data** | Solid line | Regular data exchange (positions, stats, resources) |
| **events** | Dashed line | Event-driven notifications (unit died, building completed) |
| **production** | Bold line | Entity creation flow (building produces unit) |
| **sync** | Dotted line | Synchronization data (network state) |
| **social** | Wavy line | Social features (chat, clan) |

---

## 8. System Details

### Core Runtime Systems

#### Main Loop (Unity Update Cycle)
- **Type**: Unity `MonoBehaviour.Update()`
- **Frequency**: Every frame (30-60 Hz)
- **Responsibility**: Orchestrates all per-frame processing
- **Key method**: `GameLoop.Update()` calls all subsystems in order

#### Game State Manager
- **Type**: Finite State Machine
- **States**: Loading, MainMenu, Campaign, Battle, Garage, Store, Settings
- **Transitions**: Triggered by player actions or system events
- **Persistence**: Saves current state to SQLite on app pause

#### Renderer
- **Pipeline**: Unity built-in (not URP/HDRP — mobile optimized)
- **Sprite rendering**: SpriteRenderer for 2D elements
- **3D models**: SkinnedMeshRenderer for units (low-poly)
- **Particles**: Shuriken particle system for explosions, smoke
- **Camera**: Orthographic with zoom (pinch gesture)

#### Input Manager (GGInputModule)
- **Touch processing**: Multi-touch support (2 fingers)
- **Gestures**: Tap, drag, pinch (zoom), two-finger rotate
- **Selection**: Rectangle selection (drag), tap selection
- **Commands**: Translates gestures into game commands
- **Key class**: `GGInputModule : MonoBehaviour`

#### Resource Manager
- **System**: Unity Addressables
- **Catalog**: 773 entries, 23 asset bundles
- **Loading**: Async with callback, priority queue
- **Caching**: LRU cache for frequently used assets
- **Unloading**: Reference counting, unload unused on scene change

### Gameplay Systems

#### Unit System
- **Creation**: Factory pattern, pooled objects
- **Selection**: Multi-select with rectangle, shift-add
- **Movement**: Waypoint queue, formation movement
- **Commands**: Move, Attack, Patrol, Hold, Garrison
- **Groups**: Control groups (1-9), persistent per battle

#### Combat System
- **Damage formula**: `damage = weaponDamage * (1 - armorReduction) * typeMultiplier`
- **Weapon types**: Bullet, Shell, Missile, Laser, Flame
- **Armor types**: Light, Medium, Heavy, Structure
- **Targeting**: Nearest, Weakest, Most Dangerous, Manual
- **Attack ranges**: Min/Max range per weapon

#### Building System
- **Construction**: Time-based with progress bar
- **Upgrades**: Level-based, each level improves stats
- **Production**: Queue up to 5 units per building
- **Power**: Buildings consume power; Power Plants generate it
- **Placement**: Grid-snapped, collision-checked

#### Economy System
- **Supplies**: Primary resource, from Supply Centers
- **Power**: From Power Plants, consumed by buildings
- **Uranium**: Rare resource, for special units
- **Credits**: Earned from battles and missions
- **Gold**: Premium currency, from IAP or rare rewards

#### Upgrade System
- **Tech Tree**: Linear per unit type, requires prerequisite levels
- **Unit Upgrades**: HP, Damage, Speed, Range improvements
- **Building Upgrades**: Production speed, armor, power output
- **Cost**: Escalating resource costs per level

#### AI System
- **Strategic AI**: Manages economy, base building, tech progression
- **Tactical AI**: Controls unit groups, combat decisions
- **Pathfinding**: Uses grid-based A* with terrain weighting
- **Fog of War**: AI has its own vision and explores like a player

#### Pathfinding System
- **Algorithm**: A* on a grid
- **Grid resolution**: ~1 unit per cell
- **Terrain types**: Passable, Difficult (2x cost), Impassable, Water
- **Dynamic obstacles**: Units, buildings, destroyed structures
- **Optimization**: Hierarchical pathfinding for long distances

#### Fog of War System
- **Vision ranges**: Per-unit vision radius in grid cells
- **States**: Unexplored (black), Explored (dimmed), Visible (full)
- **Stealth**: Some units have reduced detection range
- **Update**: Recalculated when units move or die

#### Mission System
- **Campaign**: ~100 missions across two factions
- **Objectives**: Destroy enemy, Defend position, Collect resources, Timer-based
- **Win conditions**: All primary objectives met
- **Loss conditions**: Base destroyed, timer expired, specific unit lost

### Content Systems

#### Maps
- **Count**: 8 unique scenarios
- **Terrain**: Procedural generation with authoring tools
- **Size**: Variable, typically 64x64 to 128x128 grid
- **Features**: Chokepoints, resource locations, start positions

#### Campaigns
- **Factions**: Coalition (Western) vs Empire (Eastern)
- **Progression**: Linear with optional side missions
- **Rewards**: Credits, upgrade points, unique units

#### Assets
- **Catalog**: 773 entries
- **Bundles**: 23 asset bundles (grouped by feature)
- **Types**: Sprites (UI), 3D Models (units/buildings), Audio, Shaders

#### UI System
- **Framework**: Zenject dependency injection
- **Pattern**: MVP (Model-View-Presenter)
- **Presenters**: One per panel/window
- **Panels**: MainMenu, BattleHUD, BuildMenu, UnitInfo, Store, Clan, etc.
- **Animations**: DOTween for transitions

#### Audio System
- **SFX**: Battle sounds, UI clicks, construction
- **Voice Over**: Unit acknowledgments, mission briefings
- **Music**: Faction-specific themes, battle intensity tracks
- **System**: Unity AudioSource with pooling

### Multiplayer Systems

#### Networking Layer
- **Main Server**: Persistent TCP connection for chat, matchmaking, profiles
- **Battle Server**: Ephemeral UDP connection for real-time gameplay
- **Protocol**: Custom binary protocol with LZ4 compression
- **Heartbeat**: 30s for main, game-tick for battle

#### Synchronization Layer
- **Mode**: Lockstep with client prediction
- **Tick rate**: 10 Hz (100ms per tick)
- **Prediction**: Client predicts own unit movement
- **Rollback**: On desync, rollback to last confirmed state

#### Command Processing
- **Validation**: Server validates all commands
- **Arbitration**: Server resolves conflicting commands
- **Queue**: Commands buffered until tick boundary
- **Determinism**: Same seed + same commands = same result

#### Replication Layer
- **State replication**: Full state on join, delta updates after
- **Desync detection**: Hash comparison every 10 ticks
- **Correction**: Server sends authoritative state on desync
- **Bandwidth**: Target <10 KB/s per player

#### Matchmaking System
- **Modes**: 1v1, 2v2, Tournament
- **Algorithm**: ELO-based with expanding search radius
- **Timeout**: 60s search, then widen criteria
- **Maps**: Random from pool, or voted

#### Chat System
- **Rooms**: Global, Clan, Battle, Private
- **Moderation**: Profanity filter, report system
- **Translation**: Auto-translate for cross-language chat
- **Friends**: Friend list, online status, invite

### Domain Systems

#### Workshop System
- **Function**: Customize unit appearance and minor stats
- **Unlockables**: Skins, decals, visual effects
- **Currency**: Credits and Gold

#### Clan System
- **Creation**: Player creates clan with name and tag
- **Management**: Leader, Officers, Members hierarchy
- **Wars**: Clan vs Clan battles with scoring
- **Size**: Up to 50 members

#### Skills System
- **Commander Skills**: Active abilities used in battle
- **Skill Trees**: 3 trees per faction (Offense, Defense, Support)
- **Cooldown**: Per-skill cooldown timers
- **Unlock**: Level-based progression

#### Rating System
- **Algorithm**: ELO with K-factor adjustments
- **Seasons**: Monthly resets with rewards
- **Leagues**: Bronze, Silver, Gold, Platinum, Diamond, Legend
- **Decay**: Inactivity penalty after 7 days

#### Store System
- **IAP**: Google Play / App Store integration
- **Packs**: Starter pack, resource bundles, unit packs
- **Offers**: Time-limited special offers
- **Currency**: Gold (premium), Credits (free)

#### Tournament System
- **Format**: Single elimination brackets
- **Size**: 8, 16, 32, or 64 players
- **Schedule**: Weekly and monthly tournaments
- **Rewards**: Gold, exclusive skins, rating points

#### Replay System
- **Recording**: Stores command stream + initial state
- **Playback**: Re-simulates from initial state
- **Controls**: Play, Pause, Fast-forward, Camera free-move
- **Share**: Upload to server, share with clan/friends
- **Size**: ~50-200 KB per replay (command stream only)
