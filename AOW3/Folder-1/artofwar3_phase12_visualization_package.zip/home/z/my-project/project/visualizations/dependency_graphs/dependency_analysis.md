# Art of War 3: Global Conflict — Dependency Analysis Report

> Comprehensive architectural dependency analysis for the reverse-engineered Unity IL2CPP game.
> Engine: Unity 3D with IL2CPP | 29,334 types | 140,824 methods | 141 custom assemblies

---

## Table of Contents

1. [High-Level Module Dependency Graph](#1-high-level-module-dependency-graph)
2. [Low-Level Class Dependency Graph](#2-low-level-class-dependency-graph)
3. [Bottleneck Analysis](#3-bottleneck-analysis)
4. [Circular Dependency Analysis](#4-circular-dependency-analysis)
5. [Critical Path Analysis](#5-critical-path-analysis)
6. [Coupling Metrics](#6-coupling-metrics)
7. [Recommendations for Re-engineering](#7-recommendations-for-re-engineering)

---

## 1. High-Level Module Dependency Graph

```mermaid
graph TD
    %% ── Core Runtime ──────────────────────────────
    CORE["🔴 Core Runtime<br/>(GameStateManager, Zenject)"]
    SCENE["Core Scene Manager<br/>(Startup→Logon→Main→Battle)"]

    %% ── Gameplay Systems ──────────────────────────
    BATTLE["🔴 Battle System<br/>(BattleScreen, LogicService)"]
    MAIN["Main System<br/>(Hub, Navigation)"]
    AI["AI System<br/>(Strategic + Tactical AI)"]
    UNITS["🔴 Unit System<br/>(Entity Spawning, Combat)"]
    BLDGS["Building System<br/>(Construction, Production)"]
    ECON["Economy System<br/>(Resources, Costs)"]
    PATH["Pathfinding<br/>(A*, NavMesh)"]
    MAP["Map System<br/>(Terrain, Fog of War)"]

    %% ── Infrastructure ────────────────────────────
    NET["🔴⚠️ Network Layer<br/>(RSA/DES, Protobuf)"]
    ASSET["⚠️ Asset System<br/>(Addressables, 773 entries)"]
    PERSIST["Persistence Layer<br/>(SQLite, PCLRaw)"]
    GUI["GUI System<br/>(DOTween, BattleGUI)"]
    AUDIO["Audio System<br/>(SFX, Music, Voice)"]

    %% ── Third-Party / External ────────────────────
    ANALYTICS["Analytics<br/>(Firebase + AppMetrica)"]
    ADS["Ads<br/>(AppLovin MAX + IronSource)"]
    BILLING["Billing<br/>(Google Play + HMS)"]
    PUSH["Push Notifications<br/>(FCM + GGNotifications)"]

    %% ── Social / Domain ───────────────────────────
    SOCIAL["Social Module<br/>(Clan, Chat, Friends)"]
    WORKSHOP["Workshop<br/>(Unit Upgrades, Tech)"]
    SKILLS["Skills System<br/>(Commander Abilities)"]
    TOURN["Tournaments<br/>(Ranked, Events)"]
    PROFILE["Profile System<br/>(Player Data, Progression)"]
    STORE["Store / IAP"]

    %% ── Core dependencies ─────────────────────────
    CORE --> SCENE
    CORE --> NET
    CORE --> ASSET
    CORE --> PERSIST
    CORE --> GUI

    SCENE --> MAIN
    SCENE --> BATTLE

    BATTLE --> NET
    BATTLE --> AI
    BATTLE --> UNITS
    BATTLE --> BLDGS
    BATTLE --> ECON
    BATTLE --> GUI
    BATTLE --> AUDIO
    BATTLE --> MAP
    BATTLE --> ASSET

    AI --> MAP
    AI --> UNITS
    AI --> BLDGS
    AI --> ECON
    AI --> PATH
    MAP --> PATH
    UNITS --> ECON
    BLDGS --> ECON
    BLDGS --> UNITS

    MAIN --> NET
    MAIN --> STORE
    MAIN --> SOCIAL
    MAIN --> WORKSHOP
    MAIN --> PROFILE
    MAIN --> SKILLS
    MAIN --> TOURN
    MAIN --> GUI
    MAIN --> ASSET
    MAIN --> AUDIO

    STORE --> BILLING
    SOCIAL --> NET
    SOCIAL --> PERSIST
    WORKSHOP --> UNITS
    WORKSHOP --> ECON
    WORKSHOP --> PERSIST
    SKILLS --> UNITS
    SKILLS --> PERSIST
    TOURN --> NET
    TOURN --> PROFILE
    PROFILE --> PERSIST
    PROFILE --> NET

    ASSET --> CORE
    NET --> CORE
    PERSIST --> CORE

    ANALYTICS --> CORE
    ADS --> CORE
    BILLING --> CORE
    PUSH --> CORE

    GUI -.->|🔴 circular| BATTLE
    UNITS -.->|🔴 circular| BLDGS

    style CORE fill:#ff4444,stroke:#aa0000,stroke-width:4px,color:#fff
    style NET fill:#ff4444,stroke:#aa0000,stroke-width:4px,color:#fff
    style UNITS fill:#ff4444,stroke:#aa0000,stroke-width:4px,color:#fff
    style BATTLE fill:#4488ff,stroke:#2244aa,stroke-width:3px,color:#fff
    style MAIN fill:#4488ff,stroke:#2244aa,stroke-width:3px,color:#fff
    style AI fill:#4488ff,stroke:#2244aa,stroke-width:2px,color:#fff
    style BLDGS fill:#4488ff,stroke:#2244aa,stroke-width:2px,color:#fff
    style ECON fill:#4488ff,stroke:#2244aa,stroke-width:2px,color:#fff
    style PATH fill:#4488ff,stroke:#2244aa,stroke-width:2px,color:#fff
    style MAP fill:#4488ff,stroke:#2244aa,stroke-width:2px,color:#fff
    style ASSET fill:#ff8800,stroke:#cc6600,stroke-width:3px,stroke-dasharray: 5 5,color:#fff
    style PERSIST fill:#44bb44,stroke:#228822,stroke-width:2px,color:#fff
    style GUI fill:#44bb44,stroke:#228822,stroke-width:2px,color:#fff
    style AUDIO fill:#44bb44,stroke:#228822,stroke-width:2px,color:#fff
    style SCENE fill:#44bb44,stroke:#228822,stroke-width:2px,color:#fff
    style ANALYTICS fill:#dddd44,stroke:#aaaa00,stroke-width:2px,color:#333
    style ADS fill:#dddd44,stroke:#aaaa00,stroke-width:2px,color:#333
    style BILLING fill:#dddd44,stroke:#aaaa00,stroke-width:2px,color:#333
    style PUSH fill:#dddd44,stroke:#aaaa00,stroke-width:2px,color:#333
    style SOCIAL fill:#8844cc,stroke:#6622aa,stroke-width:2px,color:#fff
    style WORKSHOP fill:#8844cc,stroke:#6622aa,stroke-width:2px,color:#fff
    style SKILLS fill:#8844cc,stroke:#6622aa,stroke-width:2px,color:#fff
    style TOURN fill:#8844cc,stroke:#6622aa,stroke-width:2px,color:#fff
    style PROFILE fill:#8844cc,stroke:#6622aa,stroke-width:2px,color:#fff
    style STORE fill:#dddd44,stroke:#aaaa00,stroke-width:2px,color:#333
```

---

## 2. Low-Level Class Dependency Graph

```mermaid
graph TD
    subgraph Core["com.geargames.aow.core"]
        GSM["GameStateManager"]
        DI["ZenjectContainer"]
        SCOR["SceneOrchestrator"]
        GOBJ["GameObjectFactory"]
        RESM["ResourceManager"]
        POOL["ObjectPoolManager"]
        EVBUS["EventBus"]
        COROUT["CoroutineRunner"]
    end

    subgraph Battle["com.geargames.aow.scenes.battle"]
        BS["BattleScreen"]
        LS["LogicService"]
        BGUI["BattleGUI"]
        BCTRL["BattleController"]
        BRULE["BattleRuleEngine"]
        BSTAT["BattleStateTracker"]
        BSYNC["BattleSyncManager"]
        BREPLAY["BattleReplaySystem"]
    end

    subgraph BattleGUI_NS["com.geargames.aow.scenes.battle.gui"]
        GBLU["GUIBattleListUpgrade"]
        GBHU["GUIBattleHud"]
        GBMINI["GUIMinimap"]
        GBSEL["GUISelectionPanel"]
        GBPROD["GUIProductionQueue"]
        GBTOOL["GUIQuickToolbar"]
    end

    subgraph BattleNet["com.geargames.aow.scenes.battle.network"]
        CSLB["CSLoginToBattle"]
        SCBR["SCBattleResult"]
        CSORD["CSOrderUnit"]
        CSBUILD["CSBuildStructure"]
        NPROV["NetworkProvider"]
        NCRYPT["NetworkEncryption"]
        NSERI["ProtobufSerializer"]
        NCONN["ConnectionManager"]
        NPERS["PersistentConnection"]
        NEPH["EphemeralConnection"]
    end

    subgraph Entities["com.geargames.aow.entities"]
        UENT["UnitEntity"]
        BENT["BuildingEntity"]
        EBASE["EntityBase"]
        ECOMP["EntityComponent"]
        HCOMP["HealthComponent"]
        WCOMP["WeaponComponent"]
        MCOMP["MovementComponent"]
        VCOMP["VisibilityComponent"]
        EREG["EntityRegistry"]
    end

    subgraph Map["com.geargames.aow.scenes.battle.map"]
        TMAP["TileMap"]
        TCELL["TileCell"]
        FOW["FogOfWar"]
        PATHF["AStarPathfinder"]
        NAVM["NavMeshAdapter"]
    end

    subgraph AI_NS["com.geargames.aow.scenes.battle.map.ai"]
        AIBRAIN["AIBrainController"]
        AISUP["AIStrategicPlanner"]
        AITAC["AITacticalExecutor"]
        AIECO["AIEconomyManager"]
        AIUNIT["AIUnitController"]
    end

    subgraph Economy["com.geargames.aow.economy"]
        RSH["ResourceServiceHelper"]
        RPOOL["ResourcePool"]
        COST["CostCalculator"]
        PRODC["ProductionChain"]
    end

    subgraph Main["com.geargames.aow.scenes.main"]
        MHUB["MainHubScreen"]
        MNAV["MainNavigation"]
        MBATT["MainBattleList"]
        MSTORE["MainStoreScreen"]
    end

    subgraph Workshop["Domains.Workshop"]
        WSCR["WorkshopScreen"]
        WUPG["WorkshopUpgradeService"]
        WTECH["TechTreeController"]
    end

    subgraph Clan["Domains.Clan"]
        CSCR["ClanScreen"]
        CSVC["ClanService"]
        CCHAT["ClanChatController"]
    end

    subgraph Chat["Domains.Chat"]
        CHSCR["ChatScreen"]
        CHSVC["ChatService"]
        CHMSG["MessageProcessor"]
    end

    subgraph Skills["Domains.Skills"]
        SKSCR["SkillsScreen"]
        SKSVC["SkillService"]
        SKTREE["SkillTreeController"]
    end

    subgraph Profile["Domains.Profile"]
        PSCR["ProfileScreen"]
        PSVC["ProfileService"]
        PPROG["ProgressionTracker"]
    end

    subgraph Persistence["com.geargames.aow.persistence"]
        DBM["DatabaseManager"]
        SQH["SQLiteHelper"]
        DREP["DataRepository"]
        CSER["CacheSerializer"]
    end

    subgraph Assets["com.geargames.aow.assets"]
        ALDR["AddressableLoader"]
        ACAT["AssetCatalog"]
        ABUN["BundleManager"]
        ACCH["AssetCache"]
    end

    subgraph Analytics["com.geargames.aow.analytics"]
        ANMGR["AnalyticsManager"]
        FIREV["FirebaseEventHandler"]
        APME["AppMetricaEventHandler"]
    end

    subgraph Audio["com.geargames.aow.audio"]
        AUDM["AudioManager"]
        AUDS["AudioSourcePool"]
        AUDF["SoundFXPlayer"]
    end

    %% ── Edges ──
    GSM --> DI; GSM --> EVBUS; SCOR --> GSM
    GOBJ --> POOL; GOBJ --> RESM
    SCOR --> BS; SCOR --> MHUB
    BS --> LS; BS --> BGUI; BS --> BCTRL; BS --> BSYNC; BS --> BREPLAY
    BCTRL --> BRULE; BCTRL --> BSTAT
    LS --> EREG; LS --> TMAP; LS --> AIBRAIN; LS --> RSH; LS --> BSYNC
    BGUI --> GBLU; BGUI --> GBHU; BGUI --> GBMINI; BGUI --> GBSEL; BGUI --> GBPROD; BGUI --> GBTOOL
    GBLU --> LS; GBHU --> BSTAT; GBSEL --> EREG; GBPROD --> BENT; GBTOOL --> LS
    CSLB --> NPROV; SCBR --> NPROV; CSORD --> NPROV; CSBUILD --> NPROV
    NPROV --> NCRYPT; NPROV --> NSERI; NPROV --> NCONN
    NCONN --> NPERS; NCONN --> NEPH
    BSYNC --> CSLB; BSYNC --> SCBR
    UENT --> EBASE; BENT --> EBASE; EBASE --> ECOMP
    HCOMP --> ECOMP; WCOMP --> ECOMP; MCOMP --> ECOMP; VCOMP --> ECOMP
    EREG --> UENT; EREG --> BENT
    TMAP --> TCELL; FOW --> TMAP; PATHF --> TMAP; NAVM --> TMAP
    AIBRAIN --> AISUP; AIBRAIN --> AITAC; AIBRAIN --> AIECO
    AISUP --> AITAC; AISUP --> PATHF; AITAC --> AIUNIT
    AIUNIT --> UENT; AIECO --> RSH; AIECO --> BENT
    RSH --> RPOOL; RSH --> COST; COST --> PRODC
    UENT -.->|circular| BENT
    MHUB --> MNAV; MNAV --> MBATT; MNAV --> MSTORE; MNAV --> WSCR; MNAV --> CSCR; MNAV --> CHSCR; MNAV --> SKSCR; MNAV --> PSCR
    WSCR --> WUPG; WUPG --> WTECH; WUPG --> RSH; WTECH --> UENT
    CSCR --> CSVC; CSVC --> CCHAT; CSVC --> NPROV; CCHAT --> CHSVC
    CHSCR --> CHSVC; CHSVC --> CHMSG; CHSVC --> NPROV
    SKSCR --> SKSVC; SKSVC --> SKTREE; SKTREE --> UENT
    PSCR --> PSVC; PSVC --> PPROG; PSVC --> NPROV; PPROG --> DREP
    DBM --> SQH; DREP --> DBM; DREP --> CSER
    ALDR --> ACAT; ALDR --> ABUN; ALDR --> ACCH
    BS --> ALDR; MHUB --> ALDR; GOBJ --> ALDR
    ANMGR --> FIREV; ANMGR --> APME; GSM --> ANMGR
    BS --> AUDM; MHUB --> AUDM; AUDM --> AUDS; AUDM --> AUDF
    MSTORE --> PSVC; BS --> GSM; MHUB --> GSM; NPROV --> GSM; ALDR --> RESM
    BCTRL --> CSORD; BCTRL --> CSBUILD

    style GSM fill:#ff4444,stroke:#aa0000,stroke-width:3px,color:#fff
    style LS fill:#ff4444,stroke:#aa0000,stroke-width:3px,color:#fff
    style NPROV fill:#ff4444,stroke:#aa0000,stroke-width:3px,color:#fff
    style EREG fill:#ff4444,stroke:#aa0000,stroke-width:3px,color:#fff
    style ALDR fill:#ff8800,stroke:#cc6600,stroke-width:3px,stroke-dasharray: 5 5,color:#fff
```

---

## 3. Bottleneck Analysis

### Most Depended-Upon Modules (by Fan-In)

| Rank | Module | Fan-In | Fan-Out | Instability (Fan-Out / Total) | Classification |
|------|--------|--------|---------|-------------------------------|----------------|
| 1 | **Core Runtime** | 8 | 4 | 0.33 | Stable (used by many, depends on few) |
| 2 | **Network Layer** | 7 | 1 | 0.13 | Extremely stable — single point of failure |
| 3 | **Persistence Layer** | 5 | 1 | 0.17 | Stable — SQLite access bottleneck |
| 4 | **Unit System** | 4 | 2 | 0.33 | Core entity — tightly coupled |
| 5 | **Economy System** | 4 | 0 | 0.00 | Pure leaf — no outgoing deps |
| 6 | **Asset System** | 4 | 1 | 0.20 | Stable — Addressables bottleneck |
| 7 | **GUI System** | 2 | 1 | 0.33 | Moderate coupling |
| 8 | **Profile System** | 2 | 2 | 0.50 | Balanced |

### Bottleneck Detail

#### 🚨 Network Layer (Fan-In: 7)
The Network Layer is the single most critical bottleneck in the entire architecture. Seven distinct modules depend on it:
- **Battle System** — game state sync, order dispatch
- **Main System** — matchmaking, lobby
- **Social Module** — clan/chat messaging
- **Tournaments** — ranked queue, leaderboards
- **Profile** — data fetch, authentication
- **Core Runtime** — connection lifecycle
- **Workshop** (indirect via Economy/Profile)

**Risk:** Any network outage or protocol regression cascades to 7+ modules. The RSA/DES encryption layer and protobuf serialization are also single points of failure.

#### 🚨 Asset System (Fan-In: 4)
With 773 catalog entries and 23 asset bundles, the AddressableLoader is a serialization and loading bottleneck:
- **Battle System** — unit models, map tiles, VFX
- **Main System** — UI prefabs, avatars, backgrounds
- **Core Runtime** — shared assets
- **GameObjectFactory** — object pooling and instantiation

**Risk:** Bundle loading failures (missing assets, version mismatch) cause hard crashes in both Battle and Main scenes.

#### 🚨 Persistence Layer (Fan-In: 5)
SQLite is used by Profile, Workshop, Skills, Social, and Core. While not a performance bottleneck (local DB), schema migration errors can corrupt all cached data.

---

## 4. Circular Dependency Analysis

Three circular dependency chains were identified in the decompiled codebase:

### Circular Dependency 1: GUI ↔ Battle System

```
BattleScreen → BattleGUI → [callback] → BattleScreen
```

- **Severity:** Medium
- **Nature:** BattleGUI renders HUD elements and fires user action callbacks (e.g., unit selected, ability cast) back to BattleScreen/BattleController.
- **IL2CPP Evidence:** `BattleGUI` holds a reference to `BattleScreen` via `MonoBehaviour` field injection; `BattleScreen` owns `BattleGUI` as a child component.
- **Impact:** Makes it impossible to test BattleGUI in isolation; couples rendering to game logic.

### Circular Dependency 2: UnitEntity ↔ BuildingEntity

```
BuildingEntity → UnitEntity (produces units)
UnitEntity → BuildingEntity (garrison, repair, enter)
```

- **Severity:** Low-Medium
- **Nature:** Buildings produce units (factory pattern); units can garrison in buildings or repair them. Both entity types reference each other.
- **IL2CPP Evidence:** `BuildingEntity._producedUnits : List<UnitEntity>` and `UnitEntity._garrisonBuilding : BuildingEntity`.
- **Impact:** Prevents independent entity testing; deserialization of either type requires the other to be loaded.

### Circular Dependency 3: LogicService ↔ BattleSyncManager

```
LogicService → BattleSyncManager (sends state to server)
BattleSyncManager → LogicService (applies server corrections)
```

- **Severity:** High
- **Nature:** LogicService drives the game simulation and sends diffs to BattleSyncManager, which transmits to the server. When server corrections arrive, BattleSyncManager applies them directly to LogicService's state, potentially overwriting local predictions.
- **IL2CPP Evidence:** `LogicService._syncManager : BattleSyncManager` and `BattleSyncManager._logic : LogicService`.
- **Impact:** This is the most dangerous circular dependency because it involves network state reconciliation. Incorrect ordering can cause desyncs, rubber-banding, or state corruption.

### Circular Dependency Summary

| Cycle | Classes Involved | Severity | Recommended Fix |
|-------|-----------------|----------|-----------------|
| GUI ↔ Battle | `BattleGUI` ↔ `BattleScreen` | Medium | Event bus decoupling |
| Unit ↔ Building | `UnitEntity` ↔ `BuildingEntity` | Low-Medium | Interface extraction (`IGarrisonable`, `IProducer`) |
| Logic ↔ Sync | `LogicService` ↔ `BattleSyncManager` | High | Command queue pattern + state snapshot |

---

## 5. Critical Path Analysis

### Critical Path 1: Battle Startup (Startup → Battle Ready)

```
Startup Scene
  → Logon Scene (authentication)
    → Network Layer (RSA handshake, session token)
      → Main Scene (matchmaking)
        → BattleLoading Scene (asset preload)
          → Asset System (load 23 bundles: maps, units, VFX)
            → Battle Scene (LogicService init, EntityRegistry populate)
              → Network (CSLoginToBattle → server join)
                → Game Start
```

**Total hops:** 8  
**Estimated time (cold start):** 8-15 seconds  
**Bottleneck:** Asset System (bundle download + decompression) and Network (encryption handshake)

### Critical Path 2: In-Game Unit Production

```
Player taps production button
  → GUIProductionQueue (UI event)
    → BattleGUI (forward)
      → BattleController (order creation)
        → Economy (ResourceServiceHelper: cost check + deduction)
          → Network (CSOrderUnit: validate with server)
            → BuildingEntity (production queue add)
              → UnitEntity (spawn on completion)
                → EntityRegistry (register)
                  → Pathfinding (initial path assign)
```

**Total hops:** 10  
**Latency budget:** <200ms (perceived instant)  
**Bottleneck:** Network round-trip for server validation

### Critical Path 3: Social Message Delivery

```
Player sends chat message
  → ChatScreen (UI capture)
    → ChatService (format message)
      → NetworkProvider (serialize + encrypt)
        → PersistentConnection (TCP send)
          → Server (broadcast)
            → PersistentConnection (TCP receive)
              → MessageProcessor (deserialize + decrypt)
                → ChatScreen (render)
```

**Total hops:** 9  
**Latency budget:** <500ms  
**Bottleneck:** Persistent connection + serialization

### Critical Path 4: IAP Purchase Flow

```
Player taps purchase
  → MainStoreScreen (UI)
    → ProfileService (ownership check)
      → Billing (Google Play / HMS)
        → Server validation (Network)
          → ResourceServiceHelper (grant resources)
            → PersistenceLayer (save)
              → UI update (DOTween animation)
```

**Total hops:** 8  
**Latency budget:** <3 seconds (payment + validation)  
**Bottleneck:** Billing SDK + server validation round-trip

---

## 6. Coupling Metrics

### Afferent Coupling (Ca) — How many modules depend on this module

| Module | Ca | Risk Level |
|--------|----|----|
| Core Runtime | 8 | 🔴 Critical |
| Network Layer | 7 | 🔴 Critical |
| Persistence Layer | 5 | 🟠 High |
| Unit System | 4 | 🟡 Medium |
| Economy System | 4 | 🟡 Medium |
| Asset System | 4 | 🟡 Medium |

### Efferent Coupling (Ce) — How many modules this module depends on

| Module | Ce | Risk Level |
|--------|----|----|
| Main System | 10 | 🔴 God Object risk |
| Battle System | 9 | 🔴 God Object risk |
| AI System | 5 | 🟠 High |
| Workshop | 3 | 🟢 Low |
| Social | 2 | 🟢 Low |

### Instability (I = Ce / (Ca + Ce))

| Module | Ca | Ce | I | Interpretation |
|--------|----|----|---|----------------|
| Core Runtime | 8 | 4 | 0.33 | Stable (good — foundational) |
| Network Layer | 7 | 1 | 0.13 | Very stable (rigid — hard to change) |
| Economy System | 4 | 0 | 0.00 | Perfectly stable (leaf — no deps) |
| Main System | 1 | 10 | 0.91 | Very unstable (depends on many) |
| Battle System | 2 | 9 | 0.82 | Very unstable (depends on many) |
| AI System | 1 | 5 | 0.83 | Very unstable |
| Persistence Layer | 5 | 1 | 0.17 | Stable (rigid) |
| Asset System | 4 | 1 | 0.20 | Stable (rigid) |
| GUI System | 2 | 1 | 0.33 | Balanced |
| Pathfinding | 1 | 0 | 0.00 | Perfectly stable (leaf) |

### Abstractness (A) — Ratio of abstract types to total types

| Namespace | Abstract Types | Concrete Types | A |
|-----------|---------------|----------------|---|
| com.geargames.aow.core | 4 | 4 | 0.50 |
| com.geargames.aow.entities | 3 | 6 | 0.33 |
| com.geargames.aow.scenes.battle | 2 | 6 | 0.25 |
| com.geargames.aow.scenes.battle.network | 1 | 9 | 0.10 |
| com.geargames.aow.scenes.battle.map.ai | 1 | 4 | 0.20 |
| com.geargames.aow.economy | 1 | 3 | 0.25 |
| Domains.* | 2 | 9 | 0.18 |

### Distance from Main Sequence (D = |A + I - 1|)

| Module | A | I | D | Zone |
|--------|---|---|---|------|
| Core Runtime | 0.50 | 0.33 | 0.17 | ✅ Balanced |
| Network Layer | 0.10 | 0.13 | 0.77 | ⚠️ Zone of Pain (hard to change, concrete) |
| Economy System | 0.25 | 0.00 | 0.75 | ⚠️ Zone of Pain (rigid, concrete) |
| Persistence Layer | 0.15 | 0.17 | 0.68 | ⚠️ Zone of Pain |
| Main System | 0.18 | 0.91 | 0.27 | 🟡 Moderate |
| Battle System | 0.25 | 0.82 | 0.07 | ✅ Near ideal (abstract enough for its instability) |
| Asset System | 0.10 | 0.20 | 0.70 | ⚠️ Zone of Pain |

**Key Finding:** The Network Layer, Persistence Layer, and Asset System are in the **Zone of Pain** — they are highly depended-upon (low instability) but lack abstraction (low abstractness). This means changing any of these modules requires updating all their consumers with no interface buffer.

---

## 7. Recommendations for Re-engineering

### Priority 1: Break the LogicService ↔ BattleSyncManager Circular Dependency

**Problem:** This is the most dangerous circular dependency. LogicService drives game simulation; BattleSyncManager applies server corrections directly to LogicService state.

**Recommendation:** Implement a Command Queue pattern:
- LogicService emits `IGameCommand` objects to a command queue
- BattleSyncManager reads from the queue and applies corrections as new commands
- Both depend on the `IGameCommand` interface, not on each other
- State snapshots provide rollback capability

```
Before: LogicService ←→ BattleSyncManager
After:  LogicService → ICommandQueue ← BattleSyncManager
```

### Priority 2: Introduce INetworkService Interface for Network Layer

**Problem:** Network Layer is in the Zone of Pain (Ca=7, A=0.10). All consumers directly depend on `NetworkProvider` concrete class.

**Recommendation:** Extract `INetworkService` interface:
- `INetworkService` defines: `SendAsync()`, `Subscribe()`, `GetConnectionState()`
- `NetworkProvider` implements `INetworkService`
- All 7 consumers depend on `INetworkService` instead
- Enables mock implementations for testing
- Allows swapping transport layer without cascading changes

### Priority 3: Abstract Asset System with IAssetProvider

**Problem:** Asset System is a bottleneck (Ca=4) with no abstraction (A=0.10).

**Recommendation:** Extract `IAssetProvider` interface:
- `IAssetProvider` defines: `LoadAssetAsync<T>()`, `InstantiateAsync()`, `Release()`
- `AddressableLoader` implements `IAssetProvider`
- Enables swapping Addressables for Resources or AssetDatabase in editor
- Allows offline/fallback asset loading strategies

### Priority 4: Decompose Main System (Fan-Out: 10)

**Problem:** MainHubScreen/MainNavigation acts as a god object with 10 outgoing dependencies. It directly references Workshop, Clan, Chat, Skills, Profile, Store, etc.

**Recommendation:** Apply Mediator pattern:
- `MainMediator` coordinates navigation between feature modules
- Each feature module (Workshop, Clan, etc.) registers itself as an `IMainFeature`
- MainNavigation discovers features via `IMainFeature[]` injection
- Eliminates direct coupling between Main and every feature

### Priority 5: Interface Extraction for Entity System

**Problem:** `UnitEntity` ↔ `BuildingEntity` circular dependency prevents independent testing.

**Recommendation:** Extract interfaces:
- `IProducer` — produces entities (implemented by BuildingEntity)
- `IGarrisonable` — can garrison units (implemented by BuildingEntity)
- `IOccupant` — can occupy buildings (implemented by UnitEntity)
- Both entities depend on interfaces, breaking the direct circular reference

### Priority 6: Decouple GUI from Battle Logic

**Problem:** `BattleGUI` ↔ `BattleScreen` circular dependency couples rendering to game logic.

**Recommendation:** Use UniRx/R3 reactive streams:
- `LogicService` exposes `IObservable<BattleState>` 
- `BattleGUI` subscribes to state changes reactively
- `BattleGUI` dispatches `IUserAction` via `EventBus`
- `BattleController` subscribes to `IUserAction` via `EventBus`
- No direct references between GUI and logic

### Priority 7: Persistence Layer Abstraction

**Problem:** SQLite is directly used by 5 modules with no abstraction.

**Recommendation:** Implement Repository pattern:
- `IRepository<T>` for each domain entity
- `SQLiteRepository<T>` implements `IRepository<T>`
- Consumers depend on `IRepository<T>`, not `DatabaseManager`
- Enables in-memory repositories for testing
- Allows migration to other storage backends

### Priority 8: Modularize Third-Party Integrations

**Problem:** Firebase, AppMetrica, AppLovin, IronSource, Google Play Billing, and HMS are integrated across multiple namespaces.

**Recommendation:** Create adapter layer:
- `IAnalyticsProvider` → `FirebaseAdapter`, `AppMetricaAdapter`
- `IAdsProvider` → `AppLovinAdapter`, `IronSourceAdapter`
- `IBillingProvider` → `GooglePlayAdapter`, `HMSAdapter`
- `IPushProvider` → `FCMAdapter`, `GGNotificationsAdapter`
- Each adapter in a separate assembly for easy replacement

---

## Summary Statistics

| Metric | Value |
|--------|-------|
| Total modules (high-level) | 25 |
| Total classes (low-level) | 75 |
| Circular dependencies | 3 |
| Bottleneck modules (Ca ≥ 4) | 6 |
| God object candidates (Ce ≥ 8) | 2 (Main, Battle) |
| Zone of Pain modules | 4 (Network, Economy, Persistence, Assets) |
| Critical paths analyzed | 4 |
| Recommended refactorings | 8 (prioritized) |
| Estimated re-engineering effort | ~3-4 months for P1-P4 |

---

*Generated from IL2CPP decompilation analysis of Art of War 3: Global Conflict by Gear Games.*
*Engine: Unity 3D | IL2CPP | 29,334 types | 140,824 methods | 141 custom assemblies*
