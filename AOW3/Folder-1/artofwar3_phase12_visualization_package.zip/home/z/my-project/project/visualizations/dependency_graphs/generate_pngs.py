#!/usr/bin/env python3
"""
Generate dependency graph PNGs for Art of War 3: Global Conflict.

Produces:
  - high_level_dependency.png   (module-level, ~25 nodes)
  - low_level_dependency.png    (class-level, ~75 nodes)

Uses: graphviz Python library + system Graphviz (dot layout)
"""

import graphviz
import os

OUTPUT_DIR = "/home/z/my-project/project/visualizations/dependency_graphs"
os.makedirs(OUTPUT_DIR, exist_ok=True)

FONT = "NotoSansSC"

# ──────────────────────────────────────────────────────────
#  Color palette
# ──────────────────────────────────────────────────────────
CORE_COLOR      = "#cc2222"   # Red — core/critical
CORE_FONT       = "#ffffff"
GAMEPLAY_COLOR  = "#2255bb"   # Blue — gameplay
GAMEPLAY_FONT   = "#ffffff"
INFRA_COLOR     = "#22aa22"   # Green — infrastructure
INFRA_FONT      = "#ffffff"
THIRD_COLOR     = "#aaaa22"   # Yellow — third-party
THIRD_FONT      = "#333333"
DOMAIN_COLOR    = "#6633aa"   # Purple — social/domain
DOMAIN_FONT     = "#ffffff"
BOTTLENECK_EDGE = "#ff8800"
CIRCULAR_EDGE   = "#ff0000"
BG_COLOR        = "#0f0f1e"


def make_high_level_graph() -> graphviz.Digraph:
    """Create the high-level module dependency graph."""

    g = graphviz.Digraph(
        name="AoW3_HighLevel",
        format="png",
        engine="dot",
    )
    g.attr(
        rankdir="TB",
        bgcolor=BG_COLOR,
        fontname=FONT,
        pad="0.5",
        nodesep="0.6",
        ranksep="1.0",
        fontcolor="#e0e0e0",
        label="Art of War 3: Global Conflict — High-Level Module Dependencies",
        labelloc="t",
        fontsize="22",
    )
    g.attr(
        "node",
        fontname=FONT,
        fontsize="11",
        style="filled",
        penwidth="2",
    )
    g.attr(
        "edge",
        fontname=FONT,
        fontsize="9",
        color="#888888",
    )

    # ── Cluster: Core ──
    with g.subgraph(name="cluster_core") as c:
        c.attr(label="CORE RUNTIME", fontcolor="#ff6666", color="#ff4444",
               style="bold,rounded", bgcolor="#2a1525", fontname=FONT)
        c.node("CORE", "Core Runtime\n(GameStateManager, Zenject)",
               shape="doubleoctagon", fillcolor=CORE_COLOR, fontcolor=CORE_FONT, penwidth="3", color="#ff4444")
        c.node("SCENE", "Scene Manager\n(Startup→Logon→Main→Battle)",
               shape="box", fillcolor=CORE_COLOR, fontcolor=CORE_FONT, penwidth="2", color="#ff4444")

    # ── Cluster: Gameplay ──
    with g.subgraph(name="cluster_gameplay") as c:
        c.attr(label="GAMEPLAY SYSTEMS", fontcolor="#6699ff", color="#4488ff",
               style="bold,rounded", bgcolor="#151530", fontname=FONT)
        c.node("BATTLE", "Battle System\n(BattleScreen, LogicService)",
               shape="hexagon", fillcolor=GAMEPLAY_COLOR, fontcolor=GAMEPLAY_FONT, penwidth="2.5", color="#4488ff")
        c.node("MAIN", "Main System\n(Hub, Navigation)",
               shape="hexagon", fillcolor=GAMEPLAY_COLOR, fontcolor=GAMEPLAY_FONT, penwidth="2.5", color="#4488ff")
        c.node("AI", "AI System\n(Strategic + Tactical)",
               shape="box", fillcolor=GAMEPLAY_COLOR, fontcolor=GAMEPLAY_FONT, penwidth="1.5", color="#4488ff")
        c.node("UNITS", "Unit System\n(Entity Spawning, Combat)",
               shape="doubleoctagon", fillcolor=GAMEPLAY_COLOR, fontcolor=GAMEPLAY_FONT, penwidth="2.5", color="#4488ff")
        c.node("BLDGS", "Building System\n(Construction, Production)",
               shape="box", fillcolor=GAMEPLAY_COLOR, fontcolor=GAMEPLAY_FONT, penwidth="1.5", color="#4488ff")
        c.node("ECON", "Economy System\n(Resources, Costs)",
               shape="box", fillcolor=GAMEPLAY_COLOR, fontcolor=GAMEPLAY_FONT, penwidth="1.5", color="#4488ff")
        c.node("PATH", "Pathfinding\n(A*, NavMesh)",
               shape="box", fillcolor=GAMEPLAY_COLOR, fontcolor=GAMEPLAY_FONT, penwidth="1.5", color="#4488ff")
        c.node("MAP", "Map System\n(Terrain, Fog of War)",
               shape="box", fillcolor=GAMEPLAY_COLOR, fontcolor=GAMEPLAY_FONT, penwidth="1.5", color="#4488ff")

    # ── Cluster: Infrastructure ──
    with g.subgraph(name="cluster_infra") as c:
        c.attr(label="INFRASTRUCTURE", fontcolor="#66dd66", color="#44bb44",
               style="bold,rounded", bgcolor="#152a15", fontname=FONT)
        c.node("NET", "Network Layer ⚠\n(RSA/DES, Protobuf)\nBOTTLENECK",
               shape="diamond", fillcolor=INFRA_COLOR, fontcolor=INFRA_FONT, penwidth="3", color="#ff8800")
        c.node("ASSET", "Asset System ⚠\n(Addressables, 773 entries)\nBOTTLENECK",
               shape="diamond", fillcolor=INFRA_COLOR, fontcolor=INFRA_FONT, penwidth="3", color="#ff8800")
        c.node("PERSIST", "Persistence Layer\n(SQLite, PCLRaw)",
               shape="box", fillcolor=INFRA_COLOR, fontcolor=INFRA_FONT, penwidth="1.5", color="#44bb44")
        c.node("GUI", "GUI System\n(DOTween, BattleGUI)",
               shape="box", fillcolor=INFRA_COLOR, fontcolor=INFRA_FONT, penwidth="1.5", color="#44bb44")
        c.node("AUDIO", "Audio System\n(SFX, Music, Voice)",
               shape="ellipse", fillcolor=INFRA_COLOR, fontcolor=INFRA_FONT, penwidth="1.5", color="#44bb44")

    # ── Cluster: Third-party ──
    with g.subgraph(name="cluster_external") as c:
        c.attr(label="THIRD-PARTY INTEGRATIONS", fontcolor="#cccc44", color="#aaaa00",
               style="bold,rounded", bgcolor="#2a2a15", fontname=FONT)
        c.node("ANALYTICS", "Analytics\n(Firebase + AppMetrica)",
               shape="ellipse", fillcolor=THIRD_COLOR, fontcolor=THIRD_FONT, penwidth="1.5", color="#aaaa00")
        c.node("ADS", "Ads\n(AppLovin MAX + IronSource)",
               shape="ellipse", fillcolor=THIRD_COLOR, fontcolor=THIRD_FONT, penwidth="1.5", color="#aaaa00")
        c.node("BILLING", "Billing\n(Google Play + HMS)",
               shape="ellipse", fillcolor=THIRD_COLOR, fontcolor=THIRD_FONT, penwidth="1.5", color="#aaaa00")
        c.node("PUSH", "Push Notifications\n(FCM + GGNotifications)",
               shape="ellipse", fillcolor=THIRD_COLOR, fontcolor=THIRD_FONT, penwidth="1.5", color="#aaaa00")

    # ── Cluster: Social/Domain ──
    with g.subgraph(name="cluster_social") as c:
        c.attr(label="SOCIAL / DOMAIN MODULES", fontcolor="#aa66dd", color="#8844cc",
               style="bold,rounded", bgcolor="#1a1530", fontname=FONT)
        c.node("SOCIAL", "Social Module\n(Clan, Chat, Friends)",
               shape="box", fillcolor=DOMAIN_COLOR, fontcolor=DOMAIN_FONT, penwidth="1.5", color="#8844cc")
        c.node("WORKSHOP", "Workshop\n(Unit Upgrades, Tech)",
               shape="box", fillcolor=DOMAIN_COLOR, fontcolor=DOMAIN_FONT, penwidth="1.5", color="#8844cc")
        c.node("SKILLS", "Skills System\n(Commander Abilities)",
               shape="box", fillcolor=DOMAIN_COLOR, fontcolor=DOMAIN_FONT, penwidth="1.5", color="#8844cc")
        c.node("TOURN", "Tournaments\n(Ranked, Events)",
               shape="ellipse", fillcolor=DOMAIN_COLOR, fontcolor=DOMAIN_FONT, penwidth="1.5", color="#8844cc")
        c.node("PROFILE", "Profile System\n(Player Data)",
               shape="box", fillcolor=DOMAIN_COLOR, fontcolor=DOMAIN_FONT, penwidth="1.5", color="#8844cc")
        c.node("STORE", "Store / IAP\n(Purchases, Offers)",
               shape="ellipse", fillcolor=DOMAIN_COLOR, fontcolor=DOMAIN_FONT, penwidth="1.5", color="#8844cc")

    # ═══════ Edges ═══════

    # Core
    g.edge("CORE", "SCENE", color="#ff6666", penwidth="2.5")
    g.edge("CORE", "NET", color="#ff6666", penwidth="2")
    g.edge("CORE", "ASSET", color="#ff6666", penwidth="2")
    g.edge("CORE", "PERSIST", color="#ff6666", penwidth="1.5")
    g.edge("CORE", "GUI", color="#ff6666", penwidth="1.5")

    # Scene flow
    g.edge("SCENE", "MAIN", color="#ff6666", penwidth="2.5", label="logon→", fontcolor="#ff9999")
    g.edge("SCENE", "BATTLE", color="#ff6666", penwidth="2.5", label="loading→", fontcolor="#ff9999")

    # Battle
    g.edge("BATTLE", "NET", color=BOTTLENECK_EDGE, penwidth="2.5")
    g.edge("BATTLE", "AI", color="#4488ff", penwidth="2")
    g.edge("BATTLE", "UNITS", color="#4488ff", penwidth="2")
    g.edge("BATTLE", "BLDGS", color="#4488ff", penwidth="2")
    g.edge("BATTLE", "ECON", color="#4488ff", penwidth="1.5")
    g.edge("BATTLE", "GUI", color="#44bb44", penwidth="2")
    g.edge("BATTLE", "AUDIO", color="#44bb44", penwidth="1")
    g.edge("BATTLE", "MAP", color="#4488ff", penwidth="1.5")
    g.edge("BATTLE", "ASSET", color=BOTTLENECK_EDGE, penwidth="2")

    # AI
    g.edge("AI", "MAP", color="#4488ff", penwidth="1.5")
    g.edge("AI", "UNITS", color="#4488ff", penwidth="1.5")
    g.edge("AI", "BLDGS", color="#4488ff", penwidth="1.5")
    g.edge("AI", "ECON", color="#4488ff", penwidth="1")
    g.edge("AI", "PATH", color="#4488ff", penwidth="1.5")

    # Map → Path
    g.edge("MAP", "PATH", color="#4488ff", penwidth="1.5")

    # Unit/Building/Economy
    g.edge("UNITS", "ECON", color="#4488ff", penwidth="1.5")
    g.edge("BLDGS", "ECON", color="#4488ff", penwidth="1.5")
    g.edge("BLDGS", "UNITS", color="#4488ff", penwidth="1.5")

    # Main
    g.edge("MAIN", "NET", color=BOTTLENECK_EDGE, penwidth="2")
    g.edge("MAIN", "STORE", color="#8844cc", penwidth="1.5")
    g.edge("MAIN", "SOCIAL", color="#8844cc", penwidth="1.5")
    g.edge("MAIN", "WORKSHOP", color="#8844cc", penwidth="1.5")
    g.edge("MAIN", "PROFILE", color="#8844cc", penwidth="1.5")
    g.edge("MAIN", "SKILLS", color="#8844cc", penwidth="1.5")
    g.edge("MAIN", "TOURN", color="#8844cc", penwidth="1")
    g.edge("MAIN", "GUI", color="#44bb44", penwidth="1.5")
    g.edge("MAIN", "ASSET", color=BOTTLENECK_EDGE, penwidth="2")
    g.edge("MAIN", "AUDIO", color="#44bb44", penwidth="1")

    # Store → Billing
    g.edge("STORE", "BILLING", color="#aaaa00", penwidth="1.5")

    # Social
    g.edge("SOCIAL", "NET", color=BOTTLENECK_EDGE, penwidth="1.5")
    g.edge("SOCIAL", "PERSIST", color="#44bb44", penwidth="1")

    # Domain
    g.edge("WORKSHOP", "UNITS", color="#4488ff", penwidth="1.5")
    g.edge("WORKSHOP", "ECON", color="#4488ff", penwidth="1")
    g.edge("WORKSHOP", "PERSIST", color="#44bb44", penwidth="1")
    g.edge("SKILLS", "UNITS", color="#4488ff", penwidth="1")
    g.edge("SKILLS", "PERSIST", color="#44bb44", penwidth="1")
    g.edge("TOURN", "NET", color=BOTTLENECK_EDGE, penwidth="1")
    g.edge("TOURN", "PROFILE", color="#8844cc", penwidth="1")
    g.edge("PROFILE", "PERSIST", color="#44bb44", penwidth="1.5")
    g.edge("PROFILE", "NET", color=BOTTLENECK_EDGE, penwidth="1")

    # Infrastructure → Core (provides)
    g.edge("ASSET", "CORE", color="#ff6666", penwidth="1", style="dotted", label="provides", fontcolor="#ff9999")
    g.edge("NET", "CORE", color="#ff6666", penwidth="1", style="dotted", label="provides", fontcolor="#ff9999")
    g.edge("PERSIST", "CORE", color="#ff6666", penwidth="1", style="dotted", label="provides", fontcolor="#ff9999")

    # Third-party → Core
    for t in ["ANALYTICS", "ADS", "BILLING", "PUSH"]:
        g.edge(t, "CORE", color="#aaaa00", penwidth="1", style="dotted")

    # ── Circular dependencies (red dashed) ──
    g.edge("GUI", "BATTLE", color=CIRCULAR_EDGE, penwidth="2", style="dashed",
           label="circular", fontcolor="#ff4444")
    g.edge("UNITS", "BLDGS", color=CIRCULAR_EDGE, penwidth="2", style="dashed",
           label="circular", fontcolor="#ff4444")

    return g


def make_low_level_graph() -> graphviz.Digraph:
    """Create the low-level class dependency graph."""

    g = graphviz.Digraph(
        name="AoW3_LowLevel",
        format="png",
        engine="dot",
    )
    g.attr(
        rankdir="TB",
        bgcolor=BG_COLOR,
        fontname=FONT,
        pad="0.5",
        nodesep="0.35",
        ranksep="0.8",
        fontcolor="#e0e0e0",
        label="Art of War 3: Global Conflict — Low-Level Class Dependencies",
        labelloc="t",
        fontsize="22",
        dpi="150",
    )
    g.attr(
        "node",
        fontname=FONT,
        fontsize="9",
        style="filled",
        penwidth="1.5",
    )
    g.attr(
        "edge",
        fontname=FONT,
        fontsize="7",
        color="#666666",
        arrowsize="0.6",
    )

    # Helper to add cluster
    def add_cluster(name, label, color, bgcolor, nodes_dict):
        with g.subgraph(name=name) as c:
            c.attr(label=label, fontcolor=color, color=color,
                   style="bold,rounded", bgcolor=bgcolor, fontname=FONT, fontsize="11")
            for nid, nlabel, nshape, nfill, nfont, npen, nstroke in nodes_dict:
                c.node(nid, nlabel, shape=nshape, fillcolor=nfill,
                       fontcolor=nfont, penwidth=npen, color=nstroke)

    # ── Core ──
    add_cluster("cluster_core", "com.geargames.aow.core", "#ff6666", "#2a1525", [
        ("GSM", "GameStateManager", "doubleoctagon", CORE_COLOR, CORE_FONT, "2.5", "#ff4444"),
        ("DI", "ZenjectContainer", "box", CORE_COLOR, CORE_FONT, "1.5", "#ff4444"),
        ("SCOR", "SceneOrchestrator", "box", CORE_COLOR, CORE_FONT, "1.5", "#ff4444"),
        ("GOBJ", "GameObjectFactory", "box", INFRA_COLOR, INFRA_FONT, "1", "#44bb44"),
        ("RESM", "ResourceManager", "box", BOTTLENECK_EDGE, "#ffffff", "1.5", "#ff8800"),
        ("POOL", "ObjectPoolManager", "box", INFRA_COLOR, INFRA_FONT, "1", "#44bb44"),
        ("EVBUS", "EventBus", "box", CORE_COLOR, CORE_FONT, "1.5", "#ff4444"),
        ("COROUT", "CoroutineRunner", "box", INFRA_COLOR, INFRA_FONT, "1", "#44bb44"),
    ])

    # ── Battle ──
    add_cluster("cluster_battle", "com.geargames.aow.scenes.battle", "#6699ff", "#151530", [
        ("BS", "BattleScreen", "hexagon", GAMEPLAY_COLOR, GAMEPLAY_FONT, "2", "#4488ff"),
        ("LS", "LogicService", "doubleoctagon", CORE_COLOR, CORE_FONT, "2.5", "#ff4444"),
        ("BGUI", "BattleGUI", "box", GAMEPLAY_COLOR, GAMEPLAY_FONT, "1.5", "#4488ff"),
        ("BCTRL", "BattleController", "box", GAMEPLAY_COLOR, GAMEPLAY_FONT, "1.5", "#4488ff"),
        ("BRULE", "BattleRuleEngine", "box", GAMEPLAY_COLOR, GAMEPLAY_FONT, "1", "#4488ff"),
        ("BSTAT", "BattleStateTracker", "box", GAMEPLAY_COLOR, GAMEPLAY_FONT, "1", "#4488ff"),
        ("BSYNC", "BattleSyncManager", "box", GAMEPLAY_COLOR, GAMEPLAY_FONT, "1.5", "#4488ff"),
        ("BREPLAY", "BattleReplaySystem", "box", GAMEPLAY_COLOR, GAMEPLAY_FONT, "1", "#4488ff"),
    ])

    # ── Battle GUI ──
    add_cluster("cluster_battlegui", "scenes.battle.gui", "#6699ff", "#151530", [
        ("GBLU", "GUIBattleListUpgrade", "box", "#3366cc", "#ffffff", "1", "#4488ff"),
        ("GBHU", "GUIBattleHud", "box", "#3366cc", "#ffffff", "1", "#4488ff"),
        ("GBMINI", "GUIMinimap", "box", "#3366cc", "#ffffff", "1", "#4488ff"),
        ("GBSEL", "GUISelectionPanel", "box", "#3366cc", "#ffffff", "1", "#4488ff"),
        ("GBPROD", "GUIProductionQueue", "box", "#3366cc", "#ffffff", "1", "#4488ff"),
        ("GBTOOL", "GUIQuickToolbar", "box", "#3366cc", "#ffffff", "1", "#4488ff"),
    ])

    # ── Battle Network ──
    add_cluster("cluster_battlenet", "scenes.battle.network", "#44aaff", "#101535", [
        ("CSLB", "CSLoginToBattle", "box", "#2266bb", "#ffffff", "1", "#44aaff"),
        ("SCBR", "SCBattleResult", "box", "#2266bb", "#ffffff", "1", "#44aaff"),
        ("CSORD", "CSOrderUnit", "box", "#2266bb", "#ffffff", "1", "#44aaff"),
        ("CSBUILD", "CSBuildStructure", "box", "#2266bb", "#ffffff", "1", "#44aaff"),
        ("NPROV", "NetworkProvider", "doubleoctagon", CORE_COLOR, CORE_FONT, "2.5", "#ff4444"),
        ("NCRYPT", "NetworkEncryption", "box", "#2266bb", "#ffffff", "1", "#44aaff"),
        ("NSERI", "ProtobufSerializer", "box", "#2266bb", "#ffffff", "1", "#44aaff"),
        ("NCONN", "ConnectionManager", "box", "#2266bb", "#ffffff", "1", "#44aaff"),
        ("NPERS", "PersistentConnection", "box", "#2266bb", "#ffffff", "1", "#44aaff"),
        ("NEPH", "EphemeralConnection", "box", "#2266bb", "#ffffff", "1", "#44aaff"),
    ])

    # ── Entities ──
    add_cluster("cluster_entities", "com.geargames.aow.entities", "#66dd66", "#152a15", [
        ("UENT", "UnitEntity", "box", INFRA_COLOR, INFRA_FONT, "1.5", "#44bb44"),
        ("BENT", "BuildingEntity", "box", INFRA_COLOR, INFRA_FONT, "1.5", "#44bb44"),
        ("EBASE", "EntityBase", "box", INFRA_COLOR, INFRA_FONT, "1.5", "#44bb44"),
        ("ECOMP", "EntityComponent", "box", INFRA_COLOR, INFRA_FONT, "1", "#44bb44"),
        ("HCOMP", "HealthComponent", "box", INFRA_COLOR, INFRA_FONT, "1", "#44bb44"),
        ("WCOMP", "WeaponComponent", "box", INFRA_COLOR, INFRA_FONT, "1", "#44bb44"),
        ("MCOMP", "MovementComponent", "box", INFRA_COLOR, INFRA_FONT, "1", "#44bb44"),
        ("VCOMP", "VisibilityComponent", "box", INFRA_COLOR, INFRA_FONT, "1", "#44bb44"),
        ("EREG", "EntityRegistry", "doubleoctagon", CORE_COLOR, CORE_FONT, "2", "#ff4444"),
    ])

    # ── Map ──
    add_cluster("cluster_map", "scenes.battle.map", "#66dd66", "#152a15", [
        ("TMAP", "TileMap", "box", INFRA_COLOR, INFRA_FONT, "1.5", "#44bb44"),
        ("TCELL", "TileCell", "box", INFRA_COLOR, INFRA_FONT, "1", "#44bb44"),
        ("FOW", "FogOfWar", "box", INFRA_COLOR, INFRA_FONT, "1", "#44bb44"),
        ("PATHF", "AStarPathfinder", "box", INFRA_COLOR, INFRA_FONT, "1.5", "#44bb44"),
        ("NAVM", "NavMeshAdapter", "box", INFRA_COLOR, INFRA_FONT, "1", "#44bb44"),
    ])

    # ── AI ──
    add_cluster("cluster_ai", "scenes.battle.map.ai", "#66dd66", "#152a15", [
        ("AIBRAIN", "AIBrainController", "box", INFRA_COLOR, INFRA_FONT, "1.5", "#44bb44"),
        ("AISUP", "AIStrategicPlanner", "box", INFRA_COLOR, INFRA_FONT, "1.5", "#44bb44"),
        ("AITAC", "AITacticalExecutor", "box", INFRA_COLOR, INFRA_FONT, "1", "#44bb44"),
        ("AIECO", "AIEconomyManager", "box", INFRA_COLOR, INFRA_FONT, "1", "#44bb44"),
        ("AIUNIT", "AIUnitController", "box", INFRA_COLOR, INFRA_FONT, "1", "#44bb44"),
    ])

    # ── Economy ──
    add_cluster("cluster_econ", "com.geargames.aow.economy", "#66dd66", "#152a15", [
        ("RSH", "ResourceServiceHelper", "box", BOTTLENECK_EDGE, "#ffffff", "1.5", "#ff8800"),
        ("RPOOL", "ResourcePool", "box", INFRA_COLOR, INFRA_FONT, "1", "#44bb44"),
        ("COST", "CostCalculator", "box", INFRA_COLOR, INFRA_FONT, "1", "#44bb44"),
        ("PRODC", "ProductionChain", "box", INFRA_COLOR, INFRA_FONT, "1", "#44bb44"),
    ])

    # ── Main ──
    add_cluster("cluster_main", "com.geargames.aow.scenes.main", "#aa66dd", "#1a1530", [
        ("MHUB", "MainHubScreen", "hexagon", DOMAIN_COLOR, DOMAIN_FONT, "1.5", "#8844cc"),
        ("MNAV", "MainNavigation", "box", DOMAIN_COLOR, DOMAIN_FONT, "1.5", "#8844cc"),
        ("MBATT", "MainBattleList", "box", DOMAIN_COLOR, DOMAIN_FONT, "1", "#8844cc"),
        ("MSTORE", "MainStoreScreen", "box", DOMAIN_COLOR, DOMAIN_FONT, "1", "#8844cc"),
    ])

    # ── Workshop ──
    add_cluster("cluster_workshop", "Domains.Workshop", "#aa66dd", "#1a1530", [
        ("WSCR", "WorkshopScreen", "box", DOMAIN_COLOR, DOMAIN_FONT, "1", "#8844cc"),
        ("WUPG", "WorkshopUpgradeService", "box", DOMAIN_COLOR, DOMAIN_FONT, "1", "#8844cc"),
        ("WTECH", "TechTreeController", "box", DOMAIN_COLOR, DOMAIN_FONT, "1", "#8844cc"),
    ])

    # ── Clan ──
    add_cluster("cluster_clan", "Domains.Clan", "#aa66dd", "#1a1530", [
        ("CSCR", "ClanScreen", "box", DOMAIN_COLOR, DOMAIN_FONT, "1", "#8844cc"),
        ("CSVC", "ClanService", "box", DOMAIN_COLOR, DOMAIN_FONT, "1", "#8844cc"),
        ("CCHAT", "ClanChatController", "box", DOMAIN_COLOR, DOMAIN_FONT, "1", "#8844cc"),
    ])

    # ── Chat ──
    add_cluster("cluster_chat", "Domains.Chat", "#aa66dd", "#1a1530", [
        ("CHSCR", "ChatScreen", "box", DOMAIN_COLOR, DOMAIN_FONT, "1", "#8844cc"),
        ("CHSVC", "ChatService", "box", DOMAIN_COLOR, DOMAIN_FONT, "1", "#8844cc"),
        ("CHMSG", "MessageProcessor", "box", DOMAIN_COLOR, DOMAIN_FONT, "1", "#8844cc"),
    ])

    # ── Skills ──
    add_cluster("cluster_skills", "Domains.Skills", "#aa66dd", "#1a1530", [
        ("SKSCR", "SkillsScreen", "box", DOMAIN_COLOR, DOMAIN_FONT, "1", "#8844cc"),
        ("SKSVC", "SkillService", "box", DOMAIN_COLOR, DOMAIN_FONT, "1", "#8844cc"),
        ("SKTREE", "SkillTreeController", "box", DOMAIN_COLOR, DOMAIN_FONT, "1", "#8844cc"),
    ])

    # ── Profile ──
    add_cluster("cluster_profile", "Domains.Profile", "#aa66dd", "#1a1530", [
        ("PSCR", "ProfileScreen", "box", DOMAIN_COLOR, DOMAIN_FONT, "1", "#8844cc"),
        ("PSVC", "ProfileService", "box", DOMAIN_COLOR, DOMAIN_FONT, "1", "#8844cc"),
        ("PPROG", "ProgressionTracker", "box", DOMAIN_COLOR, DOMAIN_FONT, "1", "#8844cc"),
    ])

    # ── Persistence ──
    add_cluster("cluster_persist", "com.geargames.aow.persistence", "#66dd66", "#152a15", [
        ("DBM", "DatabaseManager", "box", BOTTLENECK_EDGE, "#ffffff", "1.5", "#ff8800"),
        ("SQH", "SQLiteHelper", "box", INFRA_COLOR, INFRA_FONT, "1", "#44bb44"),
        ("DREP", "DataRepository", "box", INFRA_COLOR, INFRA_FONT, "1.5", "#44bb44"),
        ("CSER", "CacheSerializer", "box", INFRA_COLOR, INFRA_FONT, "1", "#44bb44"),
    ])

    # ── Assets ──
    add_cluster("cluster_assets", "com.geargames.aow.assets", "#cccc44", "#2a2a15", [
        ("ALDR", "AddressableLoader", "diamond", BOTTLENECK_EDGE, "#ffffff", "2", "#ff8800"),
        ("ACAT", "AssetCatalog", "box", THIRD_COLOR, THIRD_FONT, "1", "#aaaa00"),
        ("ABUN", "BundleManager", "box", THIRD_COLOR, THIRD_FONT, "1", "#aaaa00"),
        ("ACCH", "AssetCache", "box", THIRD_COLOR, THIRD_FONT, "1", "#aaaa00"),
    ])

    # ── Analytics ──
    add_cluster("cluster_analytics", "com.geargames.aow.analytics", "#cccc44", "#2a2a15", [
        ("ANMGR", "AnalyticsManager", "box", THIRD_COLOR, THIRD_FONT, "1", "#aaaa00"),
        ("FIREV", "FirebaseEventHandler", "box", THIRD_COLOR, THIRD_FONT, "1", "#aaaa00"),
        ("APME", "AppMetricaEventHandler", "box", THIRD_COLOR, THIRD_FONT, "1", "#aaaa00"),
    ])

    # ── Audio ──
    add_cluster("cluster_audio", "com.geargames.aow.audio", "#66dd66", "#152a15", [
        ("AUDM", "AudioManager", "box", INFRA_COLOR, INFRA_FONT, "1.5", "#44bb44"),
        ("AUDS", "AudioSourcePool", "box", INFRA_COLOR, INFRA_FONT, "1", "#44bb44"),
        ("AUDF", "SoundFXPlayer", "box", INFRA_COLOR, INFRA_FONT, "1", "#44bb44"),
    ])

    # ═══════ Edges ═══════
    edge_kw = dict(penwidth="1", arrowsize="0.6")
    crit_kw = dict(penwidth="1.5", color="#ff6666", arrowsize="0.7")
    circ_kw = dict(penwidth="1.5", color=CIRCULAR_EDGE, style="dashed", arrowsize="0.7")

    # Core internal
    g.edge("GSM", "DI", **edge_kw)
    g.edge("GSM", "EVBUS", **edge_kw)
    g.edge("SCOR", "GSM", **crit_kw)
    g.edge("GOBJ", "POOL", **edge_kw)
    g.edge("GOBJ", "RESM", **edge_kw)

    # Scene → Screens
    g.edge("SCOR", "BS", **crit_kw)
    g.edge("SCOR", "MHUB", **crit_kw)

    # Battle cluster
    g.edge("BS", "LS", **crit_kw)
    g.edge("BS", "BGUI", **edge_kw)
    g.edge("BS", "BCTRL", **edge_kw)
    g.edge("BS", "BSYNC", **edge_kw)
    g.edge("BS", "BREPLAY", **edge_kw)
    g.edge("BCTRL", "BRULE", **edge_kw)
    g.edge("BCTRL", "BSTAT", **edge_kw)

    # LogicService deps
    g.edge("LS", "EREG", **crit_kw)
    g.edge("LS", "TMAP", **edge_kw)
    g.edge("LS", "AIBRAIN", **edge_kw)
    g.edge("LS", "RSH", **edge_kw)
    g.edge("LS", "BSYNC", **edge_kw)

    # Battle GUI
    g.edge("BGUI", "GBLU", **edge_kw)
    g.edge("BGUI", "GBHU", **edge_kw)
    g.edge("BGUI", "GBMINI", **edge_kw)
    g.edge("BGUI", "GBSEL", **edge_kw)
    g.edge("BGUI", "GBPROD", **edge_kw)
    g.edge("BGUI", "GBTOOL", **edge_kw)
    g.edge("GBLU", "LS", color="#4488ff", **edge_kw)
    g.edge("GBHU", "BSTAT", color="#4488ff", **edge_kw)
    g.edge("GBSEL", "EREG", color="#4488ff", **edge_kw)
    g.edge("GBPROD", "BENT", color="#4488ff", **edge_kw)
    g.edge("GBTOOL", "LS", color="#4488ff", **edge_kw)

    # Network
    g.edge("CSLB", "NPROV", color="#44aaff", **edge_kw)
    g.edge("SCBR", "NPROV", color="#44aaff", **edge_kw)
    g.edge("CSORD", "NPROV", color="#44aaff", **edge_kw)
    g.edge("CSBUILD", "NPROV", color="#44aaff", **edge_kw)
    g.edge("NPROV", "NCRYPT", color="#44aaff", **edge_kw)
    g.edge("NPROV", "NSERI", color="#44aaff", **edge_kw)
    g.edge("NPROV", "NCONN", color="#44aaff", **edge_kw)
    g.edge("NCONN", "NPERS", color="#44aaff", **edge_kw)
    g.edge("NCONN", "NEPH", color="#44aaff", **edge_kw)
    g.edge("BSYNC", "CSLB", color="#44aaff", **edge_kw)
    g.edge("BSYNC", "SCBR", color="#44aaff", **edge_kw)
    g.edge("BCTRL", "CSORD", color="#44aaff", **edge_kw)
    g.edge("BCTRL", "CSBUILD", color="#44aaff", **edge_kw)

    # Entities
    g.edge("UENT", "EBASE", **edge_kw)
    g.edge("BENT", "EBASE", **edge_kw)
    g.edge("EBASE", "ECOMP", **edge_kw)
    g.edge("HCOMP", "ECOMP", **edge_kw)
    g.edge("WCOMP", "ECOMP", **edge_kw)
    g.edge("MCOMP", "ECOMP", **edge_kw)
    g.edge("VCOMP", "ECOMP", **edge_kw)
    g.edge("EREG", "UENT", **crit_kw)
    g.edge("EREG", "BENT", **crit_kw)

    # Map
    g.edge("TMAP", "TCELL", **edge_kw)
    g.edge("FOW", "TMAP", **edge_kw)
    g.edge("PATHF", "TMAP", **edge_kw)
    g.edge("NAVM", "TMAP", **edge_kw)

    # AI
    g.edge("AIBRAIN", "AISUP", **edge_kw)
    g.edge("AIBRAIN", "AITAC", **edge_kw)
    g.edge("AIBRAIN", "AIECO", **edge_kw)
    g.edge("AISUP", "AITAC", **edge_kw)
    g.edge("AISUP", "PATHF", **edge_kw)
    g.edge("AITAC", "AIUNIT", **edge_kw)
    g.edge("AIUNIT", "UENT", color="#44bb44", **edge_kw)
    g.edge("AIECO", "RSH", color="#44bb44", **edge_kw)
    g.edge("AIECO", "BENT", color="#44bb44", **edge_kw)

    # Economy
    g.edge("RSH", "RPOOL", **edge_kw)
    g.edge("RSH", "COST", **edge_kw)
    g.edge("COST", "PRODC", **edge_kw)

    # Circular: Unit ↔ Building
    g.edge("UENT", "BENT", **circ_kw, label="circ")
    g.edge("BENT", "UENT", **circ_kw, label="circ")

    # Main
    g.edge("MHUB", "MNAV", **edge_kw)
    g.edge("MNAV", "MBATT", **edge_kw)
    g.edge("MNAV", "MSTORE", **edge_kw)
    g.edge("MNAV", "WSCR", color="#8844cc", **edge_kw)
    g.edge("MNAV", "CSCR", color="#8844cc", **edge_kw)
    g.edge("MNAV", "CHSCR", color="#8844cc", **edge_kw)
    g.edge("MNAV", "SKSCR", color="#8844cc", **edge_kw)
    g.edge("MNAV", "PSCR", color="#8844cc", **edge_kw)

    # Workshop
    g.edge("WSCR", "WUPG", color="#8844cc", **edge_kw)
    g.edge("WUPG", "WTECH", color="#8844cc", **edge_kw)
    g.edge("WUPG", "RSH", color="#8844cc", **edge_kw)
    g.edge("WTECH", "UENT", color="#8844cc", **edge_kw)

    # Clan
    g.edge("CSCR", "CSVC", color="#8844cc", **edge_kw)
    g.edge("CSVC", "CCHAT", color="#8844cc", **edge_kw)
    g.edge("CSVC", "NPROV", color=BOTTLENECK_EDGE, **edge_kw)
    g.edge("CCHAT", "CHSVC", color="#8844cc", **edge_kw)

    # Chat
    g.edge("CHSCR", "CHSVC", color="#8844cc", **edge_kw)
    g.edge("CHSVC", "CHMSG", color="#8844cc", **edge_kw)
    g.edge("CHSVC", "NPROV", color=BOTTLENECK_EDGE, **edge_kw)

    # Skills
    g.edge("SKSCR", "SKSVC", color="#8844cc", **edge_kw)
    g.edge("SKSVC", "SKTREE", color="#8844cc", **edge_kw)
    g.edge("SKTREE", "UENT", color="#8844cc", **edge_kw)

    # Profile
    g.edge("PSCR", "PSVC", color="#8844cc", **edge_kw)
    g.edge("PSVC", "PPROG", color="#8844cc", **edge_kw)
    g.edge("PSVC", "NPROV", color=BOTTLENECK_EDGE, **edge_kw)
    g.edge("PPROG", "DREP", color="#44bb44", **edge_kw)

    # Persistence
    g.edge("DBM", "SQH", **edge_kw)
    g.edge("DREP", "DBM", **edge_kw)
    g.edge("DREP", "CSER", **edge_kw)

    # Assets
    g.edge("ALDR", "ACAT", color="#aaaa00", **edge_kw)
    g.edge("ALDR", "ABUN", color="#aaaa00", **edge_kw)
    g.edge("ALDR", "ACCH", color="#aaaa00", **edge_kw)
    g.edge("BS", "ALDR", color=BOTTLENECK_EDGE, **edge_kw)
    g.edge("MHUB", "ALDR", color=BOTTLENECK_EDGE, **edge_kw)
    g.edge("GOBJ", "ALDR", color=BOTTLENECK_EDGE, **edge_kw)

    # Analytics
    g.edge("ANMGR", "FIREV", color="#aaaa00", **edge_kw)
    g.edge("ANMGR", "APME", color="#aaaa00", **edge_kw)
    g.edge("GSM", "ANMGR", color="#aaaa00", **edge_kw)

    # Audio
    g.edge("BS", "AUDM", color="#44bb44", **edge_kw)
    g.edge("MHUB", "AUDM", color="#44bb44", **edge_kw)
    g.edge("AUDM", "AUDS", **edge_kw)
    g.edge("AUDM", "AUDF", **edge_kw)

    # Store → Profile
    g.edge("MSTORE", "PSVC", color="#8844cc", **edge_kw)

    # Core runtime used everywhere
    g.edge("BS", "GSM", **crit_kw)
    g.edge("MHUB", "GSM", **crit_kw)
    g.edge("NPROV", "GSM", **crit_kw)
    g.edge("ALDR", "RESM", **edge_kw)

    return g


def main():
    print("Generating high-level dependency graph...")
    hl = make_high_level_graph()
    hl.render(os.path.join(OUTPUT_DIR, "high_level_dependency"), cleanup=True)
    print(f"  → {OUTPUT_DIR}/high_level_dependency.png")

    print("Generating low-level dependency graph...")
    ll = make_low_level_graph()
    ll.render(os.path.join(OUTPUT_DIR, "low_level_dependency"), cleanup=True)
    print(f"  → {OUTPUT_DIR}/low_level_dependency.png")

    print("Done!")


if __name__ == "__main__":
    main()
