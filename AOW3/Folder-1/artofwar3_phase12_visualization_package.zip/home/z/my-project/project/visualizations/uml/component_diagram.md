# Art of War 3: Global Conflict — Component Diagram

> Major game components and their interfaces, derived from IL2CPP reverse engineering.  
> Components represent cohesive subsystems with well-defined boundaries.

## Diagram

```mermaid
flowchart TB
    %% ============================================================
    %% CLIENT COMPONENTS
    %% ============================================================

    subgraph ClientApp["Art of War 3 — Client Application"]
        direction TB

        subgraph Presentation["Presentation Layer"]
            SceneMgmt["🔄 Scene Manager<br/><i>Unity Scene Lifecycle</i>"]
            GUIFramework["🖥️ GUI Framework<br/><i>MVP Presenters + Panel Holders</i>"]
            UIDisp["📡 UI Dispatcher<br/><i>Type-safe Event Bus</i>"]
            TweenEngine["🎬 Tween Engine<br/><i>DOTween Animations</i>"]
        end

        subgraph GameLogic["Game Logic Layer"]
            BattleEngine["⚔️ Battle Engine<br/><i>Simulation, Tick Loop, Combat</i>"]
            EntitySystem["📦 Entity System<br/><i>Unit, Building, Weapon, Resource</i>"]
            AbilitySystem["✨ Ability System<br/><i>Hero & Superweapon Abilities</i>"]
            DamageSystem["💥 Damage System<br/><i>Armor/Damage Calculation</i>"]
            AIEngine["🧠 AI Engine<br/><i>Strategic + Tactical AI</i>"]
            Pathfinding["🗺️ Pathfinding<br/><i>NavGrid, A* Pathfinding</i>"]
            FOW["🌫️ Fog of War<br/><i>Visibility & Reveal System</i>"]
            EconSystem["💰 Economy System<br/><i>Resource Management, Costs</i>"]
        end

        subgraph MetaGame["Meta-Game Layer"]
            WorkshopComp["🔧 Workshop Component<br/><i>Unit Upgrades & Modifications</i>"]
            ClanComp["🏰 Clan Component<br/><i>Clan Management & Wars</i>"]
            ChatComp["💬 Chat Component<br/><i>Channels & Messaging</i>"]
            SkillsComp["📊 Skills Component<br/><i>Skill Trees & Progression</i>"]
            Matchmaking["🎯 Matchmaking<br/><i>Queue, Rating, Matching</i>"]
        end

        subgraph DataLayer["Data & Infrastructure Layer"]
            ConfigProvider["📋 Config Provider<br/><i>Addressables-based Game Config</i>"]
            LocalDB["💾 Local Database<br/><i>SQLite Persistence</i>"]
            AssetLoader["📦 Asset Loader<br/><i>Addressables, Prefabs, Scenes</i>"]
            Analytics["📊 Analytics<br/><i>Firebase Events & Crashlytics</i>"]
            DiContainer["💉 DI Container<br/><i>Zenject Bindings</i>"]
        end
    end

    %% ============================================================
    %% NETWORK COMPONENT
    %% ============================================================

    subgraph NetworkLayer["Network Layer"]
        NetTransport["🌐 Network Transport<br/><i>TCP/UDP, Connection Management</i>"]
        Protocol["📜 Protocol Layer<br/><i>CS/SC Message Serialization</i>"]
        SyncEngine["🔄 Sync Engine<br/><i>Client-Server State Sync</i>"]
        LatencyComp["⚡ Latency Compensator<br/><i>Ping/Pong, Prediction</i>"]
    end

    %% ============================================================
    %% SERVER COMPONENTS
    %% ============================================================

    subgraph ServerCluster["Server Cluster"]
        direction TB

        subgraph MainServer["Main Server"]
            AuthService["🔐 Auth Service<br/><i>Login, Tokens, Sessions</i>"]
            PlayerService["👤 Player Service<br/><i>Profiles, Progression, Inventory</i>"]
            MatchService["🎯 Match Service<br/><i>Queue, Rating, Match Creation</i>"]
            ClanService["🏰 Clan Service<br/><i>Clan CRUD, Wars, Roster</i>"]
            ChatService["💬 Chat Service<br/><i>Channels, History, Moderation</i>"]
            EconomyService["💰 Economy Service<br/><i>Resources, Transactions, Shop</i>"]
        end

        subgraph BattleServer["Battle Server"]
            BattleAuth["🔑 Battle Auth<br/><i>Session Validation, Token Exchange</i>"]
            BattleSim["⚔️ Battle Simulator<br/><i>Authoritative Simulation</i>"]
            BattleSync["📡 Battle Sync<br/><i>State Broadcast, Commands</i>"]
            BattleRecorder["📼 Battle Recorder<br/><i>Replay Data, Statistics</i>"]
        end

        subgraph DataStores["Data Stores"]
            PlayerDB["🗄️ Player DB<br/><i>PostgreSQL / MySQL</i>"]
            BattleDB["🗄️ Battle DB<br/><i>Battle Results, Replays</i>"]
            CacheStore["⚡ Cache<br/><i>Redis - Sessions, Matchmaking</i>"]
            ConfigStore["📋 Config Store<br/><i>Game Balance Data</i>"]
        end
    end

    %% ============================================================
    %% INTERFACES (ports)
    %% ============================================================

    SceneMgmt -.->|ISceneController| GUIFramework
    GUIFramework -.->|IUIDispatcher| UIDisp
    GUIFramework -.->|IAnimatable| TweenEngine

    BattleEngine -.->|IEntityManager| EntitySystem
    BattleEngine -.->|IAbilityManager| AbilitySystem
    BattleEngine -.->|IDamageResolver| DamageSystem
    BattleEngine -.->|IPathfinder| Pathfinding
    BattleEngine -.->|IFOWSystem| FOW
    BattleEngine -.->|IAIController| AIEngine

    EntitySystem -.->|IDamageApplier| DamageSystem
    AbilitySystem -.->|IDamageSource| DamageSystem
    EconSystem -.->|IEntityFactory| EntitySystem

    WorkshopComp -.->|IUnitModifier| EntitySystem
    SkillsComp -.->|IHeroEnhancer| EntitySystem

    Matchmaking -.->|INetworkClient| NetTransport
    ChatComp -.->|INetworkClient| NetTransport
    ClanComp -.->|INetworkClient| NetTransport

    %% Client → Network
    NetTransport -.->|IProtocol| Protocol
    Protocol -.->|ISyncProvider| SyncEngine
    SyncEngine -.->|ILatencyMonitor| LatencyComp

    BattleEngine -.->|IBattleNetwork| SyncEngine
    BattleEngine -.->|ICommandSender| Protocol

    ConfigProvider -.->|IAssetProvider| AssetLoader
    DiContainer -.->|injects into| GameLogic
    DiContainer -.->|injects into| MetaGame
    DiContainer -.->|injects into| DataLayer

    %% Network → Server
    NetTransport ===>|"TCP/UDP<br/>Encrypted"| AuthService
    NetTransport ===>|"TCP/UDP<br/>Encrypted"| BattleAuth

    AuthService --> PlayerService
    AuthService --> MatchService
    AuthService --> ClanService
    AuthService --> ChatService
    AuthService --> EconomyService

    BattleAuth --> BattleSim
    BattleSim --> BattleSync
    BattleSim --> BattleRecorder

    %% Server → Data
    PlayerService --> PlayerDB
    EconomyService --> PlayerDB
    MatchService --> CacheStore
    ChatService --> CacheStore
    ClanService --> PlayerDB
    BattleSync --> BattleDB
    BattleRecorder --> BattleDB
    PlayerService --> ConfigStore
    BattleSim --> ConfigStore

    %% Style
    classDef presentation fill:#3498db,stroke:#2471a3,color:#fff
    classDef gamelogic fill:#e74c3c,stroke:#c0392b,color:#fff
    classDef metagame fill:#9b59b6,stroke:#7d3c98,color:#fff
    classDef data fill:#f39c12,stroke:#d68910,color:#fff
    classDef network fill:#1abc9c,stroke:#148f77,color:#fff
    classDef server fill:#2ecc71,stroke:#27ae60,color:#fff
    classDef datastore fill:#95a5a6,stroke:#7f8c8d,color:#fff

    class SceneMgmt,GUIFramework,UIDisp,TweenEngine presentation
    class BattleEngine,EntitySystem,AbilitySystem,DamageSystem,AIEngine,Pathfinding,FOW,EconSystem gamelogic
    class WorkshopComp,ClanComp,ChatComp,SkillsComp,Matchmaking metagame
    class ConfigProvider,LocalDB,AssetLoader,Analytics,DiContainer data
    class NetTransport,Protocol,SyncEngine,LatencyComp network
    class AuthService,PlayerService,MatchService,ClanService,ChatService,EconomyService,BattleAuth,BattleSim,BattleSync,BattleRecorder server
    class PlayerDB,BattleDB,CacheStore,ConfigStore datastore
```

## Explanation

This component diagram shows the **major subsystems** of Art of War 3 and their interface relationships.

### Client Application Architecture

The client follows a **4-layer architecture**:

| Layer | Components | Pattern |
|-------|-----------|---------|
| **Presentation** | Scene Manager, GUI Framework, UI Dispatcher, Tween Engine | MVP (Model-View-Presenter) with Zenject injection |
| **Game Logic** | Battle Engine, Entity System, Ability/Damage/AI/Pathfinding/FOW | ECS-inspired (Entity composition, not full ECS) |
| **Meta-Game** | Workshop, Clan, Chat, Skills, Matchmaking | Domain-Driven Design bounded contexts |
| **Data/Infra** | Config Provider, Local DB, Asset Loader, Analytics, DI Container | Infrastructure/Repository pattern |

### Key Interface Contracts

- **`IEntityManager`** — Battle Engine's interface to create/destroy/query entities
- **`IDamageResolver`** — Unified damage calculation pipeline (weapon → armor → final damage)
- **`IBattleNetwork`** — Battle Engine's interface to the sync engine for command sending/state receiving
- **`ICommandSender`** — Protocol-level interface for sending CS messages
- **`INetworkClient`** — Used by meta-game components (Clan, Chat, Matchmaking) for server communication
- **`IUnitModifier`** / **`IHeroEnhancer`** — Workshop and Skills components modify entities through these interfaces

### Server Architecture

The server side uses a **microservice-oriented** pattern:

- **Main Server**: Handles authentication, player management, matchmaking, clans, chat, and economy. These are likely separate services communicating internally.
- **Battle Server**: A dedicated simulation host with authoritative battle logic. Multiple battle server instances run concurrently for different matches.
- **Data Stores**: PostgreSQL for relational data (players, clans), Redis for ephemeral data (matchmaking queues, sessions), and a config store for game balance.

### Network Layer

The network layer sits between client and server, providing:
- **Transport**: TCP for reliable commands, UDP for real-time sync
- **Protocol**: Binary CS/SC message serialization (matching the `CSMessage`/`SCMessage` class hierarchy)
- **Sync Engine**: Client-side prediction and server reconciliation
- **Latency Compensator**: `PingPongAsync`-based latency monitoring with `CheckConnectionToBattleHosts` for host selection

### Zenject DI

The DI Container (`DiContainer`) injects dependencies across all layers — this is the architectural backbone that enables the loose coupling between components. Each scene has its own Zenject installer that binds scene-specific dependencies.
