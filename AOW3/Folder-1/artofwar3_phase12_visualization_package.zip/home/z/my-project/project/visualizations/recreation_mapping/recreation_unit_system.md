# Recreation Mapping: Unit System

## Purpose

The Unit System is the foundational gameplay system responsible for the entire lifecycle of military units in Art of War 3: Global Conflict. It manages unit creation (spawning from factories/barracks), selection (single and multi-select with box selection), movement (pathfinding-integrated movement with formation logic), and command dispatch (attack, move, patrol, hold, special abilities). The system handles 15 standard units and 6 hero units per faction (Confederation and Resistance), each with unique stats, weapon loadouts, and behavior profiles. Units are the primary interactive agents on the battlefield and represent the core player agency in the RTS loop.

## Inputs

- **Player Input**: Selection clicks, drag-box selection, right-click commands, hotkey bindings
- **Building System**: Production queue completions that trigger unit spawning
- **Combat System**: Damage events that modify unit health, death events that remove units
- **Economy System**: Resource validation before unit production begins
- **Upgrade/Tech System**: Stat modifiers that alter unit attributes (damage, armor, speed, range)
- **Hero System**: Ability activation that temporarily modifies unit behavior or stats
- **Fog of War System**: Visibility state that determines render mode (visible/grayed/hidden)
- **Network System**: Remote player commands, tick-synchronized state updates

## Outputs

- **Unit Entities**: Fully initialized unit objects placed on the game map
- **Selection State**: Currently selected unit set, broadcast to GUI for info panel display
- **Movement Paths**: Waypoint queues passed to the pathfinding subsystem
- **Command Queue**: Ordered list of pending commands per unit
- **Death Events**: Notifications to Combat, Economy (for resource refund), and GUI systems
- **Visibility Data**: Position data fed to Fog of War for line-of-sight calculations

## Dependencies

- **Pathfinding/AI System**: For A* or JPS path computation and obstacle avoidance
- **Combat System**: For damage application, target acquisition, weapon firing logic
- **Building System**: For spawn point determination and rally point assignment
- **Economy System**: For cost deduction on production and refund on cancellation
- **Network System**: For command synchronization across clients
- **Fog of War System**: For unit visibility determination
- **Animation System**: For movement, attack, idle, and death animation triggers

## Internal Logic

The Unit System operates as an entity-component architecture. Each unit is a composite of components: `UnitIdentity` (faction, type, tier), `UnitStats` (HP, speed, armor, weapon stats), `UnitState` (idle, moving, attacking, dying), `UnitCommands` (command queue with priority), and `UnitVision` (sight range, detected enemies). The selection subsystem maintains a `SelectionManager` that tracks the currently selected unit set, supports multi-select with a maximum cap, and handles control-group bindings (Ctrl+1-9).

Unit spawning follows a factory pattern: the `UnitFactory` receives a `UnitSpawnRequest` from the Building System, validates economy resources, deducts costs, instantiates the unit prefab via Addressables, initializes all components from the unit's `UnitDefinition` ScriptableObject, and places the entity at the building's rally point. Movement uses a steering behavior model where units have individual navmesh agents but group movement applies formation offsets to maintain cohesion.

The command system uses a queue-based approach: new commands are either queued (shift-click) or replace the current queue (regular click). Each command type (`MoveCommand`, `AttackCommand`, `PatrolCommand`, `HoldCommand`) implements a common `IUnitCommand` interface with `Execute()`, `IsComplete()`, and `Cancel()` methods. Attack commands include target acquisition logic that automatically switches to the nearest valid target if the original target dies.

## Pseudocode

```
class UnitSystem:
    units: Map<UnitID, Unit>
    selectionManager: SelectionManager
    unitFactory: UnitFactory
    commandProcessor: CommandProcessor

    function onSpawnRequest(building, unitType):
        definition = UnitDefinitions.get(unitType)
        if not economySystem.canAfford(definition.cost):
            return SPAWN_FAIL_INSUFFICIENT_RESOURCES
        economySystem.deduct(definition.cost)
        unit = unitFactory.create(definition, building.faction, building.rallyPoint)
        units.put(unit.id, unit)
        eventBus.emit(UnitSpawnedEvent(unit))
        return SPAWN_SUCCESS

    function onPlayerSelect(screenRect):
        selectionManager.clear()
        for unit in units.values():
            if unit.faction == playerFaction and screenRect.contains(unit.screenPosition):
                selectionManager.add(unit)
        guiSystem.updateSelectionPanel(selectionManager.selected)

    function onPlayerCommand(command, isQueued):
        for unit in selectionManager.selected:
            if not isQueued:
                unit.clearCommands()
            unit.enqueueCommand(command)
            if command.type == MOVE:
                path = pathfindingSystem.findPath(unit.position, command.target)
                unit.setPath(path)
            elif command.type == ATTACK:
                unit.target = command.targetUnit
                unit.state = ATTACKING

class Unit:
    id: UnitID
    faction: Faction
    stats: UnitStats
    state: UnitState  // IDLE, MOVING, ATTACKING, DYING
    commandQueue: Queue<IUnitCommand>
    currentPath: Path

    function update(deltaTime):
        if commandQueue.isEmpty() and state != DYING:
            state = IDLE
            return
        currentCmd = commandQueue.peek()
        if currentCmd.isComplete():
            commandQueue.dequeue()
            return
        currentCmd.execute(this, deltaTime)

    function takeDamage(amount, armorType, weaponType):
        mitigation = ArmorTable.getMitigation(armorType, weaponType)
        actualDamage = amount * (1.0 - mitigation) - stats.armor
        stats.hp -= max(actualDamage, MIN_DAMAGE)
        if stats.hp <= 0:
            die()

    function die():
        state = DYING
        eventBus.emit(UnitDiedEvent(this))
        unitSystem.units.remove(this.id)
        // Play death animation, trigger cleanup after delay
```

## Modern Implementation Recommendations

| Approach | Recommendation |
|----------|---------------|
| **Best Overall** | **Unity 2023 with DOTS/ECS** — Use Entities 1.0 with `UnitAuthoring` baking, `UnitAspect` for system queries, and `DynamicBuffer<CommandData>` for command queues. Mass unit scenarios (hundreds of units) benefit enormously from data-oriented iteration. |
| **Alternative Engine** | **Godot 4 with GDScript/C#** — Use `Node3D` for unit scenes, custom `UnitController` scripts, and `NavigationRegion3D` for pathfinding. Simpler to prototype but less performant at scale. |
| **Performance-Critical** | **Rust + Bevy ECS** — Native performance with Bevy's ECS archetype model. Define `Unit` as a bundle of components (`Health`, `Movement`, `CommandQueue`). Compile to WebAssembly for web deployment. Ideal for deterministic lockstep multiplayer. |
| **Custom Engine** | **C++ with EnTT** — Entity-component-system with EnTT library. Full control over memory layout and simulation tick rate. Best for competitive RTS where frame-perfect determinism is required. |

**Key patterns to adopt:**
- Use an ECS architecture for all unit data — avoid heavy MonoBehaviour subclasses
- Implement command pattern with a ring buffer for command history (essential for replay)
- Separate simulation from presentation: units exist as pure data, visual representation is a view layer
- Use ScriptableObjects (or equivalent data-driven definitions) for all unit stats — never hardcode
- Implement object pooling for unit entities (pre-allocate, reuse on death) to avoid GC spikes
