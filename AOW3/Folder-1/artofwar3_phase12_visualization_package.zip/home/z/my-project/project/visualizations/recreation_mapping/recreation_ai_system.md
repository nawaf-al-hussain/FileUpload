# Recreation Mapping: AI System

## Purpose

The AI System in Art of War 3: Global Conflict provides computer-controlled opponents that simulate human strategic and tactical decision-making. The system operates at two distinct levels: **Strategic AI** (high-level decision-making — when to expand, what to build, when to attack or defend, tech progression path) and **Tactical AI** (low-level unit management — target selection, ability usage, formation, retreat decisions). Additionally, the system includes a **Pathfinding Subsystem** using A* or JPS (Jump Point Search) on a navmesh/grid for unit navigation with obstacle avoidance and dynamic replanning. The AI must handle all game modes: skirmish, campaign missions, and co-op. Difficulty scaling adjusts reaction time, resource efficiency, and decision quality. With 1,100 types and 6,600 methods, the AI System is the largest and most complex subsystem in the codebase.

## Inputs

- **Game State**: Full map visibility (AI has map awareness scaled by difficulty), unit positions, building positions, resource nodes
- **Economy System**: Current resource levels, income rates
- **Unit System**: Available units, unit health, unit capabilities
- **Building System**: Active buildings, production queues, tech level
- **Combat System**: Engagement results, threat assessments
- **Fog of War**: Modified visibility (on lower difficulties, AI respects FoW; on higher, it has full map knowledge)
- **Pathfinding Grid**: Terrain data, obstacle map, dynamic blockers

## Outputs

- **Build Orders**: Construction requests to Building System
- **Unit Production Orders**: Training requests to factory buildings
- **Unit Commands**: Move, attack, patrol, hold, ability activation commands
- **Tech Research Orders**: Upgrade requests to Tech System
- **Economy Decisions**: When to expand, when to conserve resources
- **Strategic State**: Current AI strategy (rush, turtle, boom, timing attack)

## Dependencies

- **All Game Systems**: The AI reads from every system and writes commands to most
- **Pathfinding Subsystem**: Integral part of AI for navigation
- **Economy System**: For affordability checks
- **Building System**: For build order execution
- **Unit System**: For command dispatch
- **Combat System**: For threat assessment

## Internal Logic

The Strategic AI uses a hierarchical task network (HTN) or utility-based decision system. Every N seconds (configurable by difficulty), the AI evaluates its current strategic state and selects the highest-utility action. Utility scores are calculated from factors like: current army size relative to enemy, economy strength, map control, tech advancement, and time elapsed. The AI cycles through strategic archetypes: **Rush** (early aggression with light units), **Boom** (fast economic expansion), **Turtle** (defensive teching to superweapons), and **Timing Attack** (attacking when a tech advantage peaks).

The Tactical AI runs per-unit-group and handles micro-management. Each unit group (cluster of nearby units) has a tactical controller that evaluates: should we engage, retreat, flank, or hold position? Retreat thresholds are based on unit health percentage and local force disparity. Ability usage for hero units follows cooldown-aware decision trees.

The Pathfinding Subsystem implements A* on a grid overlay of the map. Each cell has a traversal cost (open terrain = 1, forest = 2, water = impassable). Dynamic obstacles (buildings, large units) are encoded as temporary blockers that trigger replanning. For large unit groups, formation-based pathfinding computes a single path for the group leader and offsets for followers. Flow fields are used for large-scale movement (40+ units) to avoid local congestion.

## Pseudocode

```
class AISystem:
    strategicAI: Map<PlayerID, StrategicAI>
    tacticalAI: Map<PlayerID, TacticalAI>
    pathfinding: PathfindingSystem

    function update(deltaTime):
        for playerID, ai in strategicAI:
            ai.update(deltaTime)
        for playerID, ai in tacticalAI:
            ai.update(deltaTime)

class StrategicAI:
    strategy: StrategyType  // RUSH, BOOM, TURTLE, TIMING
    evaluationTimer: float
    owner: PlayerID

    function update(deltaTime):
        evaluationTimer -= deltaTime
        if evaluationTimer <= 0:
            evaluationTimer = STRATEGY_EVAL_INTERVAL  // e.g., 5 seconds
            evaluateAndDecide()

    function evaluateAndDecide():
        state = assessState()
        // Utility-based decision
        scores = {
            RUSH:   calculateRushUtility(state),
            BOOM:   calculateBoomUtility(state),
            TURTLE: calculateTurtleUtility(state),
            TIMING: calculateTimingUtility(state),
        }
        bestStrategy = max(scores, key=scores.get)
        if bestStrategy != strategy:
            transitionTo(bestStrategy)
        executeCurrentStrategy()

    function assessState() -> AIState:
        return AIState(
            armySize = countMyUnits(),
            enemyArmySize = estimateEnemyArmy(),  // Scaled by difficulty
            economyRate = economySystem.getIncomeRate(owner, SUPPLY),
            techLevel = techTree.getCurrentLevel(owner),
            mapControl = calculateMapControl(),
            timeElapsed = gameTime.elapsed
        )

    function executeCurrentStrategy():
        switch strategy:
            case RUSH:
                if armySize >= RUSH_THRESHOLD:
                    orderAttack(enemyBase, allCombatUnits)
                else:
                    produceUnits(lightCombatUnits)
                    buildBarracks()
            case BOOM:
                expandEconomy()
                buildSupplyCenters()
                if economyRate > BOOM_THRESHOLD:
                    transitionTo(TIMING)
            case TURTLE:
                buildDefenses()
                researchTech()
                if techLevel >= SUPERWEAPON_UNLOCK:
                    buildSuperweapon()
            case TIMING:
                if hasTechAdvantage():
                    orderAttack(enemyBase, allCombatUnits)
                else:
                    maintainArmy()

class TacticalAI:
    function manageUnitGroup(group):
        enemies = detectNearbyEnemies(group)
        if enemies.isEmpty():
            return  // Idle
        forceRatio = calculateForceRatio(group, enemies)
        if forceRatio < RETREAT_THRESHOLD:
            orderRetreat(group)
        elif forceRatio > ENGAGE_THRESHOLD:
            orderEngage(group, bestTarget(enemies))
        else:
            // Even fight — use micro
            for unit in group:
                if unit.isHero and unit.abilityReady:
                    useAbilityAtBestTime(unit)
                if unit.health < 0.3:
                    microRetreat(unit)

class PathfindingSystem:
    grid: NavigationGrid

    function findPath(start, goal) -> Path:
        // A* implementation
        openSet = PriorityQueue()
        openSet.push(Node(start, g=0, h=heuristic(start, goal)))
        cameFrom = Map<Position, Position>()
        gScore = Map<Position, float>()
        while not openSet.isEmpty():
            current = openSet.pop()
            if current == goal:
                return reconstructPath(cameFrom, current)
            for neighbor in getNeighbors(current):
                tentG = gScore[current] + movementCost(current, neighbor)
                if tentG < gScore.get(neighbor, infinity):
                    cameFrom[neighbor] = current
                    gScore[neighbor] = tentG
                    fScore = tentG + heuristic(neighbor, goal)
                    openSet.push(Node(neighbor, tentG, fScore))
        return PATH_NOT_FOUND  // No valid path

    function computeFlowField(target) -> FlowField:
        // Dijkstra-based flow field for mass unit movement
        // Each cell stores direction toward target
        // More efficient than A* for 40+ units moving to same area
        ...
```

## Modern Implementation Recommendations

| Approach | Recommendation |
|----------|---------------|
| **Best Overall** | **Unity 2023 with DOTS + ML-Agents** — Use ECS for AI agent decisions (one entity per AI player per strategic layer). ML-Agents for trainable tactical micro. A* Pathfinding Project (Aron Granberg) for navmesh. |
| **Alternative Engine** | **Godot 4 with C# + UtilityAI** — Implement utility-based AI with `Consideration` resources (curves). Use `NavigationRegion3D` for pathfinding. GDScript for behavior trees, C# for performance-critical pathfinding. |
| **Performance-Critical** | **Rust + Bevy ECS + Big Brain crate** — `big_brain` crate provides BT and utility AI. Bevy's ECS for parallel AI evaluation. Custom A* with `pathfinding` crate for navigation. |
| **Advanced** | **C++ with GOAP (Goal-Oriented Action Planning)** — More dynamic than HTN. AI plans sequences of actions to achieve goals. Better emergent behavior. Use Recast/Detour for navmesh pathfinding. |

**Key patterns to adopt:**
- Separate strategic AI (low-frequency, seconds) from tactical AI (high-frequency, frames)
- Utility-based AI over behavior trees for strategic decisions — more flexible, easier to tune
- Flow fields for mass unit movement — A* per-unit is too expensive for 100+ units
- Difficulty scaling via information restriction and reaction delay, not cheating
- Asynchronous pathfinding — compute paths in background jobs, not on main thread
- AI personality profiles (aggressive, defensive, balanced) as data-driven configurations
