# Recreation Mapping: Combat System

## Purpose

The Combat System governs all destructive interactions between units and structures in Art of War 3: Global Conflict. It resolves weapon fire, calculates damage using a weapon-vs-armor matrix, manages target acquisition and priority, handles area-of-effect damage (artillery, superweapons), implements friendly fire rules, and tracks kill statistics for scoring and progression. The system is the primary conflict resolution engine and directly determines gameplay balance through its damage tables and engagement rules. It supports five weapon categories (Anti-Infantry, Anti-Tank, Artillery, Thermoelectric, Naval) interacting with three armor classes (DE-I/Light, DE-II/Medium, DE-III/Heavy), creating a rock-paper-scissors dynamic that demands tactical unit composition.

## Inputs

- **Unit System**: Attacker position, weapon stats, weapon cooldown state, attack command targets
- **Building System**: Building health pools, armor types for structure damage resolution
- **Upgrade/Tech System**: Damage multipliers, range bonuses, fire-rate improvements
- **Hero System**: Active abilities that deal damage or debuff targets
- **Superweapon System**: Nuclear detonation and Chameleon Tower beam damage events
- **Fog of War System**: Line-of-sight validation before attacks can be initiated
- **Network System**: Combat event synchronization, damage confirmation across clients

## Outputs

- **Damage Events**: Applied damage values broadcast to affected units/buildings
- **Death Events**: Unit/building destruction triggers for cleanup and scoring
- **Combat Log**: Kill counts, damage dealt statistics for end-game scoreboard
- **Visual Effects**: Muzzle flash, projectile trails, explosion VFX triggers
- **Audio Events**: Weapon fire sounds, explosion sounds, unit death voice lines

## Dependencies

- **Unit System**: For attacker and target entity data
- **Building System**: For structure combat interactions
- **Economy System**: For bounty/resource gain on kills (if applicable)
- **Fog of War**: For target visibility validation
- **Audio System**: For combat sound effects
- **Network System**: For synchronized damage application

## Internal Logic

The Combat System is driven by a `CombatResolver` that processes engagement requests. Each unit with a weapon component runs a `WeaponController` that manages cooldown timers, range checks, and fire-state machines (idle → aiming → firing → cooldown). Target acquisition follows a priority system: units auto-acquire the nearest enemy within weapon range, but can be overridden by player attack-move commands. The priority weighting considers: distance (closer = higher), unit type effectiveness (bonus for favorable matchups), and threat level (units actively attacking the owner get priority).

The damage calculation pipeline is the core of the system. It uses a lookup table (`DamageTable`) indexed by `[weaponCategory][armorType]` that returns a multiplier (e.g., Anti-Tank vs DE-III/Heavy = 1.5x, Anti-Infantry vs DE-III/Heavy = 0.3x). The formula is: `finalDamage = baseDamage * weaponArmorMultiplier * upgradeModifier - flatArmorReduction`, clamped to a minimum of 1. Area-of-effect weapons (artillery, thermoelectric) use a falloff curve from the impact point: `aoeDamage = baseDamage * falloffCurve(distance / maxRadius)`. Friendly fire is disabled in standard multiplayer but can be enabled in custom games.

The system also manages projectile simulation: hitscan weapons apply damage instantly, while projectile weapons spawn a `Projectile` entity that travels toward the target and applies damage on collision. Projectiles can miss if the target moves out of the predicted path, adding a skill component to kiting micro.

## Pseudocode

```
class CombatSystem:
    damageTable: DamageTable
    combatLog: CombatLog
    activeProjectiles: List<Projectile>

    function resolveAttack(attacker, target):
        weapon = attacker.stats.weapon
        if weapon.cooldownRemaining > 0:
            return  // Still on cooldown
        if not isInRange(attacker, target, weapon.range):
            return  // Out of range
        if not fogOfWar.is_visible_to(attacker, target):
            return  // Cannot see target

        weapon.cooldownRemaining = weapon.fireRate
        if weapon.type == HITSCAN:
            applyDamage(attacker, target, weapon)
        elif weapon.type == PROJECTILE:
            projectile = spawnProjectile(attacker.position, target, weapon)
            activeProjectiles.add(projectile)

    function applyDamage(attacker, target, weapon):
        armorType = target.stats.armorType
        weaponArmorMult = damageTable.getMultiplier(weapon.category, armorType)
        upgradeMod = upgradeSystem.getDamageModifier(attacker)
        baseDmg = weapon.baseDamage
        flatReduction = target.stats.armorFlat
        finalDmg = max(baseDmg * weaponArmorMult * upgradeMod - flatReduction, MIN_DAMAGE)
        target.takeDamage(finalDmg)
        combatLog.record(attacker, target, finalDmg)
        audioSystem.playWeaponSound(weapon.soundId, attacker.position)

    function applyAOEDamage(center, radius, baseDamage, weaponCategory, sourceFaction):
        targets = spatialQuery.findAllInRange(center, radius)
        for target in targets:
            if target.faction == sourceFaction and not friendlyFireEnabled:
                continue
            dist = distance(center, target.position)
            falloff = 1.0 - (dist / radius)  // Linear falloff
            aoeDmg = baseDamage * falloff
            armorType = target.stats.armorType
            mult = damageTable.getMultiplier(weaponCategory, armorType)
            finalDmg = max(aoeDmg * mult, MIN_DAMAGE)
            target.takeDamage(finalDmg)
        vfxSystem.spawnExplosion(center, radius)
        audioSystem.playExplosionSound(center)

    function findBestTarget(unit):
        enemies = fogOfWar.getVisibleEnemies(unit)
        bestTarget = null
        bestScore = -infinity
        for enemy in enemies:
            if not isInRange(unit, enemy, unit.weapon.range):
                continue
            score = calculatePriority(unit, enemy)
            if score > bestScore:
                bestScore = score
                bestTarget = enemy
        return bestTarget

    function calculatePriority(attacker, target):
        distScore = 1.0 / (distance(attacker, target) + 1.0)
        effectivenessScore = damageTable.getMultiplier(attacker.weapon.category, target.armorType)
        threatScore = 0
        if target.currentTarget == attacker:
            threatScore = 0.5
        return distScore * 0.4 + effectivenessScore * 0.4 + threatScore * 0.2

// Damage Table (weapon category × armor type)
class DamageTable:
    // [Anti-Infantry, Anti-Tank, Artillery, Thermoelectric, Naval]
    // vs [DE-I/Light, DE-II/Medium, DE-III/Heavy]
    multipliers = [
        [1.5, 1.0, 0.3],  // Anti-Infantry
        [0.5, 1.2, 1.5],  // Anti-Tank
        [1.2, 1.0, 0.8],  // Artillery
        [1.0, 1.3, 1.0],  // Thermoelectric
        [1.0, 1.0, 1.0],  // Naval (neutral)
    ]
```

## Modern Implementation Recommendations

| Approach | Recommendation |
|----------|---------------|
| **Best Overall** | **Unity 2023 DOTS/ECS** — Implement `CombatSystem : SystemBase` querying `Attacker` and `Health` components. Use `NativeMultiHashMap` for spatial queries (range checks). Burst-compile the damage calculation loop for massive parallel combat resolution. |
| **Alternative Engine** | **Godot 4 with C#** — Use `Area3D` overlap detection for range checks, custom `DamageResolver` class with GDScript signals for hit events. Simpler but slower for large-scale battles. |
| **Performance-Critical** | **Rust + Bevy ECS** — Define `Weapon`, `Health`, `Armor` as components. Use Bevy's query system with `With<Weapon>` filters. Spatial hashing via `bevy_spatial` crate. Compile to WASM for web. |
| **Deterministic** | **C++ custom with fixed-point math** — Use fixed-point arithmetic (e.g., `Fixed<f32, 16>`) for all damage calculations. Ensures bit-identical results across platforms, essential for lockstep multiplayer. |

**Key patterns to adopt:**
- Use a data-driven damage table (JSON/ScriptableObject) — never hardcode balance values
- Implement spatial hashing (grid-based) for O(1) range queries instead of O(n²) distance checks
- Separate combat simulation from VFX/audio — the resolver should only produce events
- Use command pattern for combat events to enable replay and network rollback
- Consider hitscan vs projectile distinction carefully: hitscan is deterministic and simple, projectiles need interpolation for smooth visuals
