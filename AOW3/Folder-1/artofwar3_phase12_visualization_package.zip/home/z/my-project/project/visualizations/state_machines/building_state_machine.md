# Building State Machine — Art of War 3: Global Conflict

Complete building state machine covering construction phases, power dependency, upgrades,
damage/destruction, production queues, and building-type-specific behaviors.

## Primary Building State Machine

```mermaid
stateDiagram-v2
    direction TB

    [*] --> Planned : AddBuilding()\n[Placement confirmed]
    Planned --> Constructing : Builder assigned\n/ Resources deducted
    Planned --> Cancelled : Cancel before construction\n[Full refund]

    Constructing --> Active : Construction 100%\n[BuildingComplete()]
    Constructing --> Damaged : Attacked during construction\n[HP > 0]
    Constructing --> Destroyed : HP <= 0 during construction\n[DestroyPreBuilding()]
    Constructing --> Cancelled : Cancel during construction\n[Partial refund based on %]

    state "Active" as Active {
        direction LR
        [*] --> Operational
        Operational --> Producing : Production queued\n[Factory/Barracks/Airport]
        Producing --> Operational : Queue empty
        Operational --> Researching : Tech/Upgrade started\n[Lab/Workshop]
        Researching --> Operational : Research complete
    }

    Active --> Upgrading : Upgrade command\n[Resources available]
    Active --> Damaged : HP < MaxHP & HP > 0\n[Under attack]
    Active --> Disabled_NoPower : Power consumed > Power generated\n[Power deficit]
    Active --> Destroyed : HP <= 0

    Upgrading --> Active : Upgrade complete\n[New level, stats updated]
    Upgrading --> Damaged : Attacked during upgrade\n[HP > 0]
    Upgrading --> Destroyed : HP <= 0 during upgrade
    Upgrading --> Active : Cancel upgrade\n[Partial refund]

    Damaged --> Active : HP repaired to MaxHP\n[Engineer / Auto-repair]
    Damaged --> Destroyed : HP <= 0
    Damaged --> Disabled_NoPower : Power lost while damaged

    Disabled_NoPower --> Active : Power restored\n[Power surplus achieved]
    Disabled_NoPower --> Damaged : Attacked while unpowered
    Disabled_NoPower --> Destroyed : HP <= 0 while unpowered

    Destroyed --> Rubble : Death animation complete
    Rubble --> [*] : Rubble cleared\n/ New building placed

    Cancelled --> [*] : Cleanup complete

    state Disabled_NoPower {
        [*] --> ShutdownSequence
        ShutdownSequence --> Unpowered : Systems offline
        Unpowered : No production\nNo research\nNo abilities\nDefensive turrets offline
        Unpowered --> PowerRestoring : Power plant built/coming online
        PowerRestoring --> [*] : Power surplus detected
    }
```

## Construction Phase Detail

```mermaid
stateDiagram-v2
    direction TB

    [*] --> SitePlacement : Player selects building from build menu
    SitePlacement --> PositionValid : Valid placement location\n[No overlap, terrain OK, in territory]
    SitePlacement --> PositionInvalid : Invalid location\n[Overlap / Terrain / Out of territory]
    PositionInvalid --> SitePlacement : Re-select position

    PositionValid --> ResourceCheck : Position confirmed
    ResourceCheck --> PreConstruction : Resources sufficient
    ResourceCheck --> WaitingForResources : Resources insufficient
    WaitingForResources --> PreConstruction : Resources gathered\n[Auto-resume]

    PreConstruction --> Foundation : AddBuilding() called\n[Ghost placed, resources deducted]
    Foundation --> Framework : Construction 25%
    Framework --> Enclosure : Construction 50%
    Enclosure --> Finalization : Construction 75%
    Finalization --> BuildingComplete : Construction 100%\n[BuildingComplete() called]

    note right of Foundation : Builder unit assigned\nConstruct() called each tick
    note right of Finalization : Deconstruct() can reverse\nDestroyPreBuilding() if cancelled

    BuildingComplete --> [*] : Building operational
```

## Power Grid State Machine

```mermaid
stateDiagram-v2
    direction TB

    [*] --> PowerSurplus : Initial Power Plant built
    PowerSurplus --> PowerBalanced : Buildings consume all power
    PowerBalanced --> PowerDeficit : New building pushes\nconsumption > generation
    PowerSurplus --> PowerDeficit : Power Plant destroyed\n/ Multiple buildings added

    PowerDeficit --> PowerSurplus : New Power Plant online\n/ Buildings destroyed/offline
    PowerDeficit --> PowerSurplus : Low-priority buildings\nauto-disabled to restore power
    PowerBalanced --> PowerSurplus : Power Plant built\n/ Building destroyed

    state "PowerDeficit" as PowerDeficit {
        [*] --> PrioritizingShutdowns
        PrioritizingShutdowns --> DisablingLowPriority : Defense > Production > Tech
        DisablingLowPriority --> DisablingMediumPriority : Still in deficit
        DisablingMediumPriority --> DisablingCriticalPriority : Severe deficit
        DisablingCriticalPriority : Only defenses remain powered
    }

    note right of PowerDeficit
        Buildings disabled in priority order:
        1. Superweapons (first)
        2. Tech buildings
        3. Production buildings
        4. Resource buildings
        5. Defensive structures (last)
    end note
```

## Building Type Variants

```mermaid
stateDiagram-v2
    direction TB

    state "Production Building (Barracks/Factory/Airport)" as Production {
        [*] --> ProdActive : BuildingComplete()
        ProdActive --> ProdProducing : Unit queued\n[Resources deducted]
        ProdProducing --> ProdActive : Unit produced\n[AddUnit() called at rally point]
        ProdProducing --> ProdQueued : Multiple units in queue
        ProdQueued --> ProdProducing : Next unit starts
        ProdActive --> ProdDisabled : No power
        ProdProducing --> ProdPaused : No power during production
        ProdPaused --> ProdProducing : Power restored\n[Production resumes]
        ProdDisabled --> ProdActive : Power restored
    }

    state "Defensive Building (Turret/Bunker/Wall)" as Defensive {
        [*] --> DefActive : BuildingComplete()
        DefActive --> DefAttacking : Enemy in range\n[calcShooter() acquires target]
        DefAttacking --> DefActive : Target destroyed / Out of range
        DefActive --> DefDisabled : No power\n[Turrets only - walls unaffected]
        DefDisabled --> DefActive : Power restored
        DefAttacking --> DefDisabled : Power lost during attack
    }

    state "Tech Building (Lab/Workshop)" as Tech {
        [*] --> TechActive : BuildingComplete()
        TechActive --> TechResearching : Research started
        TechResearching --> TechActive : Research complete\n[Unlocks available]
        TechActive --> TechDisabled : No power
        TechResearching --> TechPaused : No power during research
        TechPaused --> TechResearching : Power restored
        TechDisabled --> TechActive : Power restored
    }

    state "Power Plant" as PowerPlant {
        [*] --> PPActive : BuildingComplete()
        PPActive --> PPBoosted : Adjacency bonus\n[Near other Power Plants]
        PPBoosted --> PPActive : Adjacent building destroyed
        PPActive --> PPDamaged : HP < MaxHP
        PPDamaged --> PPReducedOutput : HP < 50%\n[Power output reduced]
        PPReducedOutput --> PPActive : Repaired to full HP
    }

    state "Supply Center" as SupplyCenter {
        [*] --> SCActive : BuildingComplete()
        SCActive --> SCProducing : Supply truck spawned
        SCProducing --> SCActive : Truck deployed
        SCActive --> SCDisabled : No power
        SCDisabled --> SCActive : Power restored
    }

    state "Superweapon" as Superweapon {
        [*] --> SWStandby : BuildingComplete()
        SWStandby --> SWArming : Launch command\n[Charge cost paid]
        SWArming --> SWArmed : Charge complete
        SWArmed --> SWStandby : Cancelled
        SWArmed --> SWDisabled : No power during arming
        SWDisabled --> SWArming : Power restored\n[Arming resumes from pause point]
        SWArmed --> SWCountdown : Target confirmed
        SWCountdown --> SWLaunching : Countdown complete
        SWLaunching --> SWCooldown : Impact resolved
        SWCooldown --> SWStandby : Cooldown complete
    }
```

## Building Upgrade Flow

```mermaid
stateDiagram-v2
    direction TB

    [*] --> Level1 : BuildingComplete()
    Level1 --> Upgrading1to2 : Upgrade command (L1→L2)\n[Cost: 200 supplies, 100 uranium]
    Upgrading1to2 --> Level2 : Upgrade complete\n[HP increased, new abilities]

    Level2 --> Upgrading2to3 : Upgrade command (L2→L3)\n[Cost: 500 supplies, 250 uranium]
    Upgrading2to3 --> Level3 : Upgrade complete\n[Max level, all abilities unlocked]

    Upgrading1to2 --> Level1 : Cancel upgrade\n[50% refund]
    Upgrading2to3 --> Level2 : Cancel upgrade\n[50% refund]

    Upgrading1to2 --> Level1_Damaged : Attacked during upgrade\n[Upgrade paused, HP reduced]
    Level1_Damaged --> Upgrading1to2 : Repaired & upgrade resumed

    Upgrading2to3 --> Level2_Damaged : Attacked during upgrade
    Level2_Damaged --> Upgrading2to3 : Repaired & upgrade resumed

    note right of Level1
        Level 1: Base stats
        - Barracks: Trains basic infantry
        - Factory: Trains light vehicles
    end note

    note right of Level2
        Level 2: Enhanced stats
        - Barracks: Unlocks elite infantry
        - Factory: Unlocks heavy vehicles
        - New production queue slot
    end note

    note right of Level3
        Level 3: Maximum stats
        - Barracks: Unlocks hero units
        - Factory: Unlocks super units
        - Maximum production speed
        - Additional queue slots
    end note
```
