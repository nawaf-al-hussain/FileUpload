# Recreation Mapping: Superweapon System

## Purpose

The Superweapon System governs the two ultimate weapons in Art of War 3: Global Conflict — the **Nuclear Silo** (Confederation) and the **Chameleon Tower** (Resistance). These are Tier 3 structures that, after a significant resource and time investment, can deliver devastating attacks that can single-handedly shift the outcome of a match. The Nuclear Silo launches a nuclear warhead at a target location, dealing massive area-of-effect damage and leaving a radiation zone. The Chameleon Tower deploys a stealth/EMP hybrid effect that disables enemy units and structures in a large radius while revealing hidden units. The system handles the charge-up mechanic (superweapons must charge before firing), launch sequences with visual warnings, impact resolution with massive AoE damage, and the strategic counter-play of destroying enemy superweapon structures before they fire. Superweapons serve as late-game tiebreakers and create urgency that prevents passive stalemates.

## Inputs

- **Player Input**: Superweapon target selection, launch authorization
- **Building System**: Nuclear Silo and Chameleon Tower building states
- **Economy System**: Uranium cost for charging/firing
- **Upgrade/Tech System**: Tier 3 tech requirement for superweapon construction
- **Fog of War**: Target area must be explored (not necessarily visible) to fire

## Outputs

- **Nuclear Launch**: Missile entity traveling to target, massive AoE damage on impact, radiation zone
- **Chameleon Activation**: Large-radius EMP pulse, stealth reveal, structure disable
- **Launch Warning**: Global audio/visual alert to all players when superweapon is firing
- **Charge Progress**: Visual indicator on the building showing charge state
- **Strategic Pressure**: Knowledge that enemy is charging a superweapon creates urgency

## Dependencies

- **Building System**: For superweapon building construction and health
- **Economy System**: For uranium cost of charging
- **Combat System**: For damage application on impact
- **Fog of War System**: For target area validation
- **GUI System**: For charge indicators, launch warnings, target selection UI
- **Audio System**: For launch siren, explosion sound, EMP sound
- **Network System**: For synchronized launch events (critical — all players must see the launch)

## Internal Logic

Superweapons operate in three phases: **Construction → Charging → Ready**. Construction follows normal building rules (requires Tier 3 tech, significant supply cost). Once built, the superweapon enters the Charging phase: it passively accumulates charge over time, consuming uranium from the player's stockpile. The charge rate is configurable (e.g., 60 seconds to full charge). The charge progress is visible on the building and, critically, is also visible to the enemy player — they can see a progress bar or visual indicator that a superweapon is charging, creating counter-play urgency.

When fully charged, the superweapon enters Ready state. The player can then select a target location (must be on explored terrain) and authorize launch. Upon launch, a global warning is broadcast to all players: a siren sound plays, and a UI notification appears ("Enemy Nuclear Launch Detected!" / "Enemy Chameleon Tower Activating!"). There is a brief delay (3-5 seconds) between launch authorization and impact, giving the opponent a small window to move units out of the target area.

**Nuclear Silo**: Launches a visible missile entity that travels from the silo to the target over ~3 seconds. On impact, deals devastating damage in a large radius (e.g., 2000 base damage, 15-tile radius) with damage falloff from center. Leaves a radiation zone that deals continuous damage to units passing through for 30 seconds. Destroys most buildings and units in the inner radius outright.

**Chameleon Tower**: Does not launch a projectile. Instead, it emits an instant pulse from the tower location, affecting a very large radius (e.g., 25 tiles). Units in the radius are stunned for 8 seconds, structures are disabled for 10 seconds (no production, no firing), and all stealthed/invisible units are revealed for the duration. Less lethal than the nuclear option but tactically devastating — it creates a window for a coordinated follow-up attack.

After firing, the superweapon must recharge before it can fire again (longer cooldown than the initial charge). The building itself has moderate health — it can be destroyed by a concerted attack, which is the primary counter-play.

## Pseudocode

```
class SuperweaponSystem:
    superweapons: Map<BuildingID, Superweapon>

    function onBuildingCompleted(building):
        if building.type == NUCLEAR_SILO or building.type == CHAMELEON_TOWER:
            sw = Superweapon(
                building = building,
                state = CHARGING,
                chargeProgress = 0.0,
                chargeRate = building.definition.chargeRate,
                uraniumCost = building.definition.chargeUraniumCost
            )
            superweapons[building.id] = sw

    function updateCharging(deltaTime):
        for sw in superweapons.values():
            if sw.state != CHARGING:
                continue
            uraniumNeeded = sw.uraniumCost * deltaTime / sw.chargeTime
            if economySystem.canAffordUranium(sw.building.owner, uraniumNeeded):
                economySystem.deductUranium(sw.building.owner, uraniumNeeded)
                sw.chargeProgress += deltaTime / sw.chargeTime
                if sw.chargeProgress >= 1.0:
                    sw.state = READY
                    sw.chargeProgress = 1.0
                    eventBus.emit(SuperweaponReadyEvent(sw))
            // If insufficient uranium, charging pauses (no refund)

    function launchSuperweapon(buildingID, targetPosition):
        sw = superweapons[buildingID]
        if sw.state != READY:
            return LAUNCH_FAIL_NOT_READY
        if not fogOfWar.isExplored(sw.building.owner, targetPosition):
            return LAUNCH_FAIL_NOT_EXPLORED
        sw.state = FIRING
        // Global warning to ALL players
        for player in activePlayers:
            audioSystem.playSuperweaponWarning(player, sw.building.type)
            guiSystem.showLaunchWarning(player, sw.building.type, sw.building.faction)
        if sw.building.type == NUCLEAR_SILO:
            launchNuclearMissile(sw, targetPosition)
        elif sw.building.type == CHAMELEON_TOWER:
            activateChameleonPulse(sw)

    function launchNuclearMissile(sw, target):
        missile = spawnMissileEntity(sw.building.position, target)
        missile.speed = NUCLEAR_MISSILE_SPEED
        missile.estimatedArrival = distance(sw.building.position, target) / missile.speed
        // Track missile entity, apply damage on arrival
        scheduleCallback(missile.estimatedArrival, () => {
            onNuclearImpact(sw, target)
        })

    function onNuclearImpact(sw, target):
        // Massive AoE damage
        affectedUnits = spatialQuery.findAllInRange(target, NUCLEAR_RADIUS)
        for unit in affectedUnits:
            dist = distance(target, unit.position)
            falloff = 1.0 - (dist / NUCLEAR_RADIUS)
            damage = NUCLEAR_BASE_DAMAGE * falloff
            unit.takeDamage(damage, HEAVY, ARTILLERY)  // Counts as artillery damage
        // Damage buildings in radius
        affectedBuildings = spatialQuery.findAllBuildingsInRange(target, NUCLEAR_RADIUS)
        for building in affectedBuildings:
            dist = distance(target, building.position)
            falloff = 1.0 - (dist / NUCLEAR_RADIUS)
            building.takeDamage(NUCLEAR_BASE_DAMAGE * falloff * 0.8)
        // Spawn radiation zone
        hazardSystem.createRadiationZone(target, NUCLEAR_RADIUS * 0.7, RADIATION_DURATION)
        // VFX and audio
        vfxSystem.spawnNuclearExplosion(target, NUCLEAR_RADIUS)
        audioSystem.playNuclearExplosion(target)
        // Screen shake
        cameraSystem.screenShake(0.5, 30)
        // Reset superweapon
        sw.state = RECHARGING
        sw.chargeProgress = 0.0

    function activateChameleonPulse(sw):
        center = sw.building.position
        radius = CHAMELEON_RADIUS
        affectedUnits = spatialQuery.findAllInRange(center, radius)
        for unit in affectedUnits:
            if unit.faction != sw.building.faction:
                unit.applyStun(CHAMELEON_STUN_DURATION)
                if unit.isStealthed:
                    unit.revealStealth(CHAMELEON_REVEAL_DURATION)
        affectedBuildings = spatialQuery.findAllBuildingsInRange(center, radius)
        for building in affectedBuildings:
            if building.faction != sw.building.faction:
                building.disable(CHAMELEON_DISABLE_DURATION)
        // VFX and audio
        vfxSystem.spawnEMPPulse(center, radius)
        audioSystem.playEMPPulse(center)
        // Reset
        sw.state = RECHARGING
        sw.chargeProgress = 0.0
```

## Modern Implementation Recommendations

| Approach | Recommendation |
|----------|---------------|
| **Best Overall** | **Unity 2023 + Timeline + VFX Graph** — Use Timeline for launch sequence (missile flight, detonation). VFX Graph for nuclear explosion and EMP pulse effects. ScriptableObjects for superweapon definitions. |
| **Alternative Engine** | **Godot 4 + GUT (Godot Unit Test)** — `Superweapon : Node3D` with `AnimationPlayer` for launch sequence. `GPUParticles3D` for explosion effects. Custom shader for radiation zone. |
| **Performance-Critical** | **Rust + Bevy + bevy_hanabi** — Bevy ECS for superweapon entities. `bevy_hanabi` for particle effects. Compute shaders for AoE damage calculation. |
| **Visual Spectacle** | **Unity + Shader Graph + Post-Processing** — Nuclear explosion with HDR bloom, screen distortion, and color grading shift. EMP with electric arc shader and screen desaturation. Post-processing makes superweapons FEEL super. |

**Key patterns to adopt:**
- Three-phase lifecycle: Construction → Charging → Ready (clear state machine)
- Global player warning on launch — information symmetry is critical for counter-play
- Brief impact delay (3-5 seconds) — gives opponents a micro-window to react
- Charge progress visible to enemy — creates strategic pressure and counter-play urgency
- Uranium as the gating resource — makes uranium nodes strategically critical
- Post-fire recharge (longer than initial charge) — prevents spam, makes timing crucial
- Destroying the building during charge cancels the superweapon — the primary counter
