# AI State Machine — Art of War 3: Global Conflict

AI agent state machines for three levels of AI:
- **Strategic AI**: Base building, tech progression, resource management, game plan decisions
- **Tactical AI**: Unit control, attack/defend decisions, force composition, map control
- **Individual Unit AI**: Combat behavior, retreat logic, auto-aggro, formation adherence

## Strategic AI State Machine

```mermaid
stateDiagram-v2
    direction TB

    [*] --> Opening : Game start
    Opening --> BuildBase : Initial build order executing
    Opening --> Scout : Early scout dispatched

    BuildBase --> Gather : Base structures placed\n[Need resources to continue]
    BuildBase --> TechUp : Base structures complete\n[Sufficient resources for tech]
    BuildBase --> Defend : Under early attack\n[Military threat detected]
    BuildBase --> BuildBase : Continuous build cycle\n[Expand base]

    Gather --> BuildBase : Resources collected\n[Sufficient for next structure]
    Gather --> Scout : Resources low\n[Need map info for expansion]
    Gather --> Retreat : Enemy force overwhelming\n[Military disadvantage]

    Scout --> BuildBase : Scouted area secure\n[Good expansion location found]
    Scout --> Attack : Scouted enemy weak point\n[Opportunity identified]
    Scout --> Defend : Enemy attack spotted\n[Scout detected incoming]
    Scout --> Gather : No threats found\n[Continue economy]

    Attack --> Retreat : Attack failing\n[Force strength < enemy defense]
    Attack --> Gather : Attack successful\n[Resources from destroyed enemies]
    Attack --> Defend : Counter-attack detected\n[Base under threat]
    Attack --> Scout : Need intel on reinforcements

    Defend --> BuildBase : Threat eliminated\n[Resume construction]
    Defend --> Attack : Defense successful\n[Counter-attack opportunity]
    Defend --> Retreat : Defense failing\n[Preserve remaining forces]
    Defend --> Gather : Emergency resource need\n[Replace lost units]

    Retreat --> Defend : Enemy pursues to base\n[Base defense triggered]
    Retreat --> Gather : Safe distance reached\n[Rebuild economy]
    Retreat --> BuildBase : At base & safe\n[Rebuild defenses]

    TechUp --> BuildBase : Tech complete\n[New structures available]
    TechUp --> Defend : Vulnerable during tech\n[Under attack with weak army]
    TechUp --> Attack : Tech advantage achieved\n[Superior units available]
    TechUp --> Gather : Tech resources needed\n[Insufficient for next tier]

    note right of BuildBase
        BuildBase priority order:
        1. Power Plants (maintain surplus)
        2. Resource buildings (Supply Center)
        3. Production (Barracks/Factory)
        4. Defense (Turrets/Bunkers)
        5. Tech buildings (Lab)
        6. Superweapon (endgame)
    end note

    note right of TechUp
        Tech progression path:
        L1 → L2: Unlock advanced units
        L2 → L3: Unlock hero & super units
        Requires: Lab + Workshop + Resources
    end note
```

## Tactical AI State Machine

```mermaid
stateDiagram-v2
    direction TB

    [*] --> Evaluating : Tactical AI activated
    Evaluating --> FormingForce : Need to create attack group
    Evaluating --> Defending : Enemy threat detected\n[Threat level: HIGH]
    Evaluating --> AttackingTarget : Opportunity identified\n[Force advantage confirmed]
    Evaluating --> Flanking : Enemy weak point found\n[Side/rear exposed]

    FormingForce --> Rallying : Units selected for group\n[Composition determined]
    Rallying --> AttackingTarget : Force assembled\n[Sufficient strength]
    Rallying --> Defending : Enemy attacks during assembly\n[Force incomplete]
    Rallying --> Evaluating : Insufficient units\n[Need more production]

    AttackingTarget --> Advancing : Moving to engage
    Advancing --> Engaging : Enemy in range\n[Combat initiated]
    Engaging --> Advancing : Enemy retreating\n[Pursue]
    Engaging --> TacticalRetreat : Force taking heavy losses\n[Strength ratio unfavorable]
    Engaging --> AttackingTarget : Target destroyed\n[Next target selected]

    Defending --> Fortifying : Units to defensive positions
    Fortifying --> Engaging : Enemy in range
    Fortifying --> Repositioning : Flank detected\n[Adjust defense line]
    Repositioning --> Fortifying : New positions held

    Flanking --> Advancing : Flank route clear
    Flanking --> Engaging : Flank attack initiated
    Flanking --> TacticalRetreat : Flank detected by enemy\n[Counter-force approaching]

    TacticalRetreat --> Regrouping : At safe distance
    Regrouping --> Evaluating : Forces regrouped\n[Re-assess situation]
    Regrouping --> Defending : Enemy follows to base

    note right of Evaluating
        Evaluation criteria:
        - Force strength ratio (own vs enemy)
        - Strategic value of targets
        - Terrain advantages
        - Resource situation
        - Time pressure (superweapon timers)
    end note

    note right of FormingForce
        Force composition templates:
        - Balanced: Infantry + Vehicles + Support
        - Armored: Heavy vehicles + Hero
        - Air: Aircraft swarm
        - Naval: Submarines + Surface fleet
        - Rush: Fast units only
    end note
```

## Individual Unit AI State Machine

```mermaid
stateDiagram-v2
    direction TB

    [*] --> Idle_AI : Unit spawned / Command complete
    Idle_AI --> Scanning : Auto-aggro enabled\n[Scan for enemies]
    Idle_AI --> HoldingPosition : Hold position command
    Idle_AI --> Returning : Need to return to rally point

    Scanning --> TargetAcquired : Enemy in aggro range\n[calcShooter() returns target]
    Scanning --> Idle_AI : No enemies found\n[Scan complete]
    Scanning --> MovingToPosition : Patrol waypoint reached\n[Move to next]

    TargetAcquired --> EvaluatingTarget : Target in range
    TargetAcquired --> Pursuing : Target out of range\n[Chase target]
    EvaluatingTarget --> EngagingTarget : Target valid\n[CalcWeaponArmorDamage > 0]
    EvaluatingTarget --> Scanning : Target invalid\n[Ally / Out of range / Dead]

    EngagingTarget --> Firing : Weapon ready\n[Cooldown complete]
    Firing --> Cooldown_AI : Shot fired\n[Weapon cooldown]
    Cooldown_AI --> Firing : Cooldown complete\n[Target still valid]
    Cooldown_AI --> Scanning : Target destroyed\n[Find next target]

    Pursuing --> EngagingTarget : Target in range\n[Stop & fire]
    Pursuing --> Scanning : Target lost\n[No vision on target]
    Pursuing --> Retreating_AI : HP < retreat threshold\n[Unit heavily damaged]

    EngagingTarget --> Retreating_AI : HP < retreatThreshold\n[Self-preservation]
    EngagingTarget --> EngagingTarget : Target switched\n[Higher priority target in range]
    Firing --> Retreating_AI : HP critical\n[Interrupt fire to retreat]

    Retreating_AI --> Scanning : Safe distance reached\n[No longer under attack]
    Retreating_AI --> Retreating_AI : Continue fleeing\n[Enemy still pursuing]

    HoldingPosition --> Scanning : Hold position released\n/ Enemy enters range
    HoldingPosition --> EngagingTarget : Enemy in range\n[Hold position: fire but don't move]

    Returning --> Idle_AI : Rally point reached
    Returning --> Scanning : Enemy in aggro range\n[Interrupt return]

    note right of Retreating_AI
        Retreat logic:
        - Direction: Away from threat
        - Speed: Movement speed boost if ability
        - Rally: Toward nearest friendly structure
        - Threshold: Based on unit type
          * Infantry: 30% HP
          * Vehicle: 25% HP
          * Hero: 20% HP (braver)
    end note

    note right of EngagingTarget
        Target priority:
        1. Units attacking this unit
        2. Units attacking allies nearby
        3. Nearest enemy (by distance)
        4. Lowest HP enemy
        5. Highest threat enemy (heroes > vehicles > infantry)
    end note
```

## AI Decision Weight System

```mermaid
stateDiagram-v2
    direction TB

    state "Decision Matrix" as DecisionMatrix {
        [*] --> CalculateThreats
        CalculateThreats --> CalculateOpportunities
        CalculateOpportunities --> CalculateResources
        CalculateResources --> WeightDecision

        WeightDecision --> BuildBase_W : economy_score > threshold
        WeightDecision --> Attack_W : military_advantage > 1.5
        WeightDecision --> Defend_W : threat_level > threat_threshold
        WeightDecision --> Gather_W : resource_deficit > 0
        WeightDecision --> TechUp_W : tech_opportunity_score > threshold
        WeightDecision --> Scout_W : intel_deficit > threshold

        BuildBase_W --> ExecuteBuild : weight highest
        Attack_W --> ExecuteAttack : weight highest
        Defend_W --> ExecuteDefend : weight highest
        Gather_W --> ExecuteGather : weight highest
        TechUp_W --> ExecuteTech : weight highest
        Scout_W --> ExecuteScout : weight highest

        ExecuteBuild --> CalculateThreats : Action complete\n/ Re-evaluate
        ExecuteAttack --> CalculateThreats : Action complete\n/ Re-evaluate
        ExecuteDefend --> CalculateThreats : Action complete\n/ Re-evaluate
        ExecuteGather --> CalculateThreats : Action complete\n/ Re-evaluate
        ExecuteTech --> CalculateThreats : Action complete\n/ Re-evaluate
        ExecuteScout --> CalculateThreats : Action complete\n/ Re-evaluate
    }

    note right of DecisionMatrix
        AI difficulty levels affect:
        - Decision frequency (update rate)
        - Weight thresholds (how decisive)
        - APM (actions per minute)
        - Micro quality (ability usage)
        - Build order optimization
    end note
```
