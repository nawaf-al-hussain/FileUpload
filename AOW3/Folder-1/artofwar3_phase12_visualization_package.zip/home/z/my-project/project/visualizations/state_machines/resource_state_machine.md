# Resource State Machine — Art of War 3: Global Conflict

Resource gathering lifecycle state machines for Supply Centers, resource crates,
uranium batteries, and the full supply chain from harvesting to depositing.

## Primary Resource Gathering State Machine

```mermaid
stateDiagram-v2
    direction TB

    [*] --> Waiting : Supply truck spawned
    Waiting --> SeekingSource : Resource source available\n[Supply crate / Mine / Uranium deposit]
    Waiting --> Idle_NoSource : No resource sources on map\n[All depleted or unreachable]

    SeekingSource --> MovingToSource : Path found to nearest source
    SeekingSource --> Waiting : No reachable sources\n[Recalculate later]
    SeekingSource --> Idle_NoSource : All sources depleted

    MovingToSource --> Harvesting : Arrived at source\n[In collection range]
    MovingToSource --> SeekingSource : Source depleted en route\n[Find new source]
    MovingToSource --> Retreating_Resource : Enemy attack nearby\n[Truck is unarmed]
    MovingToSource --> Waiting : Path blocked\n[Recalculate]

    Harvesting --> Transporting : Cargo full\n[Max capacity reached]
    Harvesting --> Harvesting : Continue harvesting\n[Not yet full]
    Harvesting --> Waiting : Source depleted mid-harvest\n[Partial cargo]
    Harvesting --> Retreating_Resource : Enemy attack

    Transporting --> Depositing : Arrived at Supply Center\n/ Main base
    Transporting --> Transporting : Moving to deposit point
    Transporting --> Retreating_Resource : Enemy attack during transport
    Transporting --> SeekingSource : Deposit point destroyed\n[Find alternative]

    Depositing --> Waiting : Cargo deposited\n[Resources added to stockpile]
    Depositing --> SeekingSource : Auto-continue harvesting\n[Source still available]
    Depositing --> Idle_NoSource : Source depleted during deposit\n[No more sources]

    Retreating_Resource --> Waiting : Safe distance reached\n[Return to base]
    Retreating_Resource --> Retreating_Resource : Still under fire

    Idle_NoSource --> Waiting : New source spawned\n[Periodic resource respawn]

    note right of Harvesting
        Harvesting rates by source type:
        - Supply Crate: 50 units / 3s
        - Supply Mine: 100 units / 2s (infinite)
        - Uranium Deposit: 25 units / 4s (rare)
        Truck capacity: 200 units
    end note

    note right of Depositing
        Deposit locations:
        - Supply Center (primary)
        - Main Base HQ (fallback)
        - Forward Base (if built)
        Deposit speed: instant on arrival
    end note
```

## Resource Source Lifecycle

```mermaid
stateDiagram-v2
    direction TB

    [*] --> Spawning : Map initialized / Periodic spawn
    Spawning --> Available : Spawn animation complete

    Available --> BeingHarvested : Supply truck assigned\n[Capacity > 0]
    Available --> Depleted : Capacity reaches 0\n[No trucks harvesting]
    Available --> Contested : Enemy unit in area\n[Contested territory]

    BeingHarvested --> Available : Truck leaves / Destroyed\n[Remaining capacity > 0]
    BeingHarvested --> Depleted : Capacity reaches 0\n[All resources extracted]
    BeingHarvested --> Contested : Enemy approaches\n[Harvesting slows / pauses]

    Contested --> Available : Enemy cleared\n[Resume normal access]
    Contested --> Depleted : Capacity 0 during contest\n[Fighting over empty source]

    Depleted --> Respawning : Respawn timer starts\n[Supply crates only, 30-60s]
    Depleted --> PermanentlyDepleted : Mine exhausted\n[Uranium deposit emptied]
    Depleted --> [*] : Cleanup

    Respawning --> Available : Respawn timer complete\n[New resources generated]
    Respawning --> PermanentlyDepleted : Max respawns reached\n[Crates deplete permanently]

    PermanentlyDepleted --> [*] : Visual: rubble / empty

    note right of Spawning
        Resource source types:
        Supply Crate:
          - 500 units total
          - Respawns: Yes (3-5 times)
          - Location: Scattered across map

        Supply Mine:
          - 5000 units total
          - Respawns: No
          - Location: Fixed strategic points

        Uranium Deposit:
          - 1000 units total
          - Respawns: No
          - Location: Rare, contested areas
    end note
```

## Supply Center Production State Machine

```mermaid
stateDiagram-v2
    direction TB

    [*] --> SC_Constructing : AddBuilding()
    SC_Constructing --> SC_Active : BuildingComplete()\n[Powered & operational]
    SC_Constructing --> SC_Destroyed : DestroyPreBuilding()

    SC_Active --> SC_Producing : Auto-produce supply trucks\n[Queue not full]
    SC_Active --> SC_Disabled : No power\n[Production halted]

    SC_Producing --> SC_Active : Truck spawned\n[AddUnit() at rally point]
    SC_Producing --> SC_Paused : Max trucks reached\n[Population cap]
    SC_Producing --> SC_Disabled : Power lost during production

    SC_Paused --> SC_Producing : Truck lost\n[Below population cap]
    SC_Paused --> SC_Disabled : Power lost

    SC_Disabled --> SC_Active : Power restored\n[Resume production]
    SC_Disabled --> SC_Destroyed : HP <= 0

    SC_Active --> SC_Upgrading : Upgrade command
    SC_Upgrading --> SC_Active : Upgrade complete\n[Higher truck cap, faster production]
    SC_Upgrading --> SC_Destroyed : HP <= 0

    SC_Destroyed --> [*] : Cleanup

    note right of SC_Active
        Supply Center levels:
        L1: 2 trucks max, 15s per truck
        L2: 4 trucks max, 12s per truck
        L3: 6 trucks max, 10s per truck

        Cost per truck: None (free production)
        Truck HP: 50 (easily killed)
    end note
```

## Uranium Processing State Machine

```mermaid
stateDiagram-v2
    direction TB

    [*] --> UraniumRaw : Uranium deposit harvested
    UraniumRaw --> UraniumTransporting : Truck loaded with uranium
    UraniumTransporting --> UraniumDepositing : Arrived at processing facility

    UraniumDepositing --> UraniumProcessing : Raw uranium deposited\n[At Workshop / Lab]
    UraniumProcessing --> UraniumReady : Processing complete\n[5s per unit]
    UraniumReady --> UraniumConsumed : Used for:\n[Upgrades / Special units / Superweapon charge]

    UraniumProcessing --> UraniumPaused : No power\n[Processing halted]
    UraniumPaused --> UraniumProcessing : Power restored\n[Resume from pause point]

    note right of UraniumReady
        Uranium uses:
        - Building upgrades (L2, L3)
        - Hero unit production
        - Superweapon charge
        - Special abilities (some heroes)
        - Tech research (advanced)

        Uranium is the rare resource:
        - Limited deposits per map
        - Cannot be generated (only harvested)
        - Strategic importance increases over time
    end note
```

## Supply Chain Flow (Macro View)

```mermaid
stateDiagram-v2
    direction LR

    state "Source" as Source {
        [*] --> CrateAvailable
        CrateAvailable --> MineAvailable
        MineAvailable --> UraniumAvailable
    }

    state "Harvest" as Harvest {
        [*] --> TruckDispatched
        TruckDispatched --> TruckMovingToSource
        TruckMovingToSource --> TruckHarvesting
        TruckHarvesting --> TruckLoaded
    }

    state "Transport" as Transport {
        [*] --> TruckMovingToBase
        TruckMovingToBase --> TruckArriving
    }

    state "Deposit" as Deposit {
        [*] --> UnloadingCargo
        UnloadingCargo --> Stockpiling
        Stockpiling --> AvailableForUse
    }

    state "Consumption" as Consumption {
        [*] --> BuildingConstruction
        BuildingConstruction --> UnitProduction
        UnitProduction --> TechResearch
        TechResearch --> Upgrades
    }

    Source --> Harvest : Truck assigned
    Harvest --> Transport : Cargo full
    Transport --> Deposit : At base
    Deposit --> Consumption : Resources available
    Consumption --> Harvest : Need more resources\n[Dispatch trucks]

    note right of Source
        Resource generation:
        Supply Crates: Periodic respawn
        Supply Mines: Large finite pool
        Uranium: Rare finite deposits
    end note
```

## Resource Economy Balance State Machine

```mermaid
stateDiagram-v2
    direction TB

    [*] --> Balanced : Game starts
    Balanced --> Surplus : Income > Expenditure\n[Resources accumulating]
    Balanced --> Deficit : Expenditure > Income\n[Resources depleting]

    Surplus --> Balanced : Spending increased\n[Queued units/buildings]
    Surplus --> Stockpiling : Sustained surplus\n[Storage approaching max]
    Stockpiling --> Surplus : Storage spent

    Deficit --> Balanced : Income increased\n[More trucks / New sources]
    Deficit --> Critical : Resources near 0\n[< 10% of typical operating]
    Critical --> Stalled : Resources at 0\n[Production queues paused]
    Critical --> Deficit : Some income restored
    Deficit --> Balanced : Economy restructured

    Stalled --> Critical : Any income received\n[Resume partial production]
    Stalled --> Defeated : No income for 60s\n[Cannot rebuild economy]

    note right of Balanced
        Economy health indicators:
        - Green: Surplus (growing)
        - Yellow: Balanced (stable)
        - Orange: Deficit (shrinking)
        - Red: Critical (near zero)
        - Flashing Red: Stalled (zero)
    end note

    note right of Stalled
        When stalled:
        - All production paused
        - No new unit creation
        - No building construction
        - Existing units still fight
        - Auto-harvest continues if trucks exist
        - Player gets warning notification
    end note
```
