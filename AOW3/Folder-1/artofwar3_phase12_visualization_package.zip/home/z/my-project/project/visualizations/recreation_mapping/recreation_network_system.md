# Recreation Mapping: Network System

## Purpose

The Network System handles all multiplayer communication in Art of War 3: Global Conflict, enabling real-time PvP (1v1 and 2v2) battles. It implements a client-server architecture with tick-based synchronization, where the server (one client acts as host, or a dedicated relay) runs the authoritative simulation and clients send input commands. The system manages connection lifecycle, command serialization/deserialization (189+ message types), tick synchronization to ensure all clients simulate the same game state, client-side prediction for responsive input, server reconciliation to correct prediction errors, lag compensation for high-latency players, and disconnection/reconnection handling. The system is critical for competitive play — any desynchronization or unfair advantage from network manipulation would undermine the game's competitive integrity.

## Inputs

- **Player Input**: Local player commands (move, attack, build, produce)
- **Game State**: Current simulation state for delta compression
- **Connection Events**: Client connect, disconnect, timeout, reconnect
- **Matchmaking System**: Match start signal, player roster
- **Tick Timer**: Fixed-rate simulation tick (e.g., 10 Hz)

## Outputs

- **Synchronized Game State**: All clients converge on the same simulation state
- **Command Broadcast**: Player commands relayed to all clients in the match
- **Connection Status**: Network quality metrics (ping, packet loss, jitter)
- **Desync Detection**: Alerts when client states diverge beyond tolerance
- **Replay Data**: All commands logged for match replay

## Dependencies

- **All Simulation Systems**: Network must synchronize every deterministic system
- **Matchmaking System**: For match establishment and player pairing
- **Persistence System**: For match results and statistics
- **GUI System**: For network status display, ping indicator, disconnect warnings

## Internal Logic

The network operates on a **lockstep with prediction** model. The simulation runs at a fixed tick rate (e.g., 10 ticks per second). Each tick, the server collects all player input commands for that tick, packages them into a `TickUpdate` message, and broadcasts to all clients. Clients run local prediction: they immediately apply their own commands before receiving server confirmation, then reconcile when the server update arrives. If the predicted state differs from the server state, a rollback and resimulation occurs for the affected tick range.

Commands are serialized using a binary protocol with message type IDs (189+ types identified). Each message has a header: `[messageTypeId: uint16][tickNumber: uint32][payloadSize: uint16]` followed by the serialized payload. Commands include: `MoveCommand`, `AttackCommand`, `BuildCommand`, `ProduceCommand`, `UpgradeCommand`, `AbilityCommand`, and many more. The protocol supports delta compression for state snapshots — only changed fields are transmitted.

Lag compensation uses a "jump-ahead" buffer: the server maintains a history of game states and, when processing a command from a lagging client, applies it at the tick it was generated (not the current tick). This prevents high-ping players from being disadvantaged but creates a slight delay for other players seeing the lagging player's actions.

Desync detection uses state hashing: each tick, all clients compute a hash of their full game state (unit positions, health, resources). These hashes are compared — any divergence triggers a desync alert and, in competitive mode, a match invalidation.

## Pseudocode

```
class NetworkSystem:
    connection: NetworkConnection  // WebSocket or TCP
    tickRate: int = 10  // Ticks per second
    currentTick: uint32
    localPlayerId: PlayerID
    isServer: bool
    predictedStates: RingBuffer<GameState>  // For rollback
    commandBuffer: Map<TickNumber, List<Command>>
    pendingCommands: List<Command>

    function sendCommand(command):
        // Client: immediately predict locally, then send to server
        command.tick = currentTick + 1
        command.playerId = localPlayerId
        pendingCommands.add(command)
        applyCommandLocally(command)  // Prediction
        serializeAndSend(command)

    function onReceiveTickUpdate(update: TickUpdate):
        // Client: reconcile with server state
        if update.tick <= currentTick:
            return  // Stale update, ignore
        // Compare predicted state with server state
        serverState = deserializeState(update.stateDelta)
        predictedState = predictedStates.get(update.tick)
        if predictedState.hash != serverState.hash:
            // Desync detected — rollback and resimulate
            rollbackTo(update.tick - 1)
            applyServerState(serverState)
            resimulateFrom(update.tick)
        currentTick = update.tick
        // Apply confirmed commands
        for cmd in update.confirmedCommands:
            if cmd.playerId != localPlayerId:
                applyCommandLocally(cmd)

    function serverTick():
        // Server: collect commands, advance simulation, broadcast
        if not isServer:
            return
        tickCommands = collectCommandsForTick(currentTick)
        gameState = simulateOneTick(tickCommands)
        stateDelta = computeDelta(lastBroadcastState, gameState)
        tickUpdate = TickUpdate(
            tick = currentTick,
            stateDelta = stateDelta,
            confirmedCommands = tickCommands
        )
        broadcastToClients(tickUpdate)
        lastBroadcastState = gameState.clone()
        currentTick++

    function applyCommandLocally(command):
        // Predictive execution
        predictedStates[currentTick + 1] = captureState()
        switch command.type:
            case MOVE:
                unitSystem.moveUnit(command.unitId, command.target)
            case ATTACK:
                combatSystem.attackTarget(command.unitId, command.targetId)
            case BUILD:
                buildingSystem.requestBuild(command.buildingType, command.position)
            // ... all 189+ command types

    function rollbackTo(tick):
        // Restore game state from predicted states buffer
        state = predictedStates.get(tick)
        restoreState(state)

    function resimulateFrom(tick):
        // Re-apply all commands from tick to current
        for t in range(tick, currentTick):
            commands = commandBuffer.get(t)
            for cmd in commands:
                applyCommandLocally(cmd)

// Message serialization
class NetworkSerializer:
    function serialize(command) -> byte[]:
        buffer = ByteWriter()
        buffer.writeUint16(command.typeId)  // 189+ types
        buffer.writeUint32(command.tick)
        buffer.writeUint8(command.playerId)
        buffer.writePayload(command.serializePayload())
        return buffer.toByteArray()

    function deserialize(data: byte[]) -> Command:
        reader = ByteReader(data)
        typeId = reader.readUint16()
        tick = reader.readUint32()
        playerId = reader.readUint8()
        command = CommandFactory.create(typeId)
        command.deserializePayload(reader)
        command.tick = tick
        command.playerId = playerId
        return command
```

## Modern Implementation Recommendations

| Approach | Recommendation |
|----------|---------------|
| **Best Overall** | **Unity 2023 + Netcode for GameObjects or Fusion** — Fusion provides tick-based synchronization with prediction and rollback out of the box. Use `NetworkRunner` for authoritative server mode. |
| **Dedicated Server** | **Unity DOTS + Netcode for Entities** — Purpose-built for server-authoritative ECS games. `NetworkTick` system, `ICommandData` for inputs, automatic prediction/rollback. |
| **Alternative** | **Godot 4 + custom WebSocket server** — Use `WebSocketMultiplayerPeer` for transport. Implement lockstep logic in GDScript/C#. More work but full control. |
| **Best Performance** | **Rust + Bevy + ggrs crate** — `ggrs` (good game rollback system) provides P2P rollback netcode. Bevy ECS for simulation. Deterministic by design. Ideal for fighting games and RTS. |
| **Scalable Backend** | **Nakama server + Unity client** — Nakama handles matchmaking, rooms, and relay. Custom RPC for game logic. Scales to thousands of concurrent matches. |

**Key patterns to adopt:**
- Fixed tick rate for simulation (decouple from render frame rate)
- Client-side prediction with server reconciliation — essential for responsive input
- State hashing for desync detection — compare hashes every N ticks
- Delta compression for state updates — don't send full state every tick
- Command-based networking (send inputs, not states) for bandwidth efficiency
- Rollback buffer (ring buffer of last N game states) for prediction correction
- Binary serialization protocol with typed message IDs — never use JSON in production
- Reconnect with state catch-up: send full state snapshot, then stream missed commands
