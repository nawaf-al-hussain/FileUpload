# Recreation Mapping: Matchmaking System

## Purpose

The Matchmaking System pairs players for competitive multiplayer matches in Art of War 3: Global Conflict. It supports 1v1, 2v2, Tournament, and Clan War game modes. The system uses an ELO-based rating system to ensure fair matches, implements matchmaking queues with configurable parameters (search range expansion over time, ping-based region filtering), handles party formation for 2v2, manages tournament bracket generation and progression, and coordinates with the Clan System for clan war matchmaking. The system must balance match quality (skill similarity) with wait times (queue duration), gracefully handling low-population scenarios by gradually expanding search criteria.

## Inputs

- **Player Requests**: Queue join/leave, mode selection, party invites
- **Player Ratings**: ELO ratings per game mode (1v1, 2v2, tournament)
- **Player Region**: Geographic region for latency-based matching
- **Player Status**: Online, in-queue, in-match, idle
- **Party State**: 2v2 team composition
- **Clan Data**: Clan membership, clan war eligibility, clan ratings
- **Server Capacity**: Available dedicated server slots for match hosting

## Outputs

- **Match Assignments**: Player pairs/teams assigned to a match with server connection details
- **Rating Updates**: Post-match ELO adjustments based on results
- **Queue Statistics**: Wait time estimates, player counts in queue
- **Tournament Brackets**: Match pairings for tournament progression
- **Match History**: Recorded match outcomes for player profiles

## Dependencies

- **Network System**: For connection establishment after match creation
- **Persistence System**: For rating storage and match history
- **Clan System**: For clan war matchmaking
- **GUI System**: For queue UI, rating display, match notifications

## Internal Logic

The core matchmaking algorithm uses an ELO rating system with K-factor adjustments. Each player has a rating (starting at 1000) that increases on wins and decreases on losses, scaled by the expected outcome. The matchmaking queue groups players by game mode and region. When a player joins the queue, the system searches for opponents within an initial rating range (e.g., ±50 ELO). If no match is found within a time window, the range expands (e.g., +25 ELO every 10 seconds) until a maximum range is reached.

For 2v2, the system forms teams by pairing two individual players or matching pre-formed parties. Team ELO is calculated as the average of both players' 2v2 ratings. The system prioritizes matching pre-formed parties against other pre-formed parties before matching parties against solo-queued pairs.

Tournament mode uses a single-elimination bracket. Players register during a tournament window, and the bracket is seeded based on ratings (highest vs lowest, etc.). Each round proceeds on a schedule, and winners advance while losers are eliminated.

Clan Wars match entire clans against each other. Clan ELO is the average of participating members' ratings. The match is a series of 1v1 duels between clan members, and the clan with more duel wins takes the war.

## Pseudocode

```
class MatchmakingSystem:
    queues: Map<GameMode, MatchmakingQueue>
    ratingSystem: RatingSystem

    function joinQueue(player, mode, party=null):
        if mode == PVP_1V1:
            queues[mode].addEntry(player, player.ratings[mode])
        elif mode == PVP_2V2:
            if party:
                teamRating = avg(party.players.map(p => p.ratings[PVP_2V2]))
                queues[mode].addEntry(party, teamRating, isPreFormed=true)
            else:
                queues[mode].addSoloPlayer(player, player.ratings[PVP_2V2])

    function processQueue(mode, deltaTime):
        queue = queues[mode]
        // Expand search ranges over time
        for entry in queue.entries:
            entry.searchRange += SEARCH_EXPANSION_RATE * deltaTime
            entry.searchRange = min(entry.searchRange, MAX_SEARCH_RANGE)
        // Try to find matches
        matched = findMatches(queue)
        for match in matched:
            createMatch(match)
            removeMatchedEntries(queue, match)

    function findMatches(queue) -> List<Match>:
        matches = []
        // Sort by wait time (longest first)
        sorted = queue.entries.sortBy(e => -e.waitTime)
        for entry in sorted:
            if entry.isMatched:
                continue
            // Find best opponent within search range
            best = null
            bestRatingDiff = infinity
            for candidate in sorted:
                if candidate == entry or candidate.isMatched:
                    continue
                if candidate.isPreFormed != entry.isPreFormed:
                    continue  // Prefer pre-formed vs pre-formed
                ratingDiff = abs(entry.rating - candidate.rating)
                if ratingDiff <= entry.searchRange and ratingDiff < bestRatingDiff:
                    best = candidate
                    bestRatingDiff = ratingDiff
            if best:
                matches.append(Match(entry, best))
                entry.isMatched = true
                best.isMatched = true
        return matches

    function createMatch(match):
        server = allocateServer(match.players)
        for player in match.players:
            notifyPlayer(player, MATCH_FOUND, server.connectionInfo)

    function onMatchComplete(result: MatchResult):
        // Update ELO ratings
        for player in result.players:
            oldRating = player.ratings[result.mode]
            expectedScore = calculateExpectedScore(player, result.opponent)
            actualScore = result.isWinner(player) ? 1.0 : 0.0
            newRating = oldRating + K_FACTOR * (actualScore - expectedScore)
            player.ratings[result.mode] = round(newRating)
            persistenceSystem.saveRating(player, result.mode, newRating)

class RatingSystem:
    function calculateExpectedScore(playerA, playerB) -> float:
        return 1.0 / (1.0 + pow(10, (playerB.rating - playerA.rating) / 400.0))
```

## Modern Implementation Recommendations

| Approach | Recommendation |
|----------|---------------|
| **Best Overall** | **Nakama Server (Go)** — Built-in matchmaking, leaderboards, and tournament systems. Define matchmaking filters and ELO-based ranking. Scales horizontally. Unity SDK available. |
| **Custom Backend** | **Node.js + Redis + PostgreSQL** — Redis for real-time queue state and pub/sub. PostgreSQL for persistent ratings. Socket.io for client communication. |
| **Enterprise Scale** | **Agones (Kubernetes) + Open Match** — Google's open-source matchmaking framework. Agones manages dedicated game servers on K8s. Open Match handles matchmaking logic. |
| **Lightweight** | **Godot 4 built-in multiplayer + custom server** — Use Godot's `SceneMultiplayer` API. Implement matchmaking in a simple Python/Go relay server. |

**Key patterns to adopt:**
- ELO (or Glicko-2) for rating — Glicko-2 adds rating deviation for more accurate matching
- Search range expansion over time — trade match quality for wait time
- Region-based filtering before rating matching — latency matters in RTS
- Pre-formed party priority matching — parties vs parties first, then fill with solos
- Match confirmation flow — both players must accept before server allocates
- Rating confidence intervals — new players have wide ranges that narrow with more games
- Graceful degradation — if queue is empty for too long, offer AI opponent option
