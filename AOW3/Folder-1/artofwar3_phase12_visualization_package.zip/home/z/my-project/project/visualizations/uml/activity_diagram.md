# Art of War 3: Global Conflict — Activity Diagrams

> Behavioral diagrams for key game processes, derived from IL2CPP method flow analysis.

---

## (a) Player Session: App Launch → Battle

The complete flow from cold start through authentication, meta-game navigation, matchmaking, and into a battle.

```mermaid
flowchart TD
    Start([🚀 App Launched]) --> InitZenject[Initialize Zenject DI Container]
    InitZenject --> InitManagers[Initialize Managers<br/>ConfigManager, ResourceManager<br/>FirebaseManager, DatabaseManager]
    InitManagers --> LoadConfig[Load Game Config<br/>via Addressables]
    LoadConfig --> InitFirebase[Initialize Firebase<br/>Analytics + Crashlytics]
    InitFirebase --> CheckToken{Stored<br/>Session Token?}

    CheckToken -->|Yes| ValidateToken[Send CSAuthRequest<br/>with stored token]
    CheckToken -->|No| ShowLogin[Show Login Screen<br/>Google / Facebook / Guest]

    ValidateToken --> TokenValid{Token<br/>Valid?}
    TokenValid -->|Yes| LoadPlayer[Load Player Data<br/>from Main Server]
    TokenValid -->|No| ShowLogin

    ShowLogin --> SocialAuth[Player selects<br/>auth method]
    SocialAuth --> FirebaseAuth[Firebase Authentication<br/>Get Firebase Token]
    FirebaseAuth --> ServerAuth[Send CSAuthRequest<br/>with Firebase token]
    ServerAuth --> NewPlayer{New<br/>Player?}
    NewPlayer -->|Yes| CreateAccount[Create Player Account<br/>in Database]
    NewPlayer -->|No| LoadPlayer
    CreateAccount --> InitTutorial[Initialize Tutorial State]
    InitTutorial --> LoadPlayer

    LoadPlayer --> LoadResources[Load Player Resources<br/>Workshop, Skills, Clan status]
    LoadResources --> MainScene[Enter Main Scene<br/>AOW_Assets.Scenes.Main]

    MainScene --> ShowMainMenu[Show Main Menu<br/>Play / Clan / Workshop / Chat]
    ShowMainMenu --> PlayerChoice{Player<br/>Action}

    PlayerChoice -->|Play| SelectFaction[Select Faction<br/>Confederation / Resistance]
    PlayerChoice -->|Workshop| WorkshopFlow[Workshop Flow<br/>Unit Upgrades]
    PlayerChoice -->|Clan| ClanFlow[Clan Flow<br/>Management / Wars]
    PlayerChoice -->|Chat| ChatFlow[Chat Flow<br/>Messaging]
    PlayerChoice -->|Settings| SettingsFlow[Settings Flow<br/>Audio / Graphics / Account]

    WorkshopFlow --> ShowMainMenu
    ClanFlow --> ShowMainMenu
    ChatFlow --> ShowMainMenu
    SettingsFlow --> ShowMainMenu

    SelectFaction --> SelectMode{Game<br/>Mode}
    SelectMode -->|PvP| StartPvPMatchmaking[Start PvP Matchmaking<br/>ELO-based queue]
    SelectMode -->|PvE| SelectMission[Select PvE Mission<br/>Campaign / Co-op]
    SelectMode -->|Custom| CreateCustom[Create/Join Custom Room]

    StartPvPMatchmaking --> WaitQueue[Waiting in Queue<br/>SCMatchmakingPending]
    WaitQueue --> MatchFound{Match<br/>Found?}
    MatchFound -->|No| CancelCheck{Cancel?<br/>Timeout?}
    CancelCheck -->|Cancel| ShowMainMenu
    CancelCheck -->|Timeout| ShowQueueTimeout[Show Queue Timeout<br/>Retry / Change Mode]
    ShowQueueTimeout --> ShowMainMenu
    MatchFound -->|Yes| ShowMatchFound[Show "Match Found!"<br/>Opponent info]

    ShowMatchFound --> AcceptCheck{Player<br/>Accepts?}
    AcceptCheck -->|Decline| ShowMainMenu
    AcceptCheck -->|Accept| BattleLoading[Enter BattleLoading Scene<br/>CheckConnectionToBattleHosts]

    SelectMission --> LoadMission[BattleLoading for PvE]
    CreateCustom --> WaitForPlayers[Wait for Players<br/>in Custom Room]
    WaitForPlayers --> AllReady{All<br/>Ready?}
    AllReady -->|No| WaitForPlayers
    AllReady -->|Yes| BattleLoading

    BattleLoading --> ConnectToHost[Connect to Battle Server<br/>CSLoginToBattle → CSBattleLogon]
    ConnectToHost --> LoadBattleScene[Load Battle Scene<br/>AOW_Assets.Scenes.Battle]
    LoadBattleScene --> BattleInit[BattleInitialize<br/>Create Map + Spawn Units]
    BattleInit --> BattleStart([⚔️ Battle Started])

    style Start fill:#3498db,stroke:#2471a3,color:#fff
    style BattleStart fill:#e74c3c,stroke:#c0392b,color:#fff
    style MainScene fill:#2ecc71,stroke:#27ae60,color:#fff
    style BattleLoading fill:#f39c12,stroke:#d68910,color:#fff
```

---

## (b) Resource Gathering Cycle

The economic loop of gathering, storing, and spending resources in battle.

```mermaid
flowchart TD
    Start([💰 Resource Cycle Start]) --> CheckSources{Resource<br/>Source Type}

    CheckSources -->|Supply Point| FindSupply[Find Supply Point<br/>on Battle Map]
    CheckSources -->|Passive Income| PassiveTick[Passive Income Tick<br/>Base + building bonuses]
    CheckSources -->|Supply Box| LocateBox[Locate Supply Box<br/>on minimap]
    CheckSources -->|Building Production| CheckProducer[Check Production Building<br/>Refinery / Factory]

    FindSupply --> SendUnit[Send Unit to<br/>Supply Point]
    SendUnit --> UnitAtSupply{Unit<br/>Arrived?}
    UnitAtSupply -->|No| MoveUnit[Unit Moving<br/>Pathfinding active]
    MoveUnit --> UnitAtSupply
    UnitAtSupply -->|Yes| BeginGather[Begin Gathering<br/>GatherRate * delta]
    BeginGather --> GatherTick[Gather Tick<br/>AddResource(type, amount)]
    GatherTick --> SupplyDepleted{Supply<br/>Depleted?}
    SupplyDepleted -->|No| GatherTick
    SupplyDepleted -->|Yes| FindNewSupply[Find New Supply Point<br/>or Return to Base]

    PassiveTick --> AddToPool[Add to Resource Pool<br/>AddResource(type, amount)]
    AddToPool --> UpdateUI[Update Resource Bar<br/>in Battle HUD]

    LocateBox --> SendCollector[Send Unit to<br/>Collect Supply Box]
    SendCollector --> ArriveAtBox{Unit<br/>Arrived?}
    ArriveAtBox -->|No| MovingToBox[Unit Moving to Box]
    MovingToBox --> ArriveAtBox
    ArriveAtBox -->|Yes| CollectBox[CollectSupplyBox<br/>AddResource(type, box.amount)]
    CollectBox --> AddToPool

    CheckProducer --> ProducerActive{Building<br/>Active?}
    ProducerActive -->|No| ActivateProducer[Activate / Complete Building]
    ActivateProducer --> WaitActivation[Wait for Building<br/>Construction Complete]
    WaitActivation --> ProducerActive
    ProducerActive -->|Yes| ProduceTick[Production Tick<br/>delta * productionRate]
    ProduceTick --> CheckCapacity{Storage<br/>Capacity?}
    CheckCapacity -->|Full| WaitForSpend[Wait for<br/>Resources to be Spent]
    WaitForSpend --> ProduceTick
    CheckCapacity -->|Available| AddToPool

    AddToPool --> CheckSupplyState[ChangeSupplyState<br/>if threshold crossed]
    CheckSupplyState --> SpendDecision{Player<br/>Wants to Spend?}

    SpendDecision -->|Build| CheckBuildCost[CalculateCost for Building]
    SpendDecision -->|Train| CheckTrainCost[CalculateCost for Unit Training]
    SpendDecision -->|Upgrade| CheckUpgradeCost[CalculateCost for Upgrade]
    SpendDecision -->|No| ContinueGather[Continue Gathering]

    CheckBuildCost --> CanAffordBuild{Can<br/>Afford?}
    CanAffordBuild -->|No| ShowInsufficient[Show Insufficient<br/>Resources Warning]
    ShowInsufficient --> ContinueGather
    CanAffordBuild -->|Yes| SpendBuild[SpendResources<br/>SetCosts + Deduct]
    SpendBuild --> BuildAction[Execute Building Construction]

    CheckTrainCost --> CanAffordTrain{Can<br/>Afford?}
    CanAffordTrain -->|No| ShowInsufficient
    CanAffordTrain -->|Yes| SpendTrain[SpendResources<br/>for Unit Training]
    SpendTrain --> TrainAction[Add Unit to<br/>Training Queue]

    CheckUpgradeCost --> CanAffordUpgrade{Can<br/>Afford?}
    CanAffordUpgrade -->|No| ShowInsufficient
    CanAffordUpgrade -->|Yes| SpendUpgrade[SpendResources<br/>for Upgrade]
    SpendUpgrade --> UpgradeAction[Execute Upgrade<br/>ApplyUnitTypeModification]

    BuildAction --> UpdateUI
    TrainAction --> UpdateUI
    UpgradeAction --> UpdateUI
    ContinueGather --> CheckSources

    style Start fill:#f39c12,stroke:#d68910,color:#fff
    style AddToPool fill:#27ae60,stroke:#1e8449,color:#fff
    style ShowInsufficient fill:#e74c3c,stroke:#c0392b,color:#fff
```

---

## (c) Combat Resolution

The detailed combat loop from engagement detection through damage calculation and resolution.

```mermaid
flowchart TD
    Start([⚔️ Combat Initiated]) --> DetectTarget[Detect Enemy in<br/>Weapon Range]
    DetectTarget --> ValidateTarget{Valid<br/>Target?}

    ValidateTarget -->|Out of Range| CloseDistance[Move Unit Closer<br/>Pathfinding to Target]
    CloseDistance --> InRangeCheck{In Range<br/>Now?}
    InRangeCheck -->|No| CloseDistance
    InRangeCheck -->|Yes| ValidateTarget
    ValidateTarget -->|FOW Hidden| CannotEngage[Cannot Engage<br/>Target not visible]
    ValidateTarget -->|Valid| CheckFiringArc{In Firing<br/>Arc?}

    CheckFiringArc -->|No| RotateUnit[Rotate Unit/Turret<br/>to face target]
    RotateUnit --> CheckFiringArc
    CheckFiringArc -->|Yes| CheckCooldown{Weapon<br/>Ready?}

    CheckCooldown -->|Reloading| WaitCooldown[Wait for<br/>Cooldown Timer]
    WaitCooldown --> CheckCooldown
    CheckCooldown -->|Ready| CalcShooter[calcShooter<br/>shooter accuracy + modifiers]

    CalcShooter --> CalcDistance[calcFireDistanceMisc<br/>distance falloff calculation]
    CalcDistance --> CheckHit{Hit<br/>Roll?}

    CheckHit -->|Miss| FireMiss[Fire Visual Effect<br/>Miss Animation]
    FireMiss --> ResetCooldown1[Reset Weapon Cooldown]
    ResetCooldown1 --> CheckMoreTargets{More<br/>Targets?}
    CheckMoreTargets -->|Yes| DetectTarget
    CheckMoreTargets -->|No| Idle([Unit Idle])

    CheckHit -->|Hit| DetermineArmor[Get Target Armor Type<br/>Light / Medium / Heavy / SuperHeavy]
    DetermineArmor --> CalcDamage[CalculateWeaponArmorDamage<br/>weapon damage vs armor type]

    CalcDamage --> ArmorCalc{Armor<br/>Type?}
    ArmorCalc -->|Light| LightDmg[Apply Light Armor Multiplier<br/>High damage taken]
    ArmorCalc -->|Medium| MediumDmg[CreateDamageForMediumArmor<br/>Standard damage]
    ArmorCalc -->|Heavy| HeavyDmg[WeaponDamageHeavyValue<br/>Reduced damage]
    ArmorCalc -->|SuperHeavy| SuperHeavyDmg[SuperHeavy Armor Calc<br/>Minimal damage]

    LightDmg --> ApplyDamage
    MediumDmg --> ApplyDamage
    HeavyDmg --> ApplyDamage
    SuperHeavyDmg --> ApplyDamage

    ApplyDamage[Apply Damage to Target<br/>Target.Health -= finalDamage]
    ApplyDamage --> CheckKill{Target<br/>Destroyed?}

    CheckKill -->|No| CheckTargetAlive{Target Still<br/>in Range?}
    CheckTargetAlive -->|Yes| ResetCooldown2[Reset Weapon Cooldown]
    ResetCooldown2 --> CheckCooldown
    CheckTargetAlive -->|No| CheckMoreTargets2{More<br/>Targets?}
    CheckMoreTargets2 -->|Yes| DetectTarget
    CheckMoreTargets2 -->|No| Idle

    CheckKill -->|Yes| DestroyEntity[DestroyUnit / Destroy Building<br/>Remove from map]
    DestroyEntity --> GrantXP[Grant Experience<br/>to killing unit]
    GrantXP --> CheckHero{Killing Unit<br/>is Hero?}
    CheckHero -->|Yes| CheckHeroLevel{Hero<br/>Level Up?}
    CheckHeroLevel -->|Yes| LevelUpHero[Hero Level Up<br/>GainAbility / Upgrade]
    CheckHeroLevel -->|No| CheckMoreTargets3{More<br/>Targets?}
    CheckHero -->|No| CheckMoreTargets3
    LevelUpHero --> CheckMoreTargets3

    CheckMoreTargets3 -->|Yes| DetectTarget
    CheckMoreTargets3 -->|No| Idle

    CheckKill -->|Building| DestroyBuilding[Building Destroyed<br/>Deconstruct effects]
    DestroyBuilding --> UpdateMap[Update Pathfinding Grid<br/>Clear footprint]
    UpdateMap --> CheckMoreTargets3

    style Start fill:#e74c3c,stroke:#c0392b,color:#fff
    style ApplyDamage fill:#f39c12,stroke:#d68910,color:#fff
    style DestroyEntity fill:#8e44ad,stroke:#6c3483,color:#fff
    style Idle fill:#95a5a6,stroke:#7f8c8d,color:#fff
```

---

## (d) Matchmaking Flow

The matchmaking system from queue entry through match creation and battle assignment.

```mermaid
flowchart TD
    Start([🎯 Start Matchmaking]) --> SelectParams[Select Match Parameters<br/>Mode: PvP / PvE / Ranked<br/>Faction: Confederation / Resistance]
    SelectParams --> SendRequest[Send CSMatchmakingRequest<br/>authToken + rating + faction]

    SendRequest --> ServerReceive[Main Server Receives<br/>Matchmaking Request]
    ServerReceive --> GetRating[Get Player ELO Rating<br/>from Player Database]
    GetRating --> CalcRange[Calculate Match Range<br/>±200 ELO for search]
    CalcRange --> SearchQueue{Matching Player<br/>Found in Queue?}

    SearchQueue -->|Yes| EvaluateMatch[Evaluate Match Quality<br/>Rating gap + latency + wait time]
    SearchQueue -->|No| AddToQueue[Add Player to<br/>Matchmaking Queue in Redis]

    AddToQueue --> ExpandRange[Gradually Expand<br/>Search Range<br/>±200 → ±400 → ±600]
    ExpandRange --> WaitTick[Wait 5 seconds]
    WaitTick --> SearchQueue

    EvaluateMatch --> QualityCheck{Match Quality<br/>Acceptable?}
    QualityCheck -->|No| AddToQueue
    QualityCheck -->|Yes| CreateMatch[Create Match<br/>Assign Battle ID]

    CreateMatch --> SelectBattleServer[Select Battle Server<br/>CheckConnectionToBattleHosts logic]
    SelectBattleServer --> ServerCheck{Server<br/>Available?}

    ServerCheck -->|No| QueueServer[Queue for<br/>Next Available Server]
    QueueServer --> WaitForServer[Wait for Server Slot<br/>Auto-scaling trigger]
    WaitForServer --> ProvisionServer[Provision New<br/>Battle Server Instance]
    ProvisionServer --> ServerReady[Server Ready]
    ServerReady --> ReserveServer

    ServerCheck -->|Yes| ReserveServer[Reserve Battle Server<br/>for this match]
    ReserveServer --> NotifyPlayers[Send SCMatchFound<br/>to both players]

    NotifyPlayers --> Player1Response{Player 1<br/>Accepts?}
    Player1Response -->|Decline| CancelForP1[Cancel for Player 1<br/>Player 2 back in queue]
    CancelForP1 --> RequeueP2[Re-queue Player 2<br/>with priority]
    RequeueP2 --> SearchQueue

    Player1Response -->|Accept| Player2Response{Player 2<br/>Accepts?}
    Player2Response -->|Decline| CancelForP2[Cancel for Player 2<br/>Player 1 back in queue]
    CancelForP2 --> RequeueP1[Re-queue Player 1<br/>with priority]
    RequeueP1 --> SearchQueue

    Player2Response -->|Accept| BothAccepted[Both Players Accepted<br/>Match Confirmed]
    BothAccepted --> LoadBattle[Send Battle Server Info<br/>host, port, battleId, authToken]
    LoadBattle --> Player1Connect[Player 1: CSLoginToBattle<br/>+ CSBattleLogon]
    LoadBattle --> Player2Connect[Player 2: CSLoginToBattle<br/>+ CSBattleLogon]

    Player1Connect --> BothConnected{Both<br/>Connected?}
    Player2Connect --> BothConnected
    BothConnected -->|No| WaitConnect[Wait for Connection<br/>30s timeout]
    WaitConnect --> ConnectTimeout{Timeout?}
    ConnectTimeout -->|Yes| AbortMatch[Abort Match<br/>Disconnect connected player]
    AbortMatch --> RequeueConnected[Re-queue Connected Player]
    ConnectTimeout -->|No| BothConnected
    BothConnected -->|Yes| StartBattle[Battle Server Initializes<br/>BattleInitialize + Map + Units]
    StartBattle --> BattleBegin([⚔️ Battle Begin!])

    style Start fill:#3498db,stroke:#2471a3,color:#fff
    style BattleBegin fill:#e74c3c,stroke:#c0392b,color:#fff
    style CreateMatch fill:#27ae60,stroke:#1e8449,color:#fff
    style AbortMatch fill:#8e44ad,stroke:#6c3483,color:#fff
```

---

## (e) Building Upgrade Process

The flow for upgrading buildings from one level to the next, including prerequisites and state transitions.

```mermaid
flowchart TD
    Start([🏗️ Upgrade Initiated]) --> SelectBuilding[Player Selects<br/>Existing Building]
    SelectBuilding --> GetCurrentLevel[Get Building Current Level<br/>GetBuildingLevelName]

    GetCurrentLevel --> CalcNextLevel[Calculate Building Level State<br/>CalculateBuildingLevelState]
    CalcNextLevel --> MaxLevelCheck{Already<br/>Max Level?}

    MaxLevelCheck -->|Yes| ShowMaxLevel[Show "Max Level Reached"<br/>Cannot upgrade further]
    ShowMaxLevel --> Done([🛑 Upgrade Complete])

    MaxLevelCheck -->|No| GetNextLevel[Get Next Level Requirements<br/>GetBuildingLevelName]

    GetNextLevel --> CheckPrereqs{Prerequisites<br/>Met?}
    CheckPrereqs -->|Tech Lab Required| CheckTech{Tech Lab<br/>Built?}
    CheckTech -->|No| ShowPrereq[Show Prerequisite<br/>Missing Warning]
    ShowPrereq --> Done
    CheckTech -->|Yes| CheckPrereqs2{Other<br/>Prerequisites?}
    CheckPrereqs -->|None| CheckResources

    CheckPrereqs2 -->|Yes| CheckOtherPrereq[Check Additional<br/>Prerequisites]
    CheckOtherPrereq --> CheckPrereqs
    CheckPrereqs2 -->|No| CheckResources

    CheckResources[Calculate Upgrade Cost<br/>SetCosts + CalculateCost] --> AffordCheck{Can<br/>Afford?}

    AffordCheck -->|No| ShowCost[Show Upgrade Cost<br/>Highlight missing resources]
    ShowCost --> WaitOrCancel{Wait for<br/>Resources / Cancel?}
    WaitOrCancel -->|Cancel| Done
    WaitOrCancel -->|Wait| CheckResources

    AffordCheck -->|Yes| ConfirmUpgrade[Player Confirms<br/>Upgrade]
    ConfirmUpgrade --> DeductResources[SpendResources<br/>Deduct all costs]

    DeductResources --> CheckBuildingState{Building<br/>State?}

    CheckBuildingState -->|Idle| StartUpgrade[Start Upgrade Process<br/>Begin construction timer]
    CheckBuildingState -->|Producing| PauseProduction[Pause Current Production<br/>Queue units paused]
    PauseProduction --> StartUpgrade
    CheckBuildingState -->|Under Attack| WarnPlayer{Continue<br/>Under Fire?}
    WarnPlayer -->|No| Done
    WarnPlayer -->|Yes| StartUpgrade

    StartUpgrade --> SetUpgradeTimer[Set Upgrade Timer<br/>Level-specific duration]
    SetUpgradeTimer --> ShowProgress[Show Upgrade Progress<br/>Construction bar on building]

    ShowProgress --> UpgradeTick[Upgrade Tick<br/>Progress += delta / upgradeTime]

    UpgradeTick --> ProgressCheck{Upgrade<br/>Complete?}
    ProgressCheck -->|No| CheckInterrupt{Building<br/>Destroyed?}

    CheckInterrupt -->|Yes| BuildingLost[Building Destroyed<br/>Upgrade Lost]
    BuildingLost --> RefundCheck{Partial<br/>Refund?}
    RefundCheck -->|Yes| PartialRefund[Return 50% of<br/>spent resources]
    RefundCheck -->|No| NoRefund[No Refund<br/>Resources lost]
    PartialRefund --> Done
    NoRefund --> Done

    CheckInterrupt -->|No| UpgradeTick

    ProgressCheck -->|Yes| ApplyUpgrade[BuildingComplete<br/>Level += 1]

    ApplyUpgrade --> UpdateStats[Update Building Stats<br/>HP, Armor, Production Speed]
    UpdateStats --> UnlockNew{New<br/>Unlocks?}
    UnlockNew -->|Yes| UnlockFeatures[Unlock New Features<br/>Units / Abilities / Weapons]
    UnlockNew -->|No| ResumeCheck
    UnlockFeatures --> ResumeCheck{Was<br/>Producing?}

    ResumeCheck -->|Yes| ResumeProduction[Resume Paused<br/>Production Queue]
    ResumeCheck -->|No| ActivateBuilding[Activate Upgraded Building<br/>New visual model]

    ResumeProduction --> ActivateBuilding
    ActivateBuilding --> UpdateMap[Update Pathfinding<br/>if footprint changed]
    UpdateMap --> NotifyServer[Notify Server<br/>SCBuildingUpgrade]
    NotifyServer --> Success([✅ Upgrade Successful!])

    style Start fill:#3498db,stroke:#2471a3,color:#fff
    style Success fill:#27ae60,stroke:#1e8449,color:#fff
    style Done fill:#95a5a6,stroke:#7f8c8d,color:#fff
    style BuildingLost fill:#e74c3c,stroke:#c0392b,color:#fff
    style ApplyUpgrade fill:#f39c12,stroke:#d68910,color:#fff
```

---

## Explanation

These five activity diagrams capture the **end-to-end behavioral flows** of Art of War 3:

### (a) Player Session (App Launch → Battle)
This is the **happiest path** through the game. Key decision points:
- **Authentication**: Forks between stored token validation (fast path) and social login (slow path). Firebase handles the auth delegation.
- **Meta-game branching**: The Main Scene is a hub — players can spend time in Workshop, Clan, Chat, or Settings before entering matchmaking.
- **Game mode selection**: PvP (ELO matchmaking), PvE (mission selection), and Custom (player-created rooms) each have distinct flows.
- **Match acceptance**: Both players must accept before the battle server is reserved, preventing server waste from AFK players.

### (b) Resource Gathering Cycle
Four resource sources form the economic engine:
- **Supply Points**: Finite map resources requiring unit dispatch and continuous gathering
- **Passive Income**: Base rate modified by building bonuses (always running)
- **Supply Boxes**: Time-limited bonus pickups that appear on the minimap
- **Building Production**: Refineries/Factories that generate resources when active and not at capacity

The spending decision tree (Build / Train / Upgrade) mirrors the RTS triad of economic investment.

### (c) Combat Resolution
The combat pipeline follows a strict sequence:
1. **Target Detection** → range check + FOW validation
2. **Firing Arc** → unit/turret rotation
3. **Cooldown** → weapon fire rate limiting
4. **Hit Roll** → `calcShooter` + `calcFireDistanceMisc` accuracy calculation
5. **Damage Calculation** → `CalculateWeaponArmorDamage` with armor-type branching
6. **Resolution** → kill or continue, with XP/level-up for heroes

The four armor types (Light/Medium/Heavy/SuperHeavy) create the rock-paper-scissors dynamic between the Confederation (heavy armor) and Resistance (speed + stealth) factions.

### (d) Matchmaking Flow
The matchmaking system uses **expanding search range** (±200 → ±400 → ±600 ELO) to balance match quality with wait time. Key infrastructure:
- **Redis queue** for fast matchmaking state
- **Elastic Battle Server provisioning** when all servers are occupied
- **Dual acceptance requirement** before server reservation
- **30-second connection timeout** with re-queue for the surviving player

### (e) Building Upgrade Process
Upgrades are **interruptible** — if a building is destroyed during upgrade, the upgrade (and potentially resources) are lost. The flow handles:
- **Prerequisite chains**: Tech Lab and other buildings may be required
- **Production pausing**: Active unit queues are paused during upgrade
- **Under-fire warning**: Players can choose to upgrade even while being attacked
- **Post-upgrade unlocks**: New units, abilities, and weapon systems become available
- **Visual updates**: The building model changes to reflect the new level
