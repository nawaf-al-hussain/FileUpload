# Recreation Mapping: Audio System

## Purpose

The Audio System manages all sound playback in Art of War 3: Global Conflict, including battle sound effects (weapon fire, explosions, unit deaths), ambient environment sounds (wind, water, machinery), voice-over lines (unit acknowledgments, hero abilities, campaign dialogue), UI sound effects (button clicks, notifications, alerts), and background music (faction themes, combat music, menu music). The system must handle dozens of simultaneous audio sources during large battles, implement 3D spatial audio for positional sound (explosions sound louder when closer), manage audio priority and voice limiting (only the N most important sounds play simultaneously on mobile hardware), support dynamic music that shifts intensity based on combat state, and provide voice-over management for localized dialogue across multiple languages.

## Inputs

- **Combat System**: Weapon fire events, explosion events, unit death events
- **Unit System**: Unit selection acknowledgments, movement confirmations, ability activations
- **Building System**: Construction sounds, production complete sounds, power warnings
- **Superweapon System**: Launch siren, nuclear explosion, EMP pulse
- **GUI System**: Button clicks, notification sounds, menu transitions
- **Campaign System**: Dialogue triggers, cutscene audio, briefing voice-overs
- **Settings**: Master volume, SFX volume, music volume, VO volume

## Outputs

- **Audio Playback**: All audible sounds in the game
- **3D Positioned Audio**: Spatial sound for gameplay events
- **Dynamic Music**: Intensity-responsive background music
- **Voice Chat**: (If implemented) Player communication
- **Audio Logs**: For debugging and profiling

## Dependencies

- **All Game Systems**: Most systems trigger audio events
- **Asset System**: For loading audio clips from bundles
- **Camera System**: For listener position (3D audio falloff)
- **GUI System**: For audio settings controls
- **Persistence System**: For saving audio settings

## Internal Logic

The audio system uses an event-driven architecture: game systems fire `AudioEvent` objects into an `AudioBus`, and the `AudioManager` processes them each frame. Each `AudioEvent` has: clip reference (or clip group for variety), position (for 3D spatial), priority (CRITICAL, HIGH, NORMAL, LOW), volume, pitch variation, and category (SFX, VO, MUSIC, AMBIENT, UI).

Voice limiting is critical on mobile: the hardware can only mix a limited number of simultaneous sounds (typically 16-32). The `AudioManager` maintains a pool of `AudioSource` components. When a new sound is requested and all sources are in use, the lowest-priority currently-playing sound is stolen (stopped and replaced). Priority ordering: CRITICAL (superweapon siren, nuclear explosion) > HIGH (weapon fire nearby, unit death) > NORMAL (ambient, distant combat) > LOW (UI sounds, quiet ambient).

Sound variety is achieved through clip groups: instead of one "rifle fire" sound, the system has a group of 4-5 variations and randomly selects one each time. This prevents the "machine gun" effect of identical sounds repeating. Pitch randomization (±5%) adds further variation.

Dynamic music uses a layered stem system: the music is composed as separate stems (low-intensity layer, medium-intensity layer, high-intensity layer). The `DynamicMusicController` monitors combat intensity (number of active engagements, units in combat) and crossfades between stems. During quiet moments, only the low-intensity stem plays; during large battles, all stems blend together. This creates seamless music that matches the gameplay intensity without jarring transitions.

3D spatial audio uses Unity's built-in spatializer with distance-based volume falloff and Doppler effect for moving projectiles. The audio listener is attached to the camera. Sounds beyond a configurable max distance are culled entirely (not played).

## Pseudocode

```
class AudioSystem:
    audioBus: AudioBus
    audioPool: AudioSourcePool
    musicController: DynamicMusicController
    settings: AudioSettings
    voiceLimit: int = 24  // Max simultaneous sounds

    function playSound(audioEvent: AudioEvent):
        // Check if we should play this sound
        if audioEvent.category == SFX and settings.sfxVolume <= 0:
            return
        if audioEvent.category == VO and settings.voVolume <= 0:
            return
        if audioEvent.category == MUSIC and settings.musicVolume <= 0:
            return

        // Distance culling (3D audio)
        if audioEvent.position != null:
            distance = distance(audioEvent.position, camera.position)
            if distance > MAX_AUDIO_DISTANCE:
                return  // Too far to hear

        // Get audio clip (with variety)
        clip = selectClipFromGroup(audioEvent.clipGroup)

        // Acquire audio source from pool
        source = audioPool.acquire()
        if source == null:
            // All sources in use — try to steal lowest priority
            source = audioPool.stealLowestPriority(audioEvent.priority)
            if source == null:
                return  // Can't play this sound

        // Configure and play
        source.clip = clip
        source.priority = mapPriority(audioEvent.priority)
        source.volume = calculateVolume(audioEvent)
        source.pitch = 1.0 + randomRange(-audioEvent.pitchVariation, audioEvent.pitchVariation)
        if audioEvent.position != null:
            source.spatialBlend = 1.0  // Full 3D
            source.transform.position = audioEvent.position
        else:
            source.spatialBlend = 0.0  // 2D (UI, music)
        source.Play()

    function selectClipFromGroup(group) -> AudioClip:
        // Variety: pick random clip from group
        if group.clips.size == 1:
            return group.clips[0]
        // Avoid repeating the last played clip
        candidates = group.clips.where(c => c != group.lastPlayed)
        selected = candidates.random()
        group.lastPlayed = selected
        return selected

    function calculateVolume(event: AudioEvent) -> float:
        baseVolume = event.volume
        // Category volume
        switch event.category:
            case SFX: baseVolume *= settings.sfxVolume
            case VO: baseVolume *= settings.voVolume
            case MUSIC: baseVolume *= settings.musicVolume
            case AMBIENT: baseVolume *= settings.sfxVolume * 0.5
            case UI: baseVolume *= settings.sfxVolume
        // Distance attenuation for 3D sounds
        if event.position != null:
            dist = distance(event.position, camera.position)
            attenuation = 1.0 - (dist / MAX_AUDIO_DISTANCE)
            baseVolume *= clamp(attenuation, 0.0, 1.0)
        return clamp(baseVolume, 0.0, 1.0)

class DynamicMusicController:
    stems: Map<MusicTrack, List<AudioSource>>  // Low, Medium, High intensity layers
    currentIntensity: float = 0.0
    targetIntensity: float = 0.0
    crossfadeSpeed: float = 0.5  // Per second

    function update(deltaTime):
        // Calculate combat intensity
        combatUnits = countUnitsInCombat()
        targetIntensity = clamp(combatUnits / INTENSITY_SCALE, 0.0, 1.0)
        // Smooth transition
        currentIntensity = lerp(currentIntensity, targetIntensity, crossfadeSpeed * deltaTime)
        // Adjust stem volumes
        for track, sources in stems:
            lowVol = 1.0
            medVol = clamp(currentIntensity * 2.0 - 0.2, 0.0, 1.0)
            highVol = clamp(currentIntensity * 2.0 - 0.8, 0.0, 1.0)
            stems[LOW].volume = lowVol * settings.musicVolume
            stems[MEDIUM].volume = medVol * settings.musicVolume
            stems[HIGH].volume = highVol * settings.musicVolume

class AudioSourcePool:
    sources: List<AudioSource>
    activeSounds: List<ActiveSound>

    function acquire() -> AudioSource:
        freeSource = sources.find(s => not s.isPlaying)
        if freeSource:
            return freeSource
        return null

    function stealLowestPriority(minPriority) -> AudioSource:
        lowest = activeSounds.minBy(s => s.priority)
        if lowest and lowest.priority < minPriority:
            lowest.source.Stop()
            return lowest.source
        return null
```

## Modern Implementation Recommendations

| Approach | Recommendation |
|----------|---------------|
| **Best Overall** | **Unity 2023 + FMOD Studio** — FMOD provides event-based audio, dynamic music transitions, spatial audio, and voice limiting out of the box. Designer-friendly authoring tool. Industry standard for game audio. |
| **Alternative** | **Wwise (Audiokinetic)** — Similar to FMOD with more advanced features. Better for very large projects. Steeper learning curve. |
| **Lightweight** | **Unity built-in Audio + custom manager** — No external middleware. Custom `AudioManager` for pooling, priority, and variety. Good enough for most projects. |
| **Alternative Engine** | **Godot 4 built-in Audio** — `AudioStreamPlayer` for 2D, `AudioStreamPlayer3D` for spatial. `AudioBus` for mixing and effects. Simpler but capable. |

**Key patterns to adopt:**
- Event-driven audio (game systems emit events, audio system consumes) — decouple sound from logic
- Audio source pooling with priority-based voice stealing — essential for mobile
- Clip groups with random selection and repeat avoidance — prevents auditory fatigue
- Dynamic music with layered stems and crossfading — intensity-responsive music
- Distance culling before playing — don't waste voices on inaudible sounds
- Pitch randomization for variety — subtle but critical for perceived quality
- Category-based volume control (Master, SFX, Music, VO) — player expectation
- Preload frequently-used clips (weapon sounds, UI sounds), stream music and long dialogue
