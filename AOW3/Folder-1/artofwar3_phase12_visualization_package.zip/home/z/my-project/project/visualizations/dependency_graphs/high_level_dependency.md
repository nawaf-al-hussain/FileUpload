# Art of War 3: Global Conflict — High-Level Dependency Graph

> Module-level architecture dependencies for the reverse-engineered Unity IL2CPP game.

## Legend

| Style | Meaning |
|-------|---------|
| **Bold red border** | Core / critical system |
| **Dashed orange border** | Bottleneck (high fan-in) |
| **Blue fill** | Gameplay system |
| **Green fill** | Infrastructure / services |
| **Yellow fill** | Third-party integration |
| 🔴 | Circular dependency detected |

---

## Mermaid Dependency Graph

```mermaid
graph TD
    %% ── Core Runtime ──────────────────────────────────────
    CORE["🔴 Core Runtime<br/>(GameStateManager, Zenject)"]
    SCENE["Core Scene Manager<br/>(Startup→Logon→Main→Battle)"]

    %% ── Gameplay Systems ──────────────────────────────────
    BATTLE["🔴 Battle System<br/>(BattleScreen, LogicService)"]
    MAIN["Main System<br/>(Hub, Navigation)"]
    AI["AI System<br/>(Strategic + Tactical AI)"]
    UNITS["🔴 Unit System<br/>(Entity Spawning, Combat)"]
    BLDGS["Building System<br/>(Construction, Production)"]
    ECON["Economy System<br/>(Resources, Costs)"]
    PATH["Pathfinding<br/>(A*, NavMesh)"]
    MAP["Map System<br/>(Terrain, Fog of War)"]

    %% ── Infrastructure ────────────────────────────────────
    NET["🔴⚠️ Network Layer<br/>(RSA/DES, Protobuf)"]
    ASSET["⚠️ Asset System<br/>(Addressables, 773 entries)"]
    PERSIST["Persistence Layer<br/>(SQLite, PCLRaw)"]
    GUI["GUI System<br/>(DOTween, BattleGUI)"]
    AUDIO["Audio System<br/>(SFX, Music, Voice)"]

    %% ── Third-Party / External ────────────────────────────
    ANALYTICS["Analytics<br/>(Firebase + AppMetrica)"]
    ADS["Ads<br/>(AppLovin MAX + IronSource)"]
    BILLING["Billing<br/>(Google Play + HMS)"]
    PUSH["Push Notifications<br/>(FCM + GGNotifications)"]

    %% ── Social / Domain ───────────────────────────────────
    SOCIAL["Social Module<br/>(Clan, Chat, Friends)"]
    WORKSHOP["Workshop<br/>(Unit Upgrades, Tech)"]
    SKILLS["Skills System<br/>(Commander Abilities)"]
    TOURN["Tournaments<br/>(Ranked, Events)"]
    PROFILE["Profile System<br/>(Player Data, Progression)"]

    %% ── Core dependencies ─────────────────────────────────
    CORE --> SCENE
    CORE --> NET
    CORE --> ASSET
    CORE --> PERSIST
    CORE --> GUI

    %% ── Scene flow ────────────────────────────────────────
    SCENE --> MAIN
    SCENE --> BATTLE

    %% ── Battle internal ───────────────────────────────────
    BATTLE --> NET
    BATTLE --> AI
    BATTLE --> UNITS
    BATTLE --> BLDGS
    BATTLE --> ECON
    BATTLE --> GUI
    BATTLE --> AUDIO
    BATTLE --> MAP
    BATTLE --> ASSET

    %% ── AI dependencies ───────────────────────────────────
    AI --> MAP
    AI --> UNITS
    AI --> BLDGS
    AI --> ECON
    AI --> PATH

    %% ── Map / Pathfinding ─────────────────────────────────
    MAP --> PATH

    %% ── Unit / Building ↔ Economy ─────────────────────────
    UNITS --> ECON
    BLDGS --> ECON
    BLDGS --> UNITS

    %% ── Main system dependencies ──────────────────────────
    MAIN --> NET
    MAIN --> STORE["Store / IAP"]
    MAIN --> SOCIAL
    MAIN --> WORKSHOP
    MAIN --> PROFILE
    MAIN --> SKILLS
    MAIN --> TOURN
    MAIN --> GUI
    MAIN --> ASSET
    MAIN --> AUDIO

    %% ── Store depends on billing ──────────────────────────
    STORE --> BILLING

    %% ── Social sub-dependencies ───────────────────────────
    SOCIAL --> NET
    SOCIAL --> PERSIST

    %% ── Domain system dependencies ────────────────────────
    WORKSHOP --> UNITS
    WORKSHOP --> ECON
    WORKSHOP --> PERSIST
    SKILLS --> UNITS
    SKILLS --> PERSIST
    TOURN --> NET
    TOURN --> PROFILE
    PROFILE --> PERSIST
    PROFILE --> NET

    %% ── Infrastructure fan-out ────────────────────────────
    ASSET --> CORE
    NET --> CORE
    PERSIST --> CORE

    %% ── Third-party integrations ──────────────────────────
    ANALYTICS --> CORE
    ADS --> CORE
    BILLING --> CORE
    PUSH --> CORE

    %% ── Circular: GUI ↔ Battle ────────────────────────────
    GUI -.->|🔴 circular| BATTLE

    %% ── Circular: Units ↔ Buildings ───────────────────────
    UNITS -.->|🔴 circular| BLDGS

    %% ── Styles ────────────────────────────────────────────
    style CORE fill:#ff4444,stroke:#aa0000,stroke-width:4px,color:#fff
    style NET fill:#ff4444,stroke:#aa0000,stroke-width:4px,color:#fff
    style UNITS fill:#ff4444,stroke:#aa0000,stroke-width:4px,color:#fff
    style BATTLE fill:#4488ff,stroke:#2244aa,stroke-width:3px,color:#fff
    style MAIN fill:#4488ff,stroke:#2244aa,stroke-width:3px,color:#fff
    style AI fill:#4488ff,stroke:#2244aa,stroke-width:2px,color:#fff
    style BLDGS fill:#4488ff,stroke:#2244aa,stroke-width:2px,color:#fff
    style ECON fill:#4488ff,stroke:#2244aa,stroke-width:2px,color:#fff
    style PATH fill:#4488ff,stroke:#2244aa,stroke-width:2px,color:#fff
    style MAP fill:#4488ff,stroke:#2244aa,stroke-width:2px,color:#fff
    style ASSET fill:#ff8800,stroke:#cc6600,stroke-width:3px,stroke-dasharray: 5 5,color:#fff
    style PERSIST fill:#44bb44,stroke:#228822,stroke-width:2px,color:#fff
    style GUI fill:#44bb44,stroke:#228822,stroke-width:2px,color:#fff
    style AUDIO fill:#44bb44,stroke:#228822,stroke-width:2px,color:#fff
    style SCENE fill:#44bb44,stroke:#228822,stroke-width:2px,color:#fff
    style ANALYTICS fill:#dddd44,stroke:#aaaa00,stroke-width:2px,color:#333
    style ADS fill:#dddd44,stroke:#aaaa00,stroke-width:2px,color:#333
    style BILLING fill:#dddd44,stroke:#aaaa00,stroke-width:2px,color:#333
    style PUSH fill:#dddd44,stroke:#aaaa00,stroke-width:2px,color:#333
    style SOCIAL fill:#8844cc,stroke:#6622aa,stroke-width:2px,color:#fff
    style WORKSHOP fill:#8844cc,stroke:#6622aa,stroke-width:2px,color:#fff
    style SKILLS fill:#8844cc,stroke:#6622aa,stroke-width:2px,color:#fff
    style TOURN fill:#8844cc,stroke:#6622aa,stroke-width:2px,color:#fff
    style PROFILE fill:#8844cc,stroke:#6622aa,stroke-width:2px,color:#fff
    style STORE fill:#dddd44,stroke:#aaaa00,stroke-width:2px,color:#333
```

---

## Module Dependency Summary

| Module | Fan-In (Depended Upon By) | Fan-Out (Depends On) | Classification |
|--------|--------------------------|----------------------|----------------|
| **Core Runtime** | 8 | 4 | 🔴 Critical Core |
| **Network Layer** | 7 | 1 | 🔴 Bottleneck |
| **Asset System** | 4 | 1 | ⚠️ Bottleneck |
| **Unit System** | 4 | 2 | 🔴 Critical Core |
| **Battle System** | 2 | 9 | Highly Coupled |
| **Persistence Layer** | 5 | 1 | Infrastructure |
| **GUI System** | 2 | 1 | Infrastructure |
| **Economy System** | 4 | 0 | Leaf Gameplay |
| **AI System** | 1 | 5 | Gameplay |
| **Main System** | 1 | 10 | Highly Coupled |
| **Building System** | 2 | 2 | Gameplay |

---

## Critical Observations

1. **Network Layer** is the #1 bottleneck — 7 modules depend on it (Battle, Main, Social, Workshop, Profile, Tournaments, Core)
2. **Asset System** is the #2 bottleneck — all visual content flows through Addressables; a loading failure cascades game-wide
3. **Circular dependency: GUI ↔ Battle** — BattleGUI references Battle state while Battle triggers GUI updates
4. **Circular dependency: Units ↔ Buildings** — Buildings produce units; units interact with buildings
5. **Core Runtime** has high fan-in — most systems ultimately depend on Zenject DI and GameStateManager
6. **Main System** has highest fan-out (10) — it's the hub for all non-battle features, making it complex to modify in isolation
