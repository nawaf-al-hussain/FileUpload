# Recreation Mapping: Persistence System

## Purpose

The Persistence System handles all long-term data storage in Art of War 3: Global Conflict, bridging the gap between individual game sessions and the player's ongoing progression. It manages player profiles (name, level, experience), campaign progress (completed missions, star ratings, unlock state), multiplayer ratings (ELO per mode), inventory (unlocked units, cosmetics, hero skins), economy (credits balance, premium currency), settings (audio, graphics, controls), and daily rewards/achievements. The system uses SQLite for local storage and synchronizes with a server-side database for cloud saves and cross-device progression. It must handle offline play gracefully (queue changes locally, sync when online), resolve conflicts between local and server state, and protect against data corruption and cheating (server-authoritative for competitive data).

## Inputs

- **Game Systems**: State change events (match result, mission complete, purchase, settings change)
- **Player Input**: Profile changes, settings adjustments
- **Network System**: Server sync responses, conflict notifications
- **Authentication**: Player login/session tokens
- **Daily Timer**: Reward eligibility checks

## Outputs

- **Saved State**: Persisted data in SQLite and server database
- **Loaded State**: Restored game state on app launch
- **Sync Status**: Synchronization state (synced, pending, conflict)
- **Conflict Resolution**: Merged state when local and server diverge
- **Reward Notifications**: Daily reward availability, achievement unlocks

## Dependencies

- **All Game Systems**: For state that needs persistence
- **Network System**: For server synchronization
- **Economy System**: For credit/currency persistence
- **Matchmaking System**: For rating persistence
- **Campaign System**: For progress persistence
- **GUI System**: For loading screens, sync indicators

## Internal Logic

The persistence layer operates on an event-sourcing model: state changes are recorded as events (e.g., `MatchCompletedEvent`, `MissionCompletedEvent`, `CreditsEarnedEvent`) rather than directly mutating the saved state. The current state is derived by replaying events from the event log. This enables conflict resolution (merge event streams from local and server) and audit logging.

Local storage uses SQLite with tables for: `player_profile`, `campaign_progress`, `multiplayer_ratings`, `inventory`, `economy`, `settings`, and `event_log`. Each table has a `last_modified` timestamp and a `sync_version` counter for conflict detection.

The sync protocol follows: (1) On app launch, load local state immediately for responsive startup. (2) In background, connect to server and request latest state. (3) Compare local and server `sync_version`. If server is ahead, apply server state. If both have changes, use timestamp-based conflict resolution (last-write-wins for settings, merge for additive data like credits). (4) Upload any local events that haven't been synced.

For competitive data (ratings, match history), the server is always authoritative. Local data is treated as a cache that can be overridden. This prevents client-side rating manipulation. Economy operations (spending credits) also require server validation to prevent duplication exploits.

The system implements an auto-save mechanism that persists critical state every 60 seconds and on app pause/focus-loss (critical for mobile where the OS can kill the app at any time). Save operations are asynchronous and non-blocking.

## Pseudocode

```
class PersistenceSystem:
    localDB: SQLiteDatabase
    syncClient: SyncClient
    eventLog: EventLog
    isSyncing: bool = false
    autoSaveInterval: float = 60.0  // seconds
    autoSaveTimer: float

    function initialize():
        localDB.open("player_data.db")
        createTables()
        loadLocalState()
        // Start background sync
        syncClient.connect(authToken)
        syncClient.onSyncComplete = onSyncComplete
        syncClient.onConflict = onConflictDetected
        syncClient.startSync()

    function loadLocalState() -> PlayerState:
        profile = localDB.query("SELECT * FROM player_profile LIMIT 1")
        campaign = localDB.query("SELECT * FROM campaign_progress")
        ratings = localDB.query("SELECT * FROM multiplayer_ratings")
        inventory = localDB.query("SELECT * FROM inventory")
        economy = localDB.query("SELECT * FROM economy")
        settings = localDB.query("SELECT * FROM settings")
        return PlayerState(profile, campaign, ratings, inventory, economy, settings)

    function saveState(state: PlayerState):
        localDB.beginTransaction()
        try:
            localDB.upsert("player_profile", state.profile.toRow())
            for mission in state.campaign:
                localDB.upsert("campaign_progress", mission.toRow())
            localDB.upsert("multiplayer_ratings", state.ratings.toRow())
            localDB.upsert("economy", state.economy.toRow())
            localDB.upsert("settings", state.settings.toRow())
            localDB.commit()
        except:
            localDB.rollback()
            log.error("Failed to save state")

    function recordEvent(event: GameEvent):
        event.timestamp = time.now()
        event.syncVersion = getNextSyncVersion()
        eventLog.append(event)
        localDB.insert("event_log", event.toRow())
        // Apply event to current state
        applyEvent(event)

    function applyEvent(event):
        switch event.type:
            case MATCH_COMPLETED:
                economy.credits += event.creditsEarned
                ratings[event.mode] = event.newRating
            case MISSION_COMPLETED:
                campaign[event.missionId] = MissionProgress(
                    completed = true, stars = event.stars
                )
            case CREDITS_SPENT:
                economy.credits -= event.amount
            case SETTINGS_CHANGED:
                settings.update(event.settingsDelta)

    function onSyncComplete(serverState):
        // Compare versions
        localVersion = localDB.query("SELECT MAX(sync_version) FROM event_log")
        if serverState.version > localVersion:
            // Server has newer data — apply server state
            applyServerState(serverState)
        elif serverState.version < localVersion:
            // Local has newer data — upload to server
            uploadPendingEvents()
        else:
            // In sync
            pass

    function onConflictDetected(conflict):
        // Conflict resolution strategy
        switch conflict.dataType:
            case RATINGS:
                // Server is always authoritative for competitive data
                applyServerValue(conflict)
            case ECONOMY:
                // Merge: take the higher credit count (additive data)
                mergedValue = max(conflict.localValue, conflict.serverValue)
                applyMergedValue(conflict, mergedValue)
            case CAMPAIGN:
                // Merge: take the best progress per mission
                for mission in conflict.campaignMissions:
                    bestStars = max(conflict.local[mission].stars, conflict.server[mission].stars)
                    applyBestProgress(mission, bestStars)
            case SETTINGS:
                // Last-write-wins
                if conflict.localTimestamp > conflict.serverTimestamp:
                    keepLocal(conflict)
                else:
                    applyServerValue(conflict)

    function update(deltaTime):
        autoSaveTimer -= deltaTime
        if autoSaveTimer <= 0:
            autoSaveTimer = autoSaveInterval
            saveState(currentState)

    function onAppPause():
        // Save immediately when app goes to background
        saveState(currentState)
        syncClient.flushPendingEvents()

    function onAppResume():
        // Check for server updates
        syncClient.startSync()
```

## Modern Implementation Recommendations

| Approach | Recommendation |
|----------|---------------|
| **Best Overall** | **Unity 2023 + SQLite + PlayFab** — SQLite for local storage. PlayFab for cloud saves, player profiles, and title data. PlayFab SDK handles sync, conflict resolution, and authentication. |
| **Alternative Engine** | **Godot 4 + SQLite + Nakama** — Use `godot-sqlite` addon for local DB. Nakama server for cloud storage with built-in sync and conflict resolution. |
| **Event-Sourced** | **Custom event store + PostgreSQL** — Full event-sourcing with CQRS. PostgreSQL stores events. Projections derive read models. Powerful but complex. |
| **Lightweight** | **JSON files + Firebase Realtime DB** — Simple JSON files for local saves. Firebase for cloud sync. Easy to implement but less robust for complex state. |

**Key patterns to adopt:**
- Event-sourcing for state changes — enables conflict resolution and audit trails
- Server-authoritative for competitive data (ratings, match history) — prevent cheating
- Background sync with local-first loading — responsive startup
- Auto-save on timer AND app lifecycle events (pause/resume) — prevent data loss on mobile
- Timestamp-based conflict resolution with data-type-specific strategies
- Transaction-based local writes — prevent corruption from interrupted saves
- Encrypted local storage for sensitive data (premium currency, auth tokens)
