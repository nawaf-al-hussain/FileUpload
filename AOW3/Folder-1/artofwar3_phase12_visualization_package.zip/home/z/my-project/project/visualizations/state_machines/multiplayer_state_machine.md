# Multiplayer State Machine — Art of War 3: Global Conflict

Full multiplayer connection and session state machine covering authentication,
matchmaking, battle lifecycle, reconnection, and error handling.

## Primary Multiplayer State Machine

```mermaid
stateDiagram-v2
    direction TB

    [*] --> Disconnected : App launched
    Disconnected --> Connecting : Player taps "Play Online"\n[CSLoginToBattle initiated]
    Disconnected --> OfflineMode : Server unreachable\n[Network error]

    Connecting --> Connected : Authentication successful\n[CSLoginToBattle response OK]
    Connecting --> Disconnected : Authentication failed\n[Invalid credentials]
    Connecting --> Disconnected : Connection timeout\n[30s timeout]
    Connecting --> ConnectionError : Network error\n[Socket exception]

    ConnectionError --> Connecting : Retry button pressed\n[Exponential backoff: 2s, 4s, 8s, 16s, 30s]
    ConnectionError --> Disconnected : Max retries exceeded\n[5 attempts failed]

    Connected --> InLobby : Server assigns lobby\n[CSBattleLogon successful]
    Connected --> Disconnected : Session token expired\n[Re-auth required]
    Connected --> Disconnected : Server maintenance\n[Kicked by server]

    InLobby --> Matchmaking : "Find Match" pressed\n[Queue joined]
    InLobby --> Connected : "Back" pressed\n[Return to main lobby]
    InLobby --> Disconnected : Connection lost\n[Socket timeout]

    Matchmaking --> InBattle : Opponent found\n[Match confirmed by both players]
    Matchmaking --> InLobby : Cancel matchmaking\n[Before match found]
    Matchmaking --> Disconnected : Connection lost during search
    Matchmaking --> MatchmakingTimeout : Queue time > 120s\n[Expanding search criteria]

    MatchmakingTimeout --> InLobby : Cancel after timeout\n[Prompt player]
    MatchmakingTimeout --> InBattle : Match found with expanded criteria

    InBattle --> BattleEnding : Victory condition met\n[Base destroyed / Surrender / Timer]
    InBattle --> Reconnecting : Connection lost mid-battle\n[PingPongAsync timeout]

    BattleEnding --> ResultsScreen : Battle data synced\n[Both players acknowledged]
    BattleEnding --> Reconnecting : Lost connection during results\n[Opponent still syncing]

    Reconnecting --> InBattle : Reconnection successful\n[State synchronized from server]
    Reconnecting --> Disconnected : Reconnection timeout\n[60s grace period exceeded]
    Reconnecting --> BattleEnding : Battle ended while reconnecting\n[Server determined result]

    ResultsScreen --> InLobby : "Continue" pressed\n[Return to lobby]
    ResultsScreen --> Disconnected : Session ended\n[Player exits]

    OfflineMode --> Disconnected : Return to main menu

    Disconnected --> [*] : App closed
```

## Connection & Authentication Detail

```mermaid
stateDiagram-v2
    direction TB

    [*] --> InitConnection : CSLoginToBattle() called
    InitConnection --> DNSResolving : Resolve server hostname
    DNSResolving --> TCPConnecting : DNS resolved\n[Server IP obtained]
    DNSResolving --> DNSError : DNS resolution failed

    TCPConnecting --> TLSHandshake : TCP connected\n[Socket established]
    TCPConnecting --> TCPError : Connection refused\n/ Timeout

    TLSHandshake --> Authenticating : TLS established\n[Secure channel ready]
    TLSHandshake --> TLSError : Certificate invalid\n/ Handshake failed

    Authenticating --> AuthSuccess : Credentials valid\n[Session token received]
    Authenticating --> AuthFailed : Invalid credentials\n[Error code returned]
    Authenticating --> AuthRateLimited : Too many attempts\n[15 min cooldown]

    AuthSuccess --> SyncingState : Download player data\n[Profile, clan, inventory]
    SyncingState --> Connected : State synchronized\n[Ready for interaction]
    SyncingState --> SyncError : Data corruption\n/ Version mismatch

    DNSError --> RetryDecision : Auto-retry logic
    TCPError --> RetryDecision
    TLSError --> RetryDecision
    SyncError --> RetryDecision

    RetryDecision --> InitConnection : Retries remaining\n[Backoff delay applied]
    RetryDecision --> ConnectionFailed : Max retries exceeded

    AuthFailed --> ConnectionFailed
    AuthRateLimited --> ConnectionFailed

    Connected --> [*] : Ready

    note right of Authenticating
        CSLoginToBattle payload:
        - Player ID / Device ID
        - Auth token (from previous session)
        - Client version
        - Device info
    end note
```

## Matchmaking Detail

```mermaid
stateDiagram-v2
    direction TB

    [*] --> Queued : Join matchmaking queue
    Queued --> SearchingInitial : Initial search\n[±100 MMR range]
    SearchingInitial --> SearchingExpanded : No match in 15s\n[±200 MMR range]
    SearchingExpanded --> SearchingWide : No match in 30s\n[±400 MMR range]
    SearchingWide --> SearchingAny : No match in 60s\n[Any MMR]

    SearchingInitial --> MatchFound : Opponent matched\n[Within MMR range]
    SearchingExpanded --> MatchFound : Opponent matched
    SearchingWide --> MatchFound : Opponent matched
    SearchingAny --> MatchFound : Opponent matched

    MatchFound --> Confirming : Both players confirming\n[10s accept window]
    Confirming --> Confirmed : Both accepted\n[CSBattleLogon exchanged]
    Confirming --> Declined : One player declined\n/ Accept timeout
    Declined --> Queued : Re-queue (non-declining player)
    Declined --> InLobby : Declining player returns

    Confirmed --> LoadingBattle : Both confirmed\n[Loading screen initiated]
    LoadingBattle --> Synchronizing : Map & factions assigned\n[Seed synchronized]
    Synchronizing --> InBattle : Both players synced\n[Countdown: 3, 2, 1, GO]
    Synchronizing --> SyncFailed : Version mismatch\n/ Data error
    SyncFailed --> InLobby : Error returned\n[Both players return]

    note right of Queued
        Matchmaking criteria:
        - MMR (Matchmaking Rating)
        - Faction preference (if set)
        - Map pool rotation
        - Geographic region (ping)
        - Player level bracket
    end note
```

## Battle & Reconnection Detail

```mermaid
stateDiagram-v2
    direction TB

    state "InBattle" as InBattle {
        [*] --> Countdown
        Countdown --> ActiveBattle : Countdown complete
        ActiveBattle --> ActiveBattle : PingPongAsync()\n[every 2s heartbeat]

        ActiveBattle --> Paused : Pause requested\n[Both players must agree]
        Paused --> ActiveBattle : Both unpause\n/ Pause timer expires (30s max)

        ActiveBattle --> SurrenderInitiated : Surrender button pressed
        SurrenderInitiated --> ActiveBattle : Cancel surrender\n[Within 5s]
        SurrenderInitiated --> BattleEnding : Surrender confirmed
    }

    state "Reconnecting" as Reconnecting {
        [*] --> ConnectionLost : PingPongAsync timeout\n[No response for 5s]
        ConnectionLost --> AttemptingReconnect : Auto-reconnect started
        AttemptingReconnect --> Reauthenticating : Server reached\n[CSLoginToBattle with saved token]
        Reauthenticating --> StateResync : Auth successful\n[CSBattleLogon with battle ID]
        StateResync --> Rejoined : State synchronized\n[Fast-forward to current tick]
        StateResync --> ResyncFailed : State too divergent\n/ Battle expired

        AttemptingReconnect --> WaitingRetry : Connection failed\n[Backoff: 2s, 4s, 8s...]
        WaitingRetry --> AttemptingReconnect : Retry timer expires

        Rejoined --> [*] : Return to InBattle
        ResyncFailed --> [*] : Battle result from server\n[Grace period: 60s total]
    }

    BattleEnding --> CalculatingResults : Battle data finalized
    CalculatingResults --> ResultsScreen : Results calculated\n[MMR change, rewards]

    note right of ConnectionLost
        Grace period: 60 seconds
        - AI takes over unit control
        - Base defenses auto-activate
        - Production continues
        - If reconnected: resume play
        - If timeout: battle result determined
          by server (usually loss for DC player)
    end note

    note right of PingPongAsync
        Heartbeat system:
        - Client sends PING every 2s
        - Server responds with PONG
        - 3 missed PONGs = connection lost
        - Ping displayed in UI
        - High ping (>500ms) shows warning
    end note
```

## Error Handling State Machine

```mermaid
stateDiagram-v2
    direction TB

    [*] --> NoError : Normal operation

    NoError --> NetworkWarning : Ping > 300ms\n[Yellow indicator]
    NoError --> NetworkCritical : Ping > 500ms\n[Red indicator]
    NoError --> Disconnected_Error : Socket closed\n[Unexpected disconnect]

    NetworkWarning --> NoError : Ping normalized\n[< 200ms for 10s]
    NetworkWarning --> NetworkCritical : Ping > 500ms
    NetworkWarning --> Disconnected_Error : Connection lost

    NetworkCritical --> NetworkWarning : Ping improved\n[300-500ms range]
    NetworkCritical --> Disconnected_Error : Connection lost
    NetworkCritical --> Reconnecting_Error : 3 missed heartbeats

    Disconnected_Error --> Reconnecting_Error : Auto-reconnect initiated
    Reconnecting_Error --> NoError : Reconnection successful\n[State fully restored]
    Reconnecting_Error --> ReconnectFailed : All retries exhausted

    ReconnectFailed --> InLobby : Grace period active\n[Can re-enter battle]
    ReconnectFailed --> Disconnected_Final : Battle expired\n[Result finalized]

    Disconnected_Final --> [*] : Return to main menu

    note right of NetworkWarning
        Network quality indicators:
        Green:  < 150ms (Excellent)
        Yellow: 150-300ms (Fair)
        Orange: 300-500ms (Poor)
        Red:    > 500ms (Critical)
        DC:     No response (Disconnected)
    end note
```
