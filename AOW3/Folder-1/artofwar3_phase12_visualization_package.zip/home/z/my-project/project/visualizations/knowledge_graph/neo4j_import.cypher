// Art of War 3: Global Conflict - Neo4j Import Script
// Generated from knowledge_graph.json

// Step 1: Create constraints for unique IDs
CREATE CONSTRAINT IF NOT EXISTS FOR (n:Building) REQUIRE n.id IS UNIQUE;
CREATE CONSTRAINT IF NOT EXISTS FOR (n:Campaign) REQUIRE n.id IS UNIQUE;
CREATE CONSTRAINT IF NOT EXISTS FOR (n:Class) REQUIRE n.id IS UNIQUE;
CREATE CONSTRAINT IF NOT EXISTS FOR (n:Hero) REQUIRE n.id IS UNIQUE;
CREATE CONSTRAINT IF NOT EXISTS FOR (n:Map) REQUIRE n.id IS UNIQUE;
CREATE CONSTRAINT IF NOT EXISTS FOR (n:Network_component) REQUIRE n.id IS UNIQUE;
CREATE CONSTRAINT IF NOT EXISTS FOR (n:System) REQUIRE n.id IS UNIQUE;
CREATE CONSTRAINT IF NOT EXISTS FOR (n:Unit) REQUIRE n.id IS UNIQUE;

// Step 2: Load nodes from CSV
// Execute this with the CSV file in Neo4j import directory

LOAD CSV WITH HEADERS FROM 'file:///knowledge_graph_neo4j_nodes.csv' AS row
WITH row,
  CASE row.label
    WHEN 'building' THEN [Building]
    WHEN 'campaign' THEN [Campaign]
    WHEN 'class' THEN [Class]
    WHEN 'hero' THEN [Hero]
    WHEN 'map' THEN [Map]
    WHEN 'network_component' THEN [Network_component]
    WHEN 'system' THEN [System]
    WHEN 'unit' THEN [Unit]
    ELSE ['Entity']
  END AS labels
CALL {
  WITH row, labels
  WITH row, labels,
    apoc.convert.fromJsonMap(row.properties_json) AS props
  CALL apoc.create.node(labels, apoc.map.merge({id: row.id}, props))
  YIELD node
  RETURN node
}
;

// Alternative: Simpler node loading without APOC
// Load each entity type separately:

// Load building nodes
LOAD CSV WITH HEADERS FROM 'file:///knowledge_graph_neo4j_nodes.csv' AS row
WITH row WHERE row.label = 'building'
WITH row, apoc.convert.fromJsonMap(row.properties_json) AS props
MERGE (n:Building {id: row.id})
SET n += props
;

// Load campaign nodes
LOAD CSV WITH HEADERS FROM 'file:///knowledge_graph_neo4j_nodes.csv' AS row
WITH row WHERE row.label = 'campaign'
WITH row, apoc.convert.fromJsonMap(row.properties_json) AS props
MERGE (n:Campaign {id: row.id})
SET n += props
;

// Load class nodes
LOAD CSV WITH HEADERS FROM 'file:///knowledge_graph_neo4j_nodes.csv' AS row
WITH row WHERE row.label = 'class'
WITH row, apoc.convert.fromJsonMap(row.properties_json) AS props
MERGE (n:Class {id: row.id})
SET n += props
;

// Load hero nodes
LOAD CSV WITH HEADERS FROM 'file:///knowledge_graph_neo4j_nodes.csv' AS row
WITH row WHERE row.label = 'hero'
WITH row, apoc.convert.fromJsonMap(row.properties_json) AS props
MERGE (n:Hero {id: row.id})
SET n += props
;

// Load map nodes
LOAD CSV WITH HEADERS FROM 'file:///knowledge_graph_neo4j_nodes.csv' AS row
WITH row WHERE row.label = 'map'
WITH row, apoc.convert.fromJsonMap(row.properties_json) AS props
MERGE (n:Map {id: row.id})
SET n += props
;

// Load network_component nodes
LOAD CSV WITH HEADERS FROM 'file:///knowledge_graph_neo4j_nodes.csv' AS row
WITH row WHERE row.label = 'network_component'
WITH row, apoc.convert.fromJsonMap(row.properties_json) AS props
MERGE (n:Network_component {id: row.id})
SET n += props
;

// Load system nodes
LOAD CSV WITH HEADERS FROM 'file:///knowledge_graph_neo4j_nodes.csv' AS row
WITH row WHERE row.label = 'system'
WITH row, apoc.convert.fromJsonMap(row.properties_json) AS props
MERGE (n:System {id: row.id})
SET n += props
;

// Load unit nodes
LOAD CSV WITH HEADERS FROM 'file:///knowledge_graph_neo4j_nodes.csv' AS row
WITH row WHERE row.label = 'unit'
WITH row, apoc.convert.fromJsonMap(row.properties_json) AS props
MERGE (n:Unit {id: row.id})
SET n += props
;


// Step 3: Load edges from CSV
// Using APOC for dynamic relationship types:

LOAD CSV WITH HEADERS FROM 'file:///knowledge_graph_neo4j_edges.csv' AS row
MATCH (source {id: row.source})
MATCH (target {id: row.target})
WITH source, target, row,
  apoc.convert.fromJsonMap(row.properties_json) AS props
CALL apoc.create.relationship(source, row.type, props, target)
YIELD rel
RETURN rel
;

// Alternative: Static relationship creation for each type

// Create ATTACKS relationships
LOAD CSV WITH HEADERS FROM 'file:///knowledge_graph_neo4j_edges.csv' AS row
WITH row WHERE row.type = 'ATTACKS'
MATCH (source {id: row.source})
MATCH (target {id: row.target})
WITH source, target, row,
  apoc.convert.fromJsonMap(row.properties_json) AS props
CALL apoc.create.relationship(source, 'ATTACKS', props, target)
YIELD rel
RETURN rel
;

// Create CONTROLS relationships
LOAD CSV WITH HEADERS FROM 'file:///knowledge_graph_neo4j_edges.csv' AS row
WITH row WHERE row.type = 'CONTROLS'
MATCH (source {id: row.source})
MATCH (target {id: row.target})
WITH source, target, row,
  apoc.convert.fromJsonMap(row.properties_json) AS props
CALL apoc.create.relationship(source, 'CONTROLS', props, target)
YIELD rel
RETURN rel
;

// Create CREATES relationships
LOAD CSV WITH HEADERS FROM 'file:///knowledge_graph_neo4j_edges.csv' AS row
WITH row WHERE row.type = 'CREATES'
MATCH (source {id: row.source})
MATCH (target {id: row.target})
WITH source, target, row,
  apoc.convert.fromJsonMap(row.properties_json) AS props
CALL apoc.create.relationship(source, 'CREATES', props, target)
YIELD rel
RETURN rel
;

// Create DEPENDS_ON relationships
LOAD CSV WITH HEADERS FROM 'file:///knowledge_graph_neo4j_edges.csv' AS row
WITH row WHERE row.type = 'DEPENDS_ON'
MATCH (source {id: row.source})
MATCH (target {id: row.target})
WITH source, target, row,
  apoc.convert.fromJsonMap(row.properties_json) AS props
CALL apoc.create.relationship(source, 'DEPENDS_ON', props, target)
YIELD rel
RETURN rel
;

// Create IMPLEMENTS relationships
LOAD CSV WITH HEADERS FROM 'file:///knowledge_graph_neo4j_edges.csv' AS row
WITH row WHERE row.type = 'IMPLEMENTS'
MATCH (source {id: row.source})
MATCH (target {id: row.target})
WITH source, target, row,
  apoc.convert.fromJsonMap(row.properties_json) AS props
CALL apoc.create.relationship(source, 'IMPLEMENTS', props, target)
YIELD rel
RETURN rel
;

// Create INITIALIZES relationships
LOAD CSV WITH HEADERS FROM 'file:///knowledge_graph_neo4j_edges.csv' AS row
WITH row WHERE row.type = 'INITIALIZES'
MATCH (source {id: row.source})
MATCH (target {id: row.target})
WITH source, target, row,
  apoc.convert.fromJsonMap(row.properties_json) AS props
CALL apoc.create.relationship(source, 'INITIALIZES', props, target)
YIELD rel
RETURN rel
;

// Create OWNS relationships
LOAD CSV WITH HEADERS FROM 'file:///knowledge_graph_neo4j_edges.csv' AS row
WITH row WHERE row.type = 'OWNS'
MATCH (source {id: row.source})
MATCH (target {id: row.target})
WITH source, target, row,
  apoc.convert.fromJsonMap(row.properties_json) AS props
CALL apoc.create.relationship(source, 'OWNS', props, target)
YIELD rel
RETURN rel
;

// Create POWERS relationships
LOAD CSV WITH HEADERS FROM 'file:///knowledge_graph_neo4j_edges.csv' AS row
WITH row WHERE row.type = 'POWERS'
MATCH (source {id: row.source})
MATCH (target {id: row.target})
WITH source, target, row,
  apoc.convert.fromJsonMap(row.properties_json) AS props
CALL apoc.create.relationship(source, 'POWERS', props, target)
YIELD rel
RETURN rel
;

// Create PRODUCES relationships
LOAD CSV WITH HEADERS FROM 'file:///knowledge_graph_neo4j_edges.csv' AS row
WITH row WHERE row.type = 'PRODUCES'
MATCH (source {id: row.source})
MATCH (target {id: row.target})
WITH source, target, row,
  apoc.convert.fromJsonMap(row.properties_json) AS props
CALL apoc.create.relationship(source, 'PRODUCES', props, target)
YIELD rel
RETURN rel
;

// Create REFERENCES relationships
LOAD CSV WITH HEADERS FROM 'file:///knowledge_graph_neo4j_edges.csv' AS row
WITH row WHERE row.type = 'REFERENCES'
MATCH (source {id: row.source})
MATCH (target {id: row.target})
WITH source, target, row,
  apoc.convert.fromJsonMap(row.properties_json) AS props
CALL apoc.create.relationship(source, 'REFERENCES', props, target)
YIELD rel
RETURN rel
;

// Create REPAIRS relationships
LOAD CSV WITH HEADERS FROM 'file:///knowledge_graph_neo4j_edges.csv' AS row
WITH row WHERE row.type = 'REPAIRS'
MATCH (source {id: row.source})
MATCH (target {id: row.target})
WITH source, target, row,
  apoc.convert.fromJsonMap(row.properties_json) AS props
CALL apoc.create.relationship(source, 'REPAIRS', props, target)
YIELD rel
RETURN rel
;

// Create TRANSPORTS relationships
LOAD CSV WITH HEADERS FROM 'file:///knowledge_graph_neo4j_edges.csv' AS row
WITH row WHERE row.type = 'TRANSPORTS'
MATCH (source {id: row.source})
MATCH (target {id: row.target})
WITH source, target, row,
  apoc.convert.fromJsonMap(row.properties_json) AS props
CALL apoc.create.relationship(source, 'TRANSPORTS', props, target)
YIELD rel
RETURN rel
;

// Create UPDATES relationships
LOAD CSV WITH HEADERS FROM 'file:///knowledge_graph_neo4j_edges.csv' AS row
WITH row WHERE row.type = 'UPDATES'
MATCH (source {id: row.source})
MATCH (target {id: row.target})
WITH source, target, row,
  apoc.convert.fromJsonMap(row.properties_json) AS props
CALL apoc.create.relationship(source, 'UPDATES', props, target)
YIELD rel
RETURN rel
;

// Create UPGRADES relationships
LOAD CSV WITH HEADERS FROM 'file:///knowledge_graph_neo4j_edges.csv' AS row
WITH row WHERE row.type = 'UPGRADES'
MATCH (source {id: row.source})
MATCH (target {id: row.target})
WITH source, target, row,
  apoc.convert.fromJsonMap(row.properties_json) AS props
CALL apoc.create.relationship(source, 'UPGRADES', props, target)
YIELD rel
RETURN rel
;

// Create USES relationships
LOAD CSV WITH HEADERS FROM 'file:///knowledge_graph_neo4j_edges.csv' AS row
WITH row WHERE row.type = 'USES'
MATCH (source {id: row.source})
MATCH (target {id: row.target})
WITH source, target, row,
  apoc.convert.fromJsonMap(row.properties_json) AS props
CALL apoc.create.relationship(source, 'USES', props, target)
YIELD rel
RETURN rel
;


// Step 4: Useful queries

// Find all units produced by a specific building
MATCH (b:Building {name: 'Barracks'})-[r:PRODUCES]->(u:Unit) RETURN b, u;

// Find the entire tech tree for Confederation faction
MATCH (n) WHERE n.faction = 'Confederation' OR n.faction = 'both' RETURN n;

// Find all systems that the Battle System depends on
MATCH (s:System {name: 'Battle System'})-[r:DEPENDS_ON]->(dep:System) RETURN s, dep, r;

// Find shortest path from Headquarters to Nuclear Silo
MATCH path = shortestPath((a {name: 'Headquarters'})-[*]-(b {name: 'Nuclear Silo'})) RETURN path;

// Find all units that can attack a specific unit
MATCH (attacker)-[r:ATTACKS]->(u:Unit {name: 'Tiger'}) RETURN attacker, r;

// Find all buildings that require power from Power Plant
MATCH (p:Building {name: 'Power Plant'})-[r:POWERS]->(b:Building) RETURN p, b, r;

// Get the complete class dependency graph
MATCH (c:Class)-[r]->(other) RETURN c, other, r;