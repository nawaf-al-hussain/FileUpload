# Art of War 3: Global Conflict — Deployment Diagram

> Physical deployment architecture showing how game components  
> are distributed across client devices, servers, and data stores.

## Diagram

```mermaid
flowchart TB
    %% ============================================================
    %% MOBILE CLIENT NODE
    %% ============================================================

    subgraph MobileDevice["📱 Mobile Device (Android / iOS)"]
        direction TB

        subgraph AppProcess["Application Process (Unity Player)"]
            direction TB
            UnityRuntime["Unity Runtime<br/>IL2CPP / Mono<br/>2020.3 LTS"]
            GameDLLs["Game Assemblies<br/>Assembly-CSharp.dll<br/>29,334 types / 140,824 methods"]
            Plugins["Native Plugins<br/>Firebase SDK<br/>SQLite<br/>DOTween"]
        end

        subgraph LocalStorage["Local Storage"]
            SQLiteDB["📂 SQLite Database<br/>player_state.db<br/>game_cache.db"]
            Prefs["📂 Shared Prefs / PlayerPrefs<br/>Settings, Auth Tokens"]
            AssetCache["📂 Addressables Cache<br/>Downloaded bundles<br/>~500MB-1.5GB"]
            ReplayCache["📂 Replay Cache<br/>Battle recordings<br/>~50MB per replay"]
        end

        subgraph OSResources["OS Resources"]
            GPU["🎮 GPU (Adreno / Mali / Apple)"]
            RAM["💾 RAM (2-6GB)"]
            NetworkStack["🌐 Network Stack<br/>TCP/UDP Sockets<br/>SSL/TLS"]
        end
    end

    %% ============================================================
    %% CDN / CONTENT DELIVERY
    %% ============================================================

    subgraph CDN["☁️ CDN / Content Delivery"]
        UnityCC["Unity Cloud Content Delivery<br/>Addressables Hosting<br/>Asset Bundles"]
        UpdateServer["Update Server<br/>APK / OBB Distribution<br/>Google Play / App Store"]
    end

    %% ============================================================
    %% MAIN SERVER CLUSTER
    %% ============================================================

    subgraph MainCluster["🖥️ Main Server Cluster (Load Balanced)"]
        direction TB

        subgraph LoadBalancer["Load Balancer / API Gateway"]
            LB["🔀 Nginx / HAProxy<br/>Rate Limiting<br/>SSL Termination<br/>DDoS Protection"]
        end

        subgraph AppServers["Application Servers"]
            direction LR
            AuthNode["🔐 Auth Node<br/>Login, JWT Tokens<br/>Session Management<br/>Social Auth (Google/FB)"]
            PlayerNode["👤 Player Node<br/>Profiles, Progression<br/>Inventory, Resources<br/>Achievements"]
            MatchNode["🎯 Match Node<br/>Matchmaking Queue<br/>ELO Rating<br/>Match Creation"]
            ClanNode["🏰 Clan Node<br/>Clan CRUD<br/>Wars, Diplomacy<br/>Roster Management"]
            ChatNode["💬 Chat Node<br/>Channels (Global/Clan/PM)<br/>Message History<br/>Moderation / Filtering"]
            EconomyNode["💰 Economy Node<br/>In-App Purchases<br/>Resource Transactions<br/>Shop Catalog"]
        end

        subgraph MessageBus["Internal Message Bus"]
            RabbitMQ["📨 RabbitMQ / Kafka<br/>Event-driven communication<br/>Clan notifications<br/>Match events"]
        end
    end

    %% ============================================================
    %% BATTLE SERVER CLUSTER
    %% ============================================================

    subgraph BattleCluster["⚔️ Battle Server Cluster (Elastic)"]
        direction TB

        subgraph BattleOrchestrator["Battle Orchestrator"]
            BOrch["🎯 Battle Orchestrator<br/>Battle Assignment<br/>Server Selection<br/>Capacity Management"]
        end

        subgraph BattleInstances["Battle Server Instances (Docker)"]
            direction LR
            BS1["⚔️ Battle Instance #1<br/>2-8 Players<br/>Authoritative Simulation<br/>Tick-based Sync"]
            BS2["⚔️ Battle Instance #2<br/>2-8 Players<br/>Authoritative Simulation<br/>Tick-based Sync"]
            BS3["⚔️ Battle Instance #N<br/>2-8 Players<br/>Authoritative Simulation<br/>Tick-based Sync"]
        end

        subgraph BattleInfra["Battle Infrastructure"]
            BMonitor["📊 Battle Monitor<br/>Health Checks<br/>Auto-scaling Triggers<br/>Latency Monitoring"]
            BRecorder["📼 Replay Service<br/>Battle Recording<br/>Replay Compression<br/>Replay Storage"]
        end
    end

    %% ============================================================
    %% DATA STORES
    %% ============================================================

    subgraph DataStores["🗄️ Data Stores"]
        direction TB

        subgraph RelationalDB["Relational Database"]
            PSQL["🐘 PostgreSQL<br/>Player Profiles<br/>Clan Data<br/>Battle History<br/>Transaction Log"]
        end

        subgraph CacheLayer["Cache Layer"]
            Redis["⚡ Redis Cluster<br/>Session Tokens<br/>Matchmaking Queue<br/>Leaderboards<br/>Rate Limiting"]
        end

        subgraph ObjectStore["Object Storage"]
            S3["📦 S3 / MinIO<br/>Replay Files<br/>Battle Reports<br/>Crash Dumps<br/>Analytics Raw Data"]
        end

        subgraph AnalyticsStore["Analytics Store"]
            FirebaseDB["📊 Firebase BigQuery<br/>Event Streams<br/>Retention Data<br/>Funnel Analysis"]
            Crashlytics["🔴 Crashlytics<br/>Crash Reports<br/>Stack Traces<br/>IL2CPP Symbolication"]
        end

        subgraph ConfigStore["Configuration Store"]
            GameConfig["📋 Game Config DB<br/>Unit Stats<br/>Building Stats<br/>Weapon Stats<br/>Economy Balance"]
        end
    end

    %% ============================================================
    %% EXTERNAL SERVICES
    %% ============================================================

    subgraph ExternalServices["🌐 External Services"]
        direction LR
        GooglePlay["🏪 Google Play<br/>IAP Verification<br/>License Check"]
        AppleStore["🏪 App Store<br/>IAP Verification<br/>Receipt Validation"]
        PushNotif["🔔 Push Notifications<br/>FCM / APNs<br/>Clan Invites<br/>Battle Ready"]
    end

    %% ============================================================
    %% CONNECTIONS
    %% ============================================================

    %% Client → CDN
    AppProcess ===>|"HTTPS<br/>Asset Bundle Download"| UnityCC
    AppProcess ===>|"HTTPS<br/>App Update Check"| UpdateServer

    %% Client → Main Server
    NetworkStack ===>|"HTTPS / WSS<br/>Port 443<br/>Encrypted"| LB
    LB --> AuthNode
    LB --> PlayerNode
    LB --> MatchNode
    LB --> ClanNode
    LB --> ChatNode
    LB --> EconomyNode

    %% Client → Battle Server (direct)
    NetworkStack ===>|"TCP + UDP<br/>Ports 7000-7999<br/>Encrypted Game Protocol"| BOrch
    BOrch --> BS1
    BOrch --> BS2
    BOrch --> BS3

    %% Internal: Main Server → Message Bus
    AuthNode --- RabbitMQ
    MatchNode --- RabbitMQ
    ClanNode --- RabbitMQ
    ChatNode --- RabbitMQ
    EconomyNode --- RabbitMQ

    %% Internal: Main → Battle
    MatchNode -.->|"gRPC / Internal API<br/>Battle Assignment"| BOrch
    BMonitor -.->|"Health / Metrics"| BOrch

    %% Internal: Servers → Data
    AuthNode --> Redis
    PlayerNode --> PSQL
    MatchNode --> Redis
    MatchNode --> PSQL
    ClanNode --> PSQL
    ChatNode --> Redis
    EconomyNode --> PSQL
    EconomyNode --> Redis
    BS1 --> PSQL
    BS2 --> PSQL
    BS3 --> PSQL
    BRecorder --> S3
    BRecorder --> PSQL

    %% Internal: Config
    PlayerNode --> GameConfig
    BS1 --> GameConfig
    BS2 --> GameConfig
    BS3 --> GameConfig

    %% Client → External
    AppProcess -.->|"IAP Verification"| GooglePlay
    AppProcess -.->|"IAP Verification"| AppleStore

    %% Server → External
    EconomyNode --> GooglePlay
    EconomyNode --> AppleStore
    AuthNode -.->|"Push (via FCM)"| PushNotif

    %% Analytics
    AppProcess -.->|"Firebase SDK<br/>Analytics Events"| FirebaseDB
    AppProcess -.->|"Crash Reports"| Crashlytics

    %% Client Local
    GameDLLs --> SQLiteDB
    GameDLLs --> Prefs
    GameDLLs --> AssetCache
    UnityRuntime --> GPU
    UnityRuntime --> RAM
    GameDLLs --> NetworkStack

    %% Style
    classDef client fill:#3498db,stroke:#2471a3,color:#fff
    classDef cdn fill:#f39c12,stroke:#d68910,color:#fff
    classDef mainserver fill:#2ecc71,stroke:#27ae60,color:#fff
    classDef battleserver fill:#e74c3c,stroke:#c0392b,color:#fff
    classDef datastore fill:#9b59b6,stroke:#7d3c98,color:#fff
    classDef external fill:#95a5a6,stroke:#7f8c8d,color:#fff
    classDef infra fill:#1abc9c,stroke:#148f77,color:#fff

    class UnityRuntime,GameDLLs,Plugins,SQLiteDB,Prefs,AssetCache,ReplayCache,GPU,RAM,NetworkStack client
    class UnityCC,UpdateServer cdn
    class LB,AuthNode,PlayerNode,MatchNode,ClanNode,ChatNode,EconomyNode,RabbitMQ mainserver
    class BOrch,BS1,BS2,BS3,BMonitor,BRecorder battleserver
    class PSQL,Redis,S3,FirebaseDB,Crashlytics,GameConfig datastore
    class GooglePlay,AppleStore,PushNotif external
    class LB,BOrch,BMonitor infra
```

## Explanation

This deployment diagram shows how Art of War 3's components are **physically distributed** across infrastructure.

### Node Types

| Node | Hardware | Purpose |
|------|----------|---------|
| **Mobile Device** | Android/iOS smartphone | Game client with Unity IL2CPP runtime, local SQLite, and Addressables cache |
| **CDN** | Cloud CDN (Unity CCD) | Asset bundle delivery for Addressables — game content is downloaded on demand |
| **Main Server Cluster** | Cloud VMs behind load balancer | Stateful services: auth, player, matchmaking, clan, chat, economy |
| **Battle Server Cluster** | Elastic Docker containers | Authoritative battle simulation instances — auto-scaled based on concurrent battles |
| **Data Stores** | Managed DB services | PostgreSQL (relational), Redis (cache), S3 (object), Firebase (analytics), Config DB |
| **External Services** | Third-party APIs | Google Play / App Store for IAP, FCM/APNs for push notifications |

### Key Deployment Patterns

1. **Client-Server Architecture**: The client never trusts local state for multiplayer — battle simulation runs authoritatively on Battle Servers. The client sends commands (`CSUnitCommand`, `CSBuildingCommand`), the server simulates and broadcasts state (`SCBattleState`).

2. **Dual Connection Model**:
   - **HTTPS/WSS (Port 443)** → Main Server for meta-game operations (auth, matchmaking, chat, clan)
   - **TCP+UDP (Ports 7000-7999)** → Battle Server for real-time gameplay with low-latency UDP for state sync and TCP for reliable commands

3. **Elastic Battle Servers**: Battle instances are Docker containers that spin up per-match and spin down afterward. The `BattleOrchestrator` assigns players to instances based on latency (`CheckConnectionToBattleHosts`), and `BattleMonitor` handles auto-scaling.

4. **Local-First Client**: The client uses SQLite for offline capability — player progression and game cache survive network interruptions. Addressables cache can grow to 1.5GB with all content downloaded.

5. **IL2CPP Symbolication**: Crash reports from the IL2CPP build require symbolication — `Crashlytics` receives raw crash dumps that must be resolved using IL2CPP symbol files stored separately.

6. **Internal Communication**: Main Server nodes communicate via RabbitMQ/Kafka for event-driven patterns (clan war declarations, match completion notifications). The Match Node communicates with Battle Orchestrator via gRPC for low-latency battle assignment.

### Network Protocol Summary

| Connection | Protocol | Encryption | Purpose |
|-----------|----------|------------|---------|
| Client → CDN | HTTPS | TLS 1.3 | Asset bundle downloads |
| Client → Main Server | HTTPS / WSS | TLS 1.3 | Auth, meta-game, matchmaking |
| Client → Battle Server | TCP + UDP | Game-level encryption | Real-time battle sync |
| Main ↔ Battle | gRPC | mTLS | Battle assignment, results |
| Server → DB | PostgreSQL wire / Redis protocol | TLS | Data persistence |
| Client → Firebase | HTTPS | TLS | Analytics, crash reporting |
