# Recreation Mapping: Hero System

## Purpose

The Hero System manages the special hero units in Art of War 3: Global Conflict, which are powerful, unique units that possess active abilities beyond standard unit commands. Each faction has 6 hero units organized by tier: T1 heroes (2 per faction, basic abilities), T2 heroes (2 per faction, moderate abilities), and T3 heroes (2 per faction, powerful game-changing abilities). Heroes differ from standard units in that they have mana/energy pools, activatable abilities with cooldowns, unique visual effects, and voice-over lines. They serve as force multipliers that can turn the tide of battle with timely ability usage, adding a micro-intensive skill layer to the RTS formula. The system handles ability activation, cooldown management, mana/energy consumption, area-of-effect targeting, buff/debuff application, and hero-specific death and respawn mechanics.

## Inputs

- **Player Input**: Ability activation (hotkey or button click), target selection for targeted abilities
- **Unit System**: Hero unit position, health, mana/energy state
- **Combat System**: Damage events that may interrupt channeled abilities
- **Upgrade/Tech System**: Tier unlock requirements for hero production
- **Economy System**: Hero production cost (typically higher than standard units)

## Outputs

- **Ability Effects**: Damage, healing, buffs, debuffs, summons, terrain modification
- **Visual Effects**: Ability-specific VFX (shockwaves, beams, auras, explosions)
- **Audio Events**: Hero voice lines on ability activation, death, and spawn
- **Cooldown State**: Ability availability for UI display
- **Mana/Energy State**: Current resource pool for UI display

## Dependencies

- **Unit System**: Heroes are units with additional components
- **Combat System**: For damage application from offensive abilities
- **Economy System**: For production cost
- **Upgrade/Tech System**: For tier-gated hero availability
- **GUI System**: For ability panel, cooldown indicators, mana bar
- **Audio System**: For hero voice-overs
- **Network System**: For ability activation synchronization

## Internal Logic

Each hero unit extends the standard unit with two additional components: `HeroAbilityComponent` and `HeroManaComponent`. The `HeroAbilityComponent` contains a list of `Ability` objects (typically 2-3 per hero: a basic ability, an ultimate, and sometimes a passive). Each `Ability` has: activation cost (mana/energy), cooldown duration, cast time (0 for instant, >0 for channeled), range, targeting mode (self, targeted unit, targeted point, area), and the effect implementation.

The ability activation flow: (1) Player presses ability hotkey, (2) System checks if ability is off cooldown and hero has sufficient mana, (3) If targeted ability, enter targeting mode (cursor changes), (4) Player selects target, (5) System validates range and line-of-sight, (6) Deduct mana, start cooldown, (7) Execute ability effect — apply damage/heal, spawn VFX, apply buffs/debuffs, (8) Play hero voice line.

Buffs and debuffs are temporary status effects applied to units. Each buff has: duration, tick interval (for DoT/HoT), stat modifiers, and visual indicator (aura, icon). Buffs are managed by a `BuffManager` that tracks all active buffs per unit and expires them when their duration elapses.

Hero death differs from standard unit death — heroes may have a longer death animation with a special voice line, and in some game modes, heroes can be "revived" at the base for a resource cost after a cooldown period. This makes hero preservation a strategic consideration.

## Pseudocode

```
class HeroSystem:
    heroes: Map<UnitID, HeroUnit>
    buffManager: BuffManager

    function activateAbility(heroUnitID, abilityIndex, target=null):
        hero = heroes[heroUnitID]
        ability = hero.abilities[abilityIndex]
        // Validation
        if ability.cooldownRemaining > 0:
            return ABILITY_FAIL_ON_COOLDOWN
        if hero.mana < ability.manaCost:
            return ABILITY_FAIL_INSUFFICIENT_MANA
        if ability.requiresTarget and target is null:
            return ABILITY_FAIL_NEEDS_TARGET
        if ability.range > 0 and distance(hero.position, target.position) > ability.range:
            return ABILITY_FAIL_OUT_OF_RANGE
        // Execute
        hero.mana -= ability.manaCost
        ability.cooldownRemaining = ability.cooldownDuration
        executeAbility(hero, ability, target)
        audioSystem.playVoiceLine(hero.voiceSet.abilityLines[abilityIndex])
        networkSystem.broadcastAbility(heroUnitID, abilityIndex, target)

    function executeAbility(hero, ability, target):
        switch ability.targetingMode:
            case SELF:
                applyAbilityEffects(hero, ability, hero)
            case TARGET_UNIT:
                applyAbilityEffects(hero, ability, target)
            case TARGET_POINT:
                unitsInArea = spatialQuery.findAllInRange(target.point, ability.aoeRadius)
                for unit in unitsInArea:
                    applyAbilityEffects(hero, ability, unit)
            case AREA:
                // Point-blank AoE around the hero
                unitsInArea = spatialQuery.findAllInRange(hero.position, ability.aoeRadius)
                for unit in unitsInArea:
                    applyAbilityEffects(hero, ability, unit)
        vfxSystem.spawnAbilityVFX(ability.vfxId, hero.position, target)

    function applyAbilityEffects(caster, ability, target):
        for effect in ability.effects:
            switch effect.type:
                case DAMAGE:
                    combatSystem.applyAbilityDamage(caster, target, effect.value, effect.damageType)
                case HEAL:
                    target.heal(effect.value)
                case BUFF:
                    buffManager.applyBuff(target, effect.buffDef)
                case DEBUFF:
                    buffManager.applyDebuff(target, effect.debuffDef)
                case SUMMON:
                    for i in range(effect.summonCount):
                        summonPos = caster.position + randomOffset(effect.spawnRadius)
                        unit = unitSystem.spawnUnit(effect.summonType, caster.faction, summonPos)
                        summonDuration = effect.duration
                        buffManager.applyTimedExistence(unit, summonDuration)
                case STUN:
                    target.stun(effect.duration)
                case KNOCKBACK:
                    direction = (target.position - caster.position).normalized
                    target.pushDirection = direction * effect.force

    function updateBuffs(deltaTime):
        for unit, buffList in buffManager.activeBuffs:
            toRemove = []
            for buff in buffList:
                buff.remainingDuration -= deltaTime
                if buff.remainingDuration <= 0:
                    toRemove.append(buff)
                    onBuffExpired(unit, buff)
                elif buff.tickInterval > 0:
                    buff.tickTimer -= deltaTime
                    if buff.tickTimer <= 0:
                        buff.tickTimer = buff.tickInterval
                        onBuffTick(unit, buff)
            for buff in toRemove:
                buffList.remove(buff)
                removeBuffVisuals(unit, buff)

class Ability:
    name: string
    targetingMode: TargetingMode  // SELF, TARGET_UNIT, TARGET_POINT, AREA
    manaCost: float
    cooldownDuration: float
    cooldownRemaining: float = 0
    castTime: float = 0
    range: float
    aoeRadius: float = 0
    effects: List<AbilityEffect>
    vfxId: string

class Buff:
    def: BuffDefinition
    remainingDuration: float
    tickTimer: float
    source: UnitID

class BuffDefinition:
    name: string
    duration: float
    tickInterval: float = 0  // 0 = no ticking
    statModifiers: List<StatModifier]
    isDebuff: bool
    visualEffect: string  // Aura VFX ID
    icon: string  // UI icon
```

## Modern Implementation Recommendations

| Approach | Recommendation |
|----------|---------------|
| **Best Overall** | **Unity 2023 + ScriptableObjects + DOTS** — `AbilityDefinition` as ScriptableObject (designer-friendly). `AbilityExecutionSystem : SystemBase` for runtime logic. `DynamicBuffer<ActiveBuff>` per unit entity. |
| **Alternative Engine** | **Godot 4 with C#** — `Ability : Resource` definitions. `BuffManager : Node` autoload. Signals for ability activation events. `AnimationTree` for ability animations. |
| **Data-Driven** | **JSON ability definitions + Lua scripting** — Abilities defined in JSON with effect lists. Lua scripts for complex/custom ability logic. Enables modding and rapid iteration. |
| **Rust + Bevy** | — `Ability` as a `Component` on hero entities. `ActiveBuff` as `DynamicBuffer`. `HeroAbilitySystem` queries for `(Hero, Ability, Mana)` and processes activations. |

**Key patterns to adopt:**
- Ability definitions as data (ScriptableObject/Resource/JSON), execution as code
- Buff/debuff manager as a separate subsystem — not embedded in unit logic
- Targeting mode enum with validation per mode (self, unit, point, area)
- Cooldown and mana as pre-validation checks before any effect executes
- Buff stacking rules (replace, refresh, stack, ignore) to prevent exploits
- Ability queue for sequenced casting (hero finishes current ability before starting next)
- Network-synchronized ability activation with server-side validation
