# Combat State Machine — Art of War 3: Global Conflict

Detailed combat behavior state machine covering targeting, weapon firing, damage calculation,
death mechanics, special abilities, and weapon-type-specific behaviors.

## Primary Combat State Machine

```mermaid
stateDiagram-v2
    direction TB

    [*] --> CombatIdle : Unit in range of enemies
    CombatIdle --> Targeting : Auto-aggro triggered\n[calcShooter() acquires target]
    CombatIdle --> CombatIdle : No enemies in range\n[Scan continues]

    Targeting --> EvaluatingTarget : Target candidate found\n[calcShooter() returns target]
    Targeting --> CombatIdle : No valid targets\n[All enemies out of range / Dead]

    EvaluatingTarget --> Aiming : Target valid\n[In range, line of sight clear]
    EvaluatingTarget --> Targeting : Target invalid\n[Out of range / No LoS / Ally]
    EvaluatingTarget --> Targeting : Target died\n[Select next target]

    Aiming --> Firing : Aim complete\n[Weapon facing target]
    Aiming --> Targeting : Target moved out of range\n[Reacquire]
    Aiming --> Targeting : Target died during aim\n[Select next target]

    Firing --> Cooldown : Shot fired\n[Projectile created / Damage applied]
    Firing --> Targeting : Target destroyed by shot\n[Select next target]
    Firing --> Reloading : Magazine empty\n[Ammo depleted]

    Cooldown --> Aiming : Cooldown complete\n[Target still valid & alive]
    Cooldown --> Targeting : Target died during cooldown\n[Select next target]
    Cooldown --> Retreating : HP < retreatThreshold\n[Self-preservation override]

    Reloading --> Aiming : Reload complete\n[Magazine refilled]
    Reloading --> Retreating : HP < retreatThreshold\n[Retreat during reload]

    Retreating --> CombatIdle : Safe distance reached\n[No enemies pursuing]
    Retreating --> Targeting : Cornered\n[No retreat path, must fight]
    Retreating --> Retreating : Continue retreating

    note right of EvaluatingTarget
        Target evaluation criteria:
        1. Range check (weapon range vs distance)
        2. Line of sight (no obstacles)
        3. Target type validity
           - Anti-air can target aircraft
           - Anti-armor can target vehicles
           - Infantry weapons target all
        4. Priority scoring
           - Threat level
           - Distance (nearest first)
           - HP (lowest first for kills)
        Method: calcShooter() handles selection
    end note

    note right of Firing
        Firing applies:
        CalculateWeaponArmorDamage()
        - Base weapon damage
        - Armor reduction
        - Type modifier (bonus/penalty)
        - Random variance (±15%)
        - Critical hit chance (5%)
    end note
```

## Damage Calculation Pipeline

```mermaid
stateDiagram-v2
    direction TB

    [*] --> IncomingAttack : Projectile/Ability hits unit
    IncomingAttack --> DetermineDamageType : Attack received\n[Weapon type identified]

    DetermineDamageType --> CalculateBaseDamage : Weapon type determined\n[Ballistic / Energy / Explosive / Special]

    CalculateBaseDamage --> ApplyArmorReduction : Base damage calculated\n[Weapon damage × multiplier]

    ApplyArmorReduction --> DetermineArmorType : Target armor type checked
    DetermineArmorType --> ApplyArmorFormula : Armor type: Light / Medium / Heavy / None

    state "Armor Calculation" as ArmorCalc {
        [*] --> LightArmor : Infantry, Trucks
        [*] --> MediumArmor : Vehicles, Turrets
        [*] --> HeavyArmor : Tanks, Structures
        [*] --> NoArmor : Supply trucks, Aircraft (to AA)

        LightArmor --> DamageModified : CreateDamageForMediumArmor()\nmodifier varies by weapon
        MediumArmor --> DamageModified : Standard armor formula
        HeavyArmor --> DamageModified : Reduced damage\n[50% vs non-anti-armor]
        NoArmor --> DamageModified : Full damage taken
    }

    ApplyArmorFormula --> ApplyTypeModifiers : Armor reduction applied\n[Damage = Base × (1 - Armor%)]
    ApplyTypeModifiers --> ApplyRandomVariance : Type bonuses applied\n[Anti-armor vs Armor, etc.]

    ApplyRandomVariance --> CheckCriticalHit : Variance ±15% applied
    CheckCriticalHit --> ApplyDamage : Roll crit (5% chance)\n[Crit: 2× damage]
    CheckCriticalHit --> ApplyDamage : Normal hit\n[No crit]

    ApplyDamage --> CheckDeath : HP reduced
    CheckDeath --> UnitDying : HP <= 0\n[DestroyUnit() queued]
    CheckDeath --> CheckStun : HP > 0\n[Check for stun effect]
    CheckStun --> ApplyStun : Stun weapon type\n[Stun duration applied]
    CheckStun --> CombatContinues : No stun\n[Continue fighting]

    ApplyStun --> CombatContinues : Stun applied\n[Stunned state entered]
    UnitDying --> [*] : Death sequence
    CombatContinues --> [*] : Return to combat

    note right of ApplyTypeModifiers
        Damage type vs Armor table:
        ┌──────────────┬───────┬────────┬───────┬───────┐
        │ Weapon Type  │ Light │ Medium │ Heavy │ None  │
        ├──────────────┼───────┼────────┼───────┼───────┤
        │ Ballistic    │ 100%  │  75%   │  50%  │ 125%  │
        │ Explosive    │ 150%  │ 100%   │  75%  │ 100%  │
        │ Anti-Armor   │  75%  │ 150%   │ 200%  │ 100%  │
        │ Energy       │ 100%  │ 100%   │ 100%  │ 100%  │
        │ Fire         │ 125%  │  75%   │  50%  │ 150%  │
        │ Anti-Air     │  50%  │  50%   │  50%  │ 200%* │
        └──────────────┴───────┴────────┴───────┴───────┘
        * 200% vs aircraft specifically
    end note
```

## Weapon Type State Machines

```mermaid
stateDiagram-v2
    direction TB

    state "Ballistic Weapon (Infantry/Standard)" as Ballistic {
        [*] --> B_Ready
        B_Ready --> B_Aiming : Target acquired
        B_Aiming --> B_Firing : Aimed (0.3s)
        B_Firing --> B_Cooldown : Shot fired
        B_Cooldown --> B_Ready : Cooldown (0.5-1.0s)
    }

    state "Explosive Weapon (Grenades/Rockets)" as Explosive {
        [*] --> E_Ready
        E_Ready --> E_Aiming : Target acquired
        E_Aiming --> E_Firing : Aimed (0.5s)
        E_Firing --> E_ProjectileInFlight : Projectile launched
        E_ProjectileInFlight --> E_Impact : Projectile reaches target
        E_Impact --> E_SplashCalculation : AOE damage calculated
        E_SplashCalculation --> E_Cooldown : All targets damaged
        E_Cooldown --> E_Ready : Cooldown (1.5-3.0s)
    }

    state "Anti-Armor Weapon (AT Guns/Missiles)" as AntiArmor {
        [*] --> AA_Ready
        AA_Ready --> AA_Targeting : Armored target acquired
        AA_Targeting --> AA_LockOn : Target in range\n[Lock-on: 1.0s]
        AA_LockOn --> AA_Firing : Lock confirmed
        AA_Firing --> AA_ProjectileFlight : Missile launched
        AA_ProjectileFlight --> AA_Impact : Direct hit
        AA_Impact --> AA_Cooldown : Damage applied\n[CreateDamageForMediumArmor()]
        AA_Cooldown --> AA_Ready : Cooldown (2.0-4.0s)
        AA_Targeting --> AA_Ready : Target lost\n[No lock-on possible]
    }

    state "Anti-Air Weapon (SAM/Flak)" as AntiAir {
        [*] --> AAA_Ready
        AAA_Ready --> AAA_ScanningSky : Airborne enemy detected
        AAA_ScanningSky --> AAA_LockOn : Aircraft in range\n[Lock-on: 0.8s]
        AAA_LockOn --> AAA_Firing : Lock confirmed
        AAA_Firing --> AAA_MissileTracking : SAM launched
        AAA_MissileTracking --> AAA_Hit : Missile connects
        AAA_MissileTracking --> AAA_Missed : Aircraft evaded\n[Countermeasures / Out of range]
        AAA_Hit --> AAA_Cooldown : Damage applied
        AAA_Missed --> AAA_Cooldown : Missile lost
        AAA_Cooldown --> AAA_Ready : Cooldown (3.0-5.0s)
    }

    state "Melee Weapon (Bayonet/Blade)" as Melee {
        [*] --> M_Ready
        M_Ready --> M_Charging : Target in melee range\n[< 1.5 tiles]
        M_Charging --> M_Striking : In melee range
        M_Striking --> M_Cooldown : Strike delivered
        M_Cooldown --> M_Ready : Cooldown (0.8s)
        M_Charging --> M_Ready : Target moved away\n[Cannot reach]
    }
```

## Special Ability Combat State Machine

```mermaid
stateDiagram-v2
    direction TB

    [*] --> AbilityReady : Combat starts
    AbilityReady --> AbilityActivating : ActivateAbility()\n[Energy/Mana sufficient]
    AbilityReady --> AbilityLocked : Cooldown not expired\n/ Prerequisite not met

    AbilityLocked --> AbilityReady : Cooldown complete\n[OnAbilityCooldownHandler() fires]
    AbilityActivating --> AbilityChanneling : Cast time complete\n[Channeled abilities]

    state "Ability Types" as AbilityTypes {
        state "Instant Ability" as Instant {
            [*] --> I_Cast
            I_Cast --> I_Active : Immediate effect
            I_Active --> I_Cooldown : Effect applied
        }

        state "Channeled Ability" as Channeled {
            [*] --> Ch_Cast
            Ch_Cast --> Ch_Channeling : Cast time complete
            Ch_Channeling --> Ch_Channeling : Tick damage/effect\n[every 0.5s]
            Ch_Channeling --> Ch_Complete : Duration expires
            Ch_Channeling --> Ch_Interrupted : Stunned / Silenced / Moved
            Ch_Complete --> Ch_Cooldown
            Ch_Interrupted --> Ch_Cooldown : Partial cooldown
        }

        state "Toggle Ability" as Toggle {
            [*] --> T_Activate
            T_Activate --> T_Active : Toggled on
            T_Active --> T_Draining : Energy draining per tick
            T_Draining --> T_Active : Still has energy
            T_Draining --> T_Deactivate : Energy depleted
            T_Active --> T_Deactivate : DeactivateActiveAbility()
            T_Deactivate --> T_Cooldown
        }

        state "Passive Ability" as Passive {
            [*] --> P_Trigger
            P_Trigger --> P_Active : Trigger condition met\n[abilityPassiveWeaponActivate()]
            P_Active --> P_Duration : Duration started
            P_Duration --> P_Trigger : Duration expires\n[Can re-trigger]
        }
    }

    AbilityChanneling --> AbilityTypes : Ability type determined
    I_Cooldown --> AbilityReady : Cooldown expires
    Ch_Cooldown --> AbilityReady : Cooldown expires
    T_Cooldown --> AbilityReady : Cooldown expires

    note right of AbilityTypes
        Hero ability examples:
        - Instant: Artillery strike, EMP burst
        - Channeled: Suppressive fire, Healing beam
        - Toggle: Chameleon fog barrier, Stealth mode
        - Passive: Damage aura, Auto-repair

        Method: GetAbilityStates() returns
        { Ready, Active, Channeling, Cooldown, Locked }
    end note
```

## Death & Destruction State Machine

```mermaid
stateDiagram-v2
    direction TB

    [*] --> DeathTrigger : HP <= 0\n[CalculateWeaponArmorDamage result]
    DeathTrigger --> DeathAnimation : DestroyUnit() called\n[Play death anim]

    state "Unit Death" as UnitDeath {
        DeathAnimation --> ExplosionEffect : Vehicle/Naval death\n[Explosion VFX + SFX]
        DeathAnimation --> RagdollEffect : Infantry death\n[Ragdoll physics]
        DeathAnimation --> CrashEffect : Aircraft death\n[Crash + explosion]
        DeathAnimation --> SinkEffect : Submarine death\n[Sinking animation]

        ExplosionEffect --> WreckageState : Animation complete
        RagdollEffect --> CorpseState : Animation complete
        CrashEffect --> CrashSiteState : Animation complete
        SinkEffect --> DebrisState : Animation complete

        WreckageState --> FadingOut : 10s timer\n[Wreckage fades]
        CorpseState --> FadingOut : 8s timer\n[Corpse fades]
        CrashSiteState --> FadingOut : 12s timer\n[Debris fades]
        DebrisState --> FadingOut : 5s timer\n[No visible debris]
    }

    state "Building Destruction" as BuildingDestruction {
        [*] --> BuildingDeathTrigger : HP <= 0
        BuildingDeathTrigger --> BuildingExplosion : Major explosion VFX\n[Chain explosion if ammo stored]
        BuildingExplosion --> RubbleState : Explosion complete
        RubbleState --> RubbleRemaining : Rubble persists\n[Blocks construction]
        RubbleRemaining --> Cleared : Engineer clears\n/ Auto-clear timer (30s)
        Cleared --> [*] : Area available for building
    }

    FadingOut --> [*] : Unit fully removed from game
    FadingOut --> ExperienceAwarded : XP granted to killer\n[Veterancy check]

    note right of DeathTrigger
        Death sequence order:
        1. HP <= 0 detected
        2. DestroyUnit() called
        3. Unit removed from selection
        4. Death animation plays
        5. Population count decreased
        6. Experience awarded to killer
        7. Kill count incremented
        8. UI notification (if hero/important)
        9. Wreckage/corpse created
        10. Cleanup after fade
    end note

    note right of BuildingDestruction
        Building destruction special cases:
        - Power Plant: Power deficit cascade
          (other buildings may shut down)
        - Production: Queued units lost
          (partial refund if any)
        - Superweapon: If armed, explosion
          damages nearby friendly units
        - Airport: Aircraft crash if airborne
          and no other airport available
    end note
```

## Combat Engagement Macro State

```mermaid
stateDiagram-v2
    direction TB

    [*] --> NoEngagement : Units idle / moving
    NoEngagement --> Skirmish : Small force contact\n[< 5 units per side]

    Skirmish --> NoEngagement : One side retreats\n[Disengaged]
    Skirmish --> Battle : Reinforcements arrive\n[5+ units per side]
    Skirmish --> Skirmish : Ongoing small fight\n[Units trading fire]

    Battle --> Skirmish : One side depleted\n[< 5 units remaining]
    Battle --> NoEngagement : One side destroyed\n/ Fully retreated
    Battle --> Battle : Reinforcements arrive\n[Escalation]
    Battle --> Siege : Attacking base\n[Defensive structures involved]

    Siege --> Battle : Breached defenses\n[Inside base perimeter]
    Siege --> NoEngagement : Attack repelled\n[Attackers destroyed/retreated]
    Siege --> BaseDestroyed : All defenses down\n[Base captured/destroyed]

    BaseDestroyed --> NoEngagement : Battle resolved\n[Winner established]

    note right of Battle
        Combat intensity levels:
        Skirmish: Low intensity
          - Few units involved
          - Local tactical decision
          - No strategic impact

        Battle: Medium intensity
          - Multiple squads involved
          - Hero abilities matter
          - Resource investment at risk

        Siege: High intensity
          - Defensive structures active
          - Production at stake
          - Power grid may cascade
          - Superweapon risk

        Base assault: Critical
          - Game-deciding engagement
          - All abilities used
          - Last stand possible
    end note
```
