# Art of War 3: Global Conflict — Architecture Knowledge Graph

## Legend

| Color | Entity Type | Description |
|-------|-------------|-------------|
| 🔵 Blue | Unit | Combat units (infantry, vehicles, aircraft, naval, superweapons) |
| 🟠 Orange | Building | Structures for production, defense, economy |
| 🟢 Green | System | Game engine subsystems |
| 🟣 Purple | Class | Key C# classes in codebase |
| 🔴 Red | Campaign | Story mission sequences |
| 🟦 Teal | Map | Multiplayer/campaign battle maps |
| 🟡 Yellow | Hero | Special hero units |
| 🔷 Light Blue | Network | Multiplayer networking components |

## Relationship Types

| Line Style | Relationship | Meaning |
|------------|-------------|---------|
| ──▶ | `produces` | Building creates unit |
| ──▶ | `depends_on` | Entity requires another to function |
| ──▶ | `attacks` | Combat interaction |
| ──▶ | `upgrades` | Tech tree progression |
| ──▶ | `uses` | Runtime dependency |
| ──▶ | `implements` | Code implements system |
| ──▶ | `references` | Logical association |

---

## 1. Building → Unit Production Tree (Confederation)

```mermaid
graph TD
    subgraph Core Buildings
        HQ[Headquarters]
        CY[Construction Yard]
        PP[Power Plant]
        SC[Supply Center]
    end

    subgraph Production Buildings
        BR[Barracks]
        AVF[Assault Vehicle Factory]
        SVF[Special Vehicle Factory]
        AF[Avia Factory]
        SY[Shipyard]
        AP[Airport]
        HB[Hero Building]
        SW[Superweapon Building]
    end

    subgraph Confederation Infantry
        CE[Engineer]
        CM[Mortar]
        CS[Sniper]
        CRL[Rocket Launcher]
    end

    subgraph Confederation Vehicles
        CCT[Coil Tank]
        CJ[Jaguar]
        CZ[Zeus]
        CPW[Prairie Wolf]
    end

    subgraph Confederation Aircraft
        CA[Albatross]
        CT[Thunderbird]
        CH[Hornet]
        CD[Delta]
    end

    subgraph Confederation Naval
        CT2[Triton]
        CC[Cruiser]
    end

    subgraph Confederation Superweapon
        CNS[Nuclear Silo]
    end

    subgraph Confederation Heroes
        CH1[T1 Hero]
        CH2[T2 Hero]
        CH3[T3 Hero]
    end

    HQ --> CY
    CY --> BR
    CY --> AVF
    CY --> SVF
    CY --> AF
    CY --> SY
    CY --> AP
    CY --> HB
    CY --> SW

    PP -.->|powers| BR
    PP -.->|powers| AVF
    PP -.->|powers| SVF
    PP -.->|powers| AF
    PP -.->|powers| SW

    BR -->|produces| CE
    BR -->|produces| CM
    BR -->|produces| CS
    BR -->|produces| CRL
    AVF -->|produces| CCT
    AVF -->|produces| CJ
    SVF -->|produces| CZ
    SVF -->|produces| CPW
    AF -->|produces| CA
    AF -->|produces| CT
    AF -->|produces| CH
    AF -->|produces| CD
    SY -->|produces| CT2
    SY -->|produces| CC
    SW -->|produces| CNS
    HB -->|produces| CH1
    HB -->|produces| CH2
    HB -->|produces| CH3

    AP -.->|enables| CH
    AP -.->|enables| CD
    CH1 -->|upgrades| CH2
    CH2 -->|upgrades| CH3

    style HQ fill:#E67E22,color:#fff
    style CY fill:#E67E22,color:#fff
    style PP fill:#F1C40F,color:#000
    style SC fill:#F1C40F,color:#000
    style BR fill:#E67E22,color:#fff
    style AVF fill:#E67E22,color:#fff
    style SVF fill:#E67E22,color:#fff
    style AF fill:#E67E22,color:#fff
    style SY fill:#E67E22,color:#fff
    style AP fill:#E67E22,color:#fff
    style HB fill:#E67E22,color:#fff
    style SW fill:#E67E22,color:#fff
    style CE fill:#4A90D9,color:#fff
    style CM fill:#4A90D9,color:#fff
    style CS fill:#4A90D9,color:#fff
    style CRL fill:#4A90D9,color:#fff
    style CCT fill:#4A90D9,color:#fff
    style CJ fill:#4A90D9,color:#fff
    style CZ fill:#4A90D9,color:#fff
    style CPW fill:#4A90D9,color:#fff
    style CA fill:#4A90D9,color:#fff
    style CT fill:#4A90D9,color:#fff
    style CH fill:#4A90D9,color:#fff
    style CD fill:#4A90D9,color:#fff
    style CT2 fill:#4A90D9,color:#fff
    style CC fill:#4A90D9,color:#fff
    style CNS fill:#E74C3C,color:#fff
    style CH1 fill:#F1C40F,color:#000
    style CH2 fill:#F1C40F,color:#000
    style CH3 fill:#F1C40F,color:#000
```

---

## 2. Building → Unit Production Tree (Resistance)

```mermaid
graph TD
    subgraph Production Buildings
        BR2[Barracks]
        AVF2[Assault Vehicle Factory]
        SVF2[Special Vehicle Factory]
        AF2[Avia Factory]
        SY2[Shipyard]
        AP2[Airport]
        HB2[Hero Building]
        SW2[Superweapon Building]
    end

    subgraph Resistance Infantry
        RS[Saboteur]
        RF[Flamethrower]
        RP[Partisan]
        RGL[Grenade Launcher]
    end

    subgraph Resistance Vehicles
        RT[Tiger]
        RP2[Panther]
        RM[Mammoth]
        RH[Hyena]
    end

    subgraph Resistance Aircraft
        RK[Hawk]
        RC[Condor]
        RV[Vulture]
        RV2[Viking]
    end

    subgraph Resistance Naval
        RW[Whirlwind]
        RP3[Porcupine]
    end

    subgraph Resistance Superweapon
        RCT[Chameleon Tower]
    end

    subgraph Resistance Heroes
        RH1[T1 Hero]
        RH2[T2 Hero]
        RH3[T3 Hero]
    end

    BR2 -->|produces| RS
    BR2 -->|produces| RF
    BR2 -->|produces| RP
    BR2 -->|produces| RGL
    AVF2 -->|produces| RT
    AVF2 -->|produces| RP2
    SVF2 -->|produces| RM
    SVF2 -->|produces| RH
    AF2 -->|produces| RK
    AF2 -->|produces| RC
    AF2 -->|produces| RV
    AF2 -->|produces| RV2
    SY2 -->|produces| RW
    SY2 -->|produces| RP3
    SW2 -->|produces| RCT
    HB2 -->|produces| RH1
    HB2 -->|produces| RH2
    HB2 -->|produces| RH3

    AP2 -.->|enables| RV
    AP2 -.->|enables| RV2
    RH1 -->|upgrades| RH2
    RH2 -->|upgrades| RH3

    style BR2 fill:#E67E22,color:#fff
    style AVF2 fill:#E67E22,color:#fff
    style SVF2 fill:#E67E22,color:#fff
    style AF2 fill:#E67E22,color:#fff
    style SY2 fill:#E67E22,color:#fff
    style AP2 fill:#E67E22,color:#fff
    style HB2 fill:#E67E22,color:#fff
    style SW2 fill:#E67E22,color:#fff
    style RS fill:#4A90D9,color:#fff
    style RF fill:#4A90D9,color:#fff
    style RP fill:#4A90D9,color:#fff
    style RGL fill:#4A90D9,color:#fff
    style RT fill:#4A90D9,color:#fff
    style RP2 fill:#4A90D9,color:#fff
    style RM fill:#4A90D9,color:#fff
    style RH fill:#4A90D9,color:#fff
    style RK fill:#4A90D9,color:#fff
    style RC fill:#4A90D9,color:#fff
    style RV fill:#4A90D9,color:#fff
    style RV2 fill:#4A90D9,color:#fff
    style RW fill:#4A90D9,color:#fff
    style RP3 fill:#4A90D9,color:#fff
    style RCT fill:#E74C3C,color:#fff
    style RH1 fill:#F1C40F,color:#000
    style RH2 fill:#F1C40F,color:#000
    style RH3 fill:#F1C40F,color:#000
```

---

## 3. System Dependency Graph

```mermaid
graph TD
    subgraph Core Systems
        BS[Battle System]
        NS[Network System]
        AIS[AI System]
        ES[Economy System]
        US[Unit System]
        BLS[Building System]
        CS[Combat System]
        PS[Pathfinding System]
        FOW[Fog of War System]
    end

    subgraph Supporting Systems
        UPS[Upgrade System]
        MS[Mission System]
        AUS[Audio System]
        GUS[GUI System]
        ASS[Asset System]
        PES[Persistence System]
        ANS[Analytics System]
        ADS[Ad System]
        BIS[Billing System]
    end

    BS -->|depends_on| US
    BS -->|depends_on| BLS
    BS -->|depends_on| CS
    BS -->|depends_on| ES
    BS -->|depends_on| PS
    BS -->|depends_on| FOW
    BS -->|depends_on| NS
    BS -->|depends_on| AIS

    CS -->|depends_on| US
    CS -->|depends_on| BLS
    CS -->|depends_on| UPS

    US -->|depends_on| PS
    US -->|depends_on| ES
    US -->|depends_on| UPS
    US -->|depends_on| BLS

    BLS -->|depends_on| ES
    BLS -->|depends_on| UPS

    AIS -->|controls| US
    AIS -->|controls| BLS
    AIS -->|depends_on| ES
    AIS -->|uses| CS

    NS -->|updates| BS
    NS -->|updates| CS
    NS -->|updates| US

    MS -->|depends_on| BS
    MS -->|depends_on| AIS

    GUS -->|depends_on| BS
    GUS -->|references| ES
    GUS -->|references| UPS

    AUS -->|depends_on| BS
    ASS -->|depends_on| BS
    PES -->|references| BS
    ANS -->|references| BS
    ADS -->|references| ES
    BIS -->|references| ES

    style BS fill:#2ECC71,color:#fff
    style NS fill:#2ECC71,color:#fff
    style AIS fill:#2ECC71,color:#fff
    style ES fill:#2ECC71,color:#fff
    style US fill:#2ECC71,color:#fff
    style BLS fill:#2ECC71,color:#fff
    style CS fill:#2ECC71,color:#fff
    style PS fill:#2ECC71,color:#fff
    style FOW fill:#2ECC71,color:#fff
    style UPS fill:#82E0AA,color:#000
    style MS fill:#82E0AA,color:#000
    style AUS fill:#82E0AA,color:#000
    style GUS fill:#82E0AA,color:#000
    style ASS fill:#82E0AA,color:#000
    style PES fill:#82E0AA,color:#000
    style ANS fill:#82E0AA,color:#000
    style ADS fill:#82E0AA,color:#000
    style BIS fill:#82E0AA,color:#000
```

---

## 4. Class Architecture Diagram

```mermaid
graph TD
    subgraph Core Classes
        SM[StartupManager]
        BS2[BattleScreen]
        LS[LogicService]
        BG[BattleGUI]
        NP[NetworkProvider]
        RSH[ResourceServiceHelper]
    end

    subgraph UI Classes
        GBLU[GUIBattleListUpgrade]
    end

    subgraph Network Messages
        CLTB[CSLoginToBattle]
    end

    subgraph Debug
        DI[DebugInstaller]
    end

    SM -->|creates| NP
    SM -->|creates| RSH
    SM -->|uses| DI
    SM -->|initializes| ASS2[Asset System]
    SM -->|initializes| AUS2[Audio System]

    BS2 -->|uses| LS
    BS2 -->|owns| BG
    BS2 -->|uses| NP
    BS2 -->|uses| RSH
    BS2 -->|implements| BST[Battle System]

    LS -->|implements| CST[Combat System]
    LS -->|updates| UST[Unit System]
    LS -->|updates| BLST[Building System]
    LS -->|updates| EST[Economy System]
    LS -->|uses| PST[Pathfinding System]

    BG -->|owns| GBLU
    BG -->|implements| GUST[GUI System]
    BG -->|references| LS

    NP -->|implements| NST[Network System]
    NP -->|uses| MSVC[Main Server]
    NP -->|uses| BSVR[Battle Server]
    NP -->|uses| CSVR[Chat Server]
    NP -->|uses| CMDP[Command Processing]
    NP -->|uses| STRP[State Replication]
    NP -->|uses| DSYN[Desync Detection]
    NP -->|uses| RCON[Reconnection]

    GBLU -->|references| UPST[Upgrade System]
    GBLU -->|references| EST

    CLTB -->|uses| NP
    CLTB -->|references| MMTCH[Matchmaking]
    CLTB -->|references| MSVC

    DI -->|references| BS2
    DI -->|references| LS

    style SM fill:#9B59B6,color:#fff
    style BS2 fill:#9B59B6,color:#fff
    style LS fill:#9B59B6,color:#fff
    style BG fill:#9B59B6,color:#fff
    style NP fill:#9B59B6,color:#fff
    style RSH fill:#9B59B6,color:#fff
    style GBLU fill:#9B59B6,color:#fff
    style CLTB fill:#9B59B6,color:#fff
    style DI fill:#9B59B6,color:#fff
    style BST fill:#2ECC71,color:#fff
    style CST fill:#2ECC71,color:#fff
    style UST fill:#2ECC71,color:#fff
    style BLST fill:#2ECC71,color:#fff
    style EST fill:#2ECC71,color:#fff
    style PST fill:#2ECC71,color:#fff
    style GUST fill:#2ECC71,color:#fff
    style NST fill:#2ECC71,color:#fff
    style UPST fill:#2ECC71,color:#fff
    style ASS2 fill:#2ECC71,color:#fff
    style AUS2 fill:#2ECC71,color:#fff
    style MSVC fill:#3498DB,color:#fff
    style BSVR fill:#3498DB,color:#fff
    style CSVR fill:#3498DB,color:#fff
    style CMDP fill:#3498DB,color:#fff
    style STRP fill:#3498DB,color:#fff
    style DSYN fill:#3498DB,color:#fff
    style RCON fill:#3498DB,color:#fff
    style MMTCH fill:#3498DB,color:#fff
```

---

## 5. Network Architecture

```mermaid
graph TD
    subgraph Client
        NP2[NetworkProvider]
        CLTB2[CSLoginToBattle]
    end

    subgraph Server Infrastructure
        MS2[Main Server Connection]
        BS3[Battle Server Connection]
        CS2[Chat Server]
    end

    subgraph Matchmaking
        MM2[Matchmaking]
    end

    subgraph Battle Sync
        CP2[Command Processing]
        SR2[State Replication]
        DD2[Desync Detection]
        RC2[Reconnection]
    end

    NP2 -->|TCP| MS2
    NP2 -->|UDP| BS3
    NP2 -->|WebSocket| CS2

    MS2 -->|initiates| MM2
    MM2 -->|creates room| BS3

    BS3 -->|uses| CP2
    BS3 -->|uses| SR2
    BS3 -->|uses| DD2
    BS3 -->|uses| RC2

    SR2 -->|feeds| DD2

    CLTB2 -->|sends via| MS2
    CLTB2 -->|references| MM2

    style NP2 fill:#9B59B6,color:#fff
    style CLTB2 fill:#9B59B6,color:#fff
    style MS2 fill:#3498DB,color:#fff
    style BS3 fill:#3498DB,color:#fff
    style CS2 fill:#3498DB,color:#fff
    style MM2 fill:#3498DB,color:#fff
    style CP2 fill:#3498DB,color:#fff
    style SR2 fill:#3498DB,color:#fff
    style DD2 fill:#3498DB,color:#fff
    style RC2 fill:#3498DB,color:#fff
```

---

## 6. Campaign & Map Associations

```mermaid
graph TD
    subgraph Campaigns
        CC2[Confederation Campaign<br/>~50 Missions]
        RC2[Resistance Campaign<br/>~50 Missions]
    end

    subgraph Maps
        DB[Dustbowl<br/>Small / Desert / 2P]
        FF[Frozen Frontier<br/>Medium / Arctic / 2P]
        CA2[Coastal Assault<br/>Medium / Coastal / 4P]
        IV[Iron Valley<br/>Medium / Mountain / 2P]
        JW[Jungle Warfare<br/>Large / Tropical / 4P]
        UD[Urban Decay<br/>Medium / Urban / 2P]
        AR[Archipelago<br/>Large / Island / 6P]
        NML[No Man's Land<br/>XL / Wasteland / 8P]
    end

    CC2 -->|uses| DB
    CC2 -->|uses| FF
    CC2 -->|uses| CA2
    CC2 -->|uses| IV
    CC2 -->|uses| UD

    RC2 -->|uses| JW
    RC2 -->|uses| AR
    RC2 -->|uses| FF
    RC2 -->|uses| CA2
    RC2 -->|uses| NML

    NML -.->|multiplayer| AR
    CA2 -.->|multiplayer| JW

    style CC2 fill:#E74C3C,color:#fff
    style RC2 fill:#E74C3C,color:#fff
    style DB fill:#1ABC9C,color:#fff
    style FF fill:#1ABC9C,color:#fff
    style CA2 fill:#1ABC9C,color:#fff
    style IV fill:#1ABC9C,color:#fff
    style JW fill:#1ABC9C,color:#fff
    style UD fill:#1ABC9C,color:#fff
    style AR fill:#1ABC9C,color:#fff
    style NML fill:#1ABC9C,color:#fff
```

---

## 7. Cross-Faction Combat Interactions

```mermaid
graph LR
    subgraph Confederation Units
        CCT2[Coil Tank]
        CZ2[Zeus]
        CT3[Thunderbird]
        CH2[Hornet]
        CD2[Delta]
        CT4[Triton]
        CC3[Cruiser]
    end

    subgraph Resistance Units
        RT2[Tiger]
        RM2[Mammoth]
        RC2[Condor]
        RV2[Vulture]
        RV3[Viking]
        RW2[Whirlwind]
        RP2[Porcupine]
    end

    CCT2 -->|attacks| RT2
    CZ2 -->|EMP attacks| RM2
    CT3 -->|attacks| RT2
    CH2 -->|air-to-air| RV2
    CD2 -->|stealth bombs| RP2
    CT4 -->|torpedoes| RW2
    CC3 -->|engages| RP2

    RT2 -->|attacks| CCT2
    RM2 -->|dominates| CCT2
    RC2 -->|rockets| CCT2
    RV2 -->|air-to-air| CH2
    RV3 -->|carpet bombs| CC3

    style CCT2 fill:#4A90D9,color:#fff
    style CZ2 fill:#4A90D9,color:#fff
    style CT3 fill:#4A90D9,color:#fff
    style CH2 fill:#4A90D9,color:#fff
    style CD2 fill:#4A90D9,color:#fff
    style CT4 fill:#4A90D9,color:#fff
    style CC3 fill:#4A90D9,color:#fff
    style RT2 fill:#E67E22,color:#fff
    style RM2 fill:#E67E22,color:#fff
    style RC2 fill:#E67E22,color:#fff
    style RV2 fill:#E67E22,color:#fff
    style RV3 fill:#E67E22,color:#fff
    style RW2 fill:#E67E22,color:#fff
    style RP2 fill:#E67E22,color:#fff
```

---

## 8. Defense Building → Aircraft Interactions

```mermaid
graph TD
    subgraph Anti-Air Defenses
        AAC[Anti-Air Center]
        AAT[Anti-Air Tower]
    end

    subgraph Enemy Aircraft - Confederation
        CH3[Hornet]
        CD3[Delta]
    end

    subgraph Enemy Aircraft - Resistance
        RV4[Vulture]
        RV5[Viking]
    end

    AAC -->|engages| CH3
    AAC -->|engages| RV4
    AAT -->|engages| CD3
    AAT -->|engages| RV5

    AAT -->|upgraded from| AAC

    style AAC fill:#E67E22,color:#fff
    style AAT fill:#E67E22,color:#fff
    style CH3 fill:#4A90D9,color:#fff
    style CD3 fill:#4A90D9,color:#fff
    style RV4 fill:#4A90D9,color:#fff
    style RV5 fill:#4A90D9,color:#fff
```

---

## Statistics

| Category | Count |
|----------|-------|
| Confederation Units | 15 |
| Resistance Units | 15 |
| Hero Units | 6 |
| Buildings | 14 |
| Systems | 17 |
| Classes | 9 |
| Campaigns | 2 |
| Maps | 8 |
| Network Components | 7 |
| **Total Nodes** | **93+** |
| **Total Edges** | **224+** |
