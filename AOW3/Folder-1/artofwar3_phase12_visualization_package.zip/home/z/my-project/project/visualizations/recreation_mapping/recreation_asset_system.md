# Recreation Mapping: Resource/Asset System

## Purpose

The Resource/Asset System manages the loading, caching, and lifecycle of all game assets in Art of War 3: Global Conflict, including 3D models, textures, audio clips, animations, particle effects, shaders, and UI elements across 773 catalog entries in 23 asset bundles. Built on Unity's Addressables framework, the system handles asynchronous asset loading with dependency resolution, memory management via reference counting and LRU cache eviction, asset bundle downloading and versioning for live-updates, and runtime asset instantiation. The system is critical for performance on mobile devices where memory is constrained — efficient asset loading and unloading directly impacts frame rate and load times. It must also support the game's dual-faction structure where many assets are faction-specific (unit models, building models) while others are shared (terrain, effects).

## Inputs

- **Game Systems**: Asset load requests (unit model, building model, VFX, audio, UI prefab)
- **Addressable Catalog**: Asset keys, bundle assignments, dependency graph
- **Memory Budget**: Available memory for asset caching
- **Network**: Remote bundle download for content updates

## Outputs

- **Loaded Assets**: Instantiated prefabs, loaded textures, audio clips ready for use
- **Cache State**: Currently cached assets with reference counts
- **Memory Usage**: Current asset memory consumption for monitoring
- **Load Progress**: Async operation progress for loading screens

## Dependencies

- **All Visual Systems**: Unit rendering, building rendering, VFX, UI
- **Audio System**: For audio clip loading
- **GUI System**: For UI prefab instantiation
- **Network System**: For bundle download progress

## Internal Logic

The system wraps Unity's Addressables API with a custom `AssetManager` that adds reference counting, priority-based loading, and memory budget enforcement. When a system requests an asset, the `AssetManager` checks: (1) Is the asset already loaded and cached? If yes, increment reference count and return immediately. (2) Is the asset in a downloaded bundle? If not, trigger bundle download with progress callback. (3) Load the asset asynchronously, track the operation, and notify the requester on completion.

Reference counting ensures assets are only unloaded when no system holds a reference. When an asset's reference count drops to zero, it enters an LRU eviction pool. The system periodically checks memory usage against the budget and evicts the least-recently-used unreferenced assets until memory is within budget.

Asset bundles are organized by update frequency and size: `core` (always needed, loaded at startup), `faction_confederation`, `faction_resistance` (loaded based on player faction), `maps` (loaded per-map), `audio_common`, `audio_vo` (voice-overs, loaded on demand), `vfx`, and `ui`. This organization enables incremental downloads and selective loading.

The system also implements asset preloading: before a match starts, all assets required for the selected map and factions are preloaded during the loading screen. This prevents mid-game stuttering from on-demand loading. Critical assets (unit models, terrain textures) are loaded at high priority, while cosmetic assets (decorative VFX) load at low priority.

## Pseudocode

```
class AssetSystem:
    addressableCatalog: AssetCatalog  // 773 entries, 23 bundles
    loadedAssets: Map<AssetKey, LoadedAsset>
    lruPool: LRUCache<AssetKey, LoadedAsset>
    memoryBudget: long  // Max bytes for cached assets
    currentMemoryUsage: long
    activeOperations: Map<OperationID, AsyncLoadOperation>

    function loadAsset<T>(assetKey, priority=NORMAL, onComplete=null) -> AsyncHandle<T>:
        // Check cache first
        if loadedAssets.contains(assetKey):
            asset = loadedAssets[assetKey]
            asset.refCount++
            asset.lastAccessTime = time.now
            if onComplete:
                onComplete(asset.value)
            return AsyncHandle.completed(asset.value)

        // Check if bundle is downloaded
        bundleName = addressableCatalog.getBundleName(assetKey)
        if not bundleManager.isDownloaded(bundleName):
            downloadBundle(bundleName, priority)  // May trigger download

        // Start async load
        operation = Addressables.LoadAssetAsync<T>(assetKey)
        operation.priority = priority
        operation.onComplete += (result) => {
            loadedAsset = LoadedAsset(
                key = assetKey,
                value = result,
                refCount = 1,
                lastAccessTime = time.now,
                size = estimateMemorySize(result)
            )
            loadedAssets[assetKey] = loadedAsset
            currentMemoryUsage += loadedAsset.size
            enforceMemoryBudget()
            if onComplete:
                onComplete(result)
        }
        activeOperations[operation.id] = operation
        return AsyncHandle(operation)

    function releaseAsset(assetKey):
        if not loadedAssets.contains(assetKey):
            return
        asset = loadedAssets[assetKey]
        asset.refCount--
        if asset.refCount <= 0:
            // Move to LRU pool instead of immediate unload
            lruPool.put(assetKey, asset)
            loadedAssets.remove(assetKey)

    function enforceMemoryBudget():
        while currentMemoryUsage > memoryBudget and not lruPool.isEmpty():
            // Evict least recently used unreferenced asset
            evicted = lruPool.evictOldest()
            Addressables.Release(evicted.value)
            currentMemoryUsage -= evicted.size

    function preloadForMatch(mapId, factionA, factionB):
        requiredAssets = []
        // Map assets
        requiredAssets += addressableCatalog.getMapAssets(mapId)
        // Faction assets
        requiredAssets += addressableCatalog.getFactionAssets(factionA)
        requiredAssets += addressableCatalog.getFactionAssets(factionB)
        // Common assets
        requiredAssets += addressableCatalog.getCommonAssets()
        // Load all with progress tracking
        totalAssets = requiredAssets.size
        for i, assetKey in requiredAssets:
            loadAsset(assetKey, priority=HIGH)
            loadingScreen.setProgress(i / totalAssets)

class AssetCatalog:
    entries: Map<AssetKey, CatalogEntry>  // 773 entries
    bundles: Map<BundleName, BundleInfo>   // 23 bundles

    function getBundleName(assetKey) -> BundleName:
        return entries[assetKey].bundleName

    function getMapAssets(mapId) -> List<AssetKey>:
        return entries.where(e => e.mapId == mapId).map(e => e.key)

    function getFactionAssets(faction) -> List<AssetKey>:
        return entries.where(e => e.faction == faction).map(e => e.key)
```

## Modern Implementation Recommendations

| Approach | Recommendation |
|----------|---------------|
| **Best Overall** | **Unity 2023 + Addressables** — Already the gold standard for Unity asset management. Use Addressables with Content Update Workflow for live-updates. `AssetBundleProvider` for custom loading. |
| **Alternative Engine** | **Godot 4 + ResourceLoader** — Godot's `.tres`/`.res` resource system handles loading. Use `ResourceLoader.load_threaded()` for async. `ResourceCache` for manual caching. |
| **Custom Engine** | **Rust + Bevy + bevy_asset** — Bevy's asset system handles async loading and dependencies. `Assets<T>` resource for access. Custom `AssetLoader` implementations for custom formats. |
| **Maximum Control** | **Custom C++ asset pipeline** — Build a custom asset cooker that converts source assets to optimized binary formats. Memory-map files for zero-copy loading. Custom reference counting. Full control over memory layout. |

**Key patterns to adopt:**
- Reference counting with LRU eviction — don't unload immediately on zero refs
- Async loading with priority levels — critical assets first, cosmetic last
- Bundle organization by update frequency — enables incremental updates
- Preloading before gameplay — avoid mid-game loading hitches
- Memory budget enforcement — critical for mobile platforms
- Asset key indirection — use string keys, not direct references, for hot-patching
- Dependency-aware loading — if asset A depends on asset B, load B first
